# NpcVoice: 50 proposals for new interactions

**The line**: everything sexual here happens between adults who want it, because of who they are (attraction,
openness, money, curiosity, a kink they have). Nobody is pushed into sex by a gun, a threat, being tied up,
being your captive, or being too drunk to know. Kink and dominance are in, as play two willing adults agree on,
and either can stop it. Undressing someone who didn't agree is never a way into sex: they react like a real
person (outrage, shame, covering up, running, the law).

Each entry: **what happens** · what it needs (✅ already exists · 🔧 new work) · effort 1–10.

## A. Romance, sex and desire (consensual)
1. **The cuckold couple** – A husband with that fantasy offers his wife; she's in on it and wants it. A trip to their
   home (real house from the database), both talk the way that couple would, he watches. Either can call it off.
   ✅ trips to a person, ✅ memory · 🔧 a couple scene with both voices, 🔧 undress action · 6
2. **She takes her own clothes off** – An NPC who wants to undresses herself, piece by piece, with lines about it, and
   gets dressed again after. Uses the Unstrip recipe read from the binary. 🔧 undress/dress action · 5
3. **She knows you undressed her** – If you strip someone with the Unstrip prompt, NpcVoice notices. If she'd agreed
   to it: playful or nervous. If not: outrage, covering up, slapping, running, telling the law, and a grudge.
   🔧 clothing-state check (category walk) · 4
4. **Dressing again** – "Put your clothes back on" works, and they do it themselves after a while if nobody says
   anything. 🔧 dress action (the saved outfit, like Unstrip does) · 3
5. **Paid company** – Working girls/boys name a price, take your real money, and take you upstairs (a real
   brothel/hotel room door from the database). ✅ take_money, ✅ places · 🔧 'go upstairs together' routine · 5
6. **Courting** – Several meetings over days: flowers, a walk, a dance at the saloon; attraction grows in memory; the
   first kiss only comes when it's earned. ✅ memory/feelings · 🔧 'date' activities · 4
7. **Jealous spouse** – A married woman flirts with you; her husband hears from gossip (✅ rumours) and comes looking
   for you. 🔧 director scene 'jealous husband' · 4
8. **Consensual dominance play** – An adult who's into it asks you to boss her around (or wants to boss you). There's a
   word that ends it (she picks it), and she uses it if she wants. No real violence, no restraints from the game's
   hogtie. 🔧 a 'play' mode with a stop word · 5
9. **The voyeur couple** – A couple who like being watched invite you to sit in the corner; they talk to you while
   they're at it. 🔧 couple scene (NpcHookups) + invite · 6
10. **Threesome by mutual interest** – Two people who are both into you (and into each other) agree on it between
    themselves first, out loud. 🔧 two-partner scene · 7
11. **Morning after** – Next time you meet someone you slept with, they remember: shy, clingy, regretful, or wanting
    more, and others may have heard. ✅ memory, ✅ rumours · 🔧 'intimate' event type · 2
12. **Skinny dipping** – At a river or lake, someone you're close with suggests a swim; both undress, swim, dress
    again. 🔧 undress + swim scenario · 6
13. **Bath house** – At a hotel bath, the attendant or another guest chats with you, flirts if they're into it.
    ✅ places (bath/hotel) · 🔧 bath scenarios · 5

## B. NPC couples living their own lives (with NpcHookups when you send it)
14. **Couples at home** – Some houses with a bed (real doors/beds from the database) have a couple being intimate when
    you arrive, already undressed, changing positions now and then, talking softly to each other.
    🔧 NpcHookups integration · 7
15. **Caught in the act** – Walk in in front of them: they stop, scream, cover up, curse you, maybe grab a gun. Crouched,
    out of sight, they don't notice and carry on. 🔧 line-of-sight check + reactions · 5
16. **After** – They dress, the wife stays home (sweeps, cooks), the husband goes to work (a real store/mine/farm) and
    comes home at night or brings the kids. 🔧 daily routines (see 41) · 8
17. **Old shack, sheet on the floor** – Poor folk in a run-down shack make do with a blanket on the ground.
    ✅ shacks in the database · 🔧 ground-bed scenario choice · 3
18. **They remember** – Ask the husband tomorrow; he knows if they made love, if someone barged in, what they said.
    ✅ memory · 🔧 the scene writes to both memories · 3
19. **Affair** – The wife's lover sneaks in while the husband is at work; if the husband comes home early, there's a
    fight. 🔧 schedules + director scene · 8

## C. Trips and things that really happen on the map
20. **"Leave me alone and I'll show you where the money is"** – A real stash at a real ruin/mill/cave from the database.
    ✅ stash + ✅ real places · 1
21. **His family at their real farmhouse** – Family at the door/yard of an actual farmhouse instead of a random camp.
    ✅ done in this round · 0
22. **Revenge errand** – "The man who killed my brother drinks at the Valentine saloon": a trip there; he's spawned
    inside and knows he's wanted. ✅ trips to a person · 🔧 hostile target role · 4
23. **Debt collection** – Collect a debt from someone at a real house; they plead, pay, or pull a gun. 🔧 · 4
24. **Deliver a letter / a package** – An errand to a real store or house; they pay you on delivery. 🔧 · 3
25. **Escort** – Ride someone to the train station (real station coordinates); bandits may show up. 🔧 · 5
26. **Doctor run** – Someone wounded asks you to take them to the doctor (real doctor's office in town). 🔧 · 4
27. **Wedding** – Two NPCs you helped get married at the church (Saint Denis has real church coordinates). 🔧 · 7

## D. Fights, crime, the law
28. **Bar fight on request** – "Go punch that loudmouth": ✅ attack_person · 0
29. **Hired muscle** – Pay a tough to rough someone up, or to watch your back on a ride. 🔧 · 4
30. **Robbery partner** – An outlaw NPC proposes a stagecoach job; plan, ride, do it, split the cash. 🔧 · 8
31. **Witness intimidation** – A witness to your crime can be paid off, talked down, or will run to the law
    (✅ report_to_law). 🔧 bribe outcome · 3
32. **Bounty on you** – Lawmen across the state know your face after an arrest (✅ rumours, ✅ crime report). 🔧 · 4
33. **Jail visit** – Talk to someone in a real jail cell (jail coordinates in the database). 🔧 · 5

## E. Everyday life and activities
34. **Have a drink together** – Sit at a real saloon table and drink, both of you. ✅ activities, ✅ use_spot · 1
35. **Card game** – Join NPCs at a table; they talk trash, cheat sometimes. 🔧 card scenarios · 6
36. **Campfire evening** – Followers sit at a campfire, tell stories, play guitar, sing. ✅ activities · 🔧 scene · 3
37. **Cooking and eating** – "Make us some stew": they cook at a fire and share. ✅ activities · 2
38. **Shopping** – "Buy me a dress": you go to a real tailor/store, pay, and they wear it (outfit change). 🔧 · 6
39. **Haircut / shave** – At the barber, a chatty barber who knows town gossip. 🔧 · 3
40. **Dance at the saloon** – Ask someone to dance; both dance; others watch. ✅ dance emotes · 🔧 pair dance · 4

## F. Memory, awareness and daily life ("they know everything")
41. **Daily schedules** – Every person you've met has a day: wake, work at a real place, eat, saloon, home, sleep. If
    you look for them at 3 pm they're at work; at night they're home. 🔧 schedule engine + real places · 8
42. **Day journal** – Every person keeps a log of their day (where they went, who they talked to, what they did:
    worked, drank, made love, fought, saw a body) and uses it when you talk. ✅ events/summaries · 🔧 schedule log · 5
43. **Senses** – They remember what they saw (line of sight), heard (gunshots within range), and felt (hurt, cold,
    drunk) with times. ✅ partly · 🔧 per-person perception log · 6
44. **Couples share memories** – A wife knows what her husband told her at dinner about you. 🔧 · 4
45. **Grudges and gratitude across the map** – People you wronged or helped tell their friends; strangers react
    accordingly. ✅ rumours · 🔧 social graph · 5

## G. Smaller touches
46. **Ask them to wait for you** at a real place ("wait for me at the hotel") and they're there later. 🔧 · 4
47. **Gifts** – Give someone a real item (whisky bottle prop, flowers); they remember it. 🔧 · 4
48. **Photos** – Take their picture at the photo studio together. 🔧 · 5
49. **Children of couples you know** – Kids ask about their ma and pa, run errands, play (child rules unchanged:
    nothing romantic, ever). 🔧 · 4
50. **Weather and time talk** – They complain about the rain that's actually falling and the late hour. ✅ partly · 1

## Built in 0.5.1
- 1 (the couple, both voices): a couple who invite you home (invite_home) lead the way on their own horse to a real
  house and wait at the door; the partner who wants to watch says so himself (agree_to_watch); while it runs both of
  them talk, each with their own voice. Either can stop it.
- 9 / 10 (voyeur couple, three people): both partners in the scene, or the scene with you while the partner watches.
- 14 / 17 / 18 (couples at home, in a real bed, remembered): real house/shack/cabin, real bed found by the plugin,
  NpcVoice runs the clip pair itself (no NpcHookups needed), murmured lines, both remember it.
- 15 (caught in the act): walk in standing up in their sight -> scream, cover up, dress, a brave man grabs a gun.
  Crouched and out of sight: they carry on.

## What I won't build
- Sex with anyone who is tied up, lassoed, at gunpoint, threatened, your captive, scared of you, or too drunk to know.
- "She'll obey all your orders" as a way to get sex: the people who come with a trip keep their own will.
- Using the strip mod on someone as a way to start sex without their yes.
- Anything sexual involving children or child models (the existing child rules stay).
