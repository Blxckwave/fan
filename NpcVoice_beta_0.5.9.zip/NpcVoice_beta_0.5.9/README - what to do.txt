NpcVoice  beta 0.5.9 -  talk to anyone in RDR2 with your voice
================================================================

UPDATING FROM AN OLDER VERSION   
- Close RDR2 COMPLETELY first (also check Task Manager: no RDR2.exe left). Windows keeps the old
  NpcVoice.asi loaded while the game runs, so copying over it silently does nothing.
- Copy the new NpcVoice.asi + NpcVoice.ini next to RDR2.exe (overwrite), and use the NEW "NpcVoice brain"
  folder (close the old black window, run run_npc_brain.bat from the new folder).
- In game the green message must say:  brain 0.5.9-beta connected (plugin 0.5.9-beta)
  The first line of NpcVoice.log must say: NpcVoice.asi 0.5.9-beta loaded
  If the two don't match you get a red VERSION MISMATCH message.

HOUSEHOLDS (new - copy the NEW NpcVoice.asi too, the brain alone can't do the furniture and the positions)
- EVERY home on the map (the ~94 lived-in houses, shacks, cabins and farmhouses the mod knows - 6 in Lakay alone) has
  its own couple, the same two people every time you come back, locals of the area (bayou folk in Lakay/Lagras,
  Valentine folk around Valentine...), married or courting for years, each couple with their own way together and
  their own fantasies. They remember you.
- THEIR DAY, 18-40 things each, different for every house and every day: waking up, washing, coffee, breakfast cooked
  at their stove and eaten at their own table, chores (chickens, pigs, water pump, firewood, sawing, mending, hay /
  sweeping, laundry on the washboard, dishes, windows, sewing, knitting, letters), lunch, a rest, supper, dishes, an
  evening on the porch (music, a drink, a smoke), getting close as it gets dark. Some husbands work away all day,
  some go to church on Sunday, some have a lazy afternoon or a morning in bed.
- THEIR NIGHT, from dark to dawn, in their own bed: in sessions, changing position every minute or two (the game has
  one clip pair, so a "position" = who leads + how they lie on the bed - data/love_poses.json, add an animation pack's
  clips there if you have one), catching their breath in between, talking all the time - sweet talk, teasing, their
  fantasies told as stories, memories - in their own voices. Then they sleep until morning.
- With the new NpcVoice.asi they use their REAL furniture (the house's own chairs, stove, beds, porch). With the old one
  they do everything in place and keep one position all night.
- Stand in the doorway in sight and they stop, cover up and are furious (crouch out of sight and they don't notice). A
  gun, a lasso, a fight, fear of you: it stops at once and not again that night.
- Only homes within 70 m of you are "lived" (at most 2 at once), the rest of the map goes on without you.
  Settings: [households] in NpcVoice_brain.ini (households = 0 = off; chat/love-talk distances and how often).
  Each spoken line is one AI voice call - talk is only generated while you're close enough to hear it.

WHAT'S NEW IN 0.5.9  (people DO what you ask - copy BOTH the new NpcVoice.asi AND the new brain folder)
- WHY "GO TO SLEEP" DID NOTHING: the brain guessed from words ("sleep" -> scenarios with SLEEP in the name). "Go to
  bed" was even read as a sex request, "shut-eye" / "hit the hay" / "pass out" matched nothing, a woman could waste all
  her tries on scenarios that only exist for men (169 of them), and the AI never knew what was really possible.
- NOW THE AI GETS A MENU. Ask someone to do something and they're shown the real ways to do it right there, e.g.
     [A1] sleep in the bed - on a bed 4 m away   [A2] sleep on the ground, head on your arm   [A3] sit and doze off
  with what we already know about each ("worked before", "didn't play last time"). The AI picks one; it happens.
- EVERYTHING THE GAME HAS: a catalog of 361 activities (all the human scenarios, plus the 31 extra names from the
  scenario list you sent) and 118 gestures, each described in plain words, with the posture, what it needs (a bed, a
  chair, the bar...), which sexes can do it, and the game's own male/female versions. Many more ways of saying
  things are understood (sleep, nap, doze, shut-eye, hit the hay, turn in, go to bed, lie down, pass out...).
- THE ROOM: everyone you talk to knows the real furniture around them (beds, chairs at the table, benches, the bar, a
  fire, the wash basin) and can walk over and use it: "lie down on that bed" really means that bed.
- IT REALLY HAPPENS, OR THEY SAY SO: each option is tried for real and checked: the real spot -> the activity in their
  own (male/female) version -> if the game refuses, that version's own animation loop played directly -> the next
  option -> a quick gesture. The AI is told exactly what happened, so nobody says "I'm asleep" standing up.
- ASLEEP STAYS ASLEEP: tell someone to sleep and walk away - they keep sleeping (sitting by the fire keeps sitting).
  They wake up when they're hurt, a gun is pointed at them or a shot goes off close by - and react to THAT. Talk to a
  sleeper and they wake up groggy, knowing they were asleep.
- IT LEARNS AND KEEPS IT: what works and what doesn't is remembered per sex AND per kind of person, in your own
  folder (Documents\NpcVoice\learned_activities.json) - installing a new version no longer wipes it.
- CALIBRATE ONCE (optional, recommended): in the black brain window type   calibrate   (or e.g.  calibrate sleep )
  somewhere quiet in the open. A man and a woman appear in front of you and try every activity; everything that plays
  is saved, so from then on people pick what works on the first try. Report: Documents\NpcVoice\calibration_report.txt.
  calibrate stop  ends it. (Everything takes a while - ~10 s per activity per person.)

WHAT WAS NEW IN 0.5.8  (from your report after 0.5.7 - copy BOTH the new NpcVoice.asi AND the new brain folder)
- WHY NPCHOOKUPS WORKS AND NPCVOICE'S "COPY" DIDN'T: I took NpcHookups.asi apart again (your file, same build). Its
  clips do NOT place two bodies by themselves. NpcHookups lays the lower partner down, plays his clip IN PLACE, turns
  off collision and ragdoll, and then ATTACHES the upper partner to his hip bone, using the original scene's numbers
  for each position. It also checks every second that they're still attached and haven't sunk into the floor.
  NpcVoice 0.5.1-0.5.7 just played the two clips side by side at one point, so both stood up and it looked "weird".
  NpcVoice's own scenes (house couples at night, the couple you're sent to, a bed you're on) now do exactly what
  NpcHookups does, with its three positions: cowgirl, missionary, reverse cowgirl. During the night the couple changes
  between them.
- THE HOUSE COUPLE DRESSED, STANDING, NOT NOTICING YOU: three causes, all fixed.
  (1) When the plugin didn't report a bed in time, the night silently never started. They stood where they were
  spawned, and their daytime chat went on with the label "making love in their bed" (the lines you heard). Now the
  night always starts, on a blanket on the floor if there's no bed. If it can't happen at all, they lie down to sleep.
  (2) They were undressed the moment they spawned, before their look had loaded, and the wife's skin-tone matching
  then put outfits back on her. Now the plugin waits until they're really there, undresses them, checks, and retries.
  (3) Walking in was only noticed during the scene. Now a stranger inside their house, in their sight, is noticed day
  or night, and they speak up (who are you, what do you want, or a welcome if they know you). Crouch and stay out of
  sight and they still don't notice. (Setting: intruder_metres in [households].)
- SHOOT ONE OF A COUPLE AND THE OTHER REACTS: everything stops at once. The line in their mouth is cut off, the scene
  and the chat end, and the other one reacts right away by who they are: screams, sobs, begs, curses you, runs, or
  goes for a gun. They never chat calmly again that night and remember it for good. Also when one of them is hurt,
  has your gun on them, is tied up, or shots go off right by the house.
- NOBODY KNOWS WHAT THEY COULDN'T SEE OR HEAR: her husband was far away behind a wall and spoke of her death as if
  he'd watched. Now the plugin checks each person's real line of sight. Saw it (in sight, close enough): they know
  who and who did it. Heard a gunshot (a gun within ~160 m): they're alarmed and fear for her, but don't know who was
  hit and never say anyone is dead. A knife or a bow far away, out of sight: they know nothing until they find her.
- THE STORY ABOUT HER DEAD HUSBAND WHILE HER HUSBAND STOOD NEARBY: every person now gets the hard facts about their
  own people in their prompt ("your husband X is ALIVE and right here - never a story of him dying"; a widow: "one
  story of how he died, always the same"). What they've already told you about their family is fed back to them, so
  the next story matches the last. A widow's companion is no longer made into her husband.
- "I KNOW A PLACE" DOESN'T MOVE YOUR YELLOW LINE ANY MORE: once a trip is on, nobody (begging for her life or not)
  can replace it with a new place. Only you can, by asking for "somewhere else" / "forget that, another place".
- NO MORE COUPLE IN THE SALOON: a couple you're sent to always lives in a real home (house, cabin, farmhouse, shack),
  even when the person talked about the saloon. And nobody starts making love with other people watching (in sight
  within 15 m, or right next to you). They say "not here" and can take you home instead.
- EMOTION IS BACK IN THE VOICES: 0.5.7 turned every feeling word it didn't know into a flat "fluent", and the night
  lines could only be whisper/happy/calm, so it was nearly always "calm". Now the AI writes how a line really sounds
  (terrified, begging, furious, sobbing, tender, playful, passionate, breathless, moaning...). The voice uses the
  matching emotion and pace, or reads the feeling from the words themselves, instead of forcing "calm". The moment
  counts too: a gun on her, just hurt, terrified, furious, or in the middle of making love, and a "calm" line isn't
  said calmly.
- VOICE CLONING IS GONE (you asked): no more cloning of the game's voices, no MiniMax clone fees, no voice_samples
  folder, no scan/clone/slim .bat files, no soundfile. Everyone speaks with a stock AI voice picked for their sex and
  age, the same one for that person every time. Your old voice_clones.json and voice_samples folder (if you had them)
  are simply not used any more - delete them if you like. The plugin no longer sets the game's own voice of a person
  to match a clone.
- Still NOT verified in the real game (no game here, only the simulation rig): the attach on ambient peds (the
  numbers are NpcHookups' own, and if a ped lacks the original bone the pelvis is used, as NpcHookups does). If a
  position floats or sinks on a bed, tell me and send NpcVoice.log ("couple seq=... attached ... bone ...").

WHAT WAS NEW IN 0.5.7  (from your 00:02-00:51 logs - copy BOTH the new NpcVoice.asi AND the new brain folder)
- "I DON'T HAVE ANY PASSENGERS" IS FIXED. Cole Bailey's prompt literally said "nobody else is around - just you and
  him": in St Denis the plugin only looked at the first 256 entries of the game's ped list, and that list is full of
  horses, dogs, birds and rats - the people right next to you were often never reached (13 of 13 turns in St Denis
  said "nobody around"). Now it looks at up to 1024, AND the people on the same wagon / horse are read straight from
  the seats, so they are always there, whatever the area scan sees.
- PASSENGERS ARE IN THE CONVERSATION. Everyone on the driver's seat / in the wagon hears every word, from their own
  person, memory and voice. "Tell your passengers to get off and surrender" -> the driver answers first, then EACH
  passenger decides for himself what to do, knowing what you said and what the driver said and did (climbs down,
  hands up, begs, runs, or a brave one fights). Talk that isn't about them: they just hear it (and remember).
  Name one of them ("Martha, get down") and Martha answers.
- RIDING TWO ON A HORSE: the woman behind the man knows she's riding behind HIM on HIS horse (0.5.6 told her "on
  your horse" and she said "I ain't got no one with me"); he knows she's behind him. Couples/kin as before.
- LOOTING IS FELT. Going through someone's pockets (tied up, knocked down, hands up) or the game's hold-up "rob" -
  they feel your hands on them, react right away (curse, beg, threaten the law), remember it, and it becomes a robbery
  rumour. Also people you weren't talking to: loot them and they react.
- STRIPPED AGAINST THEIR WILL + TIED: it gets worse the closer you come. Coming toward them, a step away, right on top
  of them - each is a new moment of terror, disgust and shame (screaming at you to keep away, begging, calling for
  help, cursing you; a free one backs away). Step back and it eases a little - they are still naked and tied. Also
  works for someone stripped by another mod while you weren't talking to them. Never anything sexual for them.
- THE PEOPLE WHO LOVE THEM SEE IT. Strip, rob or tie up a woman in front of her husband, father, brother or grown son
  and he reacts by: how close they are (wife/daughter > sister > cousin > friend > someone she knows by name), how bad
  it is (stripped > tied > robbed), his honour (a man for a woman of his family), his courage, his temper (hot-headed,
  proud / timid, nervous), his age, whether he has a gun, whether YOUR gun is on HIM, how scared of you he already is,
  and an old grudge. An armed man draws and comes for you; an unarmed proud one comes at you with his fists; a scared
  one steps in shouting or runs for help/the law; an old timid man with your gun on him begs. A woman of the family
  comes to cover her, screams for help or runs; a child cries and runs to them. Every time you get close to her again
  he can boil over again. He never forgets (grudge + memory). (Body weight isn't something the game tells mods, so
  age / temper / job / gun stand in for "how big and tough he is".)

WHAT WAS NEW IN 0.5.6
- TYPE INSTEAD OF TALKING: in NpcVoice.ini (next to RDR2.exe) set TYPE_INSTEAD_OF_VOICE=1. Then: focus someone, HOLD X
  for half a second -> the game's keyboard opens -> type what you say -> Enter. Esc cancels. No microphone, no
  speech-to-text. X X (double tap) still ends the conversation. TYPE_INSTEAD_OF_VOICE=0 = your voice, as before.
- SHORTER PROMPT: people are only offered the actions that can happen right now (no wagon driving when they're on
  foot, no "dismount" when they're not on a horse...) - about 12% shorter, a little faster and cheaper, and fewer
  odd picks.

WHAT WAS NEW IN 0.5.5 (from your 18:28 log: Hans, the worker you took home at gunpoint)
- A BLACK MAN HAS A BLACK FAMILY, A WHITE MAN A WHITE ONE. 0.5.4 tried to give the wife and kids Hans's skin by
  switching their outfits, found no match, and just kept them as they were. Now: their models come from the same kind
  of townsfolk as the guide (never his exact model for a son - no twins), the plugin reads the skin properly (it waits
  for the look to load), and when a model can't get the guide's skin, that person is REBUILT with another model (up to
  3 tries) - same name, same memory, new look - before you get there.
- NOBODY STANDS ON THE ROOF. For a real house/shack the ground was measured from 300 m up and hit the roof. Now the
  family stands on the ground at the door.
- DRAGGED HOME AT GUNPOINT IS NOT A VISIT. 0.5.4 said "they seem to get along" and told Hans to introduce you while you
  held him captive. Now his family sees a man brought home by force, and he fears for them (pleads, bargains, tells
  them to run) - no introductions. The stranger never gets lines put in Hans's mouth any more.
- "I'LL COME WITH YOU" MEANS SHE COMES. Maggie said it and ran (the AI picked "flee" in the same reply). If someone says
  they'll go with you, they follow you.
- YOU CAN FOCUS PEOPLE WHILE YOU TALK AGAIN: the lock-on block is off by default, so their prompts (Unstrip's strip, rob,
  hogtie...) show up mid-conversation. (NpcVoice.ini BLOCK_LOCKON_WHILE_TALKING=1 brings the old way back.)
- THE COUPLE YOU'RE SENT TO (your 18:43-18:50 logs): they're IN THE ACT on their own bed when you walk in (a real bed
  in the house first; never the player's bedroll), and since they wanted you to come they don't stop - they talk to you,
  tease you, invite you to watch or to take the husband's place (he watches if that's his kink). Talking to either of
  them, X-X, or turning from one to the other never breaks the scene any more (0.5.4 sent Henry out of the house), and
  in the middle of it nobody "dances" or waves out of it. The guide steps back as soon as you arrive, so X goes to the
  couple. Both of them know why you came (Clara: "what do you want from me?"), and an invited couple stays warm and
  willing - how you treated the guide on the way is not their business - unless you really threaten or hurt them.
- "CLARA, COME ON OVER HERE" WORKS: calling someone by name brings them (new action call_over). People who belong
  together (a couple, a family) stay in the conversation together: talking to the wife no longer ends the husband's.
- NO MORE NARRATION / "HIS EYES DARTED..." Asking where to find a cuckold couple went to the storytelling AI (MythoMax),
  which lost the instructions and narrated instead of answering. Questions ABOUT such things now stay on the reliable
  AI; the uncensored one (a stronger, long-memory model now) is only used once it really turns intimate, with a short
  prompt it can follow, and any narration that slips through is cut out of the spoken line.
- WHERE IS IT? -> IT'S ON YOUR MAP: when you ask where to find someone and the answer names a place ("the wife-swappers
  are over at the manor by the pond"), it's marked on your map, and they're really there.
- ASK FOR A COUPLE, GET A COUPLE: when the AI forgot to say what kind of trip it was, 0.5.4 always took you to the
  guide's OWN family (Elijah: "You mean Bob and Mary?" -> "here's my family"). The kind of trip now comes from what was
  said: a couple, his own family, or the person he named.
- NPCHOOKUPS' MOANS ARE BACK: NpcVoice muted the game's own voice lines of whoever you talked to and (while an AI
  voice spoke) of everyone near you - NpcHookups' moans are game voice lines, so they went silent. Anyone in a love
  scene (NpcHookups, NpcHookupsPlus or NpcVoice's own) is never muted now, and talking to them mid-scene doesn't break
  their animation. In NpcVoice's own scenes the couple talks and moans in their own voices every 8-14 s.
  (Someone terrified of you - begging for her life - still won't say anything sexual, whatever mod started it.)
- PEOPLE ACT ON EACH OTHER: "Clara, come here" / "Clara, run!" / "Clara, hands up" / "Clara, follow me" - she does it.
- THE DEAD DON'T TALK: Clara "answered" after she'd been shot (she wasn't the one you were talking to, so the brain
  didn't know she was dead). Anyone dead is dead for every system now.
- A man and a woman on one horse, one wagon seat or arm in arm are nearly always a couple now (husband/wife or
  sweethearts), so the families-react drama happens when it should.
- Smaller fixes from the same log: Hans's wife and kids no longer "recognise" a man they never met; a phantom Korean TV
  phrase the speech-to-text heard in silence is dropped; "I7 follow you" / "don27t" apostrophes fixed; a lasso isn't
  "shot you with his lasso"; when the AI writes an action's details separately they're no longer lost (that's why
  "take me to the couple" became a family trip); a family member only chases you when you take someone by force or
  ride off with them; "I'll call the sheriff" is never read as a yes.

WHAT WAS NEW IN 0.5.4 (from your 18:13 log - 0.5.2 was really running, thank you)
- THE COUPLE YOU'RE SENT TO IS REALLY THERE. In 0.5.2 Joseph marked "a couple named Ida and Benny" on your map, but my
  code took a marked couple for a money stash and crashed ("NpcVoice turn failed: 'dollars'") - that's also why he went
  quiet - so nobody was ever built at that cabin. Fixed: a marked couple (or a person, or a place) is that, with the
  couple waiting INSIDE by their bed. When you walk in, one of them talks to you first - they know why you came - and
  if you both want it, it happens on their bed.
- BEDS INSIDE HOUSES ARE FOUND NOW. The beds in RDR2 houses are part of the map, not objects a mod can search for, so
  0.5.2 found "none" in the cabin. Now the plugin looks for the game's own SLEEPING SPOTS in the house (the points its
  NPCs lie down on in bed); with none, a blanket is laid on the floor ("sheet on the floor"). Couples at home use the
  same, so they actually show up.
- A CLEAR YES IS A YES: you ask her to bed, she answers "yes, come here" in her own words -> it happens (0.5.2 only
  talked unless the AI also picked the action). A no, or any fear/threat/captivity, still means nothing happens.

WHAT WAS NEW IN 0.5.3 (from your 17:31-18:04 log - STILL 0.5.0 in that game, see "UPDATING" above)
- "GET OFF THE WAGON" REALLY HAPPENS. 0.5.0 asked the driver to get down twice and he just sat there saying "I'm coming
  down". Now he stops the wagon, climbs down and STAYS down; if the game keeps him on his seat he's asked again, then
  set down beside the wagon. Whoever rides with him (his wife next to him) gets down with him.
- HE KNOWS WHO'S NEXT TO HIM: "just me and my load" while a woman sat beside him. Now everyone on the same wagon or the
  same horse is listed as "sitting right next to you on YOUR wagon", with who she is to him (wife, sweetheart, sister...).
- FEAR IS NOT DESIRE: someone cowering, just threatened, hurt by you or plainly terrified of you won't say sexual lines
  any more (in your log a terrified woman did, while begging for her life). Calm, willing adults: no limits, as before.
- Asking about cuckolds, swingers, threesomes, a brothel or working girls now goes to the uncensored model, so people
  answer like folk who've heard it all (and can lead you there - 0.5.2) instead of the prudish refusals in your log.

WHAT WAS NEW IN 0.5.2 (from your 16:59-17:31 log - that game was still running 0.5.0)
- The "listening..." man after the stash, the grown woman taken for a kid ("Lily Wilson Wilson") and the doubled
  surnames were already fixed in 0.5.1 - this version has those fixes too.
- FAMILIES ACT LIKE FAMILIES (kin drama). Everyone's husband/wife/sweetheart, kids, parents, brothers and sisters around
  them (from a trip, a couple at home, or two people glued together on the street) react on their own, with a voice:
     * you ride off with his wife (or she follows you away) -> he runs after your horse shouting her name, begs you to
       bring her back, or - a brave armed man, and you took her by force - draws on you. A kid cries and runs after.
     * a gun on his wife -> he pleads, or a brave man goes for his gun.
     * you hurt or kill one of them in front of the other -> a scream, then they attack you or run - and never forget.
     * you arrive at his home: he walks straight to his wife, she comes to him, the kids run to him.
- TRIPS TO ANYONE: ask about a couple who like company, a husband who likes to watch, swingers -> the person can take you
  (or mark it on your map): a real house, a married couple who are into it and glad you came (their real bed is
  found for later). Also: an ENEMY ("the man who owes me", armed and expecting trouble) and any REAL PLACE in town
  ("take me to the saloon / the hotel / the brothel / the doctor / the mine").
- PEOPLE HAVE DESIRES: about a third of grown-ups have something of their own - likes being watched, likes to take
  charge, a wild past, likes both men and women; some married men want to watch their wife with a stranger, some
  couples are open. Nobody plays shocked at "where do I find..." unless that's who they are.
- LOVERS IN TOWN: a new living-world scene - two grown-ups flirt, whisper what they want and sneak off somewhere quiet
  to do it right there. Walk in on them like a couple at home (stand up in their sight) - or watch from cover.
- COUPLES AT HOME MORE OFTEN: houses, shacks, cabins, farmhouses, hotels and the brothel within 70 m; most likely at
  night, sometimes in the afternoon.
- "Have a beer" no longer tries the bartender's animation first. "Sleep in the bed" uses a real bed nearby.

WHAT WAS NEW IN 0.5.1 (from your 15:48-16:55 logs)
- TOMMY IS A GROWN MAN. 0.5.0 called every model with "son"/"daughter" in its name a child, so U_M_Y_CzPHomesteadSon_02
  (a young man in the game) was invincible, couldn't be hurt or talked to properly ("threatening a child"). Now only real
  kid models are children (street kids, the newspaper boy, the starving shack kid, story kids). Kids are still never
  hurt (the game's own rule), but a grown man is never mistaken for one again.
- KIDS CAN FOLLOW YOU (to show the boy his mother) - never on a stranger's horse.
- "HOLDING X ONLY SAYS LISTENING" FIXED. When someone who follows you ends the talk ("let me look for him") and you press
  X again, 0.5.0 reopened the old talk and closed it again 0.1 s later - forever. Now a new talk starts.
- FAMILIES MAKE SENSE: one surname (no more "Ben Nelson Nelson"), the guide's own people (same kind of townsfolk) with
  the guide's skin tone (the plugin tries the model's outfits until the skin matches the guide's), a widow has no
  husband waiting, real kids only for kids (the game has no little-girl model outside story characters, so a young
  daughter comes as a 17-year-old), everyone busy with a chore. Lines go to whoever says them (the boy said his mother's
  line "It's alright, children" in 0.5.0). Afterwards they go back to their chores, and the one who brought you
  introduces you by name. She knows every one of them: "go talk to your son" -> she walks to him.
- EVERYONE KNOWS EVERYONE BY ONE NAME. The woman next to Thomas was "Winifred, my neighbour" and then "Ruth Peterson" -
  now the name someone gives a person is the name that person has, for everybody, and relations go both ways (if
  he's her husband, she's his wife). A man and a woman on one horse or arm in arm are a couple (or kin), and both know it.
- THEY SEE WHO'S AROUND: names, who they are to them, what they look like from the model ("a miner in soot-black
  clothes", "a lawman with a badge", "a blind man"...), and the REAL places right around them (the mine, the saloon,
  houses...). A miner model is a coal miner (Barnabas in Annesburg said "lumberjack").
- "GO DOWN THOSE STAIRS / GO INTO THE MINE / GO OVER THERE": they walk to the place you name, or wherever your camera
  points (look at the spot while you say it).
- PAIN IS REAL. Cut someone with a machete and they scream (the game's own pain voice) the same instant, then run,
  curl up, or - a brave armed man - fight back; the AI is told exactly what you did and with what ("you didn't hit me"
  can't happen).
- WORDS MATCH DEEDS - also yours: "go to sleep" + "y-yes, I'll sleep" now SLEEPS (Jesse cowered and knelt at a grave),
  "have a beer" + "sure" now DRINKS (the bottle comes with the animation - nobody says "I don't have a beer" any more).
- TRIPS ARE CLOSER AND ALWAYS ON LAND: 250-900 m (was 700-2200), always a real place from the database. Ruth's house was a
  random point in the sea; that can't happen now.
- LESS NOISE: while an AI voice speaks, the game's own chatter of the people around you is hushed (not their screams).
  When the game's own law is after you or people are panicking from a shooting, no AI lawman or AI bystanders talk on
  top of it. Only someone you can SEE and hear finds a body, one body scene at a time, short, and they only accuse
  you if they saw it (and never invent the dead person's name).
- COUPLES (new):
   * At home in bed: walk up to a real house/shack/cabin at night (or a lazy afternoon) and sometimes a couple is in bed
     inside - on the REAL bed (the plugin finds it), undressed, the same clips NpcHookups uses but run by NpcVoice
     itself, murmuring to each other now and then.
   * Walking in: stand up, walk in on them in their line of sight -> they stop, scream, cover up, curse you, get dressed,
     a brave man grabs a gun. Crouch and stay out of sight and they carry on. Both remember it; the town may hear.
   * Taking you home: someone whose partner is right there can invite you home (invite_home) - THEY lead the way on
     their horse (one is brought if they have none), the partner behind, stop at a real house, get off, wait for you at
     the door. Inside, the real bed is used for whatever the two (or three) of you decide.
   * The two-voice scene: while a couple scene runs and the partner watches because it's their own fantasy
     (agree_to_watch), both of them talk, each with their own voice.
   * Love scenes no longer NEED NpcHookups: if it isn't there (or another build), NpcVoice runs the scene itself.
     If you're in one: JUMP or SPRINT always gets you up.
   Same line as always: adults who want it, never under a threat, tied, scared, captive or a child; either can stop.
   Settings: NpcVoice_brain.ini [couples] (on/off, how often, bed height), NpcVoice.ini MUTE_BYSTANDERS_WHILE_TALKING,
   PAIN_VOICE.

WHAT WAS NEW IN 0.5.0
- A REAL GAME DATABASE (NpcVoice brain\data\db, from the community's extracted game data): 20,471 objects, 115 vehicles,
  1,982 peds, 25,831 animation dictionaries (259,323 clips), 1,493 scenarios, 16,281 clothing items, 393 real places
  with coordinates (saloons, banks, sheriffs, farmhouses, shacks, camps, mills, caves...), 1,751 doors.
- TRIPS GO TO REAL PLACES. "my friend at the saloon in Rhodes" -> the real Rhodes saloon, people at its real front
  door. A family -> a real farmhouse / house / shack / camp near you. The NPC is told which place it really is.
- UNDRESS / DRESS. People can take their own clothes off when THEY want to (for you, a bath, love-making) and put them
  back on - with the same method the Unstrip mods use (read from their code): their own skin tone, and their OWN
  outfit comes back afterwards. Never under a threat, tied up, as a captive, or a child.
- THEY KNOW WHEN THEY'RE UNDRESSED - whoever did it. Stripped with the Unstrip prompt without agreeing: outrage,
  shame, covering up, running, the law, a grudge, and the town hears of it. If she agreed (let_him_undress_you): fine.
- LOVE SCENES THROUGH NpcHookups. If she wants it ("make love with me") NpcVoice starts the NpcHookups scene for you
  (with NpcHookupsPlus taking the Arthur pair). Two NPCs: BOTH must have said yes in their own words - the cuckold
  husband who wants to watch, the couple who invite you. Stopping it works the same way as NpcHookups' own Goodbye.
  They remember it afterwards (morning after: shy, warm, regretful, wanting more).
  Needs NpcHookups.asi build 6AE4B4EA (yours). Any other build: NpcVoice says so in its log and leaves it alone.
- THEIR DAY. Everyone you meet gets a real home (a house/shack/cabin near where you met) and a real workplace that
  fits the job (a clerk at the general store, a deputy at the sheriff's office...), a routine (wake, work, lunch,
  evening at the saloon or home, church on Sunday; bartenders the other way round) and a journal of today: the
  routine so far + what REALLY happened to them. Ask them about their day - they know.
  "Meet me at the saloon tonight": remembered; next time they know you came.
- PLAY WITH A STOP WORD: a consensual dominance game she agrees to and picks a stop word for; say it (either of you)
  and it ends at once.
- BRIBES (a lawman you paid won't arrest you), HIRED GUNS (pay someone to ride with you and fight for you), GIFTS
  they remember.
- FIXED from your 15:48 log: "sit down" after "have a coffee" sat her down WITHOUT the coffee - the AI only wrote
  "sit"; now your own words count too (sit + coffee). The coffee scenario was NOT marked broken - your log shows it
  ran ("RUNNING"). And a conversation that already ended can't start talking again (the wagon driver at 15:54:22).

WHAT WAS NEW IN 0.4.0
- RIGHT MOUSE IS NOT A GUN. Holding right mouse to focus someone with empty hands is the game's "greet/antagonize"
  lock-on - 0.3.x told the NPC "the player is aiming at you". That's why the friendly tram driver threw his hands up,
  and why so many people begged for no reason. Now only a real weapon in your hand counts (not lasso, lantern...).
- X STAYS WITH THE PERSON YOU'RE TALKING TO. After Esc/alt-tab the game's auto lock-on, or someone you glanced at
  a second ago, stole the conversation. Now:
     * talking to someone (within 25 m): X always goes to them,
     * to switch: hold right mouse ON the other person (about half a second), then X,
     * nobody focused and nobody to talk to: X does nothing (no more "last focused ped"), or talks to your
       followers if they're near,
     * the game won't lock on to some people (hands up, cowering, on a wagon): aim the camera at them while
       holding right mouse - NpcVoice picks whoever the camera points at.
- WAGONS REALLY STOP. Talking to a wagon driver brings the wagon to a halt (0.3.1 only told the driver to "stand
  still", so the horses kept going). Then:
     "give me a ride"  -> he stops for you; climb on yourself; the conversation keeps going while you ride
     "take me to my marker" -> he drives to your map waypoint and stops when you get there
     "turn left / right / turn around", "faster", "slow down", "stop the wagon", "drive on"
     you can talk to other passengers on the wagon too (aim the camera at them)
  STREETCARS are on rails: the driver is left driving (no more stopping the tram with his hands up). He's a
  streetcar driver now, not an "undertaker's assistant".
- ACTIVITIES ARE DYNAMIC (like searching in Rampage, but automatic). "sit down and have a beer", "light a cigar",
  "play us something on the guitar", "warm up by the fire", "sweep the porch", "pray for her", "lean on the rail
  and smoke"... The words are matched against ~450 human scenarios in the game. The best one is played, and 3.5 s
  later the plugin checks that the person is REALLY doing it. If not, it's marked broken and the next one is tried
  (up to 4), then a matching emote. What works and what doesn't is saved in
  NpcVoice brain\data\learned_activities.json - it gets better the more you play.
  "sit on that bench / chair", "sit by the fire": they walk to a REAL bench/chair/fire nearby and use it.
  People who get along with you, or travel with you, usually say yes to a drink or a smoke now.
- PEOPLE AND BODIES HAVE TAGS. Everyone around (and every body within 70 m) is listed for the AI with a tag, so:
  "go punch that guy" -> he picks a fight with that one person; "go look at the body" -> walks over and crouches by
  it. Bodies are always in the list now (0.3.1 only kept the 24 nearest people within 40 m, so in a crowd the
  body could drop out - "Her? I don't see no one").
- TALK TO SEVERAL PEOPLE. "you two, have a drink" / "both of you" / "everyone" -> all your followers near you hear it
  and answer one after another, and each does it. Say someone's name ("Louis, go home") and it goes to them.
- THREATS WORK. Every turn the AI is told exactly how much pressure is on the person (a real gun on them, a spoken
  threat, already hurt, tied up) and how brave they are. A timid woman with a gun on her OBEYS (or runs) - no more
  "I have to get to the saloon" over and over.
- SCARED PEOPLE RUN when you turn away from them (hands up, cowering, begging) instead of standing on the road for
  two minutes. Followers in the background only speak up about things done to THEM (not when you threaten someone else).
- The lawman never barges into a conversation any more (he cut your talk with the wagon driver); he waits until
  you're done.
- TRIPS TO ANYONE. Besides family camp / missing brother / lost horse / stash, a person can now lead you to (or mark
  on your map) ANY person they talk about: "my cousin Ida knows where the gold is", "a woman at the old mill who owes
  me". When you get close, that person (or people) is spawned there, built from what was said, and they know who sent
  you. They are their own people - they decide for themselves. Ride off the other way (1.5 km further than at the
  start) or have the guide call it off, and the line disappears.
- Names fit the face (Chinatown folk get Chinese names, bayou folk French Creole, Mexican border folk Spanish) and
  jobs fit what they're doing (a wagon driver is a teamster/coachman/carter...). Fewer "going to the saloon".

WHAT WAS NEW IN 0.3.2
- "Get off your horse" now STICKS. Before, he got off, had nothing left to do, and his own AI put him
  straight back in the saddle. Now an order keeper in NpcVoice.asi checks him every 0.4 s: if the game
  puts him back on, he's pulled off again. When the talk ends he walks away ON FOOT (he doesn't ride off).
- "Ride with me" now really happens. In 0.3.1 her "here's some money" coin gesture cancelled the
  get-on-the-horse task (a gesture is a full task in RDR2). Now nothing plays on top of a mount/dismount,
  the money is still paid, and if she isn't on your horse after 14 s she is put on it (the same thing the
  game does itself when a mount takes too long). If she falls off while you ride, she gets back on.
  Same for "mount up" (his own horse) and wagon seats.
- REPORT TO THE LAW is a real action now (it did not exist before - the AI just said the words):
  "go on, report me" -> he runs to the lawman nearby, you hear them talk, the lawman walks over and
  questions YOU. The lawman can ARREST you: that goes to the game's own law system (the town comes
  after you). Talk your way out, pay a fine, or run. No lawman around: he goes to the sheriff, and the
  lawmen in that town question you next time one is near. Kill him before he gets there and nothing happens.
- TREASURE / STASHES ARE REAL now. Before, the AI could invent "treasure by the church" and nothing existed.
  Now a stash only exists if the person marks it: a yellow line on your map (250-900 m away), the line
  disappears when you arrive, a strongbox is there and walking up to it gives you the money he said
  ($5-200). He can also take you there himself ("show me").
  He is told not to name buildings he can't point to (a church, a bank) - the spot on the map is where it is.
- The person is told: words must match deeds. If they say "I'm getting on" / "I'll go to the sheriff",
  the action must be in the same reply - otherwise it's a bluff, and they know it.

INSTALL (once)
1. Open "Copy into RDR2 folder" and copy BOTH files next to RDR2.exe:
      NpcVoice.asi   NpcVoice.ini
   Nothing of yours is replaced, so BACKUPS is empty.
2. Put the folder "NpcVoice brain" anywhere you like (Desktop is fine).
3. In "NpcVoice brain", double-click install_requirements.bat (needs Python, same as your old voice_agent.py).
   "NpcVoice brain\audio_interest_keys.json" already holds your API keys. Don't share it.

PLAY
1. Double-click run_npc_brain.bat (before or after starting the game). Leave that black window open.
   In game, top-left turns green: "NpcVoice brain connected".
2. Hold RIGHT MOUSE on a person (focus), then HOLD X and speak. Let go of X when you're done.
   They stop (or keep doing their work), look at you, and answer with a voice and subtitles.
3. Within 25 m you don't need to focus again: just hold X.
4. Press X while they're talking and they shut up at once (you interrupted them).
   Double-tap X (two quick taps) = end the conversation with that person.
5. The game window must be in front for X to work. Typing "say hello" in the black window also works.

WHAT THEY KNOW, LIVE, EVERY TIME THEY SPEAK
Where (state, town, district), time and day, weather, how far you are, whether you're aiming at them
and with what gun, whether your gun is out, whether you're crouching, mounted, on a wagon, wounded or shooting.
About themselves: hogtied, lassoed, being tied, hurt, on the ground, on a horse or wagon, sitting or working,
fleeing, armed, drunk, hands up, following you, your captive.
Around them: up to 7 nearby people - who they are to them (family, friend, neighbour, workmate, the local
lawman, a stranger...), how far, what they're doing, whether they're watching. Dead bodies: who it was,
whether YOU killed them, whether they can see the body. Killing someone in front of them is remembered.
The town itself (Valentine, Saint Denis, Rhodes, ... lore) and the year 1899.
alone with you, a hookup scene going on.
Bodies you bring: a corpse on your shoulder, a tied-up living person on your shoulder, a body slung over
your horse. If it's someone you talked to before, they're named, and a neighbour from the same town knows them.
Walking up with a body, dropping it at their feet, or someone dropping dead nearby makes them react at once,
and they remember it next time.
Their own life (generated once and kept): name, age, job, family and kids, temperament, accent, quirk,
fear, dream, what they were doing today, sometimes a secret, and about 1 in 6 has a "wildcard" that
makes them surprise you (hidden gun, compulsive liar, wants to ride with you, very drunk...).

THEY REACT ON THEIR OWN
Draw a gun on them, aim at them, hogtie them, untie them, hurt them, shoot near them, walk off,
bring or drop a body,
step right up close... they speak up or act without you saying anything.

JOURNEYS (new in 0.3.0)
Ask someone to take you somewhere they talked about:
  "lead me to your wife" / "take me to your camp"   "let's go find your brother"   "let's find your horse"
If they agree - or are too scared to refuse - a YELLOW GPS LINE appears on your map (0.7-2.2 km away).
Travel together: on foot, or tell him to ride with you on your horse. Keep talking, stop for a smoke or a drink.
When you get close, the place is BUILT for real, from what he told you:
  - his camp: his wife (by the name he said), his kids, a farmhand, a dog, a wagon, chickens, campfire, tents,
    bedrolls, laundry, crates and a strongbox; everyone busy with a chore (laundry, cooking, the fire, sawing wood)
  - his brother: hurt, safe, already DEAD (he kneels and grieves), or held by KIDNAPPERS - armed men, the brother
    hogtied. Talk to their leader: pay the ransom (real money from your pocket) and he lets him go - or don't.
  - his horse, waiting for him
When you arrive, everyone reacts to HOW you arrive: with him friendly, him hogtied over your shoulder, a gun on
him, or without him. Tears, rage, relief, cursing; some run, some put their hands up, some draw on you.
Then talk to any of them - they know who they are and what just happened.
Kill the guide on the way and the line disappears - the trail ends with him.
Spawned kids (real child models only) are invincible like the game's own kids. Settings: [journeys] in NpcVoice_brain.ini.

THE LIVING WORLD (0.2.0)
People around you now live their own lives. Every so often two of them start a scene you can overhear -
real voices, subtitles, faces, gestures, and an ending that actually happens in the game:
  gossip (about the town, the rumours, sometimes about YOU)   friends joking   strangers getting to know each other
  a married couple (nagging, arguing, sweet)   a kid pestering a neighbour   workers quarrelling -> fist fight
  old friends meeting again -> going for a drink   a man courting a woman   a preacher cornering a sinner
  a beggar   a shopkeeper haggling   a lawman stopping someone -> let go / frisk / arrest / chase
  a drunk making trouble at night   outlaws whispering about a job
  a BODY FOUND: someone kneels and grieves, a lawman inspects; if people saw you do it, they point at you
  LAWMEN come and question YOU when people saw you kill or rob in that town
  very rarely at night: a friendly man lures someone away to a quiet spot and pulls a knife.
     Follow them. Talk to him later - he'll try to lure YOU. (Adult victims only.)
The people in a scene remember it (and each other: husband/wife, workmates, new friends).
The town remembers what you did: killings, robberies, hogties become rumours that spread - locals first,
grave things across the whole state - and people mention them to you.
You always come first: pressing X pauses every scene; talking to someone in a scene ends it, and they
remember what you interrupted. Settings: NpcVoice brain\NpcVoice_brain.ini [world] (scenes on/off,
how often, serial killer on/off, lawmen on/off). Each scene line is one AI voice call (MiniMax credit).

MEMORY / NEMESIS
Everyone you talk to is remembered in "NpcVoice brain\npc_memory".
Same face + same clothes in the same area = the same person. They remember what you said and did
(robbed them, tied them up, freed them, paid them) and how they feel about you (trust, fear, anger,
attraction, respect). Bad treatment builds a grudge: stranger -> rival -> nemesis.
Rivals and friends may call out to you on their own when they see you again.

WHAT THEY CAN DO (the AI picks these, or you ask)
walk away, flee (and keep shouting while running), follow you, stop following, wait, come here, stay,
wander, hands up, surrender (drop gun + hands up), hands down, drop weapon, holster, draw weapon,
attack, take cover, cower, sit, stand up, lean, smoke, drink, eat, play guitar, nod, shake head, wave,
tip hat, shake hands, dance, mount a horse, dismount (and stay off), RIDE WITH YOU (your horse, or the
wagon/horse you just got off), get off the wagon, lead their horse, REPORT YOU TO THE LAW, mark a REAL
stash on your map, (lawmen) ARREST you, give you money (real cash), take your money
(real cash, only what you have), throw money down, give/take an item (roleplay only), refuse, look at
you, point, laugh, angry gesture, show they're hurt, kneel, beg, sob, tremble, thank you, shrug,
beckon, blow a kiss, spit, calm-down gesture.
Whether they obey depends on them: their bravery, whether you're aiming at them, how they feel about you.

WHEN A CONVERSATION ENDS
You're more than 20 m away for 8 s, you ignore them for 45 s, they leave or flee, they die,
a mission starts, or you talk to someone else.
People following you, or told to stay, stay with you until you set them free ("you're free").
Afterwards they go back to their own business.

RULES BUILT IN
- Adults: no limits on talk, swearing, threats, robbery, romance, explicit sex, moaning. Once it turns
  intimate it stays on the uncensored model. The one exception: someone who is tied up, lassoed, has your
  gun on them, has their hands up or is your captive won't say sexual lines (checked on THEIR reply only).
- Explicit rape / molest wording is not role-played.
- Children: normal talk only. Sexual talk or threats toward a child -> the kid runs off.
- Story characters (CS_ and other scripted characters) are left alone.

PAUSE, ESC, ALT-TAB, WEAPON WHEEL (new in 0.3.1)
- When the game is paused or frozen (Esc menu, map, alt-tab, loading) or the weapon wheel is open, the
  voice pauses mid-word and the subtitle waits. Answers that arrive meanwhile are held until you're back.
  Scenes, reactions, journeys and the "you walked away / you ignored them" timers stop too.
- After the pause you just keep talking to the same person.

FIGHTS (new in 0.3.1)
- The person knows when they're in a fist fight with you and when their punch landed - they won't
  say "I didn't touch you" while they're hitting you. They remember it.

TALKING OVER EACH OTHER
- Pressing X stops everything at once: their voice, subtitles, gestures, any line they were about to say.
  Nobody starts talking while you hold X. Spontaneous lines only come when you're not talking.
- The game's own voice lines for that person are muted for the whole conversation.

IF SOMETHING GOES WRONG
- The game and the brain talk through small files in %LOCALAPPDATA%\NpcVoice\link - no internet,
  no ports, no firewall involved. Files are deleted as soon as they are read.
  (Old network mode: TRANSPORT=tcp in NpcVoice.ini; test_connection.exe only matters for that mode.)
- Red "can't reach the brain" message: is run_npc_brain.bat open? Its window says
  "file link: watching ..." and, once the game runs, "game connected through the file link".
- Errors show top-left on screen: red = error, yellow = warning.
- Send me these files:
     RDR2 folder:   NpcVoice.log   NpcVoice.ini   NpcVoice_native_guard.txt (if it exists)
     NpcVoice brain\logs:   npc_brain.log   turns.jsonl   native_proof.txt
  turns.jsonl holds every conversation turn: what the NPC knew, what the AI answered, which actions ran
  or were refused, and why.
- If the game ever crashes because of NpcVoice, the next start switches off the exact game function
  it was calling, and tells you on screen which one.

TESTED SO FAR (honest status)
Fake-game test rig (the real NpcVoice.asi + the real brain, under Wine): 181 of 181 checks - main 63, crash guard 3,
late brain 6, scenes 20, journeys 23, orders/law/stash 29, life 37 (wagons, trams, aim, activities, seats, X, groups,
scared, targets, bodies + 0.5.0: undress/dress with the Unstrip recipe, stripped-without-agreeing, NpcHookups bridge absent).
Brain tests: 47 brain, 20 orders, 43 0.4.x, 28 0.5.0, 13 bodies, 4 recognition, 5 resilience, 7 file link,
5 microphone, 13 director, 6 log fixes. All 161 game functions exist on your build 1311.
NOT seen in your real game yet. Watch especially:
- whether focusing (right mouse) is detected
- riders/wagon drivers stopping
- emote gestures (nod, wave, laugh...) playing on normal NPCs
- the talking face/lips
- subtitle centring
- ride-with-me seats
- carried-body detection (uses the game's own 'what is he carrying' function)
- real AI voice/latency (the AI providers could not be reached from my test machine)
- 0.3.2: the forced seat on your horse (back seat), how the game's law reacts to an arrest
- 0.5.0: the nude body pieces on ambient peds, the NpcHookups bridge (Pick / Goodbye) - build-locked to your file
- 0.4.0: wagon driving (halt / drive to waypoint / turns: the game's driving flags are a best guess),
  which scenarios play on which people (that's what the learning is for), the camera-pick focus
