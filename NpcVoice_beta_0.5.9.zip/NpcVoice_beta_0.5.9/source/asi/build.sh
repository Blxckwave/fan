#!/bin/sh
# Builds NpcVoice.asi with mingw-w64 (same toolchain/flags as the other plugins in this project)
set -e
cd "$(dirname "$0")"
x86_64-w64-mingw32-dlltool -d sh.def -l libScriptHookRDR2.a -m i386:x86-64
x86_64-w64-mingw32-g++ -O2 -Wall -Wno-misleading-indentation -Wno-unused-function -std=c++17 -fno-exceptions -fno-rtti \
  -shared -static -static-libgcc -static-libstdc++ -s -Wl,--exclude-all-symbols NpcVoice.cpp -o NpcVoice.asi \
  -L. -lScriptHookRDR2 -lws2_32
ls -la NpcVoice.asi
