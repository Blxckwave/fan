# Unstrip mods (Male Edition / Full Nude): what the binaries do

Read with objdump plus the RDR3 native DB. Everything below was **read** in the code, not guessed. Nothing here is
**tested**: no simulator covers these mods yet. Nothing is **verified in the game**.

| file | TimeDateStamp | SizeOfImage | compiler |
|---|---|---|---|
| Unstrip - Full Nude.asi (female) | 696FC675 | 0x45000 | MSVC (no function names) |
| Unstrip - Male Edition.asi | 69B7A2FF | 0x4F000 | MSVC (no function names) |

Both import only `KERNEL32` and `ScriptHookRDR2`. Neither exports any function, so another plugin can't call them
except by address (Route E in the guide, which isn't planned here).

## How a strip happens (female edition)
1. A "Strip/Unstrip" hold prompt is attached to the ped you target (`_UI_PROMPT_*`, `GET_PLAYER_TARGET_ENTITY`). The
   key comes from the .ini (`PromptKey=INPUT_FRONTEND_LS` = Z).
2. Refused for: animals (`GET_IS_ANIMAL`), children (`_IS_PED_CHILD`, male edition), and a hard-coded list of cutscene
   models (`cs_tilly`, `cs_marybeth`, ...). It logs "Cutscene skeleton (cs_) - incompatible".
3. **Save** (`0x180008990`): for slots 0..15 it reads `GET_META_PED_ASSET_GUIDS` (drawable, albedo, normal, material)
   and `GET_META_PED_ASSET_TINT` (palette, tint0..2) into a per-ped record of 16 × 32 bytes, plus a "saved" byte at +0x200.
4. **Skin tone**: it compares the ped's hand albedo with `HAND_FR1_000_C0_000_AB` .. `C1_009_AB` and logs
   "Detected albedo: %03d".
5. **Remove** (`0x180008d30`): `GET_HASH_KEY(name)` then `REMOVE_TAG_FROM_META_PED(ped, hash, 1)` for:
   upper body: `shirts_full shirts vests coats coats_full coats_closed dresses skirts corsets gowns gunbelts belts loadouts holsters_left holsters_right`
   lower body: `pants skirts chaps aprons boots boot_accessories`
   plus a list of about 120 named clothing drawables baked into some bodies (`COAT_FR1_*`, `DRESS_FR1_*`, `VEST_FR1_*`, `UPPR_FR1_*_OPENCOAT`, ...).
6. **Apply the nude body** with `_SET_META_PED_TAG` and tint `METAPED_TINT_GENERIC`:
   upper `UPPERTORSO_FR1_000` + `HAND_FR1_000_C0_<tone>_AB / _NM / _M`;
   lower `LOWERTORSO_FR1_00{3,4,5,7,9,10}` + `FEET_FR1_000_C0_<tone>_AB / _NM / _M`.
7. **Body shape**: `_SET_CHAR_EXPRESSION(ped, id, value)` for ids 0xA206, 0x6C83, 0xFD42, 0xA453, 0x231F. Random, or
   from the .ini (`ChestWidthOffset`, `ChestDepthOffset`, `UpperLegOffset`, `LowerLegOffset`, `BumOffset`).
8. `_UPDATE_PED_VARIATION`.

## How an unstrip happens (`0x180005500`, female)
Only if the ped's record has the saved byte at +0x200 set, and the ped isn't the player: remove **every** component
category, wait 10 ms, update, re-apply the 16 saved slots with `_SET_META_PED_TAG`, update, reset the 5 expressions to
0, update.

## Male edition differences
- Skips peds whose decorator `POOLS_SCRIPT_OWNED` is 1 (`DECOR_EXIST_ON` / `DECOR_GET_INT`), meaning peds owned by
  another script.
- Its removal list also has `cloaks ponchos suspenders neckwear neckties gloves belt_buckles holsters_crossdraw
  holsters_knife satchels ammo_pistols spats shoes`.
- It keeps a list of handles it cleans up with `DELETE_ENTITY` / `SET_ENTITY_AS_NO_LONGER_NEEDED`. Not yet read
  which entities those are.

## What this means for NpcVoice (companion plugin, natives only: Route B)
- **Knowing someone is undressed**, whoever did it (this mod, NpcHookups, or NpcVoice itself): walk the ped's
  component categories (`_GET_NUM_COMPONENT_CATEGORIES_IN_PED` / `_GET_PED_COMPONENT_CATEGORY_BY_INDEX`) and compare
  them with the clothing names above (joaat). No torso clothing and no leg clothing = undressed. This reads the
  game's state, not the mod's memory, so it works with any strip method.
- **Who did it**: the player was targeting them and standing within 3 m when it changed = the player; NpcVoice's own
  undress action = they did it themselves; otherwise "someone".
- **An NPC undressing or dressing on its own**: the same recipe with the same natives and asset names (steps 3–8, and
  the unstrip steps for dressing). NpcVoice keeps its own saved record, so it never touches the mod's memory.
- Not verified in the game: whether the category walk sees exactly what the mod changed; and the male nude-body
  asset names, which aren't read yet (the male strings use a different code shape).
