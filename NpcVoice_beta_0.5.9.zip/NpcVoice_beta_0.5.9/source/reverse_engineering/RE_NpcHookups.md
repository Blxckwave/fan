# NpcHookups.asi / NpcHookupsPlus.asi: what was read, and how NpcVoice uses it

Everything below was **read** with objdump plus the native DB, not guessed. Nothing that touches NpcHookups has been
**verified in the game**.

## NpcHookups.asi
- MinGW build with its **symbol table kept** (174 C++ names). The DWARF info only covers the MinGW runtime, so data
  layouts still come from the disassembly.
- Identity: TimeDateStamp **6AE4B4EA**, SizeOfImage **0x59000**, SHA-256 `7115090307d09b2e…140a89`.
- `Pick(int ped, int which)` at **RVA 0x8130**: what its "Partner 1" (which=1) and "Partner 2" (which=2) keys call.
  When both partners are picked it claims them, reads the **player's** position, places the couple about 3 m in front of
  you (DISTANCE_IN_FRONT_OF_PLAYER), lays a bedroll and starts the clips. `PedProblem` refuses the player
  ("that is you"), animals and children.
- `OnKey` at **RVA 0x1800** only does `lock or g_pending, bit`. Its `ScriptMain` swaps `g_pending` (**RVA 0x22440**) to
  zero and hands the bits to `HandleAction`. Bit **0x2** is the branch that logs "couple %d stopped, back to normal."
  with the reason "goodbye". That is the key at `g_cfg+0x10`, which `LoadConfig` reads right after `CLEAR_ALL`.
- The scene's clips: dictionary `script_story@sal1@ig@sal1_18_lenny_on_lenny`, clips `loop_male` and `loop_female`.
- Couples live in `g_c` (records of 0x128 bytes). NpcVoice does **not** read that array.

## NpcHookupsPlus.asi
- Stripped build (no names). It takes over pairs NpcHookups can't run, e.g. the same ped picked as partner 1 and 2
  ("with Arthur"). It does this by reading NpcHookups' log (TAKE_OVER_DUPLICATE_PICK=1 in its ini).
- It sets the named event `NpcHookupsPlus_SceneActive`, which NpcVoice already watches.

## What NpcVoice 0.5.0 does with it
| What | How | Risk |
|---|---|---|
| Knows who is in a scene | `IS_ENTITY_PLAYING_ANIM(ped, sal1_18 dict, loop_male/female)` on managed and nearby peds | none: a plain native |
| Starts a scene (both said yes) | calls `Pick(a,1)` + `Pick(b,2)`; with the player: `Pick(a,1)` + `Pick(a,2)` for NpcHookupsPlus | build-locked + first 16 code bytes of Pick/OnKey compared; off otherwise |
| Stops a scene | `InterlockedOr(g_pending, 0x2)`, exactly what its own key handler does | build-locked; one bit in one field |

If NpcHookups.asi is missing or is a different build, NpcVoice logs it once and the bridge stays off. Nothing is
patched on disk.

**Not done:** couples placed **at a bed in a house**. `Pick` always places the couple in front of the player. Getting
them into a house means either moving the couple after `Pick` (that needs the `g_c` record layout and the anchor and
bedroll handles: not read yet) or NpcVoice running the scene itself with these clips and NpcHookups' own position numbers.

## 0.5.8: how its scene is really built (read from the same build, 6AE4B4EA, the copy you uploaded on 2026-11-14)
Read with objdump + a script that maps each `nativeInit` hash to its name (alloc8or rdr3-nativedb) and resolves
the float constants. Function names come from its symbol table.
- `Pick` -> roles: with MEN_TAKE_MALE_ROLE=1 the man is the **base** (lower partner), the woman the **top**.
  SET_ENTITY_NO_COLLISION_ENTITY both ways, REQUEST_ANIM_DICT sal1_18 (5 s max), the position in front of the player
  (DISTANCE_IN_FRONT_OF_PLAYER, ground z), heading = player heading + 180 + HEADING_OFFSET, bedroll object,
  SET_ENTITY_COORDS_NO_OFFSET + SET_ENTITY_HEADING + SET_PED_CAN_RAGDOLL(false) + SET_PED_KEEP_TASK for both, strip.
- `PlayBase`: TASK_PLAY_ANIM(base, sal1_18, position 2 ? loop_female : loop_male, 8, -8, CLIP_DURATION or -1, flag 1)
  - IN PLACE, no coordinates. (`mode 1` uses TASK_PLAY_ANIM_ADVANCED at the scene point instead.)
- `PinBase`: base z outside [scene z - 0.5, scene z + 2.5] -> velocity 0 + SET_ENTITY_COORDS_NO_OFFSET back;
  FREEZE_ENTITY_POSITION if FREEZE_LOWER_PARTNER (default 0).
- `AttachTop` (ATTACH_MODE, default 3): SET_ENTITY_COLLISION(top, 0, 0), velocity 0, then
  ATTACH_ENTITY_TO_ENTITY(top, base, bone, x, y, z, rx + ROT_X_CORRECTION, ry + ROT_Y_CORRECTION, rz + ROT_Z_CORRECTION,
  0, 0, 0, 0, 2, 1, 0, 0). bone = `FindAttachBone`: GET_PED_BONE_INDEX(base, 0xA7D8), else
  GET_ENTITY_BONE_INDEX_BY_NAME(base, ATTACH_BONE_NAME = "SKEL_Pelvis"). Corrections default 0 / 0 / -90.
  Mode 3 with a successful calibration attaches to a "hip anchor" marker object placed where bone 591 sits on the
  player (`MakeAnchor`, M3ToEuler, ATT_ORIG + your NUDGE values). Without calibration it uses the ATT numbers on the
  bone directly, which is what NpcVoice 0.5.8 does.
- ATT table (x, y, z, rx, ry, rz): 1 Cowgirl -0.35 0.13 0.99 / -353 15 91; 2 Missionary 0.18 0.16 0.83 / -512 -188 77;
  3 Reverse cowgirl 0.19 -0.13 0.87 / -16 10 -89. NUDGE_DEF (ADJ): -0.2 0.06 0 / 0 -12 -4; -0.08 0.16 -0.12 / 0 0 14;
  0.26 0.34 0 / 0 0 0 (calibrated mode only). MAN (ATTACH_MODE 2): 0 0 0.3 / -90 0 180; 0 0 0.45 / -90 0 180; 0 0 0.3 / -90 0 0.
- `PlayTop`: TASK_PLAY_ANIM(top, sal1_18, loop_female, ...) in place (it is attached), ApplyRate = SET_ANIM_RATE on both.
- Upkeep strings: "top partner got detached -> re-attaching", "lower partner fell to z -> put back", "clip check ...
  restarting the one that stopped" (RESTART_CLIP_AFTER_MS = 900). `ResetForScene` / goodbye: DETACH_ENTITY,
  velocity 0, FREEZE off, collision on.
- Undress waits for IS_PED_READY_TO_RENDER (`WaitReady`) before it strips.
