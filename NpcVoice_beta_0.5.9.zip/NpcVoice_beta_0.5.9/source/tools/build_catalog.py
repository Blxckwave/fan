"""Builds NpcVoice brain/data/activity_catalog.json - everything a person can really DO, in words the AI understands.

Sources (all already in the package):
  - data/scenarios.json            scenario -> its variants (the game's per-sex / per-style versions)
  - source/tools/ScenariosListRDR2.txt   a community list of RDR2 scenario names (adds variants we didn't have)
  - data/db/anims.json.gz          every animation dictionary -> clips: each variant's own "@base" loop is the fallback
                                   when the game refuses to start the scenario on someone
  - data/emotes.json               the KIT emotes (quick gestures, anyone can play them)

Every entry gets: a plain-English label, concepts (sleep, sit, drink...), posture (stand / sit / lie / kneel / crouch /
lean), what it needs (a chair, a bed, a bar... = only at a real spot), which sexes have a version, and the variants
and their base clips. Run:  python build_catalog.py   (from source/tools)
"""
from __future__ import annotations

import gzip
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
BRAIN = HERE.parent.parent / "NpcVoice brain"
DATA = BRAIN / "data"

EXCLUDE = re.compile(r"^(WORLD_ANIMAL|PROP_ANIMAL|WORLD_PLAYER|PROP_PLAYER|MP_|RANSACK|SCRIPT_|CNV_|CC_|PLAYER_|SC_|"
                     r"DUAL_|PROP_VEHICLE|WORLD_FLOURISH)|_JACK_|_HORSE_|_DOG_|_WIP$|VIRGIL|NAZAR|SAL1|TRAIN_PLANS|_CA$|"
                     r"INTERACTION|DYNAMIC|_LINK$|ANIMSCENES|BEECHERS|_FLEE$")
# story-camp characters' own versions (Jack, Dutch, Javier...) - they work on anyone of that sex but the names are noise
NAMES = {"JACK", "ES", "JD", "GUS", "JAVIER", "KIERAN", "LENNY", "DUTCH", "BILL", "JOHN", "MICAH", "ABIGAIL", "HOSEA",
         "CHARLES", "PEARSON", "SEAN", "HARRIET", "WATSON", "TRELAWNY", "LANGTON", "JOE", "MP", "LOBBY", "RE", "LNS",
         "TWNREC", "VAL", "RAYFIRE"}
NOISE = {"WORLD", "HUMAN", "PROP", "CAMP", "GENERIC", "SCENARIO", "ALWAYS", "NEW", "IDLES", "IDLE", "FALLBACK", "PROPS",
         "WIP", "CA", "LINK", "A", "B", "C", "W", "1", "2", "3", "2H", "PEDS", "FWD"}
# token -> words in the label
WORDS = {
    "SEAT": "sit", "SIT": "sit", "SEATED": "sitting", "CHAIR": "on a chair", "BENCH": "on a bench", "TABLE": "at a table",
    "GROUND": "on the ground", "LEAN": "lean", "WALL": "against a wall", "RAILING": "on a railing", "POST": "on a post",
    "LEDGE": "on a ledge", "STEPS": "on the steps", "FENCE": "on a fence", "BARREL": "on a barrel", "CRATE": "on a crate",
    "STUMP": "on a stump", "LOG": "on a log", "PORCH": "on the porch", "BAR": "at the bar", "COUNTER": "at the counter",
    "DESK": "at a desk", "BED": "in bed", "PILLOW": "head on a pillow", "ARM": "head on the arm", "BACK": "back",
    "SLEEP": "sleep", "ASLEEP": "asleep", "PASSED": "passed out", "OUT": "", "SLUMPED": "slumped", "TIRED": "tired",
    "EXHAUSTED": "exhausted", "FALL": "dozing off", "RESTING": "resting", "LAZY": "lazily", "RECLINE": "reclining",
    "DRINKING": "drinking", "DRINK": "drinking", "BEER": "a beer", "WHISKEY": "whiskey", "MOONSHINE": "moonshine",
    "RUM": "rum", "COFFEE": "coffee", "CHAMPAGNE": "champagne", "FLASK": "from a flask", "BOTTLE": "a bottle",
    "GLASS": "a glass", "SMOKE": "smoke", "SMOKING": "smoking", "CIGAR": "a cigar", "PIPE": "a pipe",
    "CIGARETTE": "a cigarette", "GUITAR": "play the guitar", "BANJO": "play the banjo", "MANDOLIN": "play the mandolin",
    "FIDDLE": "play the fiddle", "CONCERTINA": "play the concertina", "TRUMPET": "play the trumpet",
    "HARMONICA": "play the harmonica", "JAW": "play the jaw harp", "HARP": "", "PIANO": "play the piano",
    "UPBEAT": "(upbeat)", "DOWNBEAT": "(slow)", "BLUES": "(blues)", "READ": "read", "READING": "reading",
    "BOOK": "a book", "NEWSPAPER": "the newspaper", "PAPER": "a paper", "JOURNAL": "a journal", "WRITE": "write",
    "WRITING": "writing", "NOTEBOOK": "in a notebook", "SKETCH": "sketch", "SKETCHING": "sketching",
    "SKETCHBOOK": "in a sketchbook", "CLIPBOARD": "with a clipboard", "STEW": "stew", "EAT": "eat", "EATING": "eating",
    "FOOD": "food", "CANNED": "canned", "SOUP": "soup", "BOWL": "a bowl", "COOK": "cook", "COOKING": "cooking",
    "STIR": "stir", "CAULDRON": "the pot", "KETTLE": "a kettle", "POT": "a pot", "FIRE": "by the fire", "TEND": "tend",
    "WARM": "warm up", "BROOM": "sweep with a broom", "STRAW": "straw", "CLEAN": "clean", "WASH": "wash",
    "WASHBOARD": "laundry on a washboard", "WASHBASIN": "at the wash basin", "BASIN": "a basin", "BUCKET": "a bucket",
    "FILL": "fill", "POUR": "pour", "DUMP": "dump", "PUMP": "pump", "WATER": "water", "DISHES": "the dishes",
    "SCRUB": "scrub", "WINDOW": "the window", "KNITTING": "knit", "SEWING": "sew", "MIRROR": "in a mirror",
    "GROOMING": "groom", "POCKET": "pocket", "FAN": "fan yourself", "HAT": "a hat", "BOOTS": "boots",
    "GUARD": "keep guard", "MILITARY": "like a soldier", "SCOUT": "scout", "BADASS": "look tough", "STERNGUY": "look stern",
    "STARE": "stare", "STOIC": "stoically", "WAITING": "wait", "IMPATIENT": "impatiently", "NERVOUS": "nervously",
    "STRESSED": "stressed", "SAD": "sadly", "CROUCH": "crouch", "INSPECT": "inspect something", "KNEEL": "kneel",
    "MOURNING": "mourn", "PRAY": "pray", "GRAVE": "at a grave", "GRAVEDIG": "dig a grave", "DANCING": "dance",
    "VOMIT": "vomit", "DRUNK": "drunk", "PEE": "pee", "SHOP": "browse", "BROWSE": "the shop", "SHOPKEEPER": "shopkeeper",
    "BARTENDER": "tend bar", "BARCUSTOMER": "at the bar", "SERVE": "serve", "KNOCK": "knock", "DOOR": "on a door",
    "KNIFE": "a knife", "SHARPEN": "sharpen", "WHITTLE": "whittle", "RIFLE": "a rifle", "PISTOL": "a pistol",
    "GUN": "a gun", "CHECK": "check", "REPAIR": "repair", "HAMMER": "hammer", "WRENCH": "with a wrench", "SAW": "saw",
    "PLANE": "plane wood", "LUMBER": "lumber", "WOOD": "wood", "AXE": "an axe", "CHOP": "chop", "SHOVEL": "shovel",
    "COAL": "coal", "PICKAXE": "a pickaxe", "SLEDGEHAMMER": "a sledgehammer", "RAKE": "rake", "PITCH": "pitch",
    "PITCHFORK": "a pitchfork", "HAY": "hay", "HAYPILE": "the hay pile", "BALE": "a bale", "FORK": "a fork",
    "FEED": "feed", "FEEDBAG": "a feed bag", "CHICKEN": "the chickens", "PIGS": "the pigs", "PIGFEED": "pig feed",
    "LIVESTOCK": "the livestock", "FISHING": "fish", "FISH": "fish", "POLE": "a pole", "ROD": "a rod", "CRAB": "crab",
    "TRAP": "a trap", "BUTCHER": "butcher", "MEAT": "meat", "CARVE": "carve", "SKINS": "skins", "TANNING": "tan",
    "RACK": "a rack", "FLESHING": "flesh a hide", "SACK": "a sack", "BOX": "a box", "BASKET": "a basket",
    "CARRYING": "carry", "PICKUP": "pick up", "PUTDOWN": "put down", "PUT": "put", "DOWN": "down", "PUSH": "push",
    "CART": "a cart", "WAGON": "a wagon", "WHEEL": "a wheel", "TARP": "a tarp", "SADDLE": "a saddle", "BRUSH": "brush",
    "HORSE": "a horse", "COTTONBOX": "cotton box", "COTTONBALE": "cotton bale", "SUGAR": "sugar", "GINNED": "ginned",
    "CHAMBERPOT": "a chamber pot", "LANTERN": "a lantern", "OILCAN": "an oil can", "CHESS": "play chess",
    "CARDS": "cards", "SHUFFLE": "shuffle", "FLETCH": "fletch", "ARROW": "arrows", "MORTAR": "mortar",
    "PESTLE": "and pestle", "MASH": "mash", "GRINDSTONE": "a grindstone", "WEEDING": "pull weeds", "SKY": "the sky",
    "STICK": "a stick", "THROWS": "throw", "ROCKS": "rocks", "TOY": "a toy", "PLAY": "play", "CRICKETS": "crickets",
    "MICROSCOPE": "a microscope", "NATURALIST": "naturalist", "CATALOG": "a catalog", "STAND": "stand",
    "STANDING": "standing", "HIGH": "high", "LOW": "low", "LEFT": "left", "RIGHT": "right", "COLD": "cold",
    "TIED": "tied", "COWER": "cower", "BRACE": "brace", "HOBO": "like a hobo", "UPPERCLASS": "genteel", "POSH": "posh",
    "GROSS": "gross", "SHAKY": "shaky", "PEW": "on a pew", "STOW": "stow", "SLING": "sling", "STORAGE": "storage",
    "FOODPREP": "prepare food", "RAW": "raw", "PLANTED": "planted", "HAND": "hand", "FACE": "face", "FLOOR": "the floor",
    "ON": "", "IN": "", "UP": "up", "WITH": "with", "NO": "no", "WITHOUT": "without", "EMPTY": "empty", "FULL": "full", "SMALL": "small",
    "LARGE": "large", "MED": "", "MALE": "", "FEMALE": "", "LADLE": "a ladle", "SCOOP": "scoop", "POKE": "poke",
    "LAY": "lay", "SPREAD": "spread", "BLOOD": "blood", "SELL": "sell", "BANKTELLER": "bank teller", "CULTURE": "",
    "SAVAGE": "", "SURVIVOR": "survivor", "THIEF": "thief", "SEARCHING": "searching", "LOST": "lost", "LURE": "a lure",
    "FLOAT": "float", "CATFISH": "catfish", "RECOVER": "recover", "TRACKS": "tracks", "SIDE": "side", "BRAINS": "brains",
    "MOONSHINER": "moonshiner", "COLLECTION": "collection", "SOAK": "soak", "BIN": "a bin", "PLANK": "a plank",
    "TOOL": "a tool", "DEER": "deer", "RABBIT": "rabbit", "WORKING": "working", "CASUAL": "casually", "ROLL": "roll",
    "INTERACTION": "", "FARMER": "farmer", "RIVERBOAT": "riverboat", "WHORE": "", "POISON": "poison", "KNIVES": "knives",
    "CRAFT": "craft", "LEAVE": "leave", "BAG": "a bag", "DROP": "drop", "HANG": "hang", "UNHANG": "unhang", "SMOKEY": "",
}
# concept -> tokens that mean it (also the retrieval vocabulary)
CONCEPT_TOKENS = {
    "sleep": {"SLEEP", "ASLEEP", "PASSED", "SLUMPED"}, "rest": {"RESTING", "EXHAUSTED", "TIRED", "LAZY", "RECLINE", "FALL"},
    "sit": {"SIT", "SEAT", "SEATED"}, "lean": {"LEAN"}, "kneel": {"KNEEL"}, "crouch": {"CROUCH"},
    "drink": {"DRINK", "DRINKING", "BEER", "WHISKEY", "MOONSHINE", "RUM", "FLASK", "CHAMPAGNE", "BOTTLE"},
    "beer": {"BEER"}, "whiskey": {"WHISKEY", "FLASK", "RUM"}, "moonshine": {"MOONSHINE"}, "coffee": {"COFFEE"},
    "champagne": {"CHAMPAGNE"}, "smoke": {"SMOKE", "SMOKING", "CIGAR", "PIPE", "CIGARETTE"}, "cigar": {"CIGAR"},
    "pipe": {"PIPE"}, "music": {"GUITAR", "BANJO", "MANDOLIN", "FIDDLE", "CONCERTINA", "TRUMPET", "HARMONICA", "JAW", "PIANO"},
    "guitar": {"GUITAR"}, "banjo": {"BANJO"}, "mandolin": {"MANDOLIN"}, "fiddle": {"FIDDLE"}, "concertina": {"CONCERTINA"},
    "trumpet": {"TRUMPET"}, "harmonica": {"HARMONICA"}, "jaw harp": {"JAW"}, "piano": {"PIANO"},
    "read": {"READ", "READING", "BOOK", "NEWSPAPER", "PAPER", "CATALOG"}, "write": {"WRITE", "WRITING", "NOTEBOOK", "JOURNAL", "CLIPBOARD"},
    "sketch": {"SKETCH", "SKETCHING", "SKETCHBOOK"}, "eat": {"EAT", "EATING", "STEW", "FOOD", "CANNED", "SOUP", "BOWL"},
    "cook": {"COOK", "COOKING", "STIR", "CAULDRON", "KETTLE", "FOODPREP", "LADLE"}, "fire": {"FIRE"}, "warm": {"FIRE"},
    "sweep": {"BROOM"}, "clean": {"CLEAN", "SCRUB", "DISHES"}, "wash": {"WASH", "WASHBOARD", "WASHBASIN", "BASIN"},
    "water": {"PUMP", "WATER", "BUCKET"}, "knit": {"KNITTING"}, "sew": {"SEWING"}, "groom": {"GROOMING", "MIRROR"},
    "fan": {"FAN"}, "guard": {"GUARD", "MILITARY", "SCOUT", "BADASS"}, "tough": {"BADASS", "STERNGUY", "STARE"},
    "wait": {"WAITING", "IMPATIENT"}, "inspect": {"INSPECT"}, "mourn": {"MOURNING", "GRAVE"}, "pray": {"MOURNING", "PRAYER", "PRAY"},
    "dance": {"DANCING"}, "vomit": {"VOMIT"}, "drunk": {"DRUNK"}, "pee": {"PEE"}, "shop": {"SHOP", "BROWSE"},
    "bartend": {"BARTENDER"}, "knock": {"KNOCK"}, "knife": {"KNIFE", "SHARPEN"}, "whittle": {"WHITTLE"},
    "gun": {"RIFLE", "PISTOL", "GUN"}, "repair": {"REPAIR", "HAMMER", "WRENCH"}, "hammer": {"HAMMER", "SLEDGEHAMMER"},
    "saw": {"SAW", "PLANE"}, "wood": {"LUMBER", "WOOD", "AXE", "CHOP", "SAW"}, "chop": {"CHOP", "AXE"},
    "dig": {"SHOVEL", "GRAVEDIG", "PICKAXE"}, "hay": {"HAY", "HAYPILE", "BALE", "PITCH", "PITCHFORK", "RAKE"},
    "feed": {"FEED", "FEEDBAG", "PIGFEED"}, "chicken": {"CHICKEN"}, "pig": {"PIGS", "PIGFEED"}, "fish": {"FISHING", "FISH", "ROD"},
    "butcher": {"BUTCHER", "MEAT", "CARVE", "FLESHING"}, "tan": {"TANNING", "SKINS"}, "carry": {"CARRYING", "SACK", "BOX", "CRATE"},
    "horse": {"SADDLE", "BRUSH", "HORSE"}, "brush": {"BRUSH"}, "chess": {"CHESS"}, "cards": {"CARDS", "SHUFFLE"},
    "cower": {"COWER"}, "think": {"STARE", "STERNGUY"}, "stand": {"STAND", "STANDING"},
}
POSTURE = [("lie", {"SLEEP", "ASLEEP", "PASSED", "SLUMPED", "RECLINE", "LAY"}), ("sit", {"SIT", "SEAT", "SEATED", "PEW"}),
           ("kneel", {"KNEEL", "MOURNING", "GRAVE"}), ("crouch", {"CROUCH", "INSPECT"}), ("lean", {"LEAN"})]
NEEDS = [("bed", {"BED"}), ("chair", {"CHAIR"}), ("bench", {"BENCH", "PEW"}), ("table", {"TABLE", "DESK"}),
         ("bar", {"BAR", "COUNTER", "BARTENDER", "BARCUSTOMER"}), ("railing", {"RAILING", "FENCE"}), ("wall", {"WALL"}),
         ("ledge", {"LEDGE", "STEPS", "POST", "BARREL", "CRATE", "STUMP", "LOG"}), ("piano", {"PIANO"}),
         ("fire", {"FIRE"}), ("washbasin", {"WASHBASIN", "BASIN"}), ("door", {"DOOR"}), ("grave", {"GRAVE"})]
PROPS = {"PILLOW": "pillow", "BEER": "beer bottle", "WHISKEY": "glass of whiskey", "MOONSHINE": "jug of moonshine",
         "COFFEE": "cup of coffee", "CIGAR": "cigar", "PIPE": "pipe", "SMOKE": "cigarette", "GUITAR": "guitar",
         "BANJO": "banjo", "FIDDLE": "fiddle", "MANDOLIN": "mandolin", "CONCERTINA": "concertina", "TRUMPET": "trumpet",
         "HARMONICA": "harmonica", "BOOK": "book", "NEWSPAPER": "newspaper", "BROOM": "broom", "BUCKET": "bucket",
         "STEW": "bowl of stew", "KNIFE": "knife", "RIFLE": "rifle", "SHOVEL": "shovel", "AXE": "axe", "HAMMER": "hammer",
         "FAN": "fan", "LANTERN": "lantern", "ROD": "fishing rod", "POLE": "fishing pole", "SKETCHBOOK": "sketchbook"}


def sex_of(variant: str) -> str:
    v = variant.upper()
    if "_FEMALE" in v:
        return "f"
    if re.search(r"_MALE(_|$)", v):
        return "m"
    return "any"


LABEL_FIX = {   # the few the word rules say badly
    "WORLD_HUMAN_SLEEP_GROUND_PILLOW_NO_PILLOW": "sleep on the bare ground, no pillow",
    "WORLD_HUMAN_SLEEP_GROUND_ARM": "sleep on the ground, head on your arm",
    "WORLD_HUMAN_SLEEP_GROUND_PILLOW": "sleep on the ground, head on a pillow",
    "WORLD_HUMAN_SIT_FALL_ASLEEP": "sit on the ground and doze off",
    "PROP_HUMAN_SLEEP_BED_PILLOW": "sleep in the bed", "PROP_HUMAN_SLEEP_BED_PILLOW_HIGH": "sleep in the bed",
    "PROP_HUMAN_SLEEP_BED_PILLOW_LEFT": "sleep in the bed (left side)",
    "PROP_HUMAN_SLEEP_BED_PILLOW_RIGHT": "sleep in the bed (right side)",
    "WORLD_HUMAN_FIRE_SIT": "sit by the fire", "WORLD_HUMAN_FIRE_STAND": "stand warming up by the fire",
    "WORLD_HUMAN_FIRE_TEND_KNEEL": "kneel and tend the fire", "WORLD_HUMAN_RE_LOST_DRUNK_SLEEP": "sleep it off, drunk",
    "WORLD_HUMAN_SIT_GROUND_DRINK_DRUNK": "sit on the ground, drunk, with a bottle",
    "WORLD_HUMAN_CAULDRON_STIR_ALWAYS": "stir the cooking pot", "WORLD_HUMAN_BROOM": "sweep with a broom",
    "WORLD_HUMAN_SMOKE": "smoke a cigarette", "WORLD_HUMAN_DRINKING": "stand and drink",
    "WORLD_HUMAN_SIT_GROUND": "sit on the ground", "WORLD_HUMAN_LEAN_BACK_WALL": "lean back against a wall",
}


def label_of(name: str) -> str:
    if name in LABEL_FIX:
        return LABEL_FIX[name]
    name = re.sub(r"_NO_([A-Z]+)", r"_WITHOUT_\1", name)
    toks = [t for t in name.split("_") if t not in NOISE and t not in NAMES and not t.isdigit()]
    words, seen = [], set()
    for t in toks:
        w = WORDS.get(t, t.lower())
        if w and w not in seen:
            words.append(w)
            seen.add(w)
    text = " ".join(words).replace("  ", " ").strip()
    text = re.sub(r"\bsit sit\b", "sit", text)
    text = re.sub(r"^sit sitting\b", "sit", text)
    return text or name.lower()


def main():
    sc = json.loads((DATA / "scenarios.json").read_text())
    listed = []
    lp = HERE / "ScenariosListRDR2.txt"
    if lp.exists():
        listed = [l.strip() for l in lp.read_text(encoding="utf-8", errors="replace").splitlines()
                  if re.fullmatch(r"[A-Z0-9_]{4,}", l.strip())]
    bases = {k: list(v) for k, v in sc.items()}
    known = set(bases) | {v for vs in bases.values() for v in vs}
    added = 0
    for n in listed:                                         # the community list: extra variants / scenarios
        if n in known:
            continue
        base = max((b for b in bases if n.startswith(b + "_")), key=len, default=None)
        if base and re.search(r"_(MALE|FEMALE)_[A-Z]$", n):
            bases[base].append(n)
        else:
            bases.setdefault(n, [])
        known.add(n)
        added += 1
    anims = json.load(gzip.open(DATA / "db" / "anims.json.gz"))
    base_clip, idle_clip = {}, {}
    for d, clips in anims.items():                           # a variant's own loop: its "@base", else its first idle
        if "@" not in d or not clips:
            continue
        if d.endswith("@base"):
            path = d.split("@", 1)[1][:-len("@base")].replace("@", "_")
            clip = "base" if "base" in clips else next((c for c in clips if "base" in c), None)
            if clip:
                base_clip.setdefault(path, (d, clip))
        elif d.endswith("@idle_a"):
            path = d.split("@", 1)[1][:-len("@idle_a")].replace("@", "_")
            clip = next((c for c in clips if re.fullmatch(r"idle_[a-z]", c)), None)
            if clip:
                idle_clip.setdefault(path, (d, clip))
    for k, v in idle_clip.items():
        base_clip.setdefault(k, v)
    out, n_clip = [], 0
    for name in sorted(bases):
        if not name.startswith(("WORLD_HUMAN_", "PROP_HUMAN_", "WORLD_CAMP_", "PROP_CAMP_", "GENERIC_")) or EXCLUDE.search(name):
            continue
        toks = set(name.split("_"))
        if toks & {"PICKUP", "PUTDOWN", "PUT"} and not toks & {"SIT", "SEAT", "LEAN"}:
            continue                                         # single pick-up / put-down beats, not something to "do"
        variants = {"m": [], "f": [], "any": []}
        for v in bases[name]:
            if EXCLUDE.search(v) and not v.startswith(name):
                continue
            variants[sex_of(v)].append(v)
        clips = {}
        for v in bases[name] or [name]:
            hit = base_clip.get(v.lower())
            if hit:
                clips[v] = list(hit)
        n_clip += len(clips)
        sexes = sorted(({"m", "f"} if variants["any"] or not bases[name] else set()) |
                       ({"m"} if variants["m"] else set()) | ({"f"} if variants["f"] else set()))
        posture = next((p for p, ks in POSTURE if toks & ks), "stand")
        needs = next((n for n, ks in NEEDS if toks & ks), "")
        soft = ""
        if name.startswith(("WORLD_HUMAN_", "WORLD_CAMP_")) and needs in ("fire", "railing", "wall", "ledge", "grave"):
            soft, needs = needs, ""                          # a WORLD_ one plays anywhere; it's just nicer at a fire / wall
        if name.startswith(("PROP_HUMAN_", "PROP_CAMP_")) and not needs:
            needs = "spot"                                   # a PROP_ scenario plays at its own furniture point
        concepts = sorted(c for c, ks in CONCEPT_TOKENS.items() if toks & ks)
        props = sorted({p for t, p in PROPS.items() if t in toks})
        out.append({"id": name, "kind": "scenario", "label": label_of(name), "concepts": concepts, "posture": posture,
                    "needs": needs, "soft": soft, "sexes": sexes, "props": props,
                    "variants": {k: v for k, v in variants.items() if v}, "clips": clips})
    emotes = json.loads((DATA / "emotes.json").read_text())
    cat = {"REACTION": 0, "ACTION": 1, "TAUNT": 2, "GREET": 3, "DANCE": 5, "TWIRL": 4}
    for e in emotes:
        parts = e.split("_")
        kind = parts[2] if len(parts) > 2 else "ACTION"
        if kind == "TWIRL":
            continue                                         # gun twirls need a gun in hand - not an everyday thing
        words = [w.lower() for w in parts[3:] if not w.isdigit()]
        lbl = " ".join(words).replace("smoke cigarette", "smoke a cigarette").replace("wet your whistle", "take a swig")
        toks = set(parts)
        concepts = sorted(c for c, ks in CONCEPT_TOKENS.items() if toks & ks) or (["dance"] if kind == "DANCE" else [])
        out.append({"id": e, "kind": "emote", "cat": cat.get(kind, 1), "label": lbl + " (a quick gesture)",
                    "concepts": concepts, "posture": "stand", "needs": "", "sexes": ["f", "m"], "props": []})
    doc = {"_readme": ["Built by source/tools/build_catalog.py - edit that, not this file.",
                       "Everything a person can do: game scenarios (with their per-sex variants and each variant's own",
                       "base loop clip as a fallback) and KIT emotes. The brain searches this by meaning."],
           "count": len(out), "with_clip_fallback": n_clip, "extra_from_list": added, "entries": out}
    (DATA / "activity_catalog.json").write_text(json.dumps(doc, indent=0, sort_keys=False), encoding="utf-8")
    print(f"{len(out)} entries ({sum(1 for x in out if x['kind'] == 'scenario')} scenarios, "
          f"{sum(1 for x in out if x['kind'] == 'emote')} emotes), {n_clip} variant clips, {added} names added from the list")


if __name__ == "__main__":
    main()
