"""Builds NpcVoice's RDR2 database (brain/data/db/*.json[.gz]) from femga/rdr3_discoveries (community-extracted
game data). Usage: python3 -I build_db.py <path to rdr3_discoveries> <output dir>

Every output keeps names + hashes exactly as extracted; nothing is invented. Locations come with real coordinates.
"""
import gzip, json, math, re, sys
from pathlib import Path

SRC, OUT = Path(sys.argv[1]), Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)


def joaat(s: str) -> int:
    h = 0
    for c in s.lower().encode():
        h = (h + c) & 0xFFFFFFFF; h = (h + (h << 10)) & 0xFFFFFFFF; h ^= h >> 6
    h = (h + (h << 3)) & 0xFFFFFFFF; h ^= h >> 11; h = (h + (h << 15)) & 0xFFFFFFFF
    return h


def text(p):
    return (SRC / p).read_text(encoding="utf-8", errors="replace")


def save(name, data, gz=False):
    raw = json.dumps(data, separators=(",", ":"), ensure_ascii=False).encode()
    if gz:
        (OUT / (name + ".json.gz")).write_bytes(gzip.compress(raw, 9))
    else:
        (OUT / (name + ".json")).write_bytes(raw)
    n = len(data)
    print(f"{name:22s} {n:8d} entries  {len(raw) / 1e6:6.2f} MB{' (gz)' if gz else ''}")
    return n


stats = {}
# ── objects / props ──
objs = {}
for m in re.finditer(r'\[(-?\d+)\]\s*=\s*"([^"]+)"\s*,\s*--\s*hex_hash:\s*0x([0-9A-Fa-f]+)\s*--\s*([^|\n]*)\|\s*([^\s]+)', text("objects/object_list.lua")):
    objs[m.group(2)] = {"h": int(m.group(3), 16), "cat": m.group(4).strip(), "rpf": m.group(5).strip()}
stats["objects"] = save("objects", objs, gz=True)

# ── vehicles ──
veh = {}
for m in re.finditer(r'\[0x([0-9A-Fa-f]+)\]\s*=\s*"([^"]+)"', text("vehicles/vehicles_list.lua")):
    veh[m.group(2)] = int(m.group(1), 16)
stats["vehicles"] = save("vehicles", veh)

# ── peds (+ how many outfit variations) ──
peds = {}
for m in re.finditer(r'\{0x([0-9A-Fa-f]+),"([^"]+)",(\d+),\}', text("peds/peds_list.lua")):
    peds[m.group(2)] = {"h": int(m.group(1), 16), "outfits": int(m.group(3))}
stats["peds"] = save("peds", peds)


def lua_dict_of_lists(src):
    out, cur = {}, None
    for line in src.splitlines():
        k = re.match(r'\s*\["([^"]+)"\]\s*=\s*\{', line)
        if k:
            cur = out.setdefault(k.group(1), [])
            continue
        v = re.match(r'\s*"([^"]+)"\s*,?', line)
        if v and cur is not None:
            cur.append(v.group(1))
        if re.match(r'\s*\},?\s*$', line):
            pass
    return out


# ── animations: every dictionary and its clips ──
anims = lua_dict_of_lists(text("animations/ingameanims/ingameanims_list.lua"))
stats["anim_dicts"] = save("anims", anims, gz=True)
stats["anim_clips"] = sum(len(v) for v in anims.values())
print(f"{'':22s} {stats['anim_clips']:8d} clips")

# ── scenarios with conditional (male/female/prop) variations ──
scen = lua_dict_of_lists(text("animations/scenarios/scenario_types_with_conditional_anims.lua"))
stats["scenarios"] = save("scenarios_conditional", scen)

# ── emotes ──
emotes = re.findall(r'"(KIT_EMOTE_[A-Z0-9_]+)"', text("animations/kit_emotes_list/kit_emotes_list.lua"))
stats["emotes"] = save("emotes", sorted(set(emotes)))

# ── clothes: every clothing item with its category (for undress/dress + 'what is he wearing') ──
cloth = []
for m in re.finditer(r'\{hashname="([^"]*)",category_hashname="([^"]*)",ped_type="([^"]*)",is_multiplayer=(\w+),category_hash=0x([0-9A-Fa-f]+),hash=0x([0-9A-Fa-f]+)', text("clothes/cloth_hash_names.lua")):
    cloth.append({"n": m.group(1), "cat": m.group(2), "sex": m.group(3), "mp": m.group(4) == "true",
                  "ch": int(m.group(5), 16), "h": int(m.group(6), 16)})
stats["clothes"] = save("clothes", cloth, gz=True)
cats = sorted({c["cat"] for c in cloth if c["cat"]})
save("cloth_categories", {c: joaat(c) for c in cats})

# ── weapons ──
weap = re.findall(r'\{`(weapon_[a-z0-9_]+)`,`(group_[a-z0-9_]+)`', text("weapons/weapons.lua"))
stats["weapons"] = save("weapons", {w: g for w, g in weap})

# ── propsets (camps, tents, tables...) and pickups ──
propsets = re.findall(r'"(p[gs]_[a-z0-9_]+)"', text("objects/propsets_list.lua"))
stats["propsets"] = save("propsets", sorted(set(propsets)))

# ── audio: soundsets with sounds, music events ──
stats["soundsets"] = save("soundsets", lua_dict_of_lists(text("audio/soundsets/soundsets.lua")))
stats["music_events"] = save("music_events", re.findall(r'"([A-Z0-9_]+)"', text("audio/music_events/music_events.lua")))

# ── PLACES: interiors (real buildings with coordinates) ──
TOWN = {"val": "Valentine", "rho": "Rhodes", "bla": "Blackwater", "new": "Saint Denis", "nbx": "Saint Denis",
        "str": "Strawberry", "ann": "Annesburg", "van": "Van Horn", "arm": "Armadillo", "tum": "Tumbleweed",
        "eme": "Emerald Ranch", "lag": "Lagras", "wal": "Wallace Station", "rig": "Riggs Station", "bra": "Braithwaite Manor",
        "can": "Canebreak Manor", "cal": "Caliga Hall", "sha": "Shady Belle", "bee": "Beecher's Hope", "lak": "Lakay", "agu": "Aguasdulces",
        "cor": "Cornwall Kerosene", "bur": "Butcher Creek", "but": "Butcher Creek", "col": "Colter", "flt": "Flatneck",
        "mac": "MacFarlane's Ranch", "pro": "Pronghorn Ranch", "dov": "Doverhill", "hea": "Heartlands"}
KIND = [("saloon", "saloon"), ("bank", "bank"), ("sheriff", "sheriff office"), ("police", "police station"),
        ("jail", "jail"), ("calaboose", "jail"), ("genst", "general store"), ("grocery", "general store"),
        ("gunsmith", "gunsmith"), ("gunshop", "gunsmith"), ("doctor", "doctor"), ("pharmacy", "doctor"),
        ("hotel", "hotel"), ("roomnbath", "hotel"), ("whore", "brothel"), ("church", "church"), ("1rmchurch", "church"),
        ("barber", "barber"), ("tailor", "tailor"), ("photo", "photo studio"), ("theater", "theater"),
        ("train", "train station"), ("depot", "station"), ("station", "station"), ("stable", "stable"),
        ("fenceshop", "fence"), ("mansion", "mansion"), ("manor", "mansion"), ("farmhouse", "farmhouse"),
        ("farmhse", "farmhouse"), ("barn", "barn"), ("cabin", "cabin"), ("shack", "shack"), ("house", "house"),
        ("res_", "house"), ("_res", "house"), ("cottage", "house"), ("homestead", "house"), ("hut", "shack"), ("cave", "cave"), ("mine", "mine"), ("tunnel", "tunnel"),
        ("school", "school"), ("boathouse", "boathouse"), ("lighthouse", "lighthouse"), ("blacksmith", "blacksmith"),
        ("gamble", "gambling hall"), ("trolley", "streetcar depot"), ("dockhouse", "dock house"), ("bunkhouse", "bunkhouse")]
LIVE_IN = {"farmhouse", "house", "cabin", "shack", "mansion", "bunkhouse", "hotel", "brothel"}


def kind_of(n):
    for k, v in KIND:
        if k in n:
            return v
    return "building"


places = []
for m in re.finditer(r'\[(\d+)\]\s*=\s*\{x=([-\d.]+),y=([-\d.]+),z=([-\d.]+),typeHashId=(-?\d+),typeHashName="([^"]+)"', text("interiors/interiors_coords_and_hashes.lua")):
    n = m.group(6)
    if n.startswith("mp0") or "tunnel" in n:
        continue
    k = kind_of(n)
    places.append({"id": int(m.group(1)), "name": n, "kind": k, "town": TOWN.get(n.split("_")[0], ""),
                   "x": round(float(m.group(2)), 2), "y": round(float(m.group(3)), 2), "z": round(float(m.group(4)), 2),
                   "lived_in": k in LIVE_IN, "src": "interior"})
# landmarks from map chunks (imaps) whose names say what they are (churches, saloons...)
for m in re.finditer(r'hashname="([^"]+)",dec_hash=-?\d+,x=([-\d.]+),y=([-\d.]+),z=([-\d.]+)', text("imaps/imaps_with_coords_and_heading.lua")):
    n = m.group(1)
    if "_strm_" in n or "_lod" in n or "interior" in n:
        continue
    for key, kind in (("church", "church"), ("saloon", "saloon"), ("graveyard", "graveyard"), ("cemetery", "graveyard"),
                      ("brothel", "brothel"), ("bathhouse", "bath house"), ("camp", "camp"), ("ranch", "ranch"),
                      ("farm", "farm"), ("mill", "mill"), ("bridge", "bridge"), ("dock", "dock"), ("fort", "fort"),
                      ("ruins", "ruins"), ("well", "well")):
        if key in n:
            places.append({"name": n, "kind": kind, "town": TOWN.get(n.split("_")[0], ""), "x": round(float(m.group(2)), 2),
                           "y": round(float(m.group(3)), 2), "z": round(float(m.group(4)), 2),
                           "lived_in": kind in ("farm", "ranch"), "src": "imap"})
            break
# households: the open-world homes that aren't separate interiors (homesteads, cabins, shacks built into the map) -
# map chunks named after a home; never an outbuilding, a ruin, a construction stage or a multiplayer piece, and not a
# second entry for a place we already have
HOME_WORDS = (("farmhouse", "farmhouse"), ("homestead", "house"), ("cottage", "house"), ("cabin", "cabin"),
              ("shack", "shack"), ("shanty", "shack"), ("hovel", "shack"), ("manor", "mansion"), ("mansion", "mansion"),
              ("plantation", "mansion"), ("house", "house"))
NOT_HOME = ("interior", "_lod", "slod", "_strm", "milo", "boathouse", "dockhouse", "carriage", "warehouse", "outhouse",
            "henhouse", "hen_house", "smokehouse", "bathhouse", "lighthouse", "guardhouse", "courthouse", "schoolhouse",
            "icehouse", "pumphouse", "housewares", "burnt", "ruin", "stage", "const", "chest", "minigame", "companion",
            "mp0", "mp_", "_es", "debris", "fire", "destroy", "props", "prop_", "decal", "grass", "_veg", "fence",
            "roadhouse", "slaughterhouse", "packinghouse", "storehouse", "clubhouse", "roundhouse", "gatehouse",
            "_gate", "sign", "door", "window", "_occl", "story", "camp", "long_", "boat")
for m in re.finditer(r'hashname="([^"]+)",dec_hash=-?\d+,x=([-\d.]+),y=([-\d.]+),z=([-\d.]+)', text("imaps/imaps_with_coords_and_heading.lua")):
    n = m.group(1)
    low = n.lower()
    if any(w in low for w in NOT_HOME):
        continue
    kind = next((k for w, k in HOME_WORDS if w in low), None)
    if not kind:
        continue
    x, y, z = round(float(m.group(2)), 2), round(float(m.group(3)), 2), round(float(m.group(4)), 2)
    if any(math.hypot(p["x"] - x, p["y"] - y) < 25 for p in places if p.get("lived_in") or p["kind"] in ("farm", "ranch")):
        continue
    places.append({"name": n, "kind": kind, "town": TOWN.get(low.split("_")[0], ""), "x": x, "y": y, "z": z,
                   "lived_in": True, "src": "imap"})
# towns: centre = mean of the places whose name says the town; others get the nearest town within 400 m
centres = {}
for t in {x["town"] for x in places if x["town"]}:
    pts = [x for x in places if x["town"] == t]
    centres[t] = (sum(x["x"] for x in pts) / len(pts), sum(x["y"] for x in pts) / len(pts))
for x in places:
    if not x["town"]:
        best = min(centres.items(), key=lambda kv: math.hypot(kv[1][0] - x["x"], kv[1][1] - x["y"]))
        if math.hypot(best[1][0] - x["x"], best[1][1] - x["y"]) < 400:
            x["town"] = best[0]
save("towns", {t: {"x": round(c[0], 1), "y": round(c[1], 1)} for t, c in centres.items()})
stats["places"] = save("places", places)

# ── doors (every door of every building, with coordinates: entrances, houses with beds) ──
doors = []
for m in re.finditer(r'\[(-?\d+)\]\s*=\s*\{(-?\d+),(-?\d+),"([^"]+)",([-\d.]+),([-\d.]+),([-\d.]+)\}', text("doorHashes/doorhashes.lua")):
    doors.append({"h": int(m.group(1)), "model": m.group(4), "x": round(float(m.group(5)), 2), "y": round(float(m.group(6)), 2),
                  "z": round(float(m.group(7)), 2)})
stats["doors"] = save("doors", doors)

# ── beds and other furniture people can use (object models) ──
furniture = {k: [n for n in objs if re.search(p, n)] for k, p in {
    "bed": r"(^|_)bed(?!pan|roll_?mat)[a-z0-9]*(\d|x)|bedroll|cot\d|mattress", "chair": r"chair|stool|bench",
    "table": r"(^|_)table", "bath": r"bathtub|tub0", "fire": r"campfire|fireplace"}.items()}
stats["furniture"] = save("furniture", {k: sorted(v) for k, v in furniture.items()})

(OUT / "SOURCE.txt").write_text("Built by tools/build_db.py from https://github.com/femga/rdr3_discoveries "
                                "(community-extracted RDR2 data).\n" + json.dumps(stats, indent=1), encoding="utf-8")
print(json.dumps(stats))
