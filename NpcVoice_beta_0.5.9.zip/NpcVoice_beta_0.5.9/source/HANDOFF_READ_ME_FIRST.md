# NpcVoice – handoff notes (beta 0.1)

## Architecture
- `asi/NpcVoice.cpp` → `NpcVoice.asi` (mingw, `build.sh`). Thin executor: focus/PTT detection, live state ticks
  (10 Hz while anyone is managed, 1 Hz otherwise), nearby scan (2 s), task/emote/scenario/anim/mood/money
  primitives, subtitles + toasts. TCP client → 127.0.0.1:47812.
  Protocol: ASI→brain JSON lines (`hello, tick, focus, engage_req, ptt, event, act_result, nearby`);
  brain→ASI space-separated, percent-encoded tokens (`engage_ok/deny, say, say_stop, task, emote, scen, anim,
  mood, money, override, release, hud, state, toast`).
- `brain/` Python (asyncio). `brain.py` orchestration, `context.py` prompt + reply parsing, `actions.py` action
  catalog (data-driven: add actions without touching C++), `safety.py` content rules (incl. game-state consent
  checks, child rules), `memory.py` persistent identities (fingerprint = model+outfit hash; nemesis grudge/rank),
  `persona.py` seeded procedural characters, `game.py` tick state + event diffing, `audio.py` mic + 3D voice.

## Native safety
- Every native lives in the `g_nat[]` table. `rig/verify_natives.py` checks each hash against the RDR3 DB:
  must exist, build ≤ 1311, name must match, no stray hash literals. 100/100 pass.
  The one native not in the DB is text scale `0x4170B650590B3B00`, proven by Bandit_Hideouts.
- First call of each native writes `NpcVoice_native_guard.txt` before calling and clears it after. A crash
  inside a first call → next start adds that native to `[NATIVES] DISABLE=` in NpcVoice.ini and shows a toast.
  Rig-tested (`host.exe guardtest`).
- `invoke()` evaluates all args before `nativeInit`. The fake hook counts nested native calls: 0.
- Brain writes `logs/native_proof.txt`: which of our natives are also found in the user's other .asi files.

## Tests
- `rig/run_rig.sh`: fake ScriptHookRDR2.dll (fibers, sim world) + host.exe under Wine + brain `--fake-ai`.
  35 checks (incl. carrying / dropping a body): connect, story-ped deny (CS_ and unlisted mission ped), hold/face/block, subtitles, gunpoint → hands
  up + fear emote, child threatened → flees, freed → flees, mount nearest horse, money, follow + persistence,
  rider hold + release-on-walk-away + resume wander, interrupt, follower death, every native handled, no nesting.
- `brain/tests/test_brain.py` (38), `test_recognition.py` (4), `test_bodies.py` (8).

## Not verified in the real game (beta)
Focus detection natives, mounted/driver hold, TASK_PLAY_EMOTE_WITH_HASH on ambient NPCs, facial talking mood /
idle override, subtitle centring estimate, ride-with-me seat indices (horse seat 0), drop weapon pickup, NpcHookups
named-event semantics (logged as found/ACTIVE/inactive), real LLM JSON quality and latency (AI hosts were blocked
from the dev sandbox).

## 0.3.2 – orders that stick, report to the law, real stashes
- **Order keeper** (`NpcVoice.cpp`, `order_*`): `dismount` → O_FOOT, `mount_near` → O_MOUNT, `ride_with_player` → O_RIDE /
  O_VEH. Checked every 400 ms in `upkeep()` for every managed ped. O_FOOT: back on a horse → TASK_DISMOUNT_ANIMAL again
  (max 8), once off → follow-up task (face the player while engaged, else wander) so the primary task slot is never empty.
  O_MOUNT/O_RIDE: not seated after 14 s → `SET_PED_ONTO_MOUNT` if within 12 m, else mount task again (max 4); a passenger who
  is off while the player rides gets back on; while the player is off the horse nothing is forced. O_VEH: same with
  `SET_PED_INTO_VEHICLE`. Passengers get `SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(NEVER)`, restored when the order ends.
  Orders end on flee/combat/follow/goto/cover (and, except O_FOOT, wander/hands up/cower/leave vehicle). On release:
  O_FOOT → wander on foot; O_RIDE/O_VEH → get off the player's horse/wagon. Failure → `event order_failed` to the brain.
- **No emote on top of a move**: ASI skips `emote` while an order is unsettled or the ped is a rider/passenger (the 0.3.1
  "she paid but never got on" bug: the coin emote replaced TASK_MOUNT_ANIMAL). `actions.plan()` also strips
  emote/scenario/anim prims from other actions in a turn that has a MOVING action.
- **Law** (`law.py`): `report_to_law` → reporter runs to the nearest lawman in the 45 m scan (`goto_player t=<law>`),
  both become actors, 2–4 LLM lines, then `Director.law_questions_player`. No lawman → sev-3 witnessed deed (heat).
  Lawmen (`conv.flags.is_law`) get `arrest` → `crime <seq> CRIME_x <bounty> <lawman>` → `_REPORT_CRIME` (0xF60386770878A98F).
- **Stash** (`journey.py` kind `stash`): `mark_stash` (unguided) or `lead_to kind=stash`; 250–900 m; strongbox + crate +
  lantern; route cleared at 30 m; within 2.6 m of the box → real money (`money` prim) + toast.
- New natives (all verified against the RDR3 DB, build ≤ 1311): SET_PED_ONTO_MOUNT, SET_PED_INTO_VEHICLE,
  SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE, _REPORT_CRIME. 139/139 pass `rig/verify_natives.py`.
- Brain waits up to 1.5 s for a fresh tick of the ped before deciding (rig found: a turn could run on an empty state).
- Tests: `rig/run_orders.sh` (29 checks), `brain/tests/test_orders.py` (20).
- Not verified in the real game: SET_PED_ONTO_MOUNT seat 0 on the player's horse, _REPORT_CRIME bounty=0 (the game picks
  the amount), how quickly ambient riders try to remount.

## 0.4.0 – from the 0.3.1 in-game logs (tram driver, wagon, Lula, Louis, the body)
- **Aim ≠ focus**: `ped_tick` only reports `aimed` when `player_weapon_threat()` (a real weapon, not unarmed/lasso/lantern/
  binoculars...). Unarmed right-mouse is the game's interaction lock-on and was being reported as aiming.
- **PTT target** (`pick_talk_target`): partner within KEEP_TALKING_DIST wins unless a focus is held ≥ 350 ms and began
  ≥ 700 ms after a pause/freeze; no partner → current focus at once, else a focus released < 0.5 s ago (held ≥ 0.25 s),
  else the nearest companion within 15 m. `camera_pick()` = focus fallback while INPUT_AIM / lock-on is held
  (smallest offset from the camera ray, ≤ body width + 5°). The rig's `talk()` now holds focus 26 frames.
- **Vehicles**: hold for a driver = `BRING_VEHICLE_TO_HALT` (was TASK_STAND_STILL, which doesn't stop a wagon);
  passengers and streetcar drivers (`IS_THIS_MODEL_A_TRAIN`) are left alone. Prims `veh_stop/go/speed/to/waypoint/turn`;
  `veh_tick` re-halts if the wagon rolls again and stops on arrival (`event veh_arrived`). Release: unhalt + drive wander.
  Ticks/engage carry `drv`, `tram`, `vspd`, `pin` (player in that vehicle) → brain flag `player_aboard` keeps the talk.
- **Activities** (`activities.py`): concepts from words → score all human scenarios (sex, sitting, furniture, extra
  stuff, learned ok/fail) → brain tries up to 4; ASI `scen_watch` checks `IS_PED_USING_SCENARIO_HASH` after 3.5 s →
  `scen_check` → `learned_activities.json`. Furniture words → `use_spot` (`TASK_USE_NEAREST_SCENARIO_TO_COORD`, real
  points). Fallback emote. Old sit/smoke/drink/eat/lean/play_instrument actions route through it.
- **Targets**: `surroundings.describe` tags people [P1..] and bodies [B1..] → `conv.targets`; actions `attack_person`,
  `go_to`, `inspect_body`, `talk_to`. Nearby scan: bodies within 70 m always included (max 6), up to 30 people.
- **Group**: `listeners()` = companions within 15 m; group words / names → `route_group` (redirect or sequential
  follow-up turns).
- **Pressure** line per turn (`context.pressure_note`), scared peds flee on `end()`, background companions only react to
  PERSONAL_EVENTS, director lawman waits while `talking_recently()`; persona names by model (Chinese / Spanish / Creole)
  and job fitted to the situation (`fit_job_to_situation`).
- New natives (all ≤ 1311, verified): BRING_VEHICLE_TO_HALT, STOP_BRINGING_VEHICLE_TO_HALT, TASK_VEHICLE_DRIVE_TO_COORD,
  SET_DRIVE_TASK_CRUISE_SPEED, IS_WAYPOINT_ACTIVE, GET_WAYPOINT_COORDS, IS_THIS_MODEL_A_TRAIN, GET_PED_IN_VEHICLE_SEAT,
  GET_ENTITY_HEADING, IS_PED_IN_VEHICLE, IS_PED_USING_SCENARIO_HASH, TASK_USE_NEAREST_SCENARIO_TO_COORD,
  DOES_SCENARIO_EXIST_IN_AREA, _GET_SCENARIO_POINT_TYPE_PED_IS_USING. 153/153 pass verify_natives.py.
- Tests: `rig/run_life.sh` (30), `brain/tests/test_v040.py` (34).
- Unverified in game: TASK_VEHICLE_DRIVE_TO_COORD drivingStyle/mode values (0 / 786603) for wagons, BRING_VEHICLE_TO_HALT
  duration units, which scenarios play in place on ambient peds (the learning covers that), camera_pick feel.

## 0.5.0 – database, undress/dress, NpcHookups bridge, daily life
- `brain/data/db/` built by `source/tools/build_db.py` from femga/rdr3_discoveries; `npcvoice/gamedb.py` loads it lazily
  (places, towns, doors, objects, anims, clothes...). Journeys pick real destinations (`pick_destination`), anchored at
  the nearest real door for buildings.
- Undress/dress (`undress_ped` / `dress_ped` in NpcVoice.cpp): the Unstrip recipe (see `source/reverse_engineering/
  RE_Unstrip_mods.md`): save 16 slots, remove clothing categories, nude UPPERTORSO/LOWERTORSO + HAND/FEET skin pieces
  for the tone read from the hand albedo, update; dress = remove all + re-apply the 16 slots a frame later. Ticks carry
  `cu`/`cl`/`nude`/`hk` once a second; `Brain.watch_body` decides who did it and reacts (consent flags).
- NpcHookups bridge (`nh_*`, see `RE_NpcHookups.md`): Pick() by RVA 0x8130 and g_pending|=2 (goodbye), build-locked
  (6AE4B4EA / 0x59000 + 16 code bytes of Pick and OnKey). Scenes are detected with IS_ENTITY_PLAYING_ANIM on the
  sal1_18 clips. make_love between two NPCs needs both convs' `consent_love`.
- `npcvoice/daylife.py`: home/work places, routine, journal (routine + today's memory events), appointments.
- Actions added: undress, dress, let_him_undress_you, agree_to_make_love, make_love, stop_making_love, start_play,
  end_play (stop word also from the player's utterance), take_bribe, work_for_him, meet_later.
- Tests: `brain/tests/test_v050.py` (28); rig `run_life.sh` grew the 0.5.0 part (fake outfits + `fake_strip`).
- 161/161 natives verified. Not verified in the game: nude pieces on ambient peds, Pick/Goodbye via the bridge.

## 0.5.1 – from the 15:48-16:55 logs (Hattie's family, Tommy, Jesse, Ruth, Annesburg) + couples
- `data.CHILD_PED`: only real child models (street kids, newspaper boy, starving kid, story kids). The CzP/EmR "son"/
  "daughter" models are young adults (ped list age "Young"). `MODEL_JOBS`/`model_job()`: job + look from the model name
  (miner -> coal miner, blind, lawman...); persona uses it.
- `brain.on_engage_req`: re-engaging an ENDED companion conv resets `ending/after_actions/pending/busy` (Hattie: every X
  ended again 0.1 s later). `wander` clears following.
- `surroundings`: one name per person for everyone (`NAMES`, key = model-outfit), mirrored relations (`PAIRS`), glued
  adults (<1.6 m / same horse) are a couple or kin, `HANDLE_IDENT` (= brain.handle_ident) gives spawned/met people their
  real persona; `conv.target_words` lets actions target by name/relation (`actions.target_by_words`). Engaged peds are
  no longer hidden from each other's lists.
- `context`: real places within 350 m (gamedb), props rule, pain rule, kids may follow; `actions.go_to_place` (DB place by
  word, else the player's camera point; "down/stairs" lowers z).
- `brain.implied_activity`: the player asked for an everyday thing + the NPC agreed -> activity from the player's words
  (replaces cower/kneel). `brain.pain_reaction` + `game.hurt_text`: instant scream/flee/cower/fight on damage.
- `journey`: real kid models only, a daughter <16 comes as 17 (no girl model), family models from the guide's model
  family + spawn flag `like=<guide>` (plugin matches skin tone), kin share the surname once, mirrored relations both ways,
  unknown script speakers skipped, chores resumed after arrival, guide introduces. `gamedb.pick_destination` always
  returns a real place; named towns capped (2.5 km homes / 4 km named buildings); defaults 250-900 m.
- `director.vanilla_busy()` (wanted / shooting / >=2 people fleeing in 40 m -> 20 s quiet), body scenes only with a finder
  <18 m in LOS, one per 150 s, 2-3 lines, accuse only if `seen_by`; dead names from `surroundings.NAMES` only.
- `couples.py`: house couples (find_bed -> spawn at the bed, like=, undress, `couple` runner), walk-in (LOS + distance +
  crouch), `invite_home` (lead the way: mount_near / spawned horse, partner `ride_behind`, `goto_any`, wait at door,
  find_bed), `make_love` on a known bed or when NpcHookups is missing, two-voice lines (`talk_tick`).
- ASI: natives PLAY_PAIN, GET_NUM_META_PED_OUTFITS, _EQUIP_META_PED_OUTFIT_PRESET, GET_PLAYER_WANTED_LEVEL,
  TASK_PLAY_ANIM_ADVANCED, GET_CLOSEST_OBJECT_OF_TYPE, STOP_ANIM_TASK, SET_ENTITY_COORDS, CLEAR_PED_TASKS_IMMEDIATELY,
  TASK_GO_TO_COORD_ANY_MEANS (171/171 verify_natives). `tone_tick` (outfit presets until the hand-albedo tone matches),
  `hush_bystanders` (ambient speech within 30 m while an AI line plays; ini MUTE_BYSTANDERS_WHILE_TALKING), pain on
  damage (ini PAIN_VOICE), `find_bed`, `couple`/`couple_stop` (clip pair at one anchor, flags 3593, re-issued every 3 s,
  player gets up with jump/sprint), tasks `pain`, `goto_any`, `ride_behind`; tick `p.wanted`.
- Tests: `brain/tests/test_v051.py` (49). All older brain suites pass. Rig (Wine 9 here): same results as untouched 0.5.0
  on this machine for main/guard/late/journeys; its scenes part is flaky here for both versions.
- NOT verified in the game: PLAY_PAIN pain id 1/2, outfit-preset tone matching, TASK_PLAY_ANIM_ADVANCED flags 3593 and
  bed_z_offset 0.55 on real beds, GET_CLOSEST_OBJECT_OF_TYPE finding interior beds, TASK_GO_TO_COORD_ANY_MEANS riding,
  ride_behind seat 0, GET_PLAYER_WANTED_LEVEL meaning in 1311.

## 0.5.7 - from the 00:02-00:51 logs (Cole Bailey's wagon, Henrietta/Seamus on one horse, Clara/Levi stripped)
- Root cause of "I don't have any passengers": `worldGetAllPeds(arr, 256)` - the pool includes animals; in St Denis the
  people next to you were past slot 256, every St Denis prompt said "Nobody else is around". `PED_POOL_MAX` = 1024 for
  all four scans (nearby, nearest_horse, hush_bystanders, camera_pick).
- `mates_json()` in ped_tick (cached 500 ms): `mates:[{h,m,o,male,alive,how}]` with how = driver|passenger (vehicle
  seats -1..max) / rider (`_GET_RIDER_OF_MOUNT`, this ped sits behind) / behind (pool search <3 m on the same mount).
  Tick + nearby also carry `mr` (rider of their mount). Nearby carries `hog`/`hasw` < 25 m, `lt`/`nude` < 6 m.
- `lt` = `_FIND_ENTITY_LOOTING_PED(ped) == player || _GET_IS_PED_BEING_ROBBED(ped, player, false)` (both build 1207,
  186/186 verify_natives).
- Brain `witness.py`: `mates_of` (tick mates + same vh/mh in the scan), `merge_into_near` (the prompt always has them,
  `how` -> exact wording, `conv.together`), `bring_in_mates` (side engagement: `on_engage_req(side=True)` = own conv,
  `actor 1`, no `engage_ok`, doesn't end the driver), route_group: mates always get an `overheard` event; an utterance
  matching `MATES_RE` / their names -> `group_followups` with the `mates` event (player's words + the driver's line +
  `ACTION_SEEN` of his actions). `on_looted`, `violation_tick` (bands 6 / 3.2 / 1.6 m, 4 s apart, relief > 8 m),
  `on_nearby` (looted / newly nude < 4 m while not in a conversation -> engage + react).
- `context`: "riding on the back of someone else's horse" when `mr`; "WITH YOU RIGHT NOW" line; pressure_note prefix
  for violated+naked (distance, tied, never sexual).
- `drama.py`: SEVERITY looted/tied/stripped; `weigh(victim=)` adds honour (male kin of a woman), TEMPER, age, a gun on
  HIM, tied himself; rage = stake for stripped; `plan_violation`; repeats while she's naked and you're < 2.5 m (45 s).
- Tests: `brain/tests/test_v057.py` (35). All older suites pass (test_voiceclone needs soundfile, as before).
- NOT verified in the game: `_FIND_ENTITY_LOOTING_PED` during the hogtied-loot prompt, `_GET_IS_PED_BEING_ROBBED`
  semantics on 1311, GET_PED_IN_VEHICLE_SEAT on coach rear seats, whether 1024 always covers St Denis (rig not run:
  no Wine here; fakehook stubs added).


## 0.5.8 - from the report after 0.5.7 (house couple standing/dressed, husband behind a wall, saloon couple, flat voices)
- **NpcHookups' real recipe** (read from NpcHookups.asi 6AE4B4EA: Pick -> PlayBase / PinBase / AttachTop / PlayTop,
  tables ATT / ADJ / MAN / ATT_ORIG, LoadConfig defaults ATTACH_MODE=3, MEN_TAKE_MALE_ROLE=1, ROT_Z_CORRECTION=-90,
  RESTART_CLIP_AFTER_MS=900, FREEZE_LOWER_PARTNER=0): base = the man, `TASK_PLAY_ANIM` in place (loop_male, loop_female
  for position 2), SET_ENTITY_COORDS_NO_OFFSET + no ragdoll + no collision between them; top = loop_female ATTACHED to the
  base's bone 0xA7D8 (GET_PED_BONE_INDEX), else SKEL_Pelvis, offsets ATT[pos] with rz-90, flags (0,0,0,0,2,1,0,0).
  Upkeep every 900 ms: re-attach, put the base back if its z left [z-0.5, z+2.5], restart a dropped clip. Couple option
  `pos=1|2|3` (+`swap=1`); without it (or with `anim=` for a pack) the old offset mode. Calibrated hip-anchor mode 3
  (marker objects, M3ToEuler) was NOT reproduced: NpcHookups falls back to these numbers on the pelvis itself.
- **Undress waits**: `undress` prim -> `undress_later` (IS_PED_READY_TO_RENDER, no tone job running), verified 1.5 s later
  by clothes_count, 3 tries.
- **`los <seq> <a> <b>`** -> `{"t":"los","see","d"}`; caps `nh_pos`, `undress_wait`, `los`. 11 natives added, 197/197
  verify_natives, enum/table order checked; fakehook stubs added.
- Brain: `perception.py` (saw / heard a shot / scream / nothing; weapon loudness from db weapons.json), used by
  `brain._death_perceived` and `drama._kin_killed` (new reaction `heard_shot`); `surroundings.family_facts` + prompt
  block "FACTS ABOUT YOUR OWN PEOPLE", `brain.note_told_facts`; `brain.trip_guard`; `couples.onlookers` gate on
  make_love; couple trips and invite_home only to homes (`pick_destination(only=)`); households: `love_start` never
  bails (floor fallback / `no_love`), `alarm_tick` + `_alarm_react`, `intruder`, chat aborts mid-lines; love_poses.json =
  NpcHookups' 3 positions; voices: `llm.EMOTION_STYLE` / `tts_style` (unknown -> no emotion sent, not "fluent"),
  `real_emotion` context overrides.
- Tests: `brain/tests/test_v058.py` (37). All older suites pass (test_v055 has a pre-existing random flake, about 1 in
  10 runs, same as 0.5.7; test_voiceclone needs soundfile).
- NOT verified in the game: the attach numbers on ambient peds / real beds, IS_PED_READY_TO_RENDER on spawned peds,
  MiniMax speech-2.6 reading emotion from the text when none is sent.
- **Voice cloning removed** (user request): voiceclone.py, voice_clone_tool.py, clone/scan/slim .bat, voice_samples/,
  test_voiceclone.py, the [voices] ini section, llm clone_from_wav / upload_clone_audio / clone_voice / NO_CLONE, the
  tts `owner` path, brain note_looks / game_voice, soundfile from the requirements. ASI: look_info (race / tone in
  nearby + engage), the `voice` command, natives _GET_META_PED_RACE and SET_AMBIENT_VOICE_NAME (195/195 verified).
  Stock voices by sex/age (brain.voice_for_ident) are what everyone uses. test_keys.py keeps the multi-key speech checks.

## 0.5.9 - activities that really happen (the "sleep" report)
- `source/tools/build_catalog.py` -> `brain/data/activity_catalog.json`: 361 scenarios (scenarios.json + the 31 extra
  names in `source/tools/ScenariosListRDR2.txt`, the user's list) + 118 KIT emotes. Per entry: label (token rules +
  LABEL_FIX), concepts, posture, needs (hard: bed/chair/bench/table/bar/piano/basin/door/spot; soft for WORLD_*:
  fire/railing/wall/ledge/grave), sexes from the variants (169 male-only), variants per sex, and each variant's own
  loop clip from anims.json.gz (`<cat>@<variant path>@base`, else `@idle_a`): 480 variants have one.
- `activities.py` rewritten: WORDS synonyms (sleep: shut-eye, hit the hay, turn in, go to bed, pass out...; "lie" /
  "crash" / "tired" left out on purpose), options(what, male, model, spots) -> tagged [A1].. (spot / scenario / emote)
  with learned status; variant_for / clip_for; learning per sex AND model in `user_dir()` (NPCVOICE_USER_DIR, else
  Documents\NpcVoice) on top of `data/learned_defaults.json`; the old data/learned_activities.json is merged once.
- `affordances.py`: `spots <seq> <ped> <r>` -> [F1].. (free spots, deduped per kind/place) in every system prompt;
  options in the turn text when the player asks for something to be done; activity args.option.
- `brain.run_activity`: chain spot (use_point, 20 s check) -> scenario with variant (`scen ... <variant>`) -> its loop
  (`anim_try` -> IS_ENTITY_PLAYING_ANIM after 1.5 s) -> next option (max 5) -> emote; honest last_results; `doing()`
  sets doing / posture / asleep. LOVE_ASK no longer matches "to bed" alone.
- `lasting.py`: lie/sit/kneel activities survive the end of the talk (actor 1); wake on damage / hp drop / aim < 25 m /
  player shooting < 35 m (reaction turn), released > 120 m or after 30 min; re-engaging a sleeper -> "woken" event.
- `calibrate.py`: console `calibrate [word|stop]`; spawns A_M_M_ValFarmer_01 + A_F_M_ValTownfolk_01, tries every
  in-place entry (scenario, then clip), learns, writes calibration_report.txt to the user dir.
- ASI 0.5.9: `scen` takes an optional variant (conditionalHash of TASK_START_SCENARIO_IN_PLACE_HASH), `anim_try`,
  `spots`; ScenWatch can watch a clip. caps += scen_variant, anim_try, spots. No new natives (195/195).
- Tests: `brain/tests/test_v059.py` (41). Not verified in the game: the conditionalHash on ambient peds, how idle_a
  loops look when played without the scenario's props, DOES_SCENARIO_EXIST_IN_AREA(mustBeFree) as the "free" flag.
