#!/bin/sh
# Full end-to-end rig: Python brain (fake AI) + real NpcVoice.asi under Wine with a fake ScriptHookRDR2.
cd "$(dirname "$0")"
LINK="$(pwd)/run/link"
LINKW="Z:$(printf '%s' "$LINK" | tr '/' '\\')"
rm -rf "$LINK"; mkdir -p "$LINK"
export TRANSPORT_NOTE=file
B=../brain
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null; sleep 1
rm -rf $B/logs $B/npc_memory $B/NpcVoice_brain.ini run/NpcVoice.log run/NpcVoice.ini run/NpcVoice_native_guard.txt
export NPCVOICE_RIG_SAY="101:hello ma'am|101:hands up or I shoot|103:hands up kid|101:you're free, go home|105:mount up|105:give me your money|105:follow me|105:fuck off and leave, don't follow me anymore|104:hello|104:tell me a long story about your life please"
NPCVOICE_SCENES=0 NPCVOICE_LINK_DIR="$LINK" SDL_AUDIODRIVER=dummy timeout 450 python3 $B/npc_brain.py --fake-ai < /dev/null > run/brain_console.txt 2>&1 &
BP=$!
sleep 3
(cd run && NPCVOICE_LINK_DIR="$LINKW" WINEDEBUG=-all timeout 400 wine host.exe)
R=$?
cp run/NpcVoice.log run/NpcVoice_main.log
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null; sleep 1
# crash-guard test: pretend the last session died inside TASK_COWER's first call
(cd run && printf 'PENDING TASK_COWER 0x3EB1FE9E8E908E15\n' > NpcVoice_native_guard.txt && NPCVOICE_LINK_DIR="$LINKW" WINEDEBUG=-all timeout 60 wine host.exe guardtest)
G=$?
# late brain: game first, brain started ~8 s later
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null; sleep 1
rm -f run/NpcVoice.log run/NpcVoice_native_guard.txt
(cd run && NPCVOICE_LINK_DIR="$LINKW" WINEDEBUG=-all timeout 120 wine host.exe latebrain) &
HP=$!
sleep 8
NPCVOICE_SCENES=0 NPCVOICE_LINK_DIR="$LINK" SDL_AUDIODRIVER=dummy timeout 100 python3 $B/npc_brain.py --fake-ai < /dev/null > run/brain_console2.txt 2>&1 &
wait $HP
L=$?
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null
# living world: NPC-to-NPC scenes
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null; sleep 1
rm -rf $B/logs $B/npc_memory run/NpcVoice.log run/NpcVoice_native_guard.txt run/NpcVoice.ini
NPCVOICE_HOUSEHOLDS=0 NPCVOICE_FORCE_SCENES="worker_quarrel,serial_killer" NPCVOICE_SCENE_COOLDOWN=3 NPCVOICE_LINK_DIR="$LINK" SDL_AUDIODRIVER=dummy timeout 400 python3 $B/npc_brain.py --fake-ai < /dev/null > run/brain_console3.txt 2>&1 &
sleep 3
(cd run && NPCVOICE_LINK_DIR="$LINKW" WINEDEBUG=-all timeout 380 wine host.exe scenes)
S=$?
cp run/NpcVoice.log run/NpcVoice_scenes.log; cp $B/logs/npc_brain.log run/brain_scenes.log 2>/dev/null
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null
./run_journeys.sh > run/journeys_out.txt 2>&1; J=$?
grep -E "PASS|FAIL|RESULT" run/journeys_out.txt
./run_orders.sh > run/orders_out.txt 2>&1
grep -E "PASS|FAIL|RESULT" run/orders_out.txt
./run_life.sh > run/life_out.txt 2>&1
grep -E "PASS|FAIL|RESULT" run/life_out.txt
echo "main=$R guard=$G late=$L scenes=$S journeys=$(grep -o 'journeys=[0-9]' run/journeys_out.txt) orders=$(grep -o 'orders=[0-9]' run/orders_out.txt) life=$(grep -o 'life=[0-9]' run/life_out.txt)"
