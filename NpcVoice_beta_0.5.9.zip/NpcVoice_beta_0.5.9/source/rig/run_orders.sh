#!/bin/sh
# 0.3.2 rig: orders that stick (dismount/ride), report to the law, a real stash
cd "$(dirname "$0")"
LINK="$(pwd)/run/link"
LINKW="Z:$(printf '%s' "$LINK" | tr '/' '\\')"
rm -rf "$LINK"; mkdir -p "$LINK"
B=../brain
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null; sleep 1
rm -rf $B/logs $B/npc_memory run/NpcVoice.log run/NpcVoice_native_guard.txt run/NpcVoice.ini
NPCVOICE_SCENES=0 NPCVOICE_JOURNEY_MIN=800 NPCVOICE_JOURNEY_MAX=900 \
NPCVOICE_RIG_SAY="601:get off your horse|602:ride with me and I'll pay you|603:go on, report me to the sheriff|604:arrest me then|605:where's that treasure you talked about" \
NPCVOICE_LINK_DIR="$LINK" SDL_AUDIODRIVER=dummy timeout 400 python3 $B/npc_brain.py --fake-ai < /dev/null > run/brain_console5.txt 2>&1 &
sleep 3
(cd run && NPCVOICE_LINK_DIR="$LINKW" WINEDEBUG=-all timeout 380 wine host.exe orders)
O=$?
cp run/NpcVoice.log run/NpcVoice_orders.log; cp $B/logs/npc_brain.log run/brain_orders.log 2>/dev/null
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null
echo "orders=$O"
