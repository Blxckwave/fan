#!/bin/sh
set -e
cd "$(dirname "$0")"
mkdir -p run
x86_64-w64-mingw32-g++ -O1 -std=c++17 -shared -static -static-libgcc -static-libstdc++ fakehook.cpp fakehook.def -o run/ScriptHookRDR2.dll
x86_64-w64-mingw32-g++ -O1 -std=c++17 -static host.cpp -o run/host.exe
cp ../asi/NpcVoice.asi run/
