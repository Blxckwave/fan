"""Checks every native hash in NpcVoice.cpp against the RDR3 native DB: exists, build <= 1311, name matches."""
import json, re, sys
from pathlib import Path
GAME_BUILD = 1311
ALLOW_NOT_IN_DB = {0x4170B650590B3B00: "text scale – proven in-game by Bandit_Hideouts (handoff §1)"}
ALLOW_NULLSUB_AFTER_1311 = {"_DISPLAY_TEXT", "_SET_TEXT_COLOR"}   # nullsub only from 1436; correct for 1311
here = Path(__file__).parent
db = {}
for ns, v in json.load(open(here / "natives.json")).items():
    for h, e in v.items():
        db[int(h, 16)] = e
src = (here.parent / "asi" / "NpcVoice.cpp").read_text()
pairs = re.findall(r'\{"([^"]+)",\s*0x([0-9A-Fa-f]{16})ull\}', src)
bad = 0
for name, hx in pairs:
    h = int(hx, 16)
    e = db.get(h)
    if not e:
        if h in ALLOW_NOT_IN_DB:
            print(f"OK*  {name:42s} 0x{hx}  not in DB: {ALLOW_NOT_IN_DB[h]}")
            continue
        print(f"FAIL {name:42s} 0x{hx}  NOT IN DB"); bad += 1; continue
    b = int(e.get("build", "0"))
    dbname = e["name"]
    issues = []
    if b > GAME_BUILD: issues.append(f"build {b} > {GAME_BUILD} (would crash: Can't find native)")
    if dbname.lstrip("_") != name.lstrip("_"): issues.append(f"name mismatch: DB says {dbname}")
    c = (e.get("comment") or "").lower()
    if ("nullsub" in c or "does nothing" in c) and dbname not in ALLOW_NULLSUB_AFTER_1311: issues.append("DB says nullsub")
    print(("FAIL " if issues else "OK   ") + f"{name:42s} 0x{hx}  build {b}  {'; '.join(issues)}")
    bad += bool(issues)
all_lits = set(int(x, 16) for x in re.findall(r"0x([0-9A-Fa-f]{16})ull", src))
listed = set(int(hx, 16) for _, hx in pairs)
stray = all_lits - listed
if stray: print("FAIL stray hash literals outside the table:", [hex(x) for x in stray]); bad += 1
print(f"\n{len(pairs)} natives checked, {bad} problem(s)")
sys.exit(1 if bad else 0)
