// Fake ScriptHookRDR2.dll for testing NpcVoice.asi under Wine.
// Same export names as the real hook; natives are dispatched by hash into a tiny simulated world.
// Also detects the 'nested native call' bug class (nativeInit while another call is still being pushed).
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <cmath>

struct V3 { float x; uint32_t a; float y; uint32_t b; float z; uint32_t c; };
struct Ent {
    int id; uint32_t model; bool human, male, dead, hog, exists = true, horse = false;
    float x, y, z; uint32_t weapon, best, outfit; int mount = 0, lastMount = 0, rider = 0, looter = 0; int veh = 0, seat = -1; uint32_t scenHash = 0;
    std::vector<uint32_t> cats; uint32_t slot[16] = {0}; bool nude = false;     // 0.5.0 outfit simulation
    int attachedTo = 0; bool blocking = false, mission = false, keep = false; int carrying = 0, killer = 0; bool scen = false, melee = false;
    std::vector<std::string> tasks;
};
static std::map<int, Ent> W;
static int g_nextId = 5000, g_gpsStarts = 0, g_blips = 0, g_blipRemoved = 0;
static int g_focus = 0, g_aim = 0, g_cash = 2500, g_hour = 14, g_min = 30, g_php = 150; static bool g_wheel = false;
static bool g_keys[256];
static std::vector<std::string> g_texts, g_lastTexts;
static std::map<uint64_t, int> g_unhandled;
static int g_nested = 0;
static bool g_mountFails = false; static int g_crimes = 0;
static bool g_waypoint = false, g_spots = false; static std::vector<uint32_t> g_brokenScen;   // 0.4.0   // 0.3.2: mount tasks that never finish, crimes reported
static void (*g_script)() = nullptr;
static LPVOID g_mainFiber = nullptr, g_scriptFiber = nullptr;
static uint64_t g_hash = 0; static std::vector<uint64_t> g_args; static bool g_inCall = false;
static uint64_t g_ret[4];
static char g_strbuf[1024];
// households rig: a house full of scenario points (beds, table chairs, stove, porch...)
struct FPt { int id; uint32_t ty; float x, y, z, h; };
static std::vector<FPt> g_pts;
static const FPt* pt(int id) { for (auto& p : g_pts) if (p.id == id) return &p; return nullptr; }

static uint32_t joaat(const char* s) {
    uint32_t h = 0;
    for (; *s; ++s) { char c = *s; if (c >= 'A' && c <= 'Z') c += 32; h += (uint8_t)c; h += h << 10; h ^= h >> 6; }
    h += h << 3; h ^= h >> 11; h += h << 15; return h;
}
static float F(int i) { float f; uint32_t v = (uint32_t)g_args[i]; memcpy(&f, &v, 4); return f; }
static int I(int i) { return (int)(int32_t)g_args[i]; }
static const char* S(int i) { return (const char*)(uintptr_t)g_args[i]; }
static Ent* E(int i) { auto it = W.find(I(i)); return it == W.end() || !it->second.exists ? nullptr : &it->second; }
static void task(int i, const std::string& t) { Ent* e = E(i); if (e) { e->tasks.push_back(t); } }
static void retv(const Ent* e) { V3 v{}; if (e) { v.x = e->x; v.y = e->y; v.z = e->z; } memcpy(g_ret, &v, sizeof v); }

static void dispatch() {
    uint64_t h = g_hash; memset(g_ret, 0, sizeof g_ret); uint64_t& R = g_ret[0];
    auto n = g_args.size(); (void)n;
    switch (h) {
    case 0x217E9DC48139933Dull: R = 0; break;                          // PLAYER_ID
    case 0x096275889B8E0EE0ull: R = 1; break;                          // PLAYER_PED_ID
    case 0x3EE1F7A8C32F24E1ull: *(uint64_t*)(uintptr_t)g_args[1] = g_focus; R = g_focus != 0; break;
    case 0xAE663DDD99C8A670ull: R = 0; break;                          // GET_PLAYER_TARGET_ENTITY
    case 0xA6817C110B830EADull: *(uint64_t*)(uintptr_t)g_args[1] = g_aim; R = g_aim != 0; break;
    case 0x8C67C11C68713D25ull: R = g_aim && I(1) == g_aim; break;     // IS_PLAYER_FREE_AIMING_AT_ENTITY
    case 0xD42BD6EB2E0F1677ull: R = E(0) != nullptr; break;            // DOES_ENTITY_EXIST
    case 0x7D5B1F88E7504BBAull: { Ent* e = E(0); R = e ? e->dead : 1; } break;
    case 0xB980061DA992779Dull: { Ent* e = E(0); R = e && e->human; } break;
    case 0x12534C348C6CB68Bull: R = I(0) == 1; break;
    case 0x6D9F5FAA7488BA46ull: { Ent* e = E(0); R = e && e->male; } break;
    case 0xDA76A9F39210D365ull: { Ent* e = E(0); R = e ? e->model : 0; } break;
    case 0xA86D5F069399F44Dull: retv(E(0)); break;                     // GET_ENTITY_COORDS
    case 0xFB6BA510A533DF81ull: { float f = 0; memcpy(&R, &f, 4); } break;
    case 0x82368787EA73C0F7ull: R = I(0) == 1 ? g_php : 150; break;
    case 0x4E209B2C1EAD5159ull: { Ent* e = E(0); R = e && e->melee; } break;                   // IS_PED_IN_MELEE_COMBAT
    case 0xF3A21BCD95725A4Aull: case 0xE2587F8CBBD87B1Dull: R = g_wheel && (uint32_t)g_args[1] == joaat("INPUT_OPEN_WHEEL_MENU"); break;
    case 0x15D757606D170C3Cull: R = 150; break;
    case 0xDC19C288082E586Eull: { Ent* e = E(0); if (e) { e->mission = true; task(0, "MISSION_ENTITY"); } } break;
    case 0x4971D2F8162B9674ull: { int id = *(int*)(uintptr_t)g_args[0]; auto it = W.find(id); if (it != W.end()) { it->second.mission = false; it->second.tasks.push_back("NO_LONGER_NEEDED"); } *(int*)(uintptr_t)g_args[0] = 0; } break;
    case 0x460BC76A0E10655Eull: { Ent* e = E(0); R = e && e->mount; } break;
    case 0xE7E11B8DCBED1058ull: { Ent* e = E(0); R = e ? e->mount : 0; } break;
    case 0x997ABD671D25CA0Bull: { Ent* e = E(0); R = e && e->veh; } break;                    // IS_PED_IN_ANY_VEHICLE
    case 0x9A9112A0FE9A4713ull: { Ent* e = E(0); R = e ? e->veh : 0; } break;                 // GET_VEHICLE_PED_IS_IN
    case 0xBB40DD2270B65366ull: { R = 0; for (auto& kv : W) if (kv.second.veh == I(0) && kv.second.seat == I(1)) R = kv.first; } break;
    case 0xA3EE4A07279BB9DBull: { Ent* e = E(0); R = e && e->veh == I(1); } break;            // IS_PED_IN_VEHICLE
    case 0xFC08C8F8C1EDF174ull: R = (uint32_t)g_args[0] == joaat("streetcar"); break;          // IS_THIS_MODEL_A_TRAIN
    case 0x260BE8F09E326A20ull: task(0, "HALT"); break;
    case 0x7C06330BFDDA182Eull: task(0, "UNHALT"); break;
    case 0xE2A2AA2F659D77A7ull: { char b[48]; snprintf(b, sizeof b, "DRIVE_TO:%d", I(1)); task(0, b); } break;
    case 0x5C9B84BD7D31D908ull: task(0, "CRUISE"); break;
    case 0x202B1BBFC6AB5EE4ull: R = g_waypoint; break;
    case 0x29B30D07C3F7873Bull: { V3 v{}; v.x = 500; v.y = 600; v.z = 0; memcpy(g_ret, &v, sizeof v); } break;
    case 0xC230DD956E2F5507ull: { float f = 0; memcpy(&R, &f, 4); } break;                      // GET_ENTITY_HEADING
    case 0xA622E66EEE92A08Dull: { Ent* e = E(0); R = e ? (int)e->cats.size() : 0; } break;
    case 0xCCB97B51893C662Full: { Ent* e = E(0); int i = I(1); R = (e && i >= 0 && i < (int)e->cats.size()) ? e->cats[i] : 0; } break;
    case 0xD710A5007C2AC539ull: { Ent* e = E(0); if (e) { uint32_t c = (uint32_t)g_args[1];
        for (size_t i = 0; i < e->cats.size(); ++i) if (e->cats[i] == c) { e->cats.erase(e->cats.begin() + i); break; } e->tasks.push_back("REMOVE_TAG"); } } break;
    case 0xBC6DF00D7A4A6819ull: { Ent* e = E(0); if (e) { uint32_t d = (uint32_t)g_args[1]; char b[40]; snprintf(b, sizeof b, "SET_TAG:%08X", d); e->tasks.push_back(b);
        if (d == joaat("UPPERTORSO_FR1_000") || d == joaat("UPPERTORSO_MR1_000")) e->nude = true;
        else if (d == joaat("SHIRT_TEST_01")) { e->nude = false; e->cats = {joaat("shirts_full"), joaat("pants"), joaat("boots"), joaat("heads")}; } } } break;
    case 0xA9C28516A6DC9D56ull: { Ent* e = E(0); int i = I(1); uint32_t d = 0, a = 0;
        if (e && i >= 0 && i < 16) { d = e->slot[i]; if (i == 0 && e->nude) d = joaat("UPPERTORSO_FR1_000"); if (i == 1) a = joaat("HAND_FR1_000_C0_003_AB"); }
        *(uint32_t*)(uintptr_t)g_args[2] = d; *(uint32_t*)(uintptr_t)g_args[3] = a; *(uint32_t*)(uintptr_t)g_args[4] = 0; *(uint32_t*)(uintptr_t)g_args[5] = 0; R = d != 0; } break;
    case 0xE7998FEC53A33BBEull: { *(uint32_t*)(uintptr_t)g_args[2] = 0; *(int*)(uintptr_t)g_args[3] = 0; *(int*)(uintptr_t)g_args[4] = 0; *(int*)(uintptr_t)g_args[5] = 0; R = 1; } break;
    case 0xCC8CA3E88256E58Full: task(0, "UPDATE_VARIATION"); break;
    case 0xDEE49D5CA6C49148ull: R = 0; break;                                                  // IS_ENTITY_PLAYING_ANIM
    // 0.5.1
    case 0xBC9AE166038A5CECull: task(0, "PAIN"); break;                                        // PLAY_PAIN
    case 0x10C70A515BC03707ull: R = 3; break;                                                  // GET_NUM_META_PED_OUTFITS
    case 0x77FF8D35EEC6BBC4ull: { char b[32]; snprintf(b, sizeof b, "OUTFIT:%d", I(1)); task(0, b); } break;
    case 0xABC532F9098BFD9Dull: R = 0; break;                                                  // GET_PLAYER_WANTED_LEVEL
    case 0x83CDB10EA29B370Bull: { char b[160]; snprintf(b, sizeof b, "ANIM_ADV:%s:rz=%.0f", (const char*)(uintptr_t)g_args[2], F(8)); task(0, b); } break;
    case 0xE143FA2249364369ull: R = 0; break;                                                  // GET_CLOSEST_OBJECT_OF_TYPE
    case 0x97FF36A1D40EA00Aull: task(0, "STOP_ANIM"); break;
    case 0x06843DA7060A026Bull: task(0, "SET_COORDS"); break;
    case 0xAAA34F8A7CB32098ull: task(0, "CLEAR_NOW"); break;
    case 0x5BC448CB78FA3E88ull: task(0, "GOTO_ANY"); break;
    case 0xD3DBCE61A490BE02ull: task(0, "LEAVE_VEHICLE"); break;
    case 0x345EC3B7EBDE1CB5ull: {                                                               // GET_SCENARIO_POINTS_IN_AREA
        int64_t* out = (int64_t*)(uintptr_t)g_args[4]; int mx = I(5), k = 0;
        for (auto& p : g_pts) { float dx = p.x - F(0), dy = p.y - F(1); if (k < mx && dx * dx + dy * dy <= F(3) * F(3)) out[k++] = p.id; }
        R = k; } break;
    case 0xA8452DD321607029ull: { const FPt* p = pt(I(0)); V3 v{}; if (p) { v.x = p->x; v.y = p->y; v.z = p->z; } memcpy(g_ret, &v, sizeof v); } break;
    case 0xB93EA7184BAA85C3ull: { const FPt* p = pt(I(0)); float f = p ? p->h : 0.f; memcpy(g_ret, &f, 4); } break;
    case 0xA92450B5AE687AAFull: { const FPt* p = pt(I(0)); R = p ? p->ty : 0; } break;
    case 0x6C8065A3B780185Bull: task(0, std::string("VOICE:") + S(1)); break;                                   // SET_AMBIENT_VOICE_NAME
    case 0xB292203008EBBAACull: { Ent* e = E(0); R = e && e->human ? (e->male ? 0x1111AAAAu : 0x2222BBBBu) : 0; } break;   // _GET_META_PED_RACE (rig: a fixed value)
    case 0x58E2E0F23F6B76C3ull: { task(0, "USE_POINT_WARP"); Ent* e = E(0); if (e) { e->scen = true; e->scenHash = 0; } } break;   // ..._COORD_WARP
    case 0x044131118D8DB3CDull: task(-1, "KEYBOARD"); break;                                   // DISPLAY_ONSCREEN_KEYBOARD
    case 0x37DF360F235A3893ull: R = 3; break;                                                  // UPDATE_ONSCREEN_KEYBOARD
    case 0xAFB4CF58A4A292B1ull: R = 0; break;
    case 0x58A39BE597CE99CDull: break;
    case 0x1899F328B0E12848ull: retv(E(0)); break;                                            // GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS
    case 0x34D6AC1157C8226Cull: { Ent* e = E(0); R = e && e->scen && e->scenHash == (uint32_t)g_args[1]; } break;
    case 0x5A59271FFADD33C1ull: R = g_spots; break;                                             // DOES_SCENARIO_EXIST_IN_AREA
    case 0x322BFDEA666E2B0Eull: { task(0, "USE_SPOT"); Ent* e = E(0); if (e) { e->scen = g_spots; e->scenHash = 0; } } break;
    case 0x2D0571BB55879DA2ull: { Ent* e = E(0); R = (e && e->scen && !e->scenHash) ? joaat("PROP_HUMAN_SEAT_BENCH") : 0; } break;
    case 0x4C8B59171957BCF7ull: { Ent* e = E(0); R = e ? e->lastMount : 0; } break;
    case 0x2F96E7720B0B19EAull: R = 0; break;
    case 0x3AA24CCC0D451379ull: { Ent* e = E(0); R = e && e->hog; } break;
    case 0xD453BB601D4A606Eull: case 0x9682F850056C9ADEull: case 0x47E4E977581C5B55ull:
    case 0x4859F1FC66A6278Eull: case 0xBBCCE00B381F8482ull: case 0x34616828CD07F1A1ull:
    case 0x84D0BF2B21862059ull: case 0xD5FE956C70FF370Bull: R = 0; break;
    case 0x57AB4A3080F85143ull: { Ent* e = E(0); R = e && e->scen; } break;                    // IS_PED_USING_ANY_SCENARIO
    case 0x3A87E44BB9A01D54ull: { Ent* e = E(0); *(uint64_t*)(uintptr_t)g_args[1] = e ? e->weapon : 0; R = 1; } break;
    case 0xADF692B254977C0Cull: { Ent* e = E(0); if (e) e->weapon = (uint32_t)g_args[1]; } break;
    case 0x8483E98E8B888AE2ull: { Ent* e = E(0); R = e ? e->best : 0; } break;
    case 0x208A1888007FC0E6ull: task(0, "DROP_WEAPON"); break;
    case 0x6FB76442469ABD68ull: { float f = 0; memcpy(&R, &f, 4); } break;
    case 0xC82CF208C2B19199ull: R = g_hour; break;
    case 0x4E162231B823DBBFull: R = g_min; break;
    case 0x4DD02D4C7FB30076ull: R = 3; break;
    case 0x43AD8FC02B429D33ull: R = I(3) == 0 ? joaat("NewHanover") : I(3) == 1 ? joaat("Valentine") : 0; break;
    case 0x4BEB42AEBCA732E9ull: R = joaat("SUNNY"); break;
    case 0x595320200B98596Eull: { V3 v{}; v.x = W[1].x; v.y = W[1].y - 3; v.z = W[1].z + 1.5f; memcpy(g_ret, &v, sizeof v); } break;
    case 0x0252D2B5582957A6ull: { V3 v{}; memcpy(g_ret, &v, sizeof v); } break;
    case 0x535384D6067BA42Eull: case 0xB15CD1CF58771DE1ull: R = 0; break;
    case 0x0C02DABFA3B98176ull: R = g_cash; break;
    case 0xBC3422DC91667621ull: g_cash += I(0); R = 1; break;
    case 0x466BC8769CF26A7Aull: g_cash -= I(0); R = 1; break;
    case 0x69F4BE8C8CC4796Cull: task(0, "LOOK_AT"); break;
    case 0x0F804F1DB19B9689ull: task(0, "CLEAR_LOOK_AT"); break;
    case 0x5AD23D40115353ACull: task(0, "TURN_TO_FACE"); break;
    case 0x919BE13EED931959ull: task(0, "STAND_STILL"); break;
    case 0xE1EF3C1216AFF2CDull: { task(0, "CLEAR_TASKS"); Ent* e = E(0); if (e) e->scen = false; } break;
    case 0x22B0D0E37CCB840Dull: task(0, "SMART_FLEE"); break;
    case 0xF2EAB31979A7F910ull: task(0, "HANDS_UP"); break;
    case 0xA98FCAFD7893C834ull: task(0, "HANDS_UP_REFRESH"); break;
    case 0x3EB1FE9E8E908E15ull: task(0, "COWER"); break;
    case 0x304AE42E357B8C7Eull: { char b[48]; snprintf(b, sizeof b, "FOLLOW:%d", I(1)); task(0, b); } break;
    case 0x6A071245EB0D1882ull: { task(0, "GO_TO_ENTITY"); Ent* e = E(0); Ent* t = E(1); if (e && t) { e->x = t->x + 1.2f; e->y = t->y; e->z = t->z; } } break;
    case 0x15D3A79D4E44B913ull: { task(0, "GOTO_COORD"); Ent* e = E(0); if (e) { e->x = F(1); e->y = F(2); e->z = F(3); } } break;
    case 0x5E3BDDBCB83F3D84ull: { char b[64]; snprintf(b, sizeof b, "GIVE_WEAPON:%08X", (uint32_t)g_args[1]); task(0, b); Ent* e = E(0); if (e) e->weapon = (uint32_t)g_args[1]; R = g_args[1]; } break;
    case 0xBB9CE077274F6A1Bull: task(0, "WANDER"); break;
    case 0xF166E48407BAC484ull: { char b[48]; snprintf(b, sizeof b, "COMBAT:%d", I(1)); task(0, b); } break;
    case 0x84D32B3BEC531324ull: task(0, "COVER"); break;
    case 0x92DB0739813C5186ull: { char b[64]; snprintf(b, sizeof b, "MOUNT:%d:seat%d", I(1), I(3)); task(0, b); Ent* e = E(0); if (e && !g_mountFails) e->mount = I(1); } break;
    case 0x028F76B6E78246EBull: { char b[64]; snprintf(b, sizeof b, "FORCED_ONTO_MOUNT:%d:seat%d", I(1), I(2)); task(0, b); Ent* e = E(0); if (e) e->mount = I(1); } break;
    case 0xF75B0D629E1C063Dull: task(0, "FORCED_INTO_VEHICLE"); break;
    case 0x7A6535691B477C48ull: { char b[32]; snprintf(b, sizeof b, "KNOCK_OFF:%d", I(1)); task(0, b); } break;
    case 0xF60386770878A98Full: { g_crimes++; char b[48]; snprintf(b, sizeof b, "CRIME_REPORTED:%08X", (uint32_t)g_args[1]); task(3, b); } break;
    case 0x48E92D3DDE23C23Aull: { task(0, "DISMOUNT"); Ent* e = E(0); if (e) e->mount = 0; } break;
    case 0xC20E50AA46D09CA8ull: task(0, "ENTER_VEHICLE"); break;
    case 0x504D54DF3F6F2247ull: task(0, "LEAVE_VEHICLE"); break;
    case 0x9A7A4A54596FE09Dull: task(0, "LEAD_HORSE"); break;
    case 0x480142959D337D00ull: task(0, "DRIVE_WANDER"); break;
    case 0x524B54361229154Full: { char b[64]; snprintf(b, sizeof b, "SCENARIO:%08X", (uint32_t)g_args[1]); task(0, b);
        Ent* e = E(0); if (e) { bool broken = false; for (auto x : g_brokenScen) if (x == (uint32_t)g_args[1]) broken = true;
                                 e->scen = !broken; e->scenHash = (uint32_t)g_args[1]; } } break;
    case 0xEA47FE3719165B94ull: { std::string t = std::string("ANIM:") + S(2); task(0, t); } break;
    case 0xA862A2AD321F94B4ull: break;
    case 0x27FF6FE8009B40CAull: case 0x537F44CB0D7F150Dull: R = 1; break;
    case 0xB31A277C1AC7B7FFull: { char b[64]; snprintf(b, sizeof b, "EMOTE:%08X:mode%d", (uint32_t)g_args[3], I(2)); task(0, b); } break;
    case 0x9F8AA94D6D97DBF4ull: { Ent* e = E(0); if (e) e->blocking = g_args[1] != 0; } break;
    case 0x971D38760FBC02EFull: { Ent* e = E(0); if (e) e->keep = g_args[1] != 0; } break;
    case 0xB8BEC0CA6F0EDB0Full: break;
    case 0x79D2F0E66F81D90Dull: break;
    case 0x9D64D7405520E3D3ull: task(0, g_args[1] ? "MUTED" : "UNMUTED"); break;
    case 0xFE99B66D079CF6BCull: break;
    case 0xFA925AC00EB830B9ull: snprintf(g_strbuf, sizeof g_strbuf, "%s", S(2)); R = (uint64_t)(uintptr_t)g_strbuf; break;
    case 0xD79334A4BB99BAD1ull: g_texts.push_back(S(0)); break;
    case 0x50A41AD966910F03ull: case 0x4170B650590B3B00ull: break;
    case 0x7B6E7BEC1143AC86ull: R = 0; break;
    case 0xBB19AC7D4DCEFD0Full: break;
    case 0xFCDFF7B72D23A1ACull: R = 1; break;
    case 0x30569F348D126A5Aull: { Ent* e = E(0); R = e ? e->outfit : 0; } break;
    case 0xFFC24B988B938B38ull: task(0, std::string("FACE_IDLE:") + S(1)); break;
    case 0x726256CC1EEB182Full: task(0, "FACE_IDLE_CLEAR"); break;
    case 0x8B3B71C80A29A4BBull: break;
    case 0x772A1969F649E902ull: { uint32_t m = (uint32_t)g_args[0]; R = m == joaat("A_C_Horse_Morgan_Bay"); } break;
    case 0xB676EFDA03DADA52ull: { Ent* e = E(0); R = e ? e->rider : 0; } break;
    case 0xE33F98BD76490ABCull: R = 0; break;   // 0.5.7 _GET_IS_PED_BEING_ROBBED
    case 0xEF2D9ED7CE684F08ull: { Ent* e = E(0); R = e ? e->looter : 0; } break;   // 0.5.7 _FIND_ENTITY_LOOTING_PED
    // 0.5.8: NpcHookups' way of playing a love scene (attach the upper partner to the lower one's hip bone)
    case 0x6B9BBD38AB0796DFull: { char b[64]; snprintf(b, sizeof b, "ATTACHED_TO:%d:bone%d", I(1), I(2)); task(0, b); Ent* e = E(0); if (e) e->attachedTo = I(1); } break;
    case 0x64CDE9D6BF8ECAD3ull: { task(0, "DETACHED"); Ent* e = E(0); if (e) e->attachedTo = 0; } break;
    case 0x3F428D08BE5AAE31ull: R = 0; break;                       // GET_PED_BONE_INDEX: an ambient ped has no 0xA7D8
    case 0xBACA8FE9C76C124Eull: R = 11; break;                      // SKEL_Pelvis
    case 0x239A3351AC1DA385ull: { Ent* e = E(0); if (e) { e->x = F(1); e->y = F(2); e->z = F(3); } } break;
    case 0xF66F820909453B8Cull: task(0, g_args[1] ? "COLLISION_ON" : "COLLISION_OFF"); break;
    case 0xE037BF068223C38Dull: case 0x1C99BB7B6E96D16Full: break;
    case 0xB128377056A54E2Aull: task(0, g_args[1] ? "RAGDOLL_ON" : "RAGDOLL_OFF"); break;
    case 0x154A3C529497053Eull: { Ent* e = E(0); R = e && e->attachedTo == I(1); } break;
    case 0xA0BC8FAED8CFEB3Cull: R = 1; break;                       // IS_PED_READY_TO_RENDER
    case 0xAAB0FE202E9FC9F0ull: case 0xE052C1B1CAA4ECE4ull: R = 1; break;
    case 0xA9C55F1C15E62E06ull: R = 2; break;
    case 0xFD340785ADF8CFB7ull: R = joaat(S(0)); break;
    case 0x176CECF6F920D707ull: break;
    case 0xA911EE21EDF69DAFull: { Ent* e = E(0); R = e && e->carrying; } break;
    case 0xD806CD2A4F2C2996ull: { Ent* e = E(0); R = e ? e->carrying : 0; } break;
    case 0x93C8B64DEB84728Cull: { Ent* e = E(0); R = e ? e->killer : 0; } break;
    case 0x138190F64DB4BBD1ull: { Ent* e = E(0); R = e && e->mission; } break;
    // ── spawning / map ──
    case 0xD6F3B6D7716CFF8Eull: case 0x1283B8B89DD5D1B6ull: R = 1; break;          // IS_MODEL_IN_CDIMAGE / HAS_MODEL_LOADED
    case 0xFA28FE3A6246FC30ull: case 0x4AD96EF928BD4F9Aull: break;                  // REQUEST_MODEL / NO_LONGER_NEEDED
    case 0xD49F9B0955C367DEull: case 0x509D5878EB39E842ull: case 0xAF35D0D2583051B0ull: {   // CREATE_PED / OBJECT / VEHICLE
        Ent e{}; e.id = g_nextId++; e.model = (uint32_t)g_args[0]; e.human = h == 0xD49F9B0955C367DEull; e.male = true;
        e.x = F(1); e.y = F(2); e.z = F(3); e.exists = true; e.weapon = joaat("WEAPON_UNARMED"); e.best = e.weapon;
        e.tasks.push_back(h == 0xD49F9B0955C367DEull ? "CREATED_PED" : h == 0x509D5878EB39E842ull ? "CREATED_OBJ" : "CREATED_VEH");
        W[e.id] = e; R = e.id; } break;
    case 0x283978A15512B2FEull: task(0, "OUTFIT"); break;
    case 0x58A850EAEE20FAA3ull: R = 1; break;
    case 0xCF2B9C0645C4651Bull: break;
    case 0x24FA4267BB8D2431ull: *(float*)(uintptr_t)g_args[3] = 0.0f; R = 1; break;   // ground z
    case 0xDCF3690AA262C03Full: R = 0; break;                                        // no water
    case 0x554D9D53F696D002ull: g_blips++; R = 77; break;
    case 0x74F74D3207ED525Cull: case 0x9CB1A1623062F402ull: break;
    case 0xF2C3C9DA47AAA54Aull: g_blipRemoved++; *(int*)(uintptr_t)g_args[0] = 0; break;
    case 0x3D3D15AF7BCAAF83ull: g_gpsStarts++; break;
    case 0x64C59DD6834FA942ull: case 0x4426D65E029A4DC0ull: case 0x9E0AB9AAEE87CE28ull: break;
    case 0x4CD38C78BD19A497ull: { int id = *(int*)(uintptr_t)g_args[0]; if (W.count(id)) W[id].exists = false; } break;
    case 0xAC2767ED8BDFAB15ull: { Ent* e = E(0); if (e && I(1) == 0) e->dead = true; } break;
    case 0xA5C38736C426FCB8ull: task(0, g_args[1] ? "INVINCIBLE" : "VINCIBLE"); break;
    case 0x42AC6401ABB8C7E5ull: { Ent* e = E(0); if (e) { e->hog = true; e->tasks.push_back("HOGTIED"); } } break;
    case 0x79559BAD83CCD038ull: { Ent* e = E(0); if (e) { e->hog = false; e->tasks.push_back("UNHOGTIED"); } } break;
    default: g_unhandled[h]++; break;
    }
}

extern "C" {
__declspec(dllexport) void fake_scriptRegister(HMODULE, void (*fn)()) { g_script = fn; }
__declspec(dllexport) void fake_scriptUnregister(HMODULE) {}
__declspec(dllexport) void fake_scriptWait(DWORD) { SwitchToFiber(g_mainFiber); }
__declspec(dllexport) void fake_nativeInit(uint64_t h) {
    if (g_inCall) { g_nested++; fprintf(stderr, "NESTED NATIVE CALL: init 0x%016llX while 0x%016llX pending\n", (unsigned long long)h, (unsigned long long)g_hash); }
    g_hash = h; g_args.clear(); g_inCall = true;
}
__declspec(dllexport) void fake_nativePush64(uint64_t v) { g_args.push_back(v); }
__declspec(dllexport) uint64_t* fake_nativeCall() { dispatch(); g_inCall = false; return g_ret; }
__declspec(dllexport) int fake_worldGetAllPeds(int* arr, int sz) {
    int n = 0; for (auto& kv : W) if (kv.second.exists && n < sz) arr[n++] = kv.first; return n;
}
// ── rig control ──
__declspec(dllexport) int fake_key_down(int vk) { return g_keys[vk & 255]; }
__declspec(dllexport) void fake_set_key(int vk, int down) { g_keys[vk & 255] = down != 0; }
__declspec(dllexport) void fake_set_focus(int ped) { g_focus = ped; }
__declspec(dllexport) void fake_set_aim(int ped) { g_aim = ped; }
__declspec(dllexport) void fake_add(int id, const char* model, int human, int male, float x, float y, float z, unsigned outfit, int mount) {
    Ent e{}; e.id = id; e.model = joaat(model); e.human = human; e.male = male; e.x = x; e.y = y; e.z = z; e.outfit = outfit;
    e.weapon = joaat("WEAPON_UNARMED"); e.best = joaat("WEAPON_UNARMED"); e.mount = mount; e.exists = true;
    if (human) { e.cats = {joaat("shirts_full"), joaat("pants"), joaat("boots"), joaat("heads")}; e.slot[0] = joaat("SHIRT_TEST_01"); e.slot[1] = joaat("HANDS_TEST"); }
    W[id] = e;
}
// what the Unstrip prompt does to a ped (0.5.0 rig): clothes gone, nude torso on
__declspec(dllexport) void fake_strip(int id) { W[id].cats = {joaat("heads")}; W[id].nude = true; }
__declspec(dllexport) void fake_set_weapon(int id, const char* w, const char* best) { W[id].weapon = joaat(w); W[id].best = joaat(best); }
__declspec(dllexport) void fake_set_pos(int id, float x, float y, float z) { W[id].x = x; W[id].y = y; W[id].z = z; }
__declspec(dllexport) void fake_set_dead(int id, int d) { W[id].dead = d != 0; }
__declspec(dllexport) void fake_set_last_mount(int id, int horse) { W[id].lastMount = horse; }
__declspec(dllexport) void fake_set_mount(int id, int horse) { W[id].mount = horse; }
__declspec(dllexport) void fake_set_mount_fails(int f) { g_mountFails = f != 0; }
__declspec(dllexport) int fake_crimes() { return g_crimes; }
__declspec(dllexport) void fake_set_in_vehicle(int id, int veh, int seat) { W[id].veh = veh; W[id].seat = seat; }
__declspec(dllexport) void fake_set_waypoint(int on) { g_waypoint = on != 0; }
__declspec(dllexport) void fake_set_spots(int on) { g_spots = on != 0; }
__declspec(dllexport) void fake_set_clock(int h, int m) { g_hour = h; g_min = m; }
__declspec(dllexport) void fake_set_home(float x, float y, float z) {      // a furnished house around x y z
    struct { const char* n; float dx, dy; } P[] = {{"PROP_HUMAN_SLEEP_BED_PILLOW_LEFT", 2, 3}, {"PROP_HUMAN_SLEEP_BED_PILLOW_RIGHT", 2.8f, 3},
        {"PROP_HUMAN_SEAT_CHAIR_TABLE_EATING_KNIFE_FORK", -1, 0}, {"PROP_HUMAN_SEAT_CHAIR_TABLE_EATING_KNIFE_FORK", -1, 1.2f},
        {"WORLD_HUMAN_CAULDRON_STIR_NO_POT", -2, -1}, {"WORLD_HUMAN_FEED_CHICKEN", 9, 2}, {"PROP_HUMAN_SEAT_CHAIR_PORCH", 4, -3},
        {"WORLD_HUMAN_BROOM_WORKING", 0.5f, 0.5f}};
    int id = 9001; g_spots = true;
    for (auto& p : P) g_pts.push_back(FPt{id++, joaat(p.n), x + p.dx, y + p.dy, z, 90.f});
}
__declspec(dllexport) void fake_break_scenario(const char* name) { g_brokenScen.push_back(joaat(name)); }
__declspec(dllexport) void fake_set_mission(int id, int m) { W[id].mission = m != 0; }
__declspec(dllexport) void fake_set_carry(int id, int what) { W[id].carrying = what; }
__declspec(dllexport) void fake_set_killer(int id, int k) { W[id].killer = k; }
__declspec(dllexport) void fake_set_melee(int id, int m) { W[id].melee = m != 0; }
__declspec(dllexport) void fake_set_wheel(int w) { g_wheel = w != 0; }
__declspec(dllexport) void fake_set_php(int hp) { g_php = hp; }
__declspec(dllexport) int fake_gps() { return g_gpsStarts; }
__declspec(dllexport) void fake_set_cash(int c) { g_cash = c; }
__declspec(dllexport) int fake_blips() { return g_blips * 100 + g_blipRemoved; }
__declspec(dllexport) int fake_count_task(const char* prefix) { int n = 0; for (auto& kv : W) for (auto& t : kv.second.tasks) if (t.compare(0, strlen(prefix), prefix) == 0) ++n; return n; }
__declspec(dllexport) int fake_cash() { return g_cash; }
__declspec(dllexport) int fake_blocking(int id) { return W[id].blocking; }
__declspec(dllexport) int fake_mission(int id) { return W[id].mission; }
__declspec(dllexport) int fake_nested() { return g_nested; }
__declspec(dllexport) int fake_has_task(int id, const char* prefix) {
    for (auto& t : W[id].tasks) if (t.compare(0, strlen(prefix), prefix) == 0) return 1; return 0;
}
__declspec(dllexport) void fake_tasks(int id, char* out, int len) {
    std::string s; for (auto& t : W[id].tasks) { s += t; s += ' '; } snprintf(out, len, "%s", s.c_str());
}
__declspec(dllexport) void fake_clear_tasks(int id) { W[id].tasks.clear(); }
__declspec(dllexport) int fake_text_seen(const char* needle) {
    for (auto& t : g_lastTexts) if (strstr(t.c_str(), needle)) return 1; return 0;
}
__declspec(dllexport) void fake_dump_texts(char* out, int len) {
    std::string s; for (auto& t : g_lastTexts) { s += t; s += " | "; } snprintf(out, len, "%s", s.c_str());
}
__declspec(dllexport) void fake_unhandled(char* out, int len) {
    std::string s; char b[64]; for (auto& kv : g_unhandled) { snprintf(b, sizeof b, "0x%016llX x%d ", (unsigned long long)kv.first, kv.second); s += b; }
    snprintf(out, len, "%s", s.c_str());
}
static void WINAPI fiber_proc(LPVOID) { if (g_script) g_script(); }
__declspec(dllexport) void fake_frame() {
    if (!g_mainFiber) g_mainFiber = ConvertThreadToFiber(nullptr);
    if (!g_scriptFiber) g_scriptFiber = CreateFiber(0, fiber_proc, nullptr);
    g_texts.clear();
    SwitchToFiber(g_scriptFiber);
    g_lastTexts = g_texts;
}
}
