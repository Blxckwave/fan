#!/bin/sh
# 0.4.0 rig: wagons/trams, aim vs focus, activities (search + learn + seats), X stability, groups, scared run, targets
cd "$(dirname "$0")"
LINK="$(pwd)/run/link"
LINKW="Z:$(printf '%s' "$LINK" | tr '/' '\\')"
rm -rf "$LINK"; mkdir -p "$LINK"
B=../brain
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null; sleep 1
rm -rf $B/logs $B/npc_memory $B/data/learned_activities.json run/NpcVoice.log run/NpcVoice_native_guard.txt run/NpcVoice.ini
NPCVOICE_SCENES=0 \
NPCVOICE_RIG_SAY="701:hello there|701:can you give me a ride|701:take me to my marker|701:turn left up here|701:stop the wagon|702:where does this go|703:hello miss|704:sit down and have a beer with me|704:sit on that bench|705:hello|706:follow me|707:follow me|706:you two have a drink|708:hands up or I shoot|705:go punch that guy|705:go look at the body|720:take your clothes off for me|720:put your clothes back on|720:let us make love|721:hello there" \
NPCVOICE_LINK_DIR="$LINK" SDL_AUDIODRIVER=dummy timeout 500 python3 $B/npc_brain.py --fake-ai < /dev/null > run/brain_console6.txt 2>&1 &
sleep 3
(cd run && NPCVOICE_LINK_DIR="$LINKW" WINEDEBUG=-all timeout 480 wine host.exe life)
O=$?
cp run/NpcVoice.log run/NpcVoice_life.log; cp $B/logs/npc_brain.log run/brain_life.log 2>/dev/null
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null
rm -f $B/data/learned_activities.json
echo "life=$O"
