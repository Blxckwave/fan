#!/bin/sh
# Only the living-world scenes test (0.5.8: households off - the rig player stands inside a fake shack, and a
# household talking to him holds the director's scenes back)
cd "$(dirname "$0")"
LINK="$(pwd)/run/link"
LINKW="Z:$(printf '%s' "$LINK" | tr '/' '\\')"
rm -rf "$LINK"; mkdir -p "$LINK"
B=../brain
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null; sleep 1
rm -rf $B/logs $B/npc_memory run/NpcVoice.log run/NpcVoice_native_guard.txt run/NpcVoice.ini
NPCVOICE_HOUSEHOLDS=0 NPCVOICE_FORCE_SCENES="worker_quarrel,serial_killer" NPCVOICE_SCENE_COOLDOWN=3 NPCVOICE_LINK_DIR="$LINK" SDL_AUDIODRIVER=dummy timeout 400 python3 $B/npc_brain.py --fake-ai < /dev/null > run/brain_console3.txt 2>&1 &
sleep 3
(cd run && NPCVOICE_LINK_DIR="$LINKW" WINEDEBUG=-all timeout 380 wine host.exe scenes)
S=$?
cp run/NpcVoice.log run/NpcVoice_scenes.log; cp $B/logs/npc_brain.log run/brain_scenes.log 2>/dev/null
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null
echo "scenes=$S"
