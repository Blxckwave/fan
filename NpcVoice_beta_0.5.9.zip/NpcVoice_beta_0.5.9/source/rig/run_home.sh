#!/bin/sh
# households rig: real NpcVoice.asi under Wine + the brain (fake AI) - a Lakay shack's day and night
cd "$(dirname "$0")"
LINK="$(pwd)/run/link"
LINKW="Z:$(printf '%s' "$LINK" | tr '/' '\\')"
rm -rf "$LINK"; mkdir -p "$LINK"
B=../brain
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null; sleep 1
rm -rf $B/logs $B/npc_memory $B/households.json run/NpcVoice.log run/NpcVoice_native_guard.txt run/NpcVoice.ini
NPCVOICE_SCENES=0 NPCVOICE_HOUSEHOLDS=1 NPCVOICE_POSE_SECONDS=2 NPCVOICE_LINK_DIR="$LINK" SDL_AUDIODRIVER=dummy \
  timeout 400 python3 $B/npc_brain.py --fake-ai < /dev/null > run/brain_console_home.txt 2>&1 &
sleep 3
(cd run && NPCVOICE_LINK_DIR="$LINKW" WINEDEBUG=-all timeout 380 wine host.exe home)
O=$?
cp run/NpcVoice.log run/NpcVoice_home.log; cp $B/logs/npc_brain.log run/brain_home.log 2>/dev/null
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null
rm -rf $B/households.json
echo "home=$O"
