#!/bin/sh
cd "$(dirname "$0")"
LINK="$(pwd)/run/link"
LINKW="Z:$(printf '%s' "$LINK" | tr '/' '\\')"
rm -rf "$LINK"; mkdir -p "$LINK"
B=../brain
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null; sleep 1
rm -rf $B/logs $B/npc_memory run/NpcVoice.log run/NpcVoice_native_guard.txt run/NpcVoice.ini
NPCVOICE_SCENES=0 NPCVOICE_JOURNEY_VARIANT=kidnapped NPCVOICE_JOURNEY_MIN=800 NPCVOICE_JOURNEY_MAX=900 \
NPCVOICE_RIG_SAY="401:take me to your wife and your family|402:let's go find your brother|403:take me to your family|0:I'll pay you forty dollars" \
NPCVOICE_LINK_DIR="$LINK" SDL_AUDIODRIVER=dummy timeout 400 python3 $B/npc_brain.py --fake-ai < /dev/null > run/brain_console4.txt 2>&1 &
sleep 3
(cd run && NPCVOICE_LINK_DIR="$LINKW" WINEDEBUG=-all timeout 380 wine host.exe journeys)
J=$?
cp run/NpcVoice.log run/NpcVoice_journeys.log; cp $B/logs/npc_brain.log run/brain_journeys.log 2>/dev/null
pkill -9 -f "npc_brain.py --fake-ai" 2>/dev/null
echo "journeys=$J"
