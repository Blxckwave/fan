"""NPC action catalog: what the AI may ask a ped to do, when it is possible, and how it is executed.

Each action expands into ASI primitives (see NpcVoice.cpp 'task'/'emote'/'scenario'/'anim'/'mood'/'money').
Everything here is data – add or tune actions without recompiling the game plugin.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Callable

from .data import GESTURES

SPEEDS = {"slow": 3.0, "walk": 2.5, "normal": 6.0, "fast": 10.0, "gallop": 14.0}
UPPER = 0      # emote playback: upper body, secondary
FULL = 2       # emote playback: full body
CAT_REACTION, CAT_ACTION, CAT_TAUNT, CAT_GREET, CAT_DANCE = 0, 1, 2, 3, 5


@dataclass
class Act:
    name: str
    desc: str
    run: Callable[["ActCtx"], list]
    requires: Callable[["ActCtx"], str] = lambda c: ""
    child_ok: bool = False
    ends: bool = False                 # conversation ends after the line is spoken
    sets: dict = field(default_factory=dict)      # conv.flags changes
    overrides_hold: bool = True        # replaces the 'stand and listen' hold
    default_when: str = "now"


class ActCtx:
    def __init__(self, conv, ped: dict, player: dict, args: dict):
        self.conv, self.ped, self.player, self.args = conv, ped, player, args or {}

    @property
    def male(self):
        return (self.conv.ident.persona["sex"] if self.conv.ident else "male") == "male"


# ── requirement helpers ──
def free_body(c: ActCtx):
    if c.ped.get("hogtied") or c.ped.get("being_hogtied"):
        return "they are hogtied and can't move"
    if c.ped.get("lassoed"):
        return "they are lassoed"
    if c.ped.get("ragdoll"):
        return "they are on the ground"
    return ""


def on_foot(c: ActCtx):
    r = free_body(c)
    if r:
        return r
    if c.ped.get("mounted"):
        return "they are on a horse"
    if c.ped.get("in_vehicle"):
        return "they are in a vehicle"
    return ""


def mounted(c: ActCtx):
    return "" if c.ped.get("mounted") else "they are not on a horse"


def armed(c: ActCtx):
    return "" if c.ped.get("has_weapon") else "they have no weapon"


def driver(c: ActCtx):
    if not c.ped.get("in_vehicle"):
        return "you're not on a wagon"
    if not c.ped.get("drv"):
        return "you're not the one driving"
    if c.ped.get("tram"):
        return "it's a streetcar on rails - it only stops at its stops"
    return ""


def ride_target(c: ActCtx):
    r = free_body(c)
    if r:
        return r
    if c.ped.get("in_vehicle") and c.ped.get("drv"):
        return "you're driving your own wagon - use give_ride to let him climb on yours"
    pl = c.player
    if pl.get("mounted") or pl.get("in_vehicle"):
        return ""
    if pl.get("last_mount_dist", 999) < 30 or pl.get("last_vehicle_dist", 999) < 30:
        return ""
    return "the player has no horse or wagon nearby"


def money_amount(c: ActCtx, cap=50.0):
    try:
        amt = float(c.args.get("amount", c.args.get("dollars", 5)))
    except (TypeError, ValueError):
        amt = 5.0
    return max(0.05, min(cap, amt))


def player_can_pay(c: ActCtx):
    amt = money_amount(c, 500)
    cash = c.player.get("cash_cents", 0) / 100.0
    return "" if cash >= amt else f"the player only has ${cash:.2f}"


def gesture(c: ActCtx, prefixes: list[str]):
    d = "ai_gestures@gen_male@standing@speaker" if c.male else "ai_gestures@gen_female@standing@speaker"
    names = [n for n in GESTURES.get(d, []) if any(n.startswith(p) for p in prefixes)]
    if not names:
        return []
    return [("anim", d, random.choice(names), 8 | 16 | 32 * 0, 0)]   # upper body + secondary


def emote(cat, name, mode=UPPER):
    return [("emote", cat, name, mode)]


def scenario(name, ms=-1):
    return [("scenario", name, ms)]


def one_of(*names):
    return random.choice(names)


A: dict[str, Act] = {}


def add(a: Act):
    A[a.name] = a


# Movement & positioning
add(Act("walk_away", "calmly leave the area", lambda c: [("block", 0), ("look_clear",), ("clear",), ("wander",)],
        free_body, child_ok=True, ends=True, default_when="after", sets={"following": False, "staying": False}))
add(Act("flee", "run away in fear (you can keep talking/shouting while running)",
        lambda c: [("block", 0), ("look_clear",), ("keep", 0), ("persist", 0), ("flee", 150)],
        free_body, child_ok=True, ends=True,
        sets={"hands_up": False, "captive": False, "following": False, "staying": False, "cowering": False}))
add(Act("follow", "follow the player around", lambda c: [("clear",), ("follow", 1.2, -1.8, 2.0), ("keep", 1), ("persist", 1)],
        free_body, child_ok=True, sets={"following": True, "staying": False}))
add(Act("stop_following", "stop following the player and go about your business (gets off his horse/wagon too)",
        lambda c: [("keep", 0), ("persist", 0)] + ([("dismount",)] if c.ped.get("mounted") else
                                                   [] if (c.ped.get("in_vehicle") and c.ped.get("drv")) else
                                                   [("leave_vehicle",)] if c.ped.get("in_vehicle") else [("clear",), ("face", 6000)]),
        free_body, child_ok=True,
        sets={"following": False, "staying": False, "captive": False}))
add(Act("wait", "stand still and wait here a while", lambda c: [("clear",), ("face", 60000)], on_foot, child_ok=True,
        sets={"staying": False}))
add(Act("come_here", "walk up to the player", lambda c: [("clear",), ("goto_player",)], on_foot, child_ok=True))
add(Act("stay", "stay right here (stronger than wait – you stay even after the talk ends)",
        lambda c: [("clear",), ("stand", -1), ("keep", 1), ("persist", 1)], on_foot, sets={"staying": True, "following": False}))
add(Act("wander", "stroll around casually", lambda c: [("clear",), ("wander",)], free_body, child_ok=True, ends=True,
        default_when="after", sets={"following": False, "staying": False, "riding": False}))

# People and bodies around you, by their tag from the list ([P1], [B1]) - 0.4.0
_STOP = {"the", "a", "an", "your", "my", "his", "her", "to", "go", "over", "there", "that", "this", "one", "with", "and",
         "man", "woman", "guy", "fella", "lady", "person", "him", "talk", "see", "both", "you", "can", "now", "who", "is"}


def _words(text: str) -> set[str]:
    import re as _re
    return {w for w in _re.findall(r"[a-z']+", (text or "").lower()) if len(w) >= 3 and w not in _STOP}


def target_by_words(conv, text: str, kinds="PB") -> int:
    """0.5.1: 'go talk to your son' / 'go to Tommy' / 'the miner' - the AI (or the player) names a person instead of a
    tag. 0.5.0 rejected that ("args.target must be a tag") and Hattie never walked over to her own son."""
    tw = getattr(conv, "target_words", {}) or {}
    want = _words(text)
    if not want:
        return 0
    best, score = 0, 0
    for tag, words in tw.items():
        if tag[:1] not in kinds:
            continue
        sc = len(want & words)
        if sc > score:
            best, score = (getattr(conv, "targets", {}) or {}).get(tag, 0), sc
    return best if score else 0


def target_of(c: ActCtx, kinds="PB"):
    raw = str(c.args.get("target") or c.args.get("who") or c.args.get("with") or "").strip()
    t = raw.upper().strip("[]")
    if t in ("ME", "PLAYER", "HIM", "YOU"):
        return -1
    h = (getattr(c.conv, "targets", {}) or {}).get(t)
    if h and t[:1] in kinds:
        return h
    h = target_by_words(c.conv, raw, kinds)
    if not h:          # nothing usable in args: what the player just asked for ("go to your son")
        said = next((x[len("Player: "):] for x in reversed(getattr(c.conv, "transcript", []) or []) if x.startswith("Player: ")), "")
        h = target_by_words(c.conv, said, kinds)
    return h or 0


def need_target(kinds):
    def f(c: ActCtx):
        r = free_body(c)
        if r:
            return r
        return "" if target_of(c, kinds) else (f"say which one: args.target = a tag from the list ({'/'.join(k + '1' for k in kinds)}) "
                                                 "or their name - nobody like that is near you right now")
    return f


add(Act("attack_person", "go and beat up / shoot someone around you; args: {\"target\": \"P2\", \"weapon\": \"fists|gun\"}",
        lambda c: ([("holster",)] if str(c.args.get("weapon", "fists")).startswith("f") else [("draw",)]) +
                  [("block", 0), ("look_clear",), ("combat", f"t={target_of(c, 'P')}")],
        need_target("P"), ends=False, sets={"fighting": True}))
add(Act("go_to", "walk over to someone or a body; args: {\"target\": \"P1|B1\" or their name}",
        lambda c: [("clear",), ("goto_player", 1.6, 1.3, f"t={target_of(c)}")], need_target("PB"), child_ok=True))
add(Act("inspect_body", "go to a body and crouch to look at it; args: {\"target\": \"B1\"}",
        lambda c: [("clear",), ("goto_player", 1.2, 1.3, f"t={target_of(c, 'B')}"), ("activity_after", 6000, "inspect crouch")],
        need_target("B"), sets={"doing": "looking at the body"}))
add(Act("talk_to", "walk over to someone to talk to them (you'll say your line to them); args: {\"target\": \"P3\"}",
        lambda c: [("clear",), ("goto_player", 1.6, 1.2, f"t={target_of(c, 'P')}"), ("face", 15000, f"t={target_of(c, 'P')}")],
        need_target("P"), child_ok=True))

def place_point(c: ActCtx):
    """0.5.1: 'go down those stairs', 'go into the mine', 'go over there': a real place nearby (the database) by its
    name, else the spot the player is LOOKING at (his camera) - he's usually looking where he means."""
    import math
    where = str(c.args.get("where") or c.args.get("place") or c.args.get("what") or "").lower()
    near = getattr(c.conv, "near_places", []) or []
    for pl in near:
        words = {pl.get("kind", ""), *str(pl.get("label", "")).lower().split()}
        if where and any(w and len(w) > 2 and w in where for w in words):
            return (round(pl["x"], 2), round(pl["y"], 2), round(pl["z"], 2))
    p = c.player
    try:
        yaw = math.radians(float(p.get("cyaw", 0)))
        pitch = math.radians(float(p.get("cpitch", 0)))
        dist = 12.0
        if pitch < -0.05:                   # looking down at something: where the view meets the ground
            dist = max(3.0, min(25.0, (float(p.get("cz", p["z"] + 1.6)) - float(p["z"]) + 1.0) / math.tan(-pitch)))
        x = float(p["x"]) - math.sin(yaw) * dist
        y = float(p["y"]) + math.cos(yaw) * dist
        z = float(p["z"]) - (2.5 if any(w in where for w in ("down", "stairs", "under", "cellar", "below", "basement")) else 0)
        return (round(x, 2), round(y, 2), round(z, 2))
    except (KeyError, TypeError, ValueError):
        return None


def can_go_place(c: ActCtx):
    return on_foot(c) or ("" if place_point(c) else "you can't tell where he means")


add(Act("go_to_place", "walk to a place right around you: somewhere from the list of places nearby, or wherever HE is "
                       "pointing/looking (down those stairs, into the mine, inside, over there); args: "
                       "{\"where\": \"down the stairs\", \"speed\": \"walk|run\"}",
        lambda c: [("clear",), ("goto_coord", *place_point(c), 2.0 if str(c.args.get("speed", "")).startswith("r") else 1.0)],
        can_go_place, child_ok=True, sets={"following": False, "staying": False}))

def call_over_prims(c: ActCtx):
    h = target_of(c, "P")
    return [("on", h, "clear"), ("on", h, "goto_player", 1.2, 1.4, f"t={c.conv.ped}"), ("on", h, "face", 12000, f"t={c.conv.ped}")]


add(Act("call_over", "call someone around you over to you - your wife, your friend, your kid ('Clara, come here!'); "
                     "they come to YOU; args: {\"who\": \"Clara\" or a tag like P2}",
        call_over_prims, lambda c: "" if target_of(c, "P") else "nobody by that name is near you", child_ok=True,
        overrides_hold=False))

def order_prims(c: ActCtx):
    h, do = target_of(c, "P"), str(c.args.get("do") or c.args.get("what") or "").lower()
    me = c.conv.ped
    if do in ("run", "flee", "get out", "get away"):
        return [("on", h, "block", 0), ("on", h, "flee", 80)]
    if do in ("hide", "go_home", "go inside"):
        return [("on", h, "clear"), ("on", h, "flee", 30)]
    if do in ("stay", "wait", "don't move"):
        return [("on", h, "clear"), ("on", h, "stand", 30000)]
    if do in ("hands_up", "surrender"):
        return [("on", h, "clear"), ("on", h, "hands_up", 60000)]
    if do in ("follow_me", "follow", "come"):
        return [("on", h, "clear"), ("on", h, "follow", 1.0, -1.2, 1.5, f"t={me}")]
    return [("on", h, "clear"), ("on", h, "goto_player", 1.2, 1.4, f"t={me}")]


add(Act("order_person", "tell someone around you (your wife, your kid, your friend) to do something - they do it if they "
                        "trust you; args: {\"who\": \"Clara\" or P2, \"do\": \"come|run|hide|stay|hands_up|follow_me|go_home\"}",
        order_prims, lambda c: "" if target_of(c, "P") else "nobody by that name is near you",
        overrides_hold=False))

add(Act("meet_later", "agree to meet him later somewhere real (your home, the saloon, the church...); args: "
                      "{\"where\": \"the saloon in Valentine\", \"when\": \"tonight\"}", lambda c: [], overrides_hold=False))


# Clothes and intimacy (0.5.0) - only between adults who WANT it; never under a threat, tied up, captive, scared
def willing(c: ActCtx):
    r = free_body(c)
    if r:
        return r
    why = getattr(c.conv, "no_sex_because", None)
    if why:
        return "not now - you are " + ", ".join(why)
    return ""


def love_target(c: ActCtx):
    r = willing(c)
    if r:
        return r
    t = str(c.args.get("with") or c.args.get("target") or "me").strip().upper().strip("[]")
    if t in ("ME", "PLAYER", "HIM", "YOU", ""):
        c.args["_with"] = 0
        return ""
    h = (getattr(c.conv, "targets", {}) or {}).get(t)
    if not h:
        return "with whom? args.with = 'me' or a tag like P2"
    c.args["_with"] = h
    return ""


add(Act("undress", "take your own clothes off - only if YOU want to (for him, a swim, a bath, making love)",
        lambda c: [("undress",)], willing, overrides_hold=False, sets={"undressing": True}))
add(Act("dress", "put your clothes back on", lambda c: [("dress",)], free_body, child_ok=True, overrides_hold=False))
add(Act("let_him_undress_you", "agree that HE may undress you (his hands)", lambda c: [], willing, overrides_hold=False,
        sets={"consent_undress": True}))
add(Act("agree_to_make_love", "say yes to making love with him or with someone here (you want it)", lambda c: [], willing,
        overrides_hold=False, sets={"consent_love": True}))
add(Act("make_love", "make love now - with him (args.with='me') or with someone here who wants it too (args.with='P2'); "
                     "only if YOU want it", lambda c: [("hookup", int(c.args.get("_with", 0)))], love_target, overrides_hold=False,
        sets={"consent_love": True}))
def partner_of(c: ActCtx):
    """Your spouse/sweetheart if they're here (by tag, name, or simply the one listed as your partner)."""
    r = willing(c) or ("they're hostile" if c.conv.flags.get("hostile") else "")
    if r:
        return r
    t = str(c.args.get("with") or "").strip()
    h = 0
    if t and t.lower() not in ("none", "no", "me", "alone", ""):
        h = target_of(c, "P")
    if not h:
        for tag, words in (getattr(c.conv, "target_words", {}) or {}).items():
            if words & {"husband", "wife", "sweetheart", "lover", "missus"}:
                h = (getattr(c.conv, "targets", {}) or {}).get(tag, 0)
                break
    c.args["_partner"] = h
    return ""


add(Act("invite_home", "take him home with you - your partner too if they're here - because YOU want to be with him in "
                       "private (a drink, the night, whatever you two or three want). You lead the way yourselves (on your "
                       "horse, your partner behind you) to your real house and wait for him at the door; args: "
                       "{\"with\": \"P2 or your partner's name, or none\", \"why\": \"one line\"}",
        lambda c: [], partner_of, overrides_hold=False, sets={"journey": "home", "invited": True}))
add(Act("agree_to_watch", "say yes to watching your husband/wife/sweetheart with him - only if it's genuinely YOUR OWN "
                          "fantasy (you can stop it any time)", lambda c: [], willing, overrides_hold=False,
        sets={"consent_watch": True}))
add(Act("stop_making_love", "stop it now (you've had enough, changed your mind, someone's coming)", lambda c: [("hookup_stop",)],
        lambda c: "", child_ok=False, overrides_hold=False))

# Consensual play, money, work (0.5.0)
def start_play_args(c: ActCtx):
    r = willing(c)
    if r:
        return r
    c.args["stop_word"] = str(c.args.get("stop_word") or "red").strip()[:24] or "red"
    return ""


add(Act("start_play", "agree to a game of dominance/submission with him that YOU want; you choose a stop word that "
                      "ends it at once; args: {\"stop_word\": \"bluebonnet\", \"who_leads\": \"you|him\"}",
        lambda c: [], start_play_args, overrides_hold=False))
add(Act("end_play", "end the game now (you said your stop word, or you've had enough)", lambda c: [], overrides_hold=False,
        sets={"play": None}))
add(Act("take_bribe", "accept his money to keep quiet / look away; args: {\"amount\": dollars}",
        lambda c: [("money", -int(money_amount(c, 500) * 100))], player_can_pay, overrides_hold=False, sets={"bribed": True}))
add(Act("work_for_him", "take his money to ride with him and watch his back (you follow and fight for him); args: {\"amount\": dollars}",
        lambda c: [("money", -int(money_amount(c, 500) * 100)), ("clear",), ("follow", 1.6, -2.4, 2.0), ("keep", 1), ("persist", 1)],
        lambda c: player_can_pay(c) or free_body(c), sets={"hired": True, "following": True}))

# Combat & submission
add(Act("hands_up", "raise your hands in surrender", lambda c: [("clear",), ("hands_up", 120000), ("block", 1)],
        free_body, sets={"hands_up": True}))
add(Act("surrender", "full surrender: drop your weapon and put your hands up",
        lambda c: [("drop_weapon",), ("clear",), ("hands_up", 120000), ("block", 1)], free_body,
        sets={"hands_up": True, "surrendered": True}))
add(Act("hands_down", "lower your hands", lambda c: [("clear",), ("face", 8000)], free_body, sets={"hands_up": False}))
add(Act("drop_weapon", "drop the weapon you are holding", lambda c: [("drop_weapon",)], armed))
add(Act("holster", "put your weapon away", lambda c: [("holster",)], armed, overrides_hold=False))
add(Act("draw_weapon", "pull out your weapon", lambda c: [("draw",)], armed, overrides_hold=False))
add(Act("attack", "attack the player (fight or shoot)", lambda c: [("block", 0), ("look_clear",), ("combat",)],
        free_body, ends=True, sets={"hostile": True, "hands_up": False}))
add(Act("cover", "take cover", lambda c: [("block", 0), ("cover",)], on_foot))
add(Act("cower", "crouch and cower in fear, shaking", lambda c: [("clear",), ("cower", 60000)], on_foot,
        child_ok=False, sets={"cowering": True}))

# Social & ambient
# 0.4.0: ANY everyday activity - the brain searches the game's ~450 human scenarios for it, checks in game that it
# really plays, learns what works, and falls back to real benches/chairs nearby or an emote (see activities.py)
def activity_text(name):
    # 0.5.9: args.option = one of the tagged options [A1].. the brain listed for this request
    return lambda c: [("activity", str(c.args.get("what") or c.args.get("activity") or name),
                       str(c.args.get("option") or c.args.get("tag") or "").strip("[] ").upper())]


add(Act("activity", "do any everyday thing for real: args {\"option\": \"A2\"} = one of the options listed for his request, "
                    "or {\"what\": \"sit and drink a beer\"} - the game finds the animation "
                    "(drink beer/whiskey/coffee, smoke cigarette/cigar, sit, sit on a bench/chair nearby, lean, sleep, play "
                    "guitar/banjo/fiddle/harmonica, eat, cook, read, write, pray, mourn, dance, sweep, wash, warm by the "
                    "fire, keep watch, check your gun, whittle, fan yourself, vomit...). Combine words freely.",
        activity_text("sit"), on_foot, child_ok=True))
add(Act("sit", "sit down (on the ground, or a bench/chair if one is near: say so in args.what)", activity_text("sit down"),
        on_foot, child_ok=True))
add(Act("stand_up", "get up / stop what you're doing", lambda c: [("activity_stop",), ("clear",), ("face", 8000)], free_body,
        child_ok=True, sets={"cowering": False, "doing": ""}))
add(Act("lean", "lean back against something", activity_text("lean"), on_foot))
add(Act("smoke", "light up and smoke (cigarette, cigar or pipe: args.what)", activity_text("smoke a cigarette"), on_foot))
add(Act("drink", "have a drink (beer, whiskey, moonshine, coffee: args.what; sitting if you say so)",
        activity_text("have a drink"), on_foot))
add(Act("eat", "sit down and eat", activity_text("sit and eat"), on_foot, child_ok=True))
add(Act("play_instrument", "play music (guitar, banjo, fiddle, harmonica: args.what)", activity_text("play the guitar"),
        on_foot))
add(Act("nod", "nod your head", lambda c: emote(CAT_REACTION, "KIT_EMOTE_REACTION_NOD_HEAD_1"), child_ok=True,
        overrides_hold=False))
add(Act("shake_head", "shake your head no", lambda c: emote(CAT_REACTION, "KIT_EMOTE_REACTION_SHAKEHEAD_1"),
        child_ok=True, overrides_hold=False))
add(Act("wave", "wave at the player", lambda c: emote(CAT_GREET, one_of("KIT_EMOTE_GREET_GENTLEWAVE_1", "KIT_EMOTE_GREET_SUBTLE_WAVE_1")),
        child_ok=True, overrides_hold=False))
add(Act("tip_hat", "tip your hat", lambda c: emote(CAT_GREET, "KIT_EMOTE_GREET_HAT_TIP_1"), overrides_hold=False))
add(Act("shake_hands", "offer a handshake", lambda c: emote(CAT_GREET, "KIT_EMOTE_GREET_HAND_SHAKE_1"), overrides_hold=False))
add(Act("dance", "dance a little", lambda c: emote(CAT_DANCE, one_of("KIT_EMOTE_DANCE_CAREFREE_A_1", "KIT_EMOTE_DANCE_DRUNK_A_1",
                                                                     "KIT_EMOTE_DANCE_OLD_A_1"), FULL), on_foot, child_ok=True))

# Horse & mount
add(Act("mount", "get on the nearest horse (your own if it's nearby)", lambda c: [("clear",), ("mount_near",)], on_foot))
add(Act("dismount", "get off your horse (and STAY off until you're told to get back on or the talk ends)",
        lambda c: [("dismount",)], mounted, child_ok=True))
add(Act("ride_with_me", "get on the player's horse or wagon with him (passenger)",
        lambda c: [("clear",), ("ride_with_player",), ("keep", 1), ("persist", 1)], ride_target,
        sets={"following": True, "riding": True}))
# Driving your own wagon (0.4.0: these really move the wagon)
add(Act("stop_wagon", "pull up / stop your wagon (it stays stopped until you drive on)", lambda c: [("veh_stop",)], driver,
        overrides_hold=False))
add(Act("give_ride", "stop and let him climb aboard your wagon (he gets on himself); you'll drive him", lambda c: [("veh_stop",)],
        driver, overrides_hold=False, sets={"giving_ride": True}))
add(Act("drive_on", "drive on / get going again along the road", lambda c: [("veh_go", SPEEDS.get(str(c.args.get("speed", "")), 6.0))],
        driver, overrides_hold=False))
add(Act("drive_to_marker", "drive to the place he marked on his map (his waypoint)",
        lambda c: [("veh_waypoint", SPEEDS.get(str(c.args.get("speed", "")), 7.0))], driver, overrides_hold=False))
add(Act("turn_wagon", "turn the wagon at the next chance; args: {\"dir\": \"left|right|back\"}",
        lambda c: [("veh_turn", str(c.args.get("dir", "left")).lower()[:5] or "left", 6.0)], driver, overrides_hold=False))
add(Act("drive_speed", "drive slower or faster; args: {\"speed\": \"slow|normal|fast\"}",
        lambda c: [("veh_speed", SPEEDS.get(str(c.args.get("speed", "normal")), 6.0))], driver, overrides_hold=False))
def leave_prims(c: ActCtx):
    """0.5.1: he climbs down - and whoever rides with him (his wife next to him) comes down too, unless he says not."""
    out = [("leave_vehicle",)]
    alone = str(c.args.get("with", "")).lower() in ("none", "alone", "no", "nobody")
    for h, rel in (getattr(c.conv, "together", {}) or {}).items():
        if not alone:
            out.append(("on", h, "leave_vehicle"))
    return out


add(Act("leave_vehicle", "get down off the wagon/vehicle (whoever rides with you gets down too unless args.with='none')",
        leave_prims,
        lambda c: "" if c.ped.get("in_vehicle") else "they are not in a vehicle", child_ok=True))
add(Act("lead_horse", "lead your horse by the reins", lambda c: [("clear",), ("lead_horse",)], on_foot))

# Items & economy (money is real: it changes the player's cash)
def pocket(c: ActCtx) -> float:
    """What they actually hand over: what was asked/offered, capped by what they have; robbed = all of it."""
    have = float((c.conv.ident.persona if c.conv.ident else {}).get("cash", 5.0))
    robbed = c.conv.flags.get("hands_up") or c.conv.seconds_since("threatened") < 180 or c.ped.get("aimed_at")
    want = c.args.get("amount", c.args.get("dollars"))
    try:
        amt = float(want) if want is not None else (have if robbed else min(have, 2.0))
    except (TypeError, ValueError):
        amt = have if robbed else min(have, 2.0)
    return round(max(0.0, min(have, amt)), 2)


def give_money(c: ActCtx):
    amt = pocket(c)
    if c.conv.ident:
        c.conv.ident.persona["cash"] = round(float(c.conv.ident.persona.get("cash", 0)) - amt, 2)
        c.args["amount"] = amt
    return emote(CAT_ACTION, "KIT_EMOTE_ACTION_BITING_GOLD_COIN_1") + [("money", int(amt * 100))] if amt > 0 else []


add(Act("give_money", "hand the player money (robbed: give it all right away); args: {\"amount\": dollars}",
        give_money, lambda c: free_body(c) or ("" if pocket(c) > 0 else "they have no money left"), overrides_hold=False))
add(Act("take_money", "accept money the player is handing you; args: {\"amount\": dollars}",
        lambda c: [("money", -int(money_amount(c, 500) * 100))], player_can_pay, overrides_hold=False))
add(Act("drop_money", "throw some money on the ground for the player; args: {\"amount\": dollars}",
        lambda c: [("money", int(money_amount(c) * 100))], free_body, overrides_hold=False))
add(Act("give_item", "hand over an item (roleplay only, nothing is added to the satchel); args: {\"item\": \"...\"}",
        lambda c: [], free_body, overrides_hold=False))
add(Act("take_item", "accept an item from the player (roleplay only)", lambda c: [], free_body, overrides_hold=False))
add(Act("offer_trade", "propose a trade or a price (say it out loud)", lambda c: [], overrides_hold=False))
add(Act("refuse", "refuse the request with a gesture",
        lambda c: emote(CAT_REACTION, one_of("KIT_EMOTE_REACTION_SHAKEHEAD_1", "KIT_EMOTE_REACTION_WAG_FINGER_1")),
        child_ok=True, overrides_hold=False))

# Reaction & status
add(Act("look_at", "look straight at the player", lambda c: [("look", 10000)], child_ok=True, overrides_hold=False))
add(Act("point", "point at something", lambda c: emote(CAT_ACTION, "KIT_EMOTE_ACTION_POINT_1"), child_ok=True,
        overrides_hold=False))
add(Act("laugh", "laugh", lambda c: emote(CAT_REACTION, one_of("KIT_EMOTE_REACTION_JOVIAL_LAUGH_1", "KIT_EMOTE_REACTION_POINTLAUGH_1")),
        child_ok=True, overrides_hold=False))
add(Act("angry_gesture", "angry threatening gesture",
        lambda c: emote(CAT_TAUNT if random.random() < 0.4 else CAT_REACTION,
                        one_of("KIT_EMOTE_TAUNT_FLIP_OFF_1", "KIT_EMOTE_REACTION_HOW_DARE_YOU_1", "KIT_EMOTE_TAUNT_IM_WATCHING_YOU_1")),
        overrides_hold=False))
add(Act("injured", "show that you are hurt", lambda c: [("mood", "MoodInjuredMedium", 8000)] + emote(CAT_REACTION, "KIT_EMOTE_REACTION_SHOT_1"),
        child_ok=True, overrides_hold=False))
add(Act("kneel", "kneel on the ground", lambda c: scenario("WORLD_HUMAN_GRAVE_MOURNING_KNEEL"), on_foot))
add(Act("beg", "beg for mercy", lambda c: emote(CAT_REACTION, "KIT_EMOTE_REACTION_BEGMERCY_1", FULL), free_body))
add(Act("sob", "break down crying", lambda c: [("mood", "MoodSadExtreme", 9000)] + emote(CAT_REACTION, "KIT_EMOTE_REACTION_SOB_1"),
        child_ok=True, overrides_hold=False))
add(Act("tremble", "shake in fear", lambda c: [("mood", "MoodPanic", 9000)] + emote(CAT_REACTION, "KIT_EMOTE_REACTION_SCARED_1"),
        child_ok=True, overrides_hold=False))
add(Act("thank", "thank the player", lambda c: emote(CAT_REACTION, "KIT_EMOTE_REACTION_THANKS_1"), child_ok=True,
        overrides_hold=False))
add(Act("shrug", "shrug", lambda c: emote(CAT_REACTION, "KIT_EMOTE_REACTION_SHRUG_1"), child_ok=True, overrides_hold=False))
add(Act("beckon", "wave the player over / 'follow me'", lambda c: emote(CAT_ACTION, one_of("KIT_EMOTE_ACTION_BECKON_1", "KIT_EMOTE_ACTION_FOLLOW_ME_1")),
        overrides_hold=False))
add(Act("blow_kiss", "blow the player a kiss", lambda c: emote(CAT_ACTION, "KIT_EMOTE_ACTION_BLOW_KISS_1"), overrides_hold=False))
add(Act("spit", "spit on the ground in contempt", lambda c: emote(CAT_ACTION, "KIT_EMOTE_ACTION_SPIT_1"), overrides_hold=False))
add(Act("calm_down", "make a 'calm down' gesture", lambda c: gesture(c, ["calm_down", "neutral_appease"]), child_ok=True,
        overrides_hold=False))

# journeys: take the player somewhere you talked about
def can_lead(c: ActCtx):
    return free_body(c) or ("" if not c.conv.flags.get("hostile") else "they're hostile")


add(Act("lead_to", "take him somewhere: your home/camp/family (kind=family), a missing relative (kind=relative), your lost "
                   "horse (kind=horse), a stash (kind=stash), ANY person you told him about - a friend, a working girl, a "
                   "fence, a doctor (kind=person), a man who owes him or wronged you - armed and expecting trouble "
                   "(kind=enemy), a COUPLE you know or heard of - an open couple, swingers, a husband who likes to watch "
                   "(kind=couple), or a real place in town - the saloon, the hotel, the brothel, the doctor, the mine "
                   "(kind=place, where=...). The people REALLY appear there, built from what you said; "
                   "args: {\"kind\": \"family|relative|horse|stash|person|enemy|couple|place\", \"where\": \"saloon\", "
                   "\"who\": \"my wife Martha and the kids\", \"story\": \"one line\", \"dollars\": 40}",
        lambda c: [], lambda c: "" if not c.conv.flags.get("hostile") else "they're hostile", overrides_hold=False,
        sets={"journey": True}))


add(Act("mark_stash", "tell him where a REAL hidden stash/treasure/loot is WITHOUT going there yourself: it gets a yellow "
                      "line on his map and really holds what you said; args: {\"what\": \"my pa's strongbox\", "
                      "\"dollars\": 5-200, \"story\": \"one line\"}",
        lambda c: [], lambda c: "" if not c.conv.flags.get("hostile") else "they're hostile", overrides_hold=False,
        sets={"stash_told": True}))


def report_prims(c: ActCtx):
    law = int(c.player.get("lawman") or 0)
    c.args["_law"] = law
    off = [("keep", 0), ("persist", 0)]
    if c.ped.get("mounted"):
        off.append(("dismount",))
    if law:          # straight to him, running (the brain keeps them going and plays the talk when they get there)
        return off + [("block", 0), ("look_clear",), ("goto_player", 1.6, 2.0, f"t={law}")]
    return off + [("block", 0), ("look_clear",), ("clear",), ("wander",)]


def lawman_near(c: ActCtx):
    r = free_body(c)
    if r:
        return r
    if c.ped.get("role") == "lawman" or c.conv.flags.get("is_law"):
        return "you ARE the law - use arrest"
    return ""


add(Act("report_to_law", "go to the lawman (the one nearby, or the sheriff in town) and report the player for what he did "
                         "- you walk/run there yourself and tell him; args: {\"crime\": \"murder|robbery|theft|assault|"
                         "threat|kidnapping|horse_theft|trespass\", \"what\": \"one line: what he did\"}",
        lambda c: report_prims(c), lawman_near, ends=True,
        sets={"reported": True, "following": False, "staying": False, "riding": False}))


def is_law(c: ActCtx):
    return "" if (c.ped.get("role") == "lawman" or c.conv.flags.get("is_law")) else "you are not the law"


CRIMES = {"murder": "CRIME_MURDER", "robbery": "CRIME_ROBBERY", "theft": "CRIME_THEFT", "assault": "CRIME_ASSAULT",
          "threat": "CRIME_THREATEN", "kidnapping": "CRIME_KIDNAPPING", "horse_theft": "CRIME_THEFT_HORSE",
          "trespass": "CRIME_TRESPASSING", "looting": "CRIME_LOOTING", "disturbance": "CRIME_DISTURBANCE"}


def crime_of(c: ActCtx) -> str:
    k = str(c.args.get("crime", "")).lower().replace(" ", "_")
    for key, val in CRIMES.items():
        if key in k:
            return val
    return "CRIME_ASSAULT" if c.conv.seconds_since("threatened") < 300 else "CRIME_DISTURBANCE"


add(Act("arrest", "(lawman) declare him under arrest / wanted: you draw on him and the whole town's law comes after him for "
                  "real; args: {\"crime\": \"murder|robbery|theft|assault|threat|kidnapping|horse_theft\"}",
        lambda c: [("draw",), ("crime", crime_of(c), int(c.args.get("bounty", 0) or 0))],
        lambda c: is_law(c) or free_body(c) or ("you took his money to look away" if c.conv.flags.get("bribed") else ""),
        overrides_hold=False, sets={"arresting": True}))


add(Act("mark_person", "tell him where to find someone you talked about WITHOUT going yourself (a yellow line on his map; "
                       "they really are there) - a person, a couple (kind=couple), an enemy (kind=enemy); args: "
                       "{\"kind\": \"person|couple|enemy\", \"who\": \"my cousin Ida, she knows about the gold\", "
                       "\"story\": \"one line\"}",
        lambda c: [], lambda c: "" if not c.conv.flags.get("hostile") else "they're hostile", overrides_hold=False))
add(Act("cancel_trip", "call off the trip you're on (he changed his mind, or you won't go on)", lambda c: [],
        lambda c: "" if c.conv.flags.get("journey") else "you're not taking him anywhere", overrides_hold=False,
        sets={"journey": False}))


def is_kidnap_leader(c: ActCtx):
    k = (c.conv.ident.d.get("flags", {}) if c.conv.ident else {}).get("kidnapper") or {}
    return "" if k.get("leader") else "not the kidnappers' leader"


add(Act("release_hostage", "let the hostage go (after you got paid, or if you give up); your men stand down",
        lambda c: [], is_kidnap_leader, overrides_hold=False))

# only for people the Director made into a serial killer
def is_killer(c: ActCtx):
    return "" if (c.conv.ident and c.conv.ident.d.get("flags", {}).get("serial_killer")) else "not a killer"


def quiet_spot(c: ActCtx):
    import math
    try:
        dx, dy = c.ped["x"] - c.player["x"], c.ped["y"] - c.player["y"]
        ang = math.atan2(dy, dx) + random.uniform(-0.6, 0.6)
        return (round(c.ped["x"] + math.cos(ang) * 60, 2), round(c.ped["y"] + math.sin(ang) * 60, 2), round(c.ped["z"], 2))
    except (KeyError, TypeError):
        return None


add(Act("lure_away", "walk off to somewhere quiet, expecting him to follow you (your secret purpose)",
        lambda c: [("clear",), ("goto_coord", *quiet_spot(c), 1.0)] if quiet_spot(c) else [],
        lambda c: is_killer(c) or free_body(c), ends=False))
add(Act("pull_knife", "pull your knife and go for him", lambda c: [("give_weapon", "WEAPON_MELEE_KNIFE"), ("block", 0), ("combat",)],
        lambda c: is_killer(c) or free_body(c), ends=True, sets={"hostile": True}))
KILLER_ONLY = {"lure_away", "pull_knife"}
LEADER_ONLY = {"release_hostage"}
LAW_ONLY = {"arrest"}
NOT_FOR_LAW = {"report_to_law"}
# actions that move the body somewhere (a mount, a dismount, a seat...). In the same turn nothing may play an
# emote/scenario on top of them: an emote is a full task in RDR2 and silently cancels the move.
MOVING = {"mount", "dismount", "ride_with_me", "leave_vehicle", "lead_horse", "follow", "flee", "walk_away", "come_here",
          "attack", "cover", "lure_away", "report_to_law", "stop_following", "wander", "attack_person", "go_to",
          "inspect_body", "talk_to", "go_to_place", "activity", "sit", "lean", "smoke", "drink", "eat", "play_instrument"}

ROMANTIC = {"blow_kiss"}
SCENE_OK = {"stop_making_love", "make_love", "agree_to_make_love", "agree_to_watch", "start_play", "end_play", "flee",
            "attack", "take_money", "give_money", "let_him_undress_you", "mark_person", "lead_to", "meet_later",
            "call_over", "order_person"}
CHILD_FORBIDDEN_WORDS = ROMANTIC | {"invite_home", "agree_to_watch", "start_play", "take_bribe", "work_for_him", "undress", "let_him_undress_you", "agree_to_make_love", "make_love", "stop_making_love",
                                    "lead_to", "mark_stash", "mark_person", "report_to_law", "arrest", "attack_person", "ride_with_me", "stay", "hands_up", "surrender", "kneel",
                                    "beg", "cower", "give_money", "take_money", "drop_money", "attack"}


INTIMATE_SET = {"undress", "dress", "let_him_undress_you", "agree_to_make_love", "make_love", "stop_making_love", "start_play",
                "end_play", "agree_to_watch", "invite_home", "follow", "stop_following", "come_here", "walk_away", "flee",
                "activity", "sit", "stand_up", "blow_kiss", "laugh", "nod", "shake_head", "wave", "take_money",
                "give_money", "mark_person", "lead_to", "refuse", "angry_gesture", "beckon", "go_to", "talk_to",
                "ride_with_me", "dismount", "wait", "stay", "attack", "drink", "smoke", "dance"}


DRIVING = {"stop_wagon", "give_ride", "drive_on", "drive_to_marker", "turn_wagon", "drive_speed"}


def fits_now(name: str, st: dict) -> bool:
    """0.5.5: only actions that can apply RIGHT NOW go in the prompt (wagon driving when they're on foot, 'dismount' when
    they're not on a horse... just cost time and tempt the AI). st: the person's live state."""
    if not st:
        return True
    if name in DRIVING:
        return bool(st.get("driver"))
    rules = {
        "leave_vehicle": st.get("in_vehicle"), "dismount": st.get("mounted"),
        "mount": not st.get("mounted") and not st.get("in_vehicle"), "lead_horse": not st.get("mounted") and not st.get("in_vehicle"),
        "inspect_body": st.get("bodies"), "attack_person": st.get("people"), "talk_to": st.get("people"),
        "call_over": st.get("people"), "order_person": st.get("people"), "go_to": st.get("people") or st.get("bodies"),
        "drop_weapon": st.get("armed") or st.get("has_weapon"), "holster": st.get("armed"),
        "draw_weapon": st.get("has_weapon") and not st.get("armed"), "hands_down": st.get("hands_up"),
        "dress": st.get("naked"), "stop_making_love": st.get("in_scene"), "end_play": st.get("play"),
        "cancel_trip": st.get("journey"), "stand_up": st.get("doing") or st.get("sitting") or st.get("cowering"),
        "stop_following": st.get("following") or st.get("riding"),
    }
    return bool(rules[name]) if name in rules else True


def catalog_text(child: bool, killer: bool = False, leader: bool = False, law: bool = False, compact: bool = False,
                 state: dict | None = None) -> str:
    """compact (0.5.5): the uncensored models get the intimate-moment subset - a shorter prompt they can follow.
    state (0.5.5): leave out what can't apply right now."""
    lines = []
    for a in A.values():
        if compact and a.name not in INTIMATE_SET:
            continue
        if not fits_now(a.name, state or {}):
            continue
        if child and not a.child_ok:
            continue
        if a.name in LAW_ONLY and not law:
            continue
        if a.name in NOT_FOR_LAW and law:
            continue
        if a.name in KILLER_ONLY and not killer:
            continue
        if a.name in LEADER_ONLY and not leader:
            continue
        lines.append(f"- {a.name}: {a.desc}")
    return "\n".join(lines)


def plan(names_or_objs, conv, ped: dict, player: dict) -> tuple[list[dict], list[str]]:
    """Validate the LLM's requested actions. Returns (approved steps, rejection notes)."""
    child = bool(conv.ident and conv.ident.persona.get("child"))
    approved, notes = [], []
    seen = set()
    # 0.5.5: models sometimes write ["lead_to", {"kind": "couple", ...}] - the dict is that action's args, not an action
    items = []
    for item in (names_or_objs or []):
        if isinstance(item, dict) and not (item.get("name") or item.get("action")) and items and isinstance(items[-1], str):
            items[-1] = {"name": items[-1], "args": item}
        else:
            items.append(item)
    for item in items[:4]:
        if isinstance(item, str):
            name, args, when = item, {}, None
        elif isinstance(item, dict):
            name = str(item.get("name") or item.get("action") or "")
            args = item.get("args") if isinstance(item.get("args"), dict) else {k: v for k, v in item.items()
                                                                               if k not in ("name", "action", "when")}
            when = item.get("when")
        else:
            continue
        name = name.strip().lower().replace(" ", "_").replace("-", "_")
        if name in seen:
            continue
        seen.add(name)
        a = A.get(name)
        if not a:
            notes.append(f"{name}: unknown action")
            continue
        if child and (not a.child_ok or name in CHILD_FORBIDDEN_WORDS):
            notes.append(f"{name}: not allowed for children")
            continue
        ctx = ActCtx(conv, ped, player, args)
        why = a.requires(ctx)
        if why:
            notes.append(f"{name}: impossible – {why}")
            continue
        try:
            prims = a.run(ctx)
        except Exception as e:  # keep the conversation going even if an action is broken
            notes.append(f"{name}: internal error {e}")
            continue
        prims = [tuple(x for x in p if x != "t=-1") for p in prims]      # target 'me' = the player (the default)
        approved.append({"name": name, "args": args, "when": (when or a.default_when),
                         "prims": prims, "act": a})
    # 0.5.5: in the middle of a love scene, words are free but the body stays in it: any other task would cancel the
    # animation (that's how the couple's scene broke). Only choices about the scene itself act.
    if conv.flags.get("in_scene"):
        for a in approved:
            if a["name"] not in SCENE_OK:
                if a["prims"]:
                    notes.append(f"{a['name']}: not now - you're in the middle of making love (say it, or stop_making_love first)")
                a["prims"] = []
    # nothing plays an emote/scenario on top of a move ordered in the same turn (it would cancel the move)
    if any(a["name"] in MOVING and a["when"] != "after" for a in approved):
        for a in approved:
            if a["name"] in MOVING:
                continue
            kept = [p for p in a["prims"] if p[0] not in ("emote", "scenario", "anim")]
            if len(kept) != len(a["prims"]):
                notes.append(f"{a['name']}: done without the gesture (you're busy moving)")
                a["prims"] = kept
    return approved, notes
