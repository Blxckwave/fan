"""Activities (0.4.0, rebuilt 0.5.9): "go to sleep", "sit down and have a drink", "play us a tune", "sweep the porch"...

0.5.9 - from your question "when I tell someone to sleep he never does":
  1. A CATALOG of everything a person can really do (data/activity_catalog.json, built by source/tools/build_catalog.py):
     every usable game scenario with a plain-English label, what it means (sleep, sit, drink...), the posture, what it
     needs (a bed, a chair, a bar = only at a real spot), which sexes have a version, the per-sex variants, and each
     variant's own animation loop as a fallback; plus the KIT emotes.
  2. MEANING, not spelling: many more words per idea ("shut-eye", "hit the hay", "turn in", "go to bed", "pass out"...),
     and the label words themselves count ("whittle", "knit", "pump water").
  3. OPTIONS: for a request the brain builds 4-6 real options - including the REAL spots around the person (that bed
     4 m away) - tagged [A1], [A2]... with what we know about each (worked before / failed here). The AI picks one by
     tag instead of guessing words.
  4. SEX-AWARE: a woman is never offered something that only has male versions (279 scenarios); the right variant
     is passed to the game.
  5. FALLBACK CHAIN per option: real spot -> scenario (variant) -> that variant's own animation loop -> next option ->
     a quick gesture. Every step is checked in the game; the AI is told what really happened.
  6. LEARNING that survives updates: what works / doesn't, per sex AND per model, in your own NpcVoice folder (not in
     the brain folder that every update replaces), on top of the shipped defaults (data/learned_defaults.json).
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from pathlib import Path

from .log import log

# concept -> scenario-name tokens (kept for older callers)
CONCEPTS = {
    "drink": ["DRINK", "DRINKING", "BEER", "WHISKEY", "MOONSHINE", "FLASK", "BOTTLE", "CHAMPAGNE"],
    "beer": ["BEER"], "whiskey": ["WHISKEY", "FLASK", "DRINKING"], "moonshine": ["MOONSHINE"],
    "coffee": ["COFFEE"], "champagne": ["CHAMPAGNE"],
    "smoke": ["SMOKE", "SMOKING", "CIGAR", "CIGARETTE", "PIPE"], "cigar": ["CIGAR"], "pipe": ["PIPE"],
    "sit": ["SIT", "SEAT", "SEATED"], "lean": ["LEAN"], "sleep": ["SLEEP", "ASLEEP", "PASSED_OUT"],
    "guitar": ["GUITAR"], "banjo": ["BANJO"], "fiddle": ["FIDDLE"], "harmonica": ["HARMONICA"], "trumpet": ["TRUMPET"],
    "mandolin": ["MANDOLIN"], "concertina": ["CONCERTINA"], "jaw harp": ["JAW_HARP"], "piano": ["PIANO"],
    "music": ["GUITAR", "BANJO", "FIDDLE", "HARMONICA", "TRUMPET", "MANDOLIN", "CONCERTINA", "JAW_HARP", "PIANO"],
    "eat": ["EAT", "EATING", "STEW", "FOOD", "CANNED"], "cook": ["COOK", "COOKING", "STIR", "CAULDRON", "KETTLE"],
    "read": ["READ", "READING", "BOOK", "NEWSPAPER", "JOURNAL"], "write": ["WRITE", "NOTEBOOK", "SKETCH", "JOURNAL"],
    "sketch": ["SKETCH", "SKETCHING", "SKETCHBOOK"], "whittle": ["WHITTLE"], "knife": ["SHARPEN_KNIFE", "WHITTLE"],
    "pray": ["PRAY", "PRAYER", "MOURNING"], "mourn": ["MOURNING"], "kneel": ["KNEEL"],
    "dance": ["DANCE", "DANCING"], "sweep": ["BROOM", "SWEEP"], "wash": ["WASH", "WASHBOARD", "LAUNDRY", "BUCKET"],
    "fire": ["FIRE"], "warm": ["FIRE"], "wait": ["WAITING", "STAND_WAITING", "IMPATIENT"],
    "guard": ["GUARD", "BADASS", "STERNGUY", "STARE"], "tough": ["BADASS", "STERNGUY"],
    "gun": ["CHECK_PISTOL", "PISTOL", "RIFLE", "GUN"], "clean": ["CLEAN"], "repair": ["REPAIR", "HAMMER", "WRENCH"],
    "hammer": ["HAMMER"], "saw": ["SAW"], "wood": ["SAW", "LUMBER", "AXE", "CHOP"], "chop": ["CHOP", "AXE"],
    "dig": ["DIG", "GRAVEDIG", "SHOVEL"], "fish": ["FISH"], "feed": ["FEED"], "chicken": ["CHICKEN"], "pig": ["PIGS"],
    "horse": ["HORSE_TEND", "BRUSH"], "brush": ["BRUSH"], "vomit": ["VOMIT", "HURL"], "drunk": ["DRUNK"],
    "pee": ["PEE"], "fan": ["FAN"], "mirror": ["MIRROR"], "inspect": ["INSPECT", "CROUCH_INSPECT"],
    "shop": ["SHOP_BROWSE"], "knock": ["KNOCK_DOOR"], "bartend": ["BARTENDER", "BAR_DRINK_BARTENDER"],
    "crouch": ["CROUCH"], "rest": ["SIT_BACK_EXHAUSTED", "REST", "SLEEP"], "think": ["STARE", "STERNGUY"],
    "knit": ["KNITTING"], "sew": ["SEWING"], "water": ["PUMP", "WATER", "BUCKET"], "hay": ["HAY", "PITCH", "RAKE"],
    "groom": ["GROOMING", "MIRROR"], "chess": ["CHESS"], "cards": ["CARDS"], "butcher": ["BUTCHER"], "tan": ["TANNING"],
    "carry": ["CARRYING", "SACK", "BOX"], "cower": ["COWER"],
}
# what people SAY -> concept. 0.5.9: many more ways of saying the same thing
WORDS = {
    # sleep / rest
    "sleep": "sleep", "asleep": "sleep", "nap": "sleep", "doze": "sleep", "doze off": "sleep", "snooze": "sleep",
    "kip": "sleep", "slumber": "sleep", "shut eye": "sleep", "shuteye": "sleep", "hit the hay": "sleep",
    "hit the sack": "sleep", "turn in": "sleep", "go to bed": "sleep", "get to bed": "sleep", "off to bed": "sleep",
    "bed down": "sleep", "lie down": "sleep", "lay down": "sleep", "pass out": "sleep", "passed out": "sleep",
    "close your eyes": "sleep", "get some rest": "rest", "rest": "rest", "relax": "rest",
    "take a load off": "rest", "take a break": "rest", "catch your breath": "rest", 
    # drink / smoke
    "drink": "drink", "drinking": "drink", "drunk": "drunk", "booze": "drink", "a drink": "drink", "shot": "whiskey",
    "swig": "drink", "wet your whistle": "drink", "beer": "beer", "ale": "beer", "whiskey": "whiskey",
    "whisky": "whiskey", "bourbon": "whiskey", "rum": "whiskey", "gin": "whiskey", "moonshine": "moonshine",
    "coffee": "coffee", "champagne": "champagne", "flask": "whiskey", "bottle": "drink", "smoke": "smoke",
    "smoking": "smoke", "cigarette": "smoke", "cig": "smoke", "cigar": "cigar", "pipe": "pipe", "light up": "smoke",
    "tobacco": "smoke",
    # sit / lean / postures
    "sit": "sit", "sitting": "sit", "seat": "sit", "bench": "sit", "chair": "sit", "stool": "sit",
    "have a seat": "sit", "take a seat": "sit", "lean": "lean", "kneel": "kneel", "crouch": "crouch", "squat": "crouch",
    # music
    "guitar": "guitar", "banjo": "banjo", "fiddle": "fiddle", "violin": "fiddle", "harmonica": "harmonica",
    "trumpet": "trumpet", "mandolin": "mandolin", "concertina": "concertina", "accordion": "concertina",
    "jaw harp": "jaw harp", "piano": "piano", "play": "music", "music": "music", "tune": "music", "song": "music",
    "sing": "music", "serenade": "music",
    # chores and pastimes
    "eat": "eat", "food": "eat", "stew": "eat", "supper": "eat", "dinner": "eat", "breakfast": "eat", "lunch": "eat",
    "cook": "cook", "cooking": "cook", "stir the pot": "cook", "read": "read", "book": "read", "newspaper": "read",
    "paper": "read", "write": "write", "journal": "write", "letter": "write", "draw": "sketch", "sketch": "sketch",
    "whittle": "whittle", "carve": "whittle", "sharpen": "knife", "pray": "pray", "mourn": "mourn", "grieve": "mourn",
    "dance": "dance", "sweep": "sweep", "broom": "sweep", "clean": "clean", "scrub": "clean", "dishes": "clean",
    "wash": "wash", "laundry": "wash", "fire": "fire", "warm up": "warm", "get warm": "warm", "wait": "wait",
    "guard": "guard", "keep watch": "guard", "stand guard": "guard", "look out": "guard", "clean your gun": "gun",
    "check your gun": "gun", "repair": "repair", "fix": "repair", "hammer": "hammer", "saw": "saw", "chop": "chop",
    "wood": "wood", "firewood": "chop", "dig": "dig", "shovel": "dig", "fish": "fish", "fishing": "fish",
    "feed": "feed", "chickens": "chicken", "pigs": "pig", "brush": "brush", "groom": "groom", "knit": "knit",
    "sew": "sew", "mend": "sew", "pump water": "water", "fetch water": "water", "hay": "hay",
    "pitchfork": "hay", "chess": "chess", "cards": "cards", "puke": "vomit", "vomit": "vomit", "throw up": "vomit",
    "piss": "pee", "pee": "pee", "fan": "fan", "mirror": "mirror", "inspect": "inspect", "look at": "inspect",
    "think": "think", "butcher": "butcher", "carry": "carry", "tough": "tough", "cower": "cower",
}
EXTRA_KEYS = {"drink", "smoke", "music", "read", "sleep", "drunk", "sketch", "whittle", "eat"}
GENERIC = {"drink": ("beer", "whiskey", "moonshine", "champagne", "coffee"), "smoke": ("cigar", "pipe"),
           "music": ("guitar", "banjo", "fiddle", "harmonica", "trumpet", "mandolin", "concertina", "jaw harp", "piano")}
ALT = {"beer": ["drink"], "whiskey": ["drink"], "moonshine": ["drink"], "champagne": ["drink"], "coffee": ["drink"],
       "cigar": ["smoke"], "pipe": ["smoke"], "banjo": ["guitar", "music"], "mandolin": ["guitar", "music"],
       "fiddle": ["music"], "rest": ["sit", "sleep"], "sleep": ["rest"], "warm": ["fire"], "pray": ["mourn", "kneel"]}
POSTURE_OF = {"sleep": "lie", "sit": "sit", "lean": "lean", "kneel": "kneel", "crouch": "crouch"}
# a spot type (the game's scenario point) -> what it is in words, by what it needs
SPOT_WORDS = {"bed": "a bed", "chair": "a chair", "bench": "a bench", "table": "a table", "bar": "the bar",
              "railing": "a railing", "wall": "a wall", "ledge": "a ledge / steps", "piano": "a piano", "fire": "a fire",
              "washbasin": "a wash basin", "door": "a door", "grave": "a grave", "spot": "a spot"}
EMOTE_FALLBACK = {
    "drink": (1, "KIT_EMOTE_ACTION_WET_YOUR_WHISTLE_1"), "beer": (1, "KIT_EMOTE_ACTION_WET_YOUR_WHISTLE_1"),
    "whiskey": (1, "KIT_EMOTE_ACTION_WET_YOUR_WHISTLE_1"), "moonshine": (1, "KIT_EMOTE_ACTION_WET_YOUR_WHISTLE_1"),
    "smoke": (1, "KIT_EMOTE_ACTION_SMOKE_CIGARETTE_1"), "cigar": (1, "KIT_EMOTE_ACTION_SMOKE_CIGAR_1"),
    "pray": (1, "KIT_EMOTE_ACTION_PRAYER_1"), "dance": (5, "KIT_EMOTE_DANCE_CAREFREE_A_1"),
    "music": (1, "KIT_EMOTE_ACTION_AIR_BANJO_1"), "write": (1, "KIT_EMOTE_ACTION_TAKE_NOTES_1"),
    "vomit": (0, "KIT_EMOTE_REACTION_HURL_1"), "think": (1, "KIT_EMOTE_ACTION_IDEA_1"),
    "sleep": (1, "KIT_EMOTE_ACTION_YAWN_1"), "rest": (1, "KIT_EMOTE_ACTION_YAWN_1"),
}
LASTING = {"lie", "sit", "kneel"}            # postures that stay after the talk (asleep, sitting...)
STOP_WORDS = {"the", "a", "an", "and", "your", "you", "some", "go", "to", "on", "in", "of", "for", "with", "at", "it",
              "me", "my", "do", "get", "have", "take", "please", "now", "up", "down", "there", "here", "just", "little",
              "bit", "while", "will", "can", "could", "would", "be", "that", "this", "out", "off", "over"}


def has(name: str, key: str) -> bool:
    return key in name if "_" in key else key in name.split("_")


def concepts_of(text: str) -> list[str]:
    t = " " + re.sub(r"[^a-z ]", " ", (text or "").lower().replace("shut-eye", "shut eye")) + " "
    t = re.sub(r"\s+", " ", t)
    found = []
    for w in sorted(WORDS, key=len, reverse=True):
        if f" {w} " in t or (len(w) > 4 and " " not in w and w in t):
            c = WORDS[w]
            if c not in found:
                found.append(c)
            t = t.replace(w, " ")
    return found


def words_of(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z]+", (text or "").lower()) if len(w) > 2 and w not in STOP_WORDS}


def user_dir() -> Path:
    """Your own NpcVoice folder - kept when you install a new version (the brain folder is replaced every time)."""
    env = os.environ.get("NPCVOICE_USER_DIR")
    if env:
        return Path(env)
    home = Path(os.environ.get("USERPROFILE") or Path.home())
    docs = home / "Documents"
    return (docs if docs.exists() else home) / "NpcVoice"


class Activities:
    def __init__(self, scenarios: list[str], learned_path: Path | None = None, catalog_path: Path | None = None,
                 defaults_path: Path | None = None):
        here = Path(__file__).resolve().parent.parent / "data"
        catalog_path = catalog_path or here / "activity_catalog.json"
        defaults_path = defaults_path or here / "learned_defaults.json"
        self.entries: list[dict] = []
        try:
            self.entries = json.loads(catalog_path.read_text(encoding="utf-8")).get("entries", [])
        except Exception as e:
            log.warning("[ACTIVITY] no activity catalog (%s) - only the scenario names", e)
        if not self.entries:                         # an old package: scenarios by name only
            self.entries = [{"id": s, "kind": "scenario", "label": s.lower().replace("_", " "), "concepts": [],
                             "posture": "stand", "needs": "", "sexes": ["f", "m"], "variants": {}, "clips": {}}
                            for s in scenarios if s.startswith(("WORLD_HUMAN_", "PROP_HUMAN_", "WORLD_CAMP_", "PROP_CAMP_"))]
        self.by_id = {e["id"]: e for e in self.entries}
        self.all = [e["id"] for e in self.entries if e["kind"] == "scenario"]
        self.lock = threading.Lock()
        self.defaults = {}
        try:
            self.defaults = json.loads(defaults_path.read_text(encoding="utf-8"))
        except Exception:
            self.defaults = {}
        self.path = learned_path if learned_path is not None else user_dir() / "learned_activities.json"
        self.learned = {}
        try:
            self.learned = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            self.learned = {}
        old = here / "learned_activities.json"          # 0.5.8 and older kept it in the brain folder
        if old.exists() and old.resolve() != Path(self.path).resolve():
            try:
                for k, v in json.loads(old.read_text(encoding="utf-8")).items():
                    if k not in self.learned:
                        self.learned[k] = v
            except Exception:
                pass

    # ── learning ──
    def save(self):
        with self.lock:
            try:
                Path(self.path).parent.mkdir(parents=True, exist_ok=True)
                Path(self.path).write_text(json.dumps(self.learned, indent=1, sort_keys=True), encoding="utf-8")
            except Exception as e:
                log.warning("[ACTIVITY] could not save what was learned: %s", e)

    def learn(self, scen: str, male: bool, ok: bool, model: str = "", how: str = "scenario"):
        sex = "m" if male else "f"
        keys = [f"{scen}|{sex}"] + ([f"{scen}|{sex}|{model.upper()}"] if model else [])
        if how != "scenario":
            keys = [f"{k}|{how}" for k in keys]
        with self.lock:
            for k in keys:
                e = self.learned.setdefault(k, {"ok": 0, "fail": 0})
                e["ok" if ok else "fail"] += 1
                e["t"] = int(time.time())
        log.info("[ACTIVITY] learned: %s (%s) %s (%s%s)", scen, "male" if male else "female", "WORKS" if ok else "broken",
                 how, f", {model}" if model else "")
        self.save()

    def record(self, scen: str, male: bool, model: str = "", how: str = "scenario") -> dict:
        """-> {"ok", "fail"} - this model first, then this sex; your own play first, then the shipped defaults."""
        sex = "m" if male else "f"
        suffix = "" if how == "scenario" else f"|{how}"
        for k in ([f"{scen}|{sex}|{model.upper()}{suffix}"] if model else []) + [f"{scen}|{sex}{suffix}"]:
            for src in (self.learned, self.defaults):
                if k in src:
                    return src[k]
        return {}

    def status(self, scen: str, male: bool, model: str = "") -> str:
        r = self.record(scen, male, model)
        if r.get("ok", 0) > r.get("fail", 0):
            return "worked before"
        if r.get("fail", 0) and not r.get("ok", 0):
            return "didn't play last time"
        return ""

    # ── search ──
    @staticmethod
    def expand(cons: list[str]) -> list[str]:
        out = list(cons)
        for g, specific in GENERIC.items():
            if g in out and any(x in out for x in specific):
                out.remove(g)
        return out

    def score(self, e: dict, cons: list[str], words: set[str], male: bool, model: str = "") -> float:
        if e["kind"] == "scenario" and ("m" if male else "f") not in e.get("sexes", ["f", "m"]):
            return -1                                # 0.5.9: no version of it for this sex
        ec = set(e.get("concepts") or [])
        name = e["id"]
        sc = 0.0
        for c in cons:
            if c in ec or (not ec and any(has(name, k) for k in CONCEPTS.get(c, [c.upper()]))):
                sc += 10 if c not in ("sit", "lean", "rest") else 6
            elif ALT.get(c) and ALT[c][0] in ec:
                sc += 5                              # the closest thing (a banjo -> a guitar)
            elif any(a in ec for a in ALT.get(c, [])[1:]):
                sc += 2                              # something in the family (a banjo -> any music)
            else:
                sc -= 7
        lw = words_of(e.get("label", ""))
        sc += 3 * len(words & lw)                    # the request's own words in the label ("whittle", "porch")
        if sc <= 0:
            return -1
        for c in EXTRA_KEYS:                         # doing something nobody asked for (sit -> sit AND play guitar)
            if c not in cons and c in ec:
                sc -= 3
        want_post = next((POSTURE_OF[c] for c in cons if c in POSTURE_OF), None)
        if want_post and e.get("posture") != want_post:
            sc -= 4
        if e["kind"] == "emote":
            sc -= 6                                  # a gesture is the last resort, not the thing itself
        if e.get("soft") and not any(c in ("fire", "warm", "lean") for c in cons):
            sc -= 2
        if name.startswith("WORLD_HUMAN_"):
            sc += 4
        if "bartend" not in cons and "BARTENDER" in name:
            sc -= 9
        sc -= name.count("_") * 0.3
        r = self.record(name, male, model)
        if r:
            sc += min(6, 2 * r.get("ok", 0)) - 4 * max(0, r.get("fail", 0) - r.get("ok", 0))
        return sc

    def options(self, what: str, male: bool, model: str = "", spots: list[dict] | None = None, limit: int = 6,
                said: str = "") -> tuple[list[dict], list[str]]:
        """The real things this person can do for `what` right here, best first -> ([option], concepts).
        option = {tag, kind: spot|scenario|emote, id, label, status, needs, spot?}"""
        cons = self.expand(concepts_of(what) + [c for c in concepts_of(said) if c not in concepts_of(what)])
        words = words_of(what) | words_of(said)
        if not cons and not words:
            return [], []
        ranked = []
        spots = spots or []
        for e in self.entries:
            sc = self.score(e, cons, words, male, model)
            if sc <= 0:
                continue
            need = e.get("needs") or ""
            if need:                                 # needs furniture: only as a REAL spot of that kind right here
                hits = [s for s in spots if s.get("id") == e["id"] or (need != "spot" and s.get("needs") == need)]
                for s in hits:
                    ranked.append((sc + 6 - min(5.0, float(s.get("d", 9)) / 3), {"kind": "spot", "entry": e, "spot": s}))
                continue
            ranked.append((sc, {"kind": e["kind"], "entry": e}))
        ranked.sort(key=lambda x: -x[0])
        out, seen = [], set()
        for sc, o in ranked:
            e = o["entry"]
            stag = (o.get("spot") or {}).get("tag")
            key = ("spot", stag) if stag else (o["kind"], e["id"])
            if key in seen:
                continue                             # one option per real spot (the best use of that bed)
            seen.add(key)
            lbl = e["label"]
            if o["kind"] == "spot":
                s = o["spot"]
                lbl = f"{lbl} - on {SPOT_WORDS.get(s.get('needs') or e.get('needs'), 'a spot')} {float(s.get('d', 0)):.0f} m away ({s.get('tag')})"
            out.append({"kind": o["kind"], "id": e["id"], "label": lbl, "needs": e.get("needs", ""),
                        "posture": e.get("posture", "stand"), "status": self.status(e["id"], male, model),
                        "spot": o.get("spot"), "cat": e.get("cat")})
            if len(out) >= limit:
                break
        if not any(o["kind"] == "emote" for o in out):
            em = self.emote_for(cons)
            if em and len(out) < limit + 1:
                out.append({"kind": "emote", "id": em[1], "label": em[1].replace("KIT_EMOTE_", "").replace("_1", "")
                            .replace("_", " ").lower() + " (a quick gesture)", "needs": "", "posture": "stand",
                            "status": "", "spot": None, "cat": em[0]})
        for i, o in enumerate(out, 1):
            o["tag"] = f"A{i}"
        return out, cons

    def variant_for(self, scen: str, male: bool, ped: int = 0) -> str:
        """The game's own version of this scenario for this sex ('' = let the game choose)."""
        e = self.by_id.get(scen) or {}
        v = e.get("variants") or {}
        pool = v.get("m" if male else "f") or v.get("any") or []
        if not pool:
            return ""
        good = [x for x in pool if self.record(x, male).get("ok")] or pool
        return good[ped % len(good)]

    def clip_for(self, scen: str, variant: str, male: bool) -> tuple[str, str] | None:
        e = self.by_id.get(scen) or {}
        clips = e.get("clips") or {}
        if variant and variant in clips:
            return tuple(clips[variant])
        for v, c in clips.items():
            sv = "f" if "_FEMALE" in v else "m" if re.search(r"_MALE(_|$)", v) else "any"
            if sv in ("any", "m" if male else "f"):
                return tuple(c)
        return None

    def lasting(self, scen: str) -> bool:
        return (self.by_id.get(scen) or {}).get("posture") in LASTING

    # ── older callers ──
    def candidates(self, what: str, male: bool, limit: int = 4, model: str = "") -> tuple[list[str], list[str]]:
        opts, cons = self.options(what, male, model, [], limit + 2)
        return [o["id"] for o in opts if o["kind"] == "scenario"][:limit], cons

    def emote_for(self, cons: list[str]):
        for c in cons:
            if c in EMOTE_FALLBACK:
                return EMOTE_FALLBACK[c]
        return None

    def wants_furniture(self, cons: list[str], what: str) -> bool:
        w = (what or "").lower()
        return any(k in w for k in ("bench", "chair", "stool", "table", "bar", "porch", "railing", "fire", "wall", " bed",
                                    "cot", "bedroll", "mattress", "couch", "sofa"))

    def spot_of(self, type_name: str) -> dict | None:
        """A scenario point's type name -> what it is (label, needs) from the catalog."""
        e = self.by_id.get(type_name)
        if not e:
            base = max((k for k in self.by_id if type_name.startswith(k + "_")), key=len, default=None)
            e = self.by_id.get(base) if base else None
        if not e or e["kind"] != "scenario":
            return None
        return {"id": e["id"], "label": e["label"], "needs": e.get("needs") or "spot", "posture": e.get("posture", "stand")}
