"""Calibration (0.5.9): find out, in YOUR game, which activities really play - instead of learning it one failure at a time.

In the black brain window type:
    calibrate            every in-place activity in the catalog (about 200 - takes a while: ~10 s each)
    calibrate sleep      only what matches a word ("sleep", "drink", "guitar", "sit"...)
    calibrate stop       stop it
Stand somewhere open and quiet (not in town, no law around). A man and a woman are spawned in front of you; each one
tries every activity in their own version, then (if the game refuses) that version's own animation loop. What plays is
saved to your NpcVoice folder (learned_activities.json) and used from then on; a report goes to calibration_report.txt.
"""
from __future__ import annotations

import asyncio
import time

from .activities import concepts_of, user_dir, words_of
from .log import log

MALE = "A_M_M_ValFarmer_01"
FEMALE = "A_F_M_ValTownfolk_01"


class Calibrator:
    def __init__(self, brain):
        self.b = brain
        self.task: asyncio.Task | None = None
        self.stop = False

    def start(self, what: str = ""):
        if self.task and not self.task.done():
            self.b.asi.toast("info", 5, "Calibration is already running ('calibrate stop' ends it).")
            return
        self.stop = False
        self.task = asyncio.create_task(self.run(what))

    def cancel(self):
        self.stop = True

    def entries(self, what: str) -> list[dict]:
        cons, words = concepts_of(what), words_of(what)
        out = []
        for e in self.b.activities.entries:
            if e["kind"] != "scenario" or e.get("needs"):
                continue                                 # furniture ones need a real spot - tested when used
            if what and not (set(cons) & set(e.get("concepts") or []) or words & words_of(e["label"])):
                continue
            out.append(e)
        return out

    async def run(self, what: str):
        b = self.b
        todo = self.entries(what)
        if not todo:
            b.asi.toast("warn", 6, f"Calibration: nothing in the catalog matches '{what}'.")
            return
        pl = b.game.player or {}
        x, y, z = float(pl.get("x", 0)), float(pl.get("y", 0)), float(pl.get("z", 0))
        peds = {}
        for sex, model, dx in (("m", MALE, 3.0), ("f", FEMALE, -3.0)):
            h = await b.couples.spawned(b.couples.spawn(model, x + dx, y + 3.0, z, 180.0, "ground"))
            if h:
                peds[sex] = (h, model)
                b.asi.send("actor", h, 1)
        if not peds:
            b.asi.toast("err", 6, "Calibration: couldn't spawn the two test people.")
            return
        b.asi.toast("ok", 8, f"Calibration: {len(todo)} activities x {len(peds)} people - stand still, 'calibrate stop' ends it.")
        log.info("[CALIBRATE] %d activities, peds %s", len(todo), peds)
        caps = set((b.asi_info or {}).get("caps") or [])
        report, n_ok, n_clip, n_bad = [], 0, 0, 0
        t0 = time.time()
        try:
            for i, e in enumerate(todo, 1):
                if self.stop:
                    break
                for sex, (h, model) in peds.items():
                    if sex not in e.get("sexes", ["f", "m"]) or b.dead(h):
                        continue
                    male = sex == "m"
                    variant = b.activities.variant_for(e["id"], male, i) if "scen_variant" in caps else ""
                    r = await b.scen_try(h, ("scenario", e["id"], -1, variant), 7)
                    ok = bool(r.get("ok"))
                    b.activities.learn(e["id"], male, ok, model)
                    how = "scenario" if ok else ""
                    if not ok and "anim_try" in caps:
                        clip = b.activities.clip_for(e["id"], variant, male)
                        if clip:
                            r = await b.scen_try(h, ("anim_try", clip[0], clip[1]), 5)
                            if r.get("ok"):
                                how = "clip"
                            b.activities.learn(e["id"], male, bool(r.get("ok")), model, "clip")
                    n_ok += how == "scenario"
                    n_clip += how == "clip"
                    n_bad += not how
                    report.append(f"{e['id']:<55} {sex}  {how or 'DOES NOT PLAY'}   ({e['label']})")
                    b.asi.prim(h, "calibrate", ("clear",))
                    await asyncio.sleep(0.6)
                if i % 10 == 0:
                    b.asi.toast("info", 4, f"Calibration {i}/{len(todo)}: {n_ok} play, {n_clip} only as a loop, {n_bad} don't")
        finally:
            for h, _ in peds.values():
                b.asi.send("actor", h, 0)
                b.asi.send("despawn", h, "delete")
            try:
                d = user_dir()
                d.mkdir(parents=True, exist_ok=True)
                (d / "calibration_report.txt").write_text(
                    f"NpcVoice calibration {time.strftime('%Y-%m-%d %H:%M')} ({what or 'everything'}), "
                    f"{time.time() - t0:.0f} s\n{n_ok} play as scenarios, {n_clip} only as their animation loop, "
                    f"{n_bad} don't play\n\n" + "\n".join(report) + "\n", encoding="utf-8")
            except Exception as ex:
                log.warning("[CALIBRATE] report not written: %s", ex)
            msg = f"Calibration done: {n_ok} play, {n_clip} as a loop only, {n_bad} don't - saved (calibration_report.txt)."
            b.asi.toast("ok", 10, msg)
            log.info("[CALIBRATE] %s", msg)
