"""What the NPC you're talking to can see around them, and how they're connected to those people.

Relationships are generated once per pair (NPC identity + the other person's face/clothes) and stored in the
NPC's memory, so the same neighbour stays the same neighbour. Rules of thumb:
  - people doing the same job nearby (cotton pickers, dock workers, miners...) are often workmates
  - locals in the NPC's own town: some neighbours/acquaintances, a few friends, rarely family
  - lawmen, travellers, gang members: mostly strangers
  - anyone the player has talked to before keeps the name/job the brain already gave them
"""
from __future__ import annotations

import random
import re

from .persona import F_FIRST, M_FIRST, SURNAMES

WORK_ROLES = {"labourer", "rancher", "shopkeeper", "bartender", "doctor", "guard", "lawman", "soldier", "prostitute"}

LORE = {
    "Valentine": "a muddy livestock town in the Heartlands of New Hanover: cattle, cowhands, saloons, a doctor; "
                 "Sheriff Malloy keeps a loose kind of order.",
    "Rhodes": "a small Lemoyne town among tobacco farms; the Gray and Braithwaite families have an old, bloody feud; "
              "Sheriff Leigh Gray is the law.",
    "Saint Denis": "the biggest city around: trolleys, factories, rich folk and slums side by side; the police are "
                   "everywhere and crime boss Angelo Bronte runs a lot from the shadows.",
    "Strawberry": "a mountain town in West Elizabeth that wants to become a fancy tourist resort; it has a jail.",
    "Blackwater": "a modern, growing town in West Elizabeth; government men and Pinkertons are around; people still "
                  "talk about the bloody ferry robbery there.",
    "Annesburg": "a company coal-mining town in Roanoke Ridge: soot, poor miners, hard lives.",
    "Van Horn": "a lawless trading post on the coast: no sheriff, rough sailors and thieves.",
    "Armadillo": "a desert town in New Austin struck by cholera: half empty, sick and grim.",
    "Tumbleweed": "an old, nearly abandoned desert town in New Austin.",
    "Emerald Ranch": "a ranching settlement in New Hanover with a few farms and a fence who buys stolen goods.",
    "Lagras": "a tiny swamp village deep in Bluewater Marsh.",
    "Wapiti": "a reservation in the Grizzlies where the Wapiti people were pushed by the government.",
}
ERA = ("It's 1899: the frontier is closing, the law and the railroads are taming the West, Pinkertons hunt outlaw "
       "gangs, and everyone has heard of the Van der Linde gang.")


BUILDINGS = {
    "Valentine": "saloons, a general store, gunsmith, doctor, butcher, stables, the sheriff's office, a hotel and the train "
                 "station with its post office",
    "Saint Denis": "many saloons (the Bastille among them), shops, a tailor, a gunsmith, doctors, the police station, a "
                   "bank, the train station with a post office, a theatre, trolleys, the docks and the market",
    "Rhodes": "the Parlour House saloon, a general store, gunsmith, doctor, sheriff's office, a bank and the train station",
    "Strawberry": "a general store, doctor, sheriff's office with a jail, a hotel and the welcome centre",
    "Blackwater": "a saloon, general store, gunsmith, doctor, a bank, the police office, the train station and the docks",
    "Annesburg": "a saloon, general store, gunsmith, doctor, the train station and the coal mine",
    "Van Horn": "a rough saloon, a general store, a doctor, the docks and an old lighthouse",
    "Armadillo": "a saloon, general store, gunsmith, doctor, sheriff's office, the train station, and the sick and the dead",
    "Tumbleweed": "a saloon, a general store, a gunsmith and the sheriff's office",
}


def lore_line(place: str) -> str:
    base = LORE.get(place, "")
    b = BUILDINGS.get(place)
    return (base + (f" In town: {b}." if b else "")).strip()


def _name(rng, male: bool) -> str:
    return f"{rng.choice(M_FIRST if male else F_FIRST)} {rng.choice(SURNAMES)}"


# ── 0.5.1: one world, one truth ──────────────────────────────────────────────────────────────────────────────────
# 0.5.0 let every NPC invent names for the people around them: Thomas called the woman beside him "Winifred, my
# neighbour", then she told you she was Ruth Peterson. Now a person has ONE name for everybody (the one they'll give
# you when you talk to them), relationships are mirrored (if he's her husband, she's his wife), and two adults who
# are glued together (riding one horse, standing arm in arm) are a pair - married, courting or kin.
NAMES: dict[str, dict] = {}        # model-outfit key (or handle) -> {"name", "job"} for people not talked to yet
PAIRS: dict[tuple, str] = {}       # (key A, key B) -> what B is to A
MIRROR = {"your husband": "your wife", "your wife": "your husband", "your sweetheart": "your sweetheart",
          "your neighbour": "your neighbour", "a friend of yours": "a friend of yours", "your cousin": "your cousin",
          "your workmate": "your workmate", "your friend from work": "your friend from work", "your brother": None,
          "your sister": None, "an old friend": "an old friend", "someone you know by name": "someone you know by name",
          "your boss": "a hand who works for you", "a new hand you barely know": "your new boss"}
HANDLE_IDENT = {}                  # filled by the brain: ped handle -> identity id (people talked to / spawned)


def key_of(other: dict) -> str:
    o = int(other.get("o", other.get("outfit", 0)) or 0) & 0xFFFFFFFF
    m = int(other.get("m", other.get("model", 0)) or 0) & 0xFFFFFFFF
    return f"{m:08x}-{o:08x}" if o else f"h{int(other.get('h', other.get('ped', 0)) or 0)}"


def name_for(key: str, male: bool, seed: str = "") -> dict:
    """The name this person will have for EVERYONE (and that they'll give when you talk to them)."""
    if key not in NAMES:
        rng = random.Random(f"name|{key}|{seed}")
        NAMES[key] = {"name": _name(rng, male)}
    return NAMES[key]


def _ident_of(memory, handle: int):
    iid = HANDLE_IDENT.get(int(handle or 0))
    return memory.ids.get(iid) if (iid and memory is not None and hasattr(memory, "ids")) else None


def _mirror(rel: str, my_male: bool) -> str | None:
    if rel in ("your brother", "your sister"):
        return "your brother" if my_male else "your sister"
    if rel in ("your son", "your daughter"):
        return "your pa" if my_male else "your ma"
    if rel in ("your pa", "your ma", "your mother", "your father"):
        return "your son" if my_male else "your daughter"
    return MIRROR.get(rel)


def relation(conv, other: dict, other_cls: dict, place: str, memory) -> dict:
    """-> {name, rel, job, male} for another person near the NPC (stable across calls AND across NPCs)."""
    me = conv.ident
    key = key_of(other)
    mykey = getattr(conv, "_key", None) or f"h{conv.ped}"
    rels = me.d.setdefault("relations", {})
    male = bool(other.get("male"))
    known_ident = _ident_of(memory, other.get("h"))
    if known_ident is None and int(other.get("o", 0) or 0) and memory is not None:
        known_ident = memory.find(int(other.get("m", 0)), int(other.get("o", 0)), place, {me.id}, include_dead=True)
    # someone they're tied to for real (a spawned family member, a person the player met): their real name
    if known_ident is not None:
        kp = known_ident.persona
        r = rels.get(f"id:{known_ident.id}") or {}
        mine = rels.get("guide") or {}
        if not r and mine.get("name") == kp.get("name"):     # the one who brought the stranger here
            r = {"rel": mine.get("rel", "family")}
        if not r:          # the member's own side ('guide') tells who I am to them -> mirror it
            g = (known_ident.d.get("relations") or {}).get("guide") or {}
            if g.get("name") == me.persona.get("name"):
                rel = _mirror(g.get("rel", ""), me.persona.get("sex") == "male") or "family"
                r = {"rel": rel}
        rel = r.get("rel") or PAIRS.get((mykey, key)) or rels.get(key, {}).get("rel") or "someone you've seen around"
        out = {"name": kp["name"], "rel": rel, "job": kp.get("job", ""), "male": kp.get("sex") == "male"}
        rels[f"id:{known_ident.id}"] = {"rel": rel}
        return out
    if key in rels and not key.startswith("h"):
        r = rels[key]
        r.setdefault("name", name_for(key, male)["name"])
        return r
    if (mykey, key) in PAIRS:
        rel = PAIRS[(mykey, key)]
        r = {"name": name_for(key, male)["name"], "rel": rel, "job": other_cls.get("model_job") or other_cls.get("role") or "",
             "male": male}
        rels[key] = r
        return r
    rng = random.Random(f"{me.id}|{key}")
    my_role, their_role = me.persona.get("role"), other_cls.get("role") or "townsfolk"
    local = (me.persona.get("home") == place) or (me.d.get("home_zone") == place)
    de = float(other.get("de", 99))
    i_child, they_child = bool(me.persona.get("child")), bool(other_cls.get("child"))
    my_male = me.persona.get("sex") == "male"
    glued = de < 1.6 or (other.get("mnt") and de < 1.3) or other.get("_together")   # same horse / same wagon / arm in arm
    if they_child:
        rel = rng.choices(["your own child", "a neighbour's kid", "a kid you've seen around", "a stranger's kid"],
                          [10, 30, 35, 25])[0] if local and not i_child else "another kid"
        if glued and not i_child:
            rel = "your own child"
    elif glued and not i_child and my_male != male and me.persona.get("age", 30) >= 18:
        fam = me.persona.get("family", "")
        spouse_taken = any(str(v.get("rel", "")) in ("your husband", "your wife") for k, v in rels.items()
                           if isinstance(v, dict) and k != key)
        # a man and a woman on one horse / one wagon seat / arm in arm: almost always a couple - but a widow's late
        # husband stays dead and a married woman has ONE husband (0.5.8: she had a living husband nearby AND a story
        # about her husband being killed)
        if fam.startswith("widowed") or spouse_taken:
            rel = rng.choices(["your sweetheart", "your brother" if male else "your sister", "a friend of yours"], [50, 25, 25])[0]
        elif fam.startswith("married") or rng.random() < 0.7:
            rel = "your husband" if male else "your wife"
        else:
            rel = rng.choices(["your sweetheart", "your brother" if male else "your sister"], [75, 25])[0]
    elif glued and not i_child:
        rel = rng.choices(["a friend of yours", "your brother" if male else "your sister", "your cousin", "your workmate"],
                          [40, 20, 15, 25])[0]
    elif my_role == their_role and my_role in WORK_ROLES | {"townsfolk"} and other.get("scen"):
        rel = rng.choices(["your workmate", "your friend from work", "your boss", "a new hand you barely know"],
                          [45, 25, 10, 20])[0]
    elif their_role in ("lawman", "guard"):
        rel = "the local lawman" if local and rng.random() < 0.6 else "a lawman you don't know"
    elif their_role in ("outlaw", "drifter", "backwoods"):
        rel = "a rough stranger"
    elif local:
        rel = rng.choices(["your neighbour", "someone you know by name", "a friend of yours", "your cousin",
                           "your sweetheart" if me.persona.get("romance_openness", 0) > 0.4 else "an old friend",
                           "a stranger"], [22, 28, 14, 4, 3, 29])[0]
    else:
        rel = "a stranger"
    anon = rel in ("a stranger", "a rough stranger", "a lawman you don't know", "a stranger's kid", "another kid")
    name = "" if anon else name_for(key, male)["name"]
    if rel in ("your husband", "your wife", "your own child", "your brother", "your sister") and name:
        name = name.split()[0] + " " + me.persona["name"].split()[-1]          # family shares the surname
        NAMES[key] = {"name": name}
    r = {"name": name, "rel": rel, "job": other_cls.get("model_job") or other_cls.get("role") or "", "male": male}
    if not key.startswith("h"):
        rels[key] = r
    back = _mirror(rel, my_male) if rel != "your own child" else ("your pa" if my_male else "your ma")
    if back and not anon:
        PAIRS[(key, mykey)] = back
        PAIRS[(mykey, key)] = rel
    if rel in ("your husband", "your wife") and "married" not in me.persona.get("family", ""):
        rest = re.sub(r"^(single|courting|widowed)\s*,?\s*", "", me.persona.get("family", ""))
        me.persona["family"] = f"married to {name}" + (", " + rest if rest else "")
        me.dirty()
    return r


def family_facts(conv, near_peds: list[dict], memory) -> list[str]:
    """0.5.8: the hard facts about this person's own people, so the AI can't contradict them: a husband who is ALIVE
    and right here is not 'killed years ago'; a widow's husband is dead and no man nearby is him; one spouse only."""
    me = conv.ident
    fam = str(me.persona.get("family", ""))
    my_male = me.persona.get("sex") == "male"
    spouse_word = "wife" if my_male else "husband"
    out, here = [], []
    for k, v in (me.d.get("relations") or {}).items():
        if not isinstance(v, dict) or v.get("rel") not in ("your husband", "your wife", "your own child", "your son",
                                                            "your daughter", "your brother", "your sister", "your pa", "your ma"):
            continue
        h = 0
        if k.startswith("id:") and memory is not None:
            ident = memory.ids.get(k[3:])
            if ident is not None:
                if ident.d.get("dead"):
                    out.append(f"{v['rel'].replace('your ', 'Your ')} {ident.persona.get('name', '')} is DEAD (it happened "
                               "recently)." if conv.ident.d.get("knows_dead", {}).get(ident.id) else "")
                    continue
                h = next((hh for hh, iid in (HANDLE_IDENT or {}).items() if iid == ident.id), 0)
                name = ident.persona.get("name", "")
            else:
                name = ""
        else:
            name = v.get("name", "")
        p = next((x for x in near_peds if int(x.get("h", 0)) == h and h), None) if h else \
            next((x for x in near_peds if key_of(x) == k), None)
        if p is not None and p.get("alive", 1):
            here.append((v["rel"], name, p.get("de", p.get("d", 0))))
    for rel, name, d in here:
        out.append(f"{rel.replace('your ', 'Your ')} {name} is ALIVE and right here ({d:.0f} m). Never tell a story in which "
                   f"{name.split()[0] if name else 'they'} died or was killed - it isn't true.")
    if fam.startswith("widowed"):
        late = me.d.get("late_spouse") or ""
        out.append(f"You are widowed: your {spouse_word}{' ' + late if late else ''} died some years ago - ONE story of how, "
                   "the same every time you tell it. Nobody around you is your late " + spouse_word + ".")
    elif fam.startswith("married") and not any(r in ("your husband", "your wife") for r, _, _ in here):
        out.append(f"You are married; your {spouse_word} is alive (not here right now - at home or at work). Don't "
                   f"invent a dead {spouse_word}.")
    told = me.d.get("told_facts") or []
    if told:
        out.append("What you've already told him about your life (stay consistent): " + "; ".join(told[-6:]))
    return [x for x in out if x]


REL_WORDS = {"your husband": "husband man hubby", "your wife": "wife missus woman", "your own child": "son daughter kid child boy girl",
             "your sweetheart": "sweetheart lover beau girl fella", "your brother": "brother", "your sister": "sister",
             "your pa": "pa father dad daddy", "your ma": "ma mother mama mom momma", "your son": "son boy kid child",
             "your daughter": "daughter girl kid child", "your cousin": "cousin", "your neighbour": "neighbour neighbor",
             "the local lawman": "lawman sheriff deputy law", "a lawman you don't know": "lawman sheriff deputy law",
             "a friend of yours": "friend", "your workmate": "workmate friend coworker"}


def describe(conv, near_peds: list[dict], peddb, place: str, memory) -> tuple[list[str], list[str]]:
    """-> (lines about living people around, lines about the dead) from the NPC's point of view."""
    alive_lines, dead_lines = [], []
    targets, words = {}, {}           # [P1] / [B1] tags the AI can use as action targets (+ names/relations for them)
    mine = {}
    try:
        from .game import Game  # noqa
        mine = conv._me_tick() if hasattr(conv, "_me_tick") else {}
    except Exception:
        mine = {}
    myveh, mymount = int(mine.get("vh", 0) or 0), int(mine.get("mh", 0) or 0)
    conv.together = {}
    for p in sorted(near_peds, key=lambda x: x.get("de", x.get("d", 99))):
        if int(p.get("h", 0)) == int(conv.ped):
            continue
        d = p.get("de", p.get("d", 99))
        cls = peddb.classify(int(p.get("m", 0)), bool(p.get("male")))
        if cls["nonhuman"]:
            continue
        together = (myveh and int(p.get("vh", 0) or 0) == myveh) or (mymount and int(p.get("mh", 0) or 0) == mymount) \
            or bool(p.get("how"))           # 0.5.7: read from the seats themselves (tick 'mates')
        if together:
            p = dict(p, _together=True)
        r = relation(conv, p, cls, place, memory)
        who = f"{r['name']} ({r['rel']})" if r["name"] else r["rel"]
        if together and p.get("alive", 1):
            conv.together[int(p.get("h", 0))] = r["rel"]
        what = "man" if r["male"] else "woman"
        if cls.get("child"):
            what = "boy" if r["male"] else "girl"
        look = cls.get("look") or ""
        job = f" ({r['job']})" if r["job"] and r["job"] not in ("townsfolk", "") else ""
        sees = p.get("elos", p.get("los", 0))
        wset = set((r["name"] + " " + r["rel"] + " " + r["job"] + " " + look + " " + what + " " +
                    REL_WORDS.get(r["rel"], "")).lower().replace("(", " ").replace(")", " ").split())
        if not p.get("alive", 1):
            if d > 70:
                continue
            killer = " - the PLAYER killed them" if p.get("kp") else ""
            seen = "you can see the body" if sees else "out of your sight - but he can point you to it"
            tag = f"B{sum(1 for k in targets if k[0] == 'B') + 1}"
            targets[tag] = int(p.get("h", 0))
            words[tag] = wset | {"body", "corpse", "dead"}
            dead_lines.append(f"[{tag}] DEAD: {who}, a {what}{job}, lying {d:.0f} m from you ({seen}){killer}.")
        else:
            if d > 40 or len(alive_lines) >= 10:
                continue
            doing = ("fleeing" if p.get("flee") else "on horseback" if p.get("mnt") else
                     "busy working" if p.get("scen") else "walking by" if p.get("spd", 0) > 0.8 else "standing around")
            if p.get("hk"):
                doing = "making love with someone"
            if together:
                how = p.get("how") or ""
                drv_me = bool(mine.get("drv"))
                him = "him" if r["male"] else "her"
                if how == "driver":
                    doing = f"DRIVING the wagon you're riding on - right beside you, arm's reach"
                elif how == "passenger" or (myveh and not how):
                    doing = ("sitting right next to you on YOUR wagon - your passenger" if drv_me else
                             "riding on the same wagon, right beside you")
                elif how == "rider":
                    doing = f"holding the reins of the horse you're both on - you're riding BEHIND {him}, holding on"
                elif how == "behind":
                    doing = f"riding behind you on YOUR horse, holding on to you"
                else:
                    doing = "riding on the same horse with you"
            watch = ", watching" if sees and d < 20 else ""
            tag = f"P{len(alive_lines) + 1}"
            targets[tag] = int(p.get("h", 0))
            words[tag] = wset
            looks = f" - {look}" if look and look not in who else ""
            alive_lines.append(f"[{tag}] {who} - a {what}{job}{looks}, {d:.0f} m away, {doing}{watch}"
                               + ("" if sees or d < 6 else " (not in your line of sight)") + ".")
    conv.targets = targets
    conv.target_words = {k: {w.strip(".,'") for w in v if len(w.strip(".,'")) >= 3} for k, v in words.items()}
    return alive_lines, dead_lines
