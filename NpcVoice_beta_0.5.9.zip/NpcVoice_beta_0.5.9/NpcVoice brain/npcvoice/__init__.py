"""NpcVoice brain – talks to NpcVoice.asi inside RDR2."""
VERSION = "0.5.9-beta"
