"""Live game state from NpcVoice.asi ticks, plus change detection (events the NPC can react to)."""
from __future__ import annotations

import math
import time

from .data import Zones, weather_name

ZONES = Zones()
DOW = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
WEAPON_NAMES = {}  # filled lazily: hash -> name


def _weapon_name(h: int) -> str:
    if not WEAPON_NAMES:
        from .hashing import joaat
        for n in ("WEAPON_UNARMED WEAPON_REVOLVER_CATTLEMAN WEAPON_REVOLVER_SCHOFIELD WEAPON_REVOLVER_DOUBLEACTION "
                  "WEAPON_REVOLVER_LEMAT WEAPON_REVOLVER_NAVY WEAPON_PISTOL_VOLCANIC WEAPON_PISTOL_MAUSER "
                  "WEAPON_PISTOL_SEMIAUTO WEAPON_PISTOL_M1899 WEAPON_REPEATER_CARBINE WEAPON_REPEATER_WINCHESTER "
                  "WEAPON_REPEATER_HENRY WEAPON_REPEATER_EVANS WEAPON_RIFLE_VARMINT WEAPON_RIFLE_SPRINGFIELD "
                  "WEAPON_RIFLE_BOLTACTION WEAPON_SNIPERRIFLE_ROLLINGBLOCK WEAPON_SNIPERRIFLE_CARCANO "
                  "WEAPON_SHOTGUN_DOUBLEBARREL WEAPON_SHOTGUN_PUMP WEAPON_SHOTGUN_REPEATING WEAPON_SHOTGUN_SAWEDOFF "
                  "WEAPON_SHOTGUN_SEMIAUTO WEAPON_BOW WEAPON_MELEE_KNIFE WEAPON_MELEE_MACHETE WEAPON_MELEE_HATCHET "
                  "WEAPON_MELEE_CLEAVER WEAPON_LASSO WEAPON_THROWN_THROWING_KNIVES WEAPON_THROWN_DYNAMITE "
                  "WEAPON_THROWN_MOLOTOV WEAPON_MELEE_LANTERN WEAPON_MELEE_TORCH WEAPON_KIT_BINOCULARS").split():
            WEAPON_NAMES[joaat(n)] = n.replace("WEAPON_", "").replace("_", " ").lower()
    return WEAPON_NAMES.get(int(h or 0) & 0xFFFFFFFF, "a weapon" if h else "")


def weapon_name(h) -> str:
    return _weapon_name(h)


class Game:
    def __init__(self):
        self.player: dict = {}
        self.world: dict = {}
        self.peds: dict[int, dict] = {}
        self.last_tick = 0.0
        self.game_minutes_total = 0.0
        self._last_clock = None
        self.near: dict = {}          # filled from the 'nearby' scan
        self.near_peds: list = []

    def on_tick(self, msg: dict, memory_player: dict):
        self.last_tick = time.time()
        self.player = msg.get("p") or {}
        self.world = msg.get("w") or {}
        for pd in msg.get("peds") or []:
            h = int(pd.get("h", 0))
            if h:
                pd["_t"] = time.time()
                self.peds[h] = pd
        # monotonic in-game clock (minutes) for 'how long ago' memories
        hr, mn = self.world.get("hr"), self.world.get("mn")
        if hr is not None and mn is not None:
            now = hr * 60 + mn
            if self._last_clock is not None:
                d = now - self._last_clock
                if d < -600:      # wrapped past midnight
                    d += 1440
                if 0 < d < 600:
                    memory_player["game_minutes"] = memory_player.get("game_minutes", 0.0) + d
            self._last_clock = now
        self.game_minutes_total = memory_player.get("game_minutes", 0.0)

    def ped(self, h: int) -> dict:
        return self.peds.get(int(h), {})

    def zone(self) -> dict:
        w = self.world
        return {"state": ZONES.name(w.get("st")), "town": ZONES.name(w.get("town")),
                "district": ZONES.name(w.get("dist")), "weather": weather_name(w.get("wx"))}

    def place(self) -> str:
        z = self.zone()
        if z["town"]:
            return z["town"]
        return z["district"] or z["state"] or "the wilderness"

    def time_text(self) -> str:
        hr, mn = self.world.get("hr", 12), self.world.get("mn", 0)
        part = ("late night" if hr < 5 else "early morning" if hr < 8 else "morning" if hr < 12 else
                "afternoon" if hr < 17 else "evening" if hr < 21 else "night")
        dow = DOW[self.world.get("dow", 0) % 7] if self.world.get("dow") is not None else ""
        return f"{dow} {part}, {hr:02d}:{mn:02d}".strip()

    @staticmethod
    def dist(a: dict, b: dict) -> float:
        try:
            return math.dist((a["x"], a["y"], a["z"]), (b["x"], b["y"], b["z"]))
        except (KeyError, TypeError):
            return 999.0


def hurt_text(cur: dict, pcur: dict, prev: dict) -> str:
    """0.5.1: say WHAT he did to them, with what (Tommy, hit with a machete: "you didn't hit me!")."""
    w = weapon_name(pcur.get("wpn")) if pcur.get("armed") else ""
    hp0, hp1 = prev.get("hp") or 0, cur.get("hp") or 0
    lost = max(0, hp0 - hp1)
    bad = " It's BAD - you're bleeding heavily." if (cur.get("hpmax") and hp1 < 0.4 * cur["hpmax"]) else \
        " It hurts like hell." if lost >= 8 else ""
    if "lasso" in w:
        what = "caught you with his lasso and yanked you down"
    elif not w or w in ("unarmed",):
        what = "punched you in the fight" if cur.get("melee") else "struck you"
    elif any(k in w for k in ("machete", "knife", "hatchet", "cleaver", "axe")):
        what = f"cut you with his {w} - you SCREAM, there's blood"
    elif any(k in w for k in ("bow",)):
        what = "shot an arrow into you"
    elif any(k in w for k in ("lantern", "torch")):
        what = f"hit you with his {w}"
    else:
        what = f"SHOT you with his {w}"
    return f"The player just {what}!{bad} You felt it - you know exactly what he did."


# events detected by comparing two snapshots of the same ped (+ player)
def diff_events(prev: dict, cur: dict, pprev: dict, pcur: dict) -> list[tuple[str, str, int]]:
    """-> list of (event_key, description for the NPC, importance 1-3)."""
    ev = []
    if not prev or not cur:
        return ev

    def rose(k):
        return not prev.get(k) and cur.get(k)

    def fell(k):
        return prev.get(k) and not cur.get(k)

    if rose("aimed"):
        ev.append(("aimed", f"The player just pointed his {weapon_name(pcur.get('wpn')) or 'gun'} right at you.", 3))
    if fell("aimed") and not cur.get("hog"):
        ev.append(("aim_lowered", "The player lowered his gun.", 1))
    if rose("hog"):
        ev.append(("hogtied", "The player just hogtied you – your hands and feet are bound and you're on the ground.", 3))
    if fell("hog") and cur.get("alive", 1):
        ev.append(("freed", "You are no longer tied up – the ropes are off.", 3))
    if rose("lasso"):
        ev.append(("lassoed", "The player just caught you with his lasso.", 3))
    if cur.get("dmg"):
        ev.append(("hurt_by_player", hurt_text(cur, pcur, prev), 3))
    if rose("melee"):
        ev.append(("fist_fight", "You are now in a FIST FIGHT with the player - you're swinging at him.", 3))
    php0, php1 = pprev.get("hp") or 0, pcur.get("hp") or 0
    if cur.get("melee") and php0 and php1 and php1 <= php0 - 3 and 0 < cur.get("d", 99) < 4:
        ev.append(("hit_player", "Your punch just LANDED on the player - you hit him and he felt it. You know you did it.", 3))
    if prev.get("hp") and cur.get("hp") and cur["hp"] < prev["hp"] - 10 and not cur.get("dmg"):
        ev.append(("hurt", "You just got hurt.", 2))
    if rose("rag") and not cur.get("hog"):
        ev.append(("knocked_down", "You've been knocked to the ground.", 2))
    if pcur.get("shoot") and not pprev.get("shoot"):
        ev.append(("shots", "The player just fired a gun near you!", 3))
    if pcur.get("armed") and not pprev.get("armed"):
        ev.append(("weapon_drawn", f"The player just drew his {weapon_name(pcur.get('wpn')) or 'weapon'}.", 2))
    if pprev.get("armed") and not pcur.get("armed"):
        ev.append(("weapon_away", "The player put his weapon away.", 1))
    if pcur.get("mounted") and not pprev.get("mounted"):
        ev.append(("player_mounted", "The player just got on his horse.", 1))
    if pcur.get("crouch") and not pprev.get("crouch"):
        ev.append(("player_crouch", "The player just crouched down low.", 1))
    # bodies / captives the player brings along
    if pcur.get("c") and not pprev.get("c"):
        if pcur.get("cdead"):
            ev.append(("carrying_body", "The player just walked up carrying a DEAD BODY over his shoulder.", 3))
        elif pcur.get("chog"):
            ev.append(("carrying_captive", "The player is carrying a tied-up, living person over his shoulder.", 3))
    if pprev.get("c") and not pcur.get("c") and (pprev.get("cdead") or pprev.get("chog")):
        what = "a dead body" if pprev.get("cdead") else "the tied-up person"
        ev.append(("dropped_body", f"The player just dropped {what} on the ground right in front of you.", 3))
    if pcur.get("hb") and pcur.get("hbdead") and not (pprev.get("hb") and pprev.get("hbdead")):
        ev.append(("body_on_horse", "You notice a dead body slung over the player's horse.", 2))
    d0, d1 = prev.get("d", 0), cur.get("d", 0)
    if d0 <= 8 < d1:
        ev.append(("player_leaving", "The player is walking away from you.", 1))
    if d0 > 4 >= d1 > 0:
        ev.append(("player_close", "The player stepped right up close to you.", 1))
    return ev
