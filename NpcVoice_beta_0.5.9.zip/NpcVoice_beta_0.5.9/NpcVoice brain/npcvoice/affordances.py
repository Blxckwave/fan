"""Affordances (0.5.9): what THIS person can really do, right here - so the AI picks from real options instead of
guessing words.

- SPOTS: the game's own furniture points around the person (beds, chairs at a table, benches, the bar, a fire, the wash
  basin...), from the plugin (`spots` -> GET_SCENARIO_POINTS_IN_AREA), with whether each is free. Tagged [F1], [F2]...
  and listed in every prompt: "Real spots around you: [F1] a bed - sleep in the bed, 4 m".
- OPTIONS: when the player asks for something to be DONE (sleep, sit, drink, play a tune, sweep...), the 4-6 best real
  ways to do it here - the spots first, then scenarios this person's sex has, then a gesture - tagged [A1]... with what
  we already know about each ("worked before", "didn't play last time"). The AI answers with the activity action and
  args {"option": "A2"}; the brain then tries that one first and the next ones if the game refuses, and tells the AI
  honestly what happened.
"""
from __future__ import annotations

import asyncio
import math
import time

from .activities import concepts_of, SPOT_WORDS
from .hashing import joaat
from .log import log

SPOT_RADIUS = 14.0
SPOT_TTL = 20.0
ACT_VERBS = ("sleep", "sit", "lie", "lay", "drink", "smoke", "play", "eat", "cook", "read", "write", "sweep", "wash",
             "dance", "lean", "kneel", "pray", "rest", "nap", "whittle", "knit", "sew", "chop", "fish", "warm", "relax")


class Affordances:
    def __init__(self, brain):
        self.b = brain
        self.waiters: dict[int, asyncio.Future] = {}
        self.seq = 80000
        self._names: dict[int, str] | None = None

    # ── the type names of scenario points ──
    def names(self) -> dict[int, str]:
        if self._names is None:
            n = {}
            acts = self.b.activities
            for e in acts.entries:
                if e["kind"] != "scenario":
                    continue
                n[joaat(e["id"]) & 0xFFFFFFFF] = e["id"]
                for vs in (e.get("variants") or {}).values():
                    for v in vs:
                        n.setdefault(joaat(v) & 0xFFFFFFFF, e["id"])
            hh = getattr(self.b, "households", None)
            for h, name in (getattr(hh, "point_names", None) or {}).items():
                n.setdefault(int(h) & 0xFFFFFFFF, name)
            self._names = n
        return self._names

    def can_scan(self) -> bool:
        return "spots" in set((self.b.asi_info or {}).get("caps") or []) and bool(self.b.asi.up)

    def on_spots(self, m: dict):
        fut = self.waiters.pop(int(m.get("seq", 0)), None)
        if fut and not fut.done():
            fut.set_result(m)

    async def scan(self, ped: int, radius: float = SPOT_RADIUS, timeout: float = 1.2) -> list[dict]:
        if not self.can_scan():
            return []
        self.seq += 1
        seq = self.seq
        fut = asyncio.get_running_loop().create_future()
        self.waiters[seq] = fut
        self.b.asi.send("spots", seq, int(ped), round(radius, 1))
        try:
            m = await asyncio.wait_for(fut, timeout)
        except asyncio.TimeoutError:
            return []
        finally:
            self.waiters.pop(seq, None)
        me = self.b.game.ped(ped) or {}
        out = []
        names = self.names()
        for p in m.get("pts") or []:
            try:
                th, x, y, z, hd = int(p[0]) & 0xFFFFFFFF, float(p[1]), float(p[2]), float(p[3]), float(p[4])
                free = bool(int(p[5])) if len(p) > 5 else True
            except (TypeError, ValueError, IndexError):
                continue
            name = names.get(th, "")
            info = self.b.activities.spot_of(name) if name else None
            if not info:
                continue
            d = math.dist((x, y, z), (me["x"], me["y"], me.get("z", z))) if "x" in me else 0.0
            out.append(dict(info, x=x, y=y, z=z, h=hd, free=free, d=round(d, 1), type=name))
        out.sort(key=lambda s: (not s["free"], s["d"]))
        kept, seen = [], set()
        for s in out:                                # one per kind of thing and place (a bed has 2-3 pillow points)
            k = (s["needs"], round(s["x"]), round(s["y"]))
            if k in seen:
                continue
            seen.add(k)
            kept.append(s)
        for i, s in enumerate(kept[:8], 1):
            s["tag"] = f"F{i}"
        return kept[:8]

    async def spots_for(self, conv) -> list[dict]:
        me = self.b.game.ped(conv.ped) or {}
        cache = getattr(conv, "spots", None)
        at = getattr(conv, "_spots_at", (0.0, 0.0, 0.0))
        moved = "x" in me and math.hypot(me["x"] - at[1], me["y"] - at[2]) > 4
        if cache is not None and time.time() - at[0] < SPOT_TTL and not moved:
            return cache
        conv.spots = await self.scan(conv.ped)
        conv._spots_at = (time.time(), float(me.get("x", 0)), float(me.get("y", 0)))
        if conv.spots:
            log.info("[SPOTS] %s: %s", conv.name, ", ".join(f"{s['tag']} {s['needs']} {s['d']:.0f}m" for s in conv.spots))
        return conv.spots

    # ── a turn: spots always, options when he asks for something to be done ──
    async def prepare(self, conv, utterance: str):
        try:
            spots = await self.spots_for(conv)
        except Exception:
            spots = []
        conv.options = []
        if not utterance:
            return
        low = utterance.lower()
        if not concepts_of(utterance) and not any(v in low for v in ACT_VERBS):
            return
        male = conv.ident.persona.get("sex") == "male"
        model = (getattr(conv, "cls", None) or {}).get("model_name", "") if isinstance(getattr(conv, "cls", None), dict) else ""
        opts, cons = self.b.activities.options(utterance, male, model, [s for s in spots if s.get("free", True)], 6)
        conv.options = opts
        conv.options_for = utterance
        if opts:
            log.info("[OPTIONS] %s for %r (%s): %s", conv.name, utterance, cons,
                     " | ".join(f"{o['tag']} {o['kind']}:{o['id']}" for o in opts))


def spots_text(conv) -> str:
    spots = [s for s in (getattr(conv, "spots", None) or []) if s.get("free", True)]
    if not spots:
        return ""
    items = [f"[{s['tag']}] {SPOT_WORDS.get(s['needs'], 'a spot')} ({s['label']}), {s['d']:.0f} m" for s in spots[:6]]
    return ("Real spots around you (furniture you can use - for an everyday thing there, use activity with "
            "args.option from the options, or args.what naming it): " + "; ".join(items) + ".")


def options_text(conv) -> str:
    opts = getattr(conv, "options", None) or []
    if not opts:
        return ""
    items = []
    for o in opts:
        st = f" - {o['status']}" if o.get("status") else ""
        items.append(f"[{o['tag']}] {o['label']}{st}")
    return ("(WHAT YOU CAN REALLY DO for what he just asked - if you're willing, do ONE of these with the activity "
            "action, args {\"option\": \"A1\"} - the best fitting one first; it happens for real. Don't promise anything "
            "else: " + "; ".join(items) + ".)")
