"""Long-term memory: every NPC you talk to becomes a persistent 'identity' with feelings and history.

Recognition fingerprint = model hash + outfit hash (+ where they were first met). RDR2 re-uses the same
face and clothes for ambient people, so meeting that face again in the same area is treated as meeting
the same person again – they remember you, what you did, and how they feel about you (nemesis-style).
"""
from __future__ import annotations

import json
import os
import threading
import time
import uuid
from pathlib import Path

from .log import log
from . import persona as persona_mod

STATS = ("trust", "fear", "anger", "attraction", "respect")
BASE_STATS = {"trust": 35, "fear": 10, "anger": 5, "attraction": 15, "respect": 30}


def clamp(v, lo=0, hi=100):
    return max(lo, min(hi, v))


class Identity:
    def __init__(self, data: dict, store: "MemoryStore"):
        self.d = data
        self.store = store

    @property
    def id(self):
        return self.d["id"]

    @property
    def persona(self):
        return self.d["persona"]

    @property
    def stats(self):
        return self.d["stats"]

    def add_event(self, what: str, game_min: float, where: str, weight: int = 1):
        ev = {"real": time.time(), "game_min": game_min, "where": where, "what": what, "w": weight}
        self.d["events"].append(ev)
        self.d["events"] = self.d["events"][-60:]
        log.info("[MEM] %s: event '%s' @%s", self.persona["name"], what, where)
        self.dirty()

    def adjust(self, deltas: dict, why: str = "", cap: int = 15):
        changed = {}
        for k, v in (deltas or {}).items():
            if k in STATS:
                try:
                    v = int(round(float(v)))
                except (TypeError, ValueError):
                    continue
                v = max(-cap, min(cap, v))
                old = self.stats[k]
                self.stats[k] = clamp(old + v)
                if self.stats[k] != old:
                    changed[k] = f"{old}->{self.stats[k]}"
        g = self.d["nemesis"]
        g["grudge"] = clamp(int(0.7 * self.stats["anger"] + 0.35 * self.stats["fear"]
                                + 0.25 * (100 - self.stats["trust"]) - 20))
        g["rank"] = "nemesis" if g["grudge"] >= 70 else "rival" if g["grudge"] >= 45 else \
            "friend" if self.stats["trust"] >= 70 else "acquaintance" if self.d["times_met"] > 1 else "stranger"
        if changed:
            log.info("[MEM] %s stats %s %s -> rank=%s grudge=%s", self.persona["name"], changed, why,
                     g["rank"], g["grudge"])
        self.dirty()
        return changed

    def remember_fact(self, fact: str):
        fact = (fact or "").strip()
        if fact and fact not in self.d["facts"]:
            self.d["facts"].append(fact[:200])
            self.d["facts"] = self.d["facts"][-25:]
            self.dirty()

    def add_summary(self, text: str, game_min: float, where: str):
        if text:
            self.d["summaries"].append({"real": time.time(), "game_min": game_min, "where": where, "text": text[:600]})
            self.d["summaries"] = self.d["summaries"][-12:]
            self.dirty()

    def dirty(self):
        self.store.save(self)


class MemoryStore:
    def __init__(self, folder: Path):
        self.folder = folder
        self.folder.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self.ids: dict[str, Identity] = {}
        self.by_fp: dict[str, list[str]] = {}
        self.player = {"game_minutes": 0.0, "reputation_notes": []}
        self._load()

    def _load(self):
        n = 0
        for p in self.folder.glob("*.json"):
            if p.name == "_player.json":
                try:
                    self.player.update(json.loads(p.read_text(encoding="utf-8")))
                except Exception as e:
                    log.error("[MEM] cannot read %s: %s", p, e)
                continue
            try:
                d = json.loads(p.read_text(encoding="utf-8"))
                ident = Identity(d, self)
                self.ids[ident.id] = ident
                self.by_fp.setdefault(d["fp"], []).append(ident.id)
                n += 1
            except Exception as e:
                log.error("[MEM] cannot read %s: %s", p, e)
        log.info("[MEM] loaded %d remembered people from %s", n, self.folder)

    def save(self, ident: Identity):
        with self._lock:
            path = self.folder / f"{ident.id}.json"
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps(ident.d, ensure_ascii=False, indent=1), encoding="utf-8")
            os.replace(tmp, path)

    def save_player(self):
        with self._lock:
            path = self.folder / "_player.json"
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.player, ensure_ascii=False, indent=1), encoding="utf-8")
            os.replace(tmp, path)

    @staticmethod
    def fingerprint(model: int, outfit: int) -> str | None:
        if not outfit:
            return None   # cannot tell people apart without the outfit hash
        return f"{model & 0xFFFFFFFF:08x}-{outfit & 0xFFFFFFFF:08x}"

    def find(self, model: int, outfit: int, zone: str, exclude: set[str], include_dead: bool = False) -> Identity | None:
        fp = self.fingerprint(model, outfit)
        if not fp:
            return None
        cands = [self.ids[i] for i in self.by_fp.get(fp, []) if i not in exclude and i in self.ids
                 and (include_dead or not self.ids[i].d.get("dead"))]
        if not cands:
            return None
        # same area first; travellers/drifters/outlaws can turn up anywhere
        same = [c for c in cands if c.d.get("home_zone") == zone or c.d.get("last_zone") == zone]
        roaming = [c for c in cands if c.persona.get("role") in ("drifter", "outlaw", "lawman", "soldier")]
        pick = (same or roaming or [])
        if not pick:
            return None
        return max(pick, key=lambda c: c.d.get("last_seen", 0))

    def create(self, model: int, outfit: int, cls: dict, zone: str, game_min: float) -> Identity:
        iid = f"{model & 0xFFFFFFFF:08x}_{uuid.uuid4().hex[:8]}"
        p = persona_mod.generate(iid, cls, zone)
        d = {
            "id": iid, "fp": self.fingerprint(model, outfit) or f"nofp-{iid}", "model": model & 0xFFFFFFFF,
            "outfit": outfit & 0xFFFFFFFF, "model_name": cls["model_name"], "persona": p,
            "stats": dict(BASE_STATS), "events": [], "facts": [], "summaries": [],
            "nemesis": {"grudge": 0, "rank": "stranger"}, "times_met": 0,
            "home_zone": zone, "last_zone": zone, "first_seen": time.time(), "last_seen": time.time(),
            "first_game_min": game_min, "last_game_min": game_min, "flags": {},
        }
        if p.get("wildcard", "").startswith("instantly takes a liking"):
            d["stats"]["trust"] = 60
        if p["role"] == "lawman":
            d["stats"]["respect"] = 20
        ident = Identity(d, self)
        self.ids[iid] = ident
        self.by_fp.setdefault(d["fp"], []).append(iid)
        self.save(ident)
        log.info("[MEM] NEW person %s (%s) model=%s outfit=%08x zone=%s wildcard=%r secret=%r",
                 p["name"], p["job"], cls["model_name"], outfit & 0xFFFFFFFF, zone, p.get("wildcard"), p.get("secret"))
        return ident


def ago(game_min_now: float, game_min_then: float, real_then: float) -> str:
    gm = max(0.0, game_min_now - game_min_then)
    days = gm / 1440.0
    if days >= 2:
        return f"about {int(days)} days ago"
    if days >= 1:
        return "yesterday"
    hours = gm / 60
    if hours >= 2:
        return f"about {int(hours)} hours ago"
    real = time.time() - real_then
    if real > 3 * 3600:
        return "a while back"
    return "just a little while ago"


def recall_text(ident: Identity, game_min_now: float) -> str:
    d = ident.d
    if d["times_met"] <= 1 and not d["events"] and not d["summaries"]:
        return "You have never met this stranger before."
    lines = [f"You have met this man {d['times_met'] - 1} time(s) before. Last time: "
             f"{ago(game_min_now, d.get('last_game_min', 0), d.get('last_seen', 0))} in {d.get('last_zone') or 'these parts'}."]
    s = ident.stats
    lines.append(f"Your feelings toward him (0-100): trust {s['trust']}, fear {s['fear']}, anger {s['anger']}, "
                 f"attraction {s['attraction']}, respect {s['respect']}. He is your {d['nemesis']['rank']} "
                 f"(grudge {d['nemesis']['grudge']}/100).")
    for sm in d["summaries"][-4:]:
        lines.append(f"- {ago(game_min_now, sm['game_min'], sm['real'])} in {sm['where']}: {sm['text']}")
    big = [e for e in d["events"] if e.get("w", 1) >= 2][-8:]
    for e in big:
        lines.append(f"- You remember: {e['what']} ({ago(game_min_now, e['game_min'], e['real'])}, {e['where']}).")
    if d["facts"]:
        lines.append("Things you know about him: " + "; ".join(d["facts"][-10:]))
    return "\n".join(lines)
