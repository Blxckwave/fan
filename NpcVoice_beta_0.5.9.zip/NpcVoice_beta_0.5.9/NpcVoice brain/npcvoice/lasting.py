"""Lasting activities (0.5.9): someone you told to go to sleep STAYS asleep after you stop talking (and someone sitting
by the fire stays sitting) - until something wakes them.

- When a conversation ends while the person is asleep / sitting / kneeling (and not scared of you), they're kept in
  that pose: the plugin keeps them as a quiet "actor" (no task is forced on them, ambient events don't pull them out).
- They wake up / get up when: they're hurt, a gun is pointed at them, shots ring out close by (a sleeper hears a gun
  within ~35 m), or you walk off far (>120 m: they're left to the game).
- Talk to a sleeper and they know they were asleep: woken by your voice, groggy. Wake them with a gunshot and they
  react to THAT.
"""
from __future__ import annotations

import time

from .activities import LASTING
from .log import log

WAKE_SHOT_M = 35.0
LEAVE_M = 120.0
MAX_SECONDS = 1800.0


class Lasting:
    def __init__(self, brain):
        self.b = brain
        self.held: dict[int, dict] = {}

    def on_end(self, conv, reason: str):
        f = conv.flags
        post = f.get("doing_posture")
        if not f.get("doing") or post not in LASTING or reason in ("they died", "they are gone"):
            return
        if f.get("hands_up") or f.get("cowering") or f.get("surrendered") or f.get("captive") or conv.companion:
            return
        if self.b.dead(conv.ped):
            return
        self.held[conv.ped] = {"ident": conv.ident, "label": f["doing"], "posture": post, "asleep": bool(f.get("asleep")),
                               "id": f.get("doing_id", ""), "since": time.time(), "cls": conv.cls,
                               "hp": (self.b.game.ped(conv.ped) or {}).get("hp")}
        self.b.asi.send("actor", conv.ped, 1)
        log.info("[LASTING] %s stays %s after the talk%s", conv.name, f["doing"], " (asleep)" if f.get("asleep") else "")

    def on_engage(self, conv):
        h = self.held.pop(conv.ped, None)
        if not h:
            return
        f = conv.flags
        f["doing"], f["doing_posture"], f["doing_id"] = h["label"], h["posture"], h["id"]
        f["asleep"] = h["asleep"]
        mins = (time.time() - h["since"]) / 60
        if h["asleep"]:
            conv.pending_events.append(("woken", f"You were ASLEEP ({h['label']}) for {mins:.0f} min - his voice just woke "
                                                 "you. You're groggy, confused for a moment, maybe annoyed at being woken.", 2))
        else:
            conv.pending_events.append(("still_doing", f"You're still {h['label']} (for {mins:.0f} min now) when he comes "
                                                       "back to you.", 1))

    def tick(self):
        if not self.held:
            return
        b = self.b
        pl = b.game.player or {}
        for ped, h in list(self.held.items()):
            st = b.game.ped(ped) or {}
            if b.dead(ped):
                self.held.pop(ped, None)
                continue
            d = float(st.get("d", 999) or 999)
            if (st and d > LEAVE_M) or time.time() - h["since"] > MAX_SECONDS:
                self.held.pop(ped, None)
                b.asi.send("actor", ped, 0)
                continue
            if any(c.ped == ped and not c.ended for c in b.convs.values()):
                continue
            hp, last = st.get("hp"), h.get("hp")
            if hp is not None:
                h["hp"] = hp
            why = ""
            if st.get("dmg") or (hp is not None and last is not None and hp < last - 1):
                why = "hurt"
            elif st.get("aimed") and d < 25:
                why = "gun"
            elif pl.get("shoot") and d < WAKE_SHOT_M:
                why = "shot"
            if why:
                self.wake(ped, h, why)

    def wake(self, ped: int, h: dict, why: str):
        b = self.b
        self.held.pop(ped, None)
        ident = h["ident"]
        was = "asleep" if h["asleep"] else h["label"]
        ev = {"hurt": f"!! You were {was} - and something HURT you. You're awake at once, in pain and shock.",
              "gun": f"!! You were {was} - you open your eyes and a GUN is pointed at you.",
              "shot": f"!! You were {was} - a GUNSHOT right by you jolts you awake. You don't know yet what happened."}[why]
        log.info("[LASTING] %s wakes up / gets up: %s", ident.persona.get("name"), why)
        b.asi.prim(ped, "lasting", ("clear",))
        if why == "hurt":
            b.asi.prim(ped, "lasting", ("pain", 1))
        others = any(not c.ended for c in b.convs.values())
        conv = b.on_engage_req({"ped": ped, "model": int(ident.d.get("model", 0) or 0), "outfit": int(ident.d.get("outfit", 0) or 0),
                                "male": ident.persona.get("sex") == "male", "alive": 1, "human": 1},
                               forced_ident=ident, reason="woken", side=others)
        if conv:
            conv.flags["doing"] = ""
            conv.flags["asleep"] = False
            conv.pending_events.append(("woken", ev, 3))
            conv.mark("threatened")
            import asyncio
            asyncio.create_task(b.run_turn(conv, reaction=True))
