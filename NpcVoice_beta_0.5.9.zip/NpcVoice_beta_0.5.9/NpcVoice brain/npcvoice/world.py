"""Town memory: what the player did, where and when -> rumours, reputation, lawmen asking questions.

Deeds are stored in npc_memory/_player.json (memory.player["deeds"]).
Severity: 1 minor (brawl, rudeness), 2 serious (robbery, hogtying), 3 grave (killing).
"""
from __future__ import annotations

import random
import time

from .log import log


def add_deed(memory, place: str, state: str, what: str, severity: int, game_min: float, witnessed: int = 0,
             about_player: bool = True):
    deeds = memory.player.setdefault("deeds", [])
    deeds.append({"place": place, "state": state, "what": what, "sev": severity, "game_min": game_min,
                  "real": time.time(), "witnessed": witnessed, "player": about_player})
    memory.player["deeds"] = deeds[-200:]
    memory.save_player()
    log.info("[WORLD] deed @%s sev=%d witnesses=%d: %s", place, severity, witnessed, what)


def _ago(now_min, then_min):
    d = max(0.0, now_min - then_min) / 1440.0
    return "today" if d < 0.6 else "yesterday" if d < 1.6 else f"{int(d)} days ago"


def rumours(memory, place: str, state: str, game_min: float, seed: str, limit: int = 3) -> list[str]:
    """What this person has heard. Grave things spread to the whole state, others stay local."""
    rng = random.Random(seed)
    out = []
    for d in reversed(memory.player.get("deeds", [])):
        age_days = max(0.0, game_min - d["game_min"]) / 1440.0
        if age_days > 4:
            continue
        local = d["place"] == place
        if not local and not (d["sev"] >= 3 and d["state"] == state):
            continue
        p = {1: 0.35, 2: 0.6, 3: 0.85}.get(d["sev"], 0.4) * (1.0 if local else 0.45) * (1.0 if d["witnessed"] else 0.6)
        p *= max(0.3, 1.0 - age_days / 5)
        if rng.random() < p:
            who = ("a stranger - rough-looking, they say he looks a lot like the man in front of you"
                   if d["player"] and d["witnessed"] else "somebody")
            out.append(f"{d['what'].replace('THE_STRANGER', who)} ({_ago(game_min, d['game_min'])}, {d['place']})")
        if len(out) >= limit:
            break
    return out


def heat(memory, place: str, game_min: float) -> int:
    """How hot the player is in this place right now (for lawmen): sum of recent witnessed severities."""
    h = 0
    for d in memory.player.get("deeds", []):
        if d.get("player") and d["place"] == place and d["witnessed"] and game_min - d["game_min"] < 2 * 1440:
            h += d["sev"]
    return h
