"""Journeys: "lead me to your wife", "let's go find your brother", "where's your horse?".

The NPC agrees (or is too scared to refuse) -> lead_to action -> a destination a few km away gets a yellow GPS
line on the map. You travel together (on foot, or he rides on your horse) and keep talking. When you get close,
the place is built for real: a camp with the family he told you about (names, kids, dog, wagon, workers, chores,
campfire, tents, laundry, crates, a strongbox), or his brother hurt / dead / held by kidnappers. When you arrive
everyone reacts to HOW you arrive: friendly, with their man hogtied over your shoulder, with a gun on him, without
him because you killed him on the way... Then you can talk to any of them.

Children who are spawned are invincible and only ever react by hiding/running - that line stays.
"""
from __future__ import annotations

import asyncio
import json
import math
import random
import re
import time
import traceback

from . import world
from .log import log, turn as log_turn
from .persona import describe as describe_persona

FEMALE = ["A_F_M_FAMILYTRAVELERS_COOL_01", "A_F_M_FAMILYTRAVELERS_WARM_01", "A_F_M_ValTownfolk_01", "A_F_M_RhdTownfolk_01",
          "A_F_M_StrTownfolk_01", "A_F_M_BtcHillbilly_01", "A_F_M_ROUGHTRAVELLERS_01", "A_F_M_ArmTownfolk_02"]
MALE = ["A_M_M_FAMILYTRAVELERS_COOL_01", "A_M_M_FAMILYTRAVELERS_WARM_01", "A_M_M_RANCHERTRAVELERS_COOL_01",
        "A_M_M_RANCHERTRAVELERS_WARM_01", "A_M_M_ValFarmer_01", "A_M_M_RANCHER_01"]
OLD = {"female": ["A_F_O_BtcHillbilly_01", "A_F_O_LagTownfolk_01"], "male": ["A_M_O_BtcHillbilly_01", "A_M_O_GuaTownfolk_01"]}
# 0.5.1: REAL child models only (0.5.0 used the CzP homestead "sons" - young men - as little kids: Tommy). The game has
# no ambient girl-child model outside story characters, so a daughter under 16 comes as an older (17-19) daughter.
KIDS = {"male": ["A_M_Y_NbxStreetKids_01", "A_M_Y_NbxStreetKids_Slums_01", "A_M_Y_SDStreetKids_Slums_02",
                 "U_M_Y_ShackStarvingKid_01"], "female": []}
YOUNG = {"male": ["U_M_Y_CzPHomesteadSon_01", "U_M_Y_CzPHomesteadSon_02", "U_M_Y_CzPHomesteadSon_03",
                  "U_M_Y_CZPHOMESTEADSON_04", "U_M_Y_CZPHOMESTEADSON_05", "U_M_Y_EmRSon_01"],
         "female": ["U_F_Y_CzPHomesteadDaughter_01"]}
DOING_BY_REL = {"wife": "cooking", "husband": "sawing wood", "mother": "laundry", "father": "smoking", "son": "sawing wood",
                "daughter": "sweeping", "farmhand": "hammering", "brother": "tending the fire", "sister": "laundry",
                "grandmother": "sitting by the fire", "grandfather": "sitting by the fire"}
WORKERS = ["A_M_M_RANCHER_01", "A_M_M_ValFarmer_01", "A_M_M_RANCHERTRAVELERS_WARM_01", "A_M_M_FAMILYTRAVELERS_WARM_01"]
OUTLAWS = ["G_M_M_UniDuster_01", "G_M_M_UniDuster_02", "G_M_M_UniBanditos_01", "G_M_M_UniCriminals_01", "G_M_M_UniCriminals_02"]
DOGS = ["a_c_dogcollie_01", "a_c_doghound_01", "a_c_doglab_01", "a_c_dogcatahoulacur_01", "a_c_doghobo_01",
        "a_c_dogaustraliansheperd_01"]
HORSES = ["a_c_horse_americanstandardbred_buckskin", "a_c_horse_americanpaint_overo", "a_c_horse_appaloosa_blanket",
          "a_c_horse_andalusian_darkbay"]
WAGONS = ["cart01", "cart03", "chuckwagon000x", "wagon02x", "wagontraveller01x"]
DOING = {   # chore -> scenario (all checked against the game's scenario list)
    "laundry": "WORLD_HUMAN_WASHBOARD", "cooking": "WORLD_HUMAN_STIR_SOUP", "tending the fire": "WORLD_HUMAN_FIRE_TEND_KNEEL",
    "sitting by the fire": "WORLD_HUMAN_FIRE_SIT", "smoking": "WORLD_HUMAN_SMOKE", "feeding chickens": "WORLD_HUMAN_FEED_CHICKEN",
    "playing": "WORLD_HUMAN_SIT_GROUND", "sweeping": "WORLD_HUMAN_BROOM", "drinking": "WORLD_HUMAN_DRINKING",
    "sawing wood": "WORLD_HUMAN_SAW_WOOD", "hammering": "WORLD_HUMAN_HAMMER_GROUND", "keeping watch": "WORLD_HUMAN_BADASS",
    "waiting": "WORLD_HUMAN_STAND_WAITING", "resting": "WORLD_HUMAN_SIT_BACK_EXHAUSTED",
}
PROPS = ["p_campfire02x", "p_ambtentburlap01x", "p_ambtentplaid01x", "p_bedrollopen01x", "p_laundrypile01x",
         "p_crate03x", "p_crate05x", "p_stool02x", "p_chair04x", "p_bucket03x", "p_pot02x", "p_lantern05x"]
# real places a trip of each kind can lead to (data/db/places.json - houses, shacks, camps, mills... with coordinates)
PLACE_KINDS = {
    "family": ["farmhouse", "house", "cabin", "shack", "camp", "ranch", "farm"],
    "relative": ["camp", "cabin", "shack", "cave", "barn", "mine", "ruins"],
    "horse": ["camp", "barn", "stable", "ranch", "farm"],
    "stash": ["cave", "ruins", "mill", "barn", "camp", "graveyard", "mine", "well", "bridge"],
    "person": ["house", "shack", "cabin", "camp", "farmhouse", "hotel", "saloon", "brothel"],
    "couple": ["house", "cabin", "farmhouse", "shack", "mansion"],     # 0.5.8: their HOME - never the saloon
    "place": ["saloon", "hotel", "general store"],
}
BUILDINGS = {"house", "farmhouse", "cabin", "shack", "mansion", "hotel", "saloon", "brothel", "barn", "stable", "bank",
             "general store", "doctor", "church", "jail", "sheriff office", "gunsmith", "theater", "school", "bunkhouse"}
REACTIONS = ["stay", "welcome", "run_to_guide", "flee", "hands_up", "cower", "draw_weapon", "attack", "beg", "sob", "kneel",
             "hide_with_kids"]


def joaat_cached(name: str) -> int:
    from .hashing import joaat
    return joaat(name) & 0xFFFFFFFF


class Journey:
    def __init__(self, conv, kind, target, story, guided=True):
        self.id = f"J{int(time.time()) % 100000}"
        self.conv = conv
        self.guide = conv.ped
        self.guide_ident = conv.ident
        self.kind = kind
        self.target = target or ("my family" if kind == "family" else "him")
        self.story = story or ""
        self.dest = None
        self.plan: dict = {}
        self.state = "planning"
        self.spawned: list[dict] = []
        self.pending: dict[int, dict] = {}
        self.probe_seq = 0
        self.probe_tries = 0
        self.arrived_at = 0.0
        self.started = time.time()
        self.guided = guided            # False: a stash he only told you about (mark_stash) - you go alone
        self.place = None               # a real place from data/db (house, shack, camp, mill...) or None = open ground
        self.where = ""


class Journeys:
    def __init__(self, brain):
        self.b = brain
        self.active: Journey | None = None
        self.done: list[Journey] = []
        self.old: list[Journey] = []
        self.seq = 9000
        self.rng = random.Random()

    # ── start ──
    def start(self, conv, args: dict, guided: bool = True):
        if self.active and self.active.state not in ("done", "failed", "arrived"):
            self.b.asi.toast("info", 4, "You're already on the way somewhere.")
            return
        if self.active:
            self.old.append(self.active)        # cleaned up later, once you're far from it
        kind = str(args.get("kind") or "").lower()
        if not kind or kind == "family":
            kind = self.infer_kind(conv, args, kind)
        hostile = any(w in kind for w in ("enemy", "revenge", "debt", "owes", "killer", "rival"))
        kind = "couple" if any(w in kind for w in ("couple", "swinger", "cuckold", "husband and wife", "pair", "open")) else \
            "place" if kind in ("place", "saloon", "hotel", "brothel", "cathouse", "doctor", "church", "store", "shop", "mine",
                                "bar", "bank", "station", "barber", "bath", "jail", "sheriff") else \
            "person" if hostile else \
            "stash" if any(w in kind for w in ("stash", "treasure", "loot", "money", "chest", "gold", "cache", "box")) else \
            "relative" if kind in ("brother", "sister", "relative", "son", "father", "missing") else \
            "person" if kind in ("person", "friend", "someone", "woman", "man", "girl", "contact", "people", "wife_of",
                                 "acquaintance", "partner", "lover", "worker") else \
            "horse" if "horse" in kind else "family"
        who = str(args.get("who") or args.get("what") or "")
        if kind == "stash" and not who:
            who = "the stash"
        if kind == "place" and not who:
            who = str(args.get("kind", "")) or "the place"
        j = Journey(conv, kind, who, str(args.get("story", "")), guided=guided)
        j.hostile = hostile
        if kind == "stash":             # what's in it is decided now (what he said, or a fair amount) - it's REAL
            try:
                dollars = float(re.search(r"\d+(\.\d+)?", str(args.get("dollars", args.get("amount", "")))).group(0))
            except AttributeError:
                dollars = 0.0
            j.plan = {"what": who, "dollars": round(max(5.0, min(200.0, dollars or self.rng.uniform(15, 80))), 2)}
        self.active = j
        g = self.b.game
        dmin, dmax = self.b.cfg.journey_min_m, self.b.cfg.journey_max_m
        if kind == "stash":             # a stash is something you can walk/ride to now, not a day's travel
            dmin, dmax = min(dmin, 250.0), min(dmax, 900.0)
        ang = self.rng.uniform(0, 2 * math.pi)
        dist = self.rng.uniform(dmin, dmax)
        pl = g.player
        j.dest = [round(pl.get("x", 0) + math.cos(ang) * dist, 1), round(pl.get("y", 0) + math.sin(ang) * dist, 1),
                  round(pl.get("z", 0), 1)]
        # 0.4.1: a REAL place when there is one - the kind/town he talked about, else a fitting one nearby
        j.place = None
        db = getattr(self.b, "db", None)
        if db is not None and db.ok:
            said = " ".join([j.target, j.story, str(args.get("where", ""))] + j.conv.transcript[-4:])
            kinds = PLACE_KINDS.get(kind, ["camp"])
            if kind == "place":
                kinds = db.kinds_in(" ".join([str(args.get("kind", "")), j.target, str(args.get("where", ""))])) or kinds
            place = db.pick_destination(pl.get("x", 0), pl.get("y", 0), said, kinds, dmin, dmax, self.rng,
                                        only=PLACE_KINDS["couple"] if kind == "couple" else None)
            if place:
                j.place = place
                ax, ay, az = place["x"], place["y"], place["z"]
                if place["kind"] in BUILDINGS:          # stand at its real front door, not inside the walls
                    door = min((d for d in self.b.db._load("doors", [])
                                if math.hypot(d["x"] - ax, d["y"] - ay) < 45), default=None,
                               key=lambda d: math.hypot(d["x"] - ax, d["y"] - ay))
                    if door:
                        ax, ay, az = door["x"], door["y"], door["z"]
                j.dest = [round(ax, 1), round(ay, 1), round(az, 1)]
                dist = math.hypot(ax - pl.get("x", 0), ay - pl.get("y", 0))
                where = f"{place['kind']}" + (f" in {place['town']}" if place.get("town") else " out in the wilds")
                j.where = where
                conv.last_results.append(f"{kind} trip: it's a real {where}, {dist:.0f} m from here - talk about it as that place")
        j.state = "route"
        j.start_dist = dist
        label = f"{conv.ident.persona['first_name']}: {j.target}"[:40]
        self.b.asi.send("route", *j.dest, label)
        if not guided and kind in ("person", "couple", "place"):     # 0.5.3: a couple / a place was taken for a stash
            self.b.asi.toast("ok", 7, f"{conv.name} told you where to find {j.target[:50]}. Follow the yellow line "
                                      f"({dist / 1000:.1f} km).")
            conv.ident.add_event(f"you sent him to {j.target}", g.game_minutes_total, g.place(), 2)
            conv.last_results.append(f"mark_person: marked on his map, {dist:.0f} m away - {j.target} really is there")
            log.info("[JOURNEY] %s: %s sent him to %s (%s, alone) at %s, %.0f m away", j.id, conv.name, j.target, kind, j.dest, dist)
            asyncio.create_task(self.make_plan(j))
            return
        if not guided:
            self.b.asi.toast("ok", 7, f"{conv.name} marked a stash on your map (\"{j.target[:50]}\"). Follow the yellow "
                                      f"line ({dist / 1000:.1f} km).")
            conv.ident.add_event(f"you told him where {j.target} is hidden", g.game_minutes_total, g.place(), 2)
            conv.last_results.append(f"mark_stash: it's marked on his map, {dist:.0f} m from here - that's where it really is")
            log.info("[JOURNEY] %s: %s marked %s (stash) at %s, %.0f m away ($%.2f)",
                     j.id, conv.name, j.target, j.dest, dist, j.plan["dollars"])
            return
        self.b.asi.toast("ok", 6, f"{conv.name} is taking you to {j.target}" + (f" ({j.where})" if getattr(j, "where", "") else "")
                         + f". Follow the yellow line ({dist / 1000:.1f} km).")
        conv.ident.add_event(f"you agreed to take him to {j.target}", g.game_minutes_total, g.place(), 2)
        conv.flags["journey"] = j.kind
        if not conv.flags.get("following") and not conv.flags.get("riding") and not self.b.dead(conv.ped):
            conv.flags["following"] = True
            for p in (("clear",), ("follow", 1.2, -1.8, 2.0), ("keep", 1), ("persist", 1)):
                self.b.asi.prim(conv.ped, "lead_to", p)
        log.info("[JOURNEY] %s: %s leads to %s (%s) at %s, %.0f m away", j.id, conv.name, j.target, j.kind, j.dest, dist)
        asyncio.create_task(self.make_plan(j))

    COUPLE_TALK = re.compile(r"\b(couple|swap\w*|swinger\w*|cuckold\w*|threesome|husband and (?:his )?wife|open marriage|"
                             r"like company|watch (?:his|her) (?:wife|husband))\b", re.I)
    OWN_FAMILY = re.compile(r"\b(my (?:wife|husband|kids?|children|family|folks|ma|pa|son|daughter|missus|home|place|camp|"
                            r"house|cabin|shack|farm)|our (?:home|place|camp|house|farm))\b", re.I)

    def infer_kind(self, conv, args, given: str) -> str:
        """0.5.5: the AI often writes lead_to without a kind - 0.5.4 then took you to HIS family (Elijah: 'You mean
        Bob and Mary?' -> 'here's my family'). The kind comes from what was actually said."""
        who = " ".join(str(args.get(k, "")) for k in ("who", "what", "story", "where"))
        said = next((t[len("Player: "):] for t in reversed(conv.transcript) if t.startswith("Player: ")), "")
        mine = next((t for t in reversed(conv.transcript) if not t.startswith("Player: ")), "")
        if self.COUPLE_TALK.search(who) or self.COUPLE_TALK.search(said) or self.COUPLE_TALK.search(mine):
            return "couple"
        if self.OWN_FAMILY.search(who) or (given == "family" and not who.strip()):
            return "family"
        if who.strip() and not self.OWN_FAMILY.search(who):
            return "person"
        if self.OWN_FAMILY.search(said):
            return "family"
        return given or "family"

    # ── what's waiting there (from what he told you) ──
    async def make_plan(self, j: Journey):
        p = j.guide_ident.persona
        said = "\n".join(j.conv.transcript[-14:])
        if j.kind in ("stash", "place"):
            if j.kind == "place" and not j.plan:
                j.plan = {"place": getattr(j, "where", "") or j.target}     # (an empty plan never 'arrived')
            log.info("[JOURNEY] %s plan: %s", j.id, json.dumps(j.plan))
            return
        if self.b.cfg.fake_ai:
            j.plan = self.fake_plan(j)
        else:
            schema = {
                "family": '{"place":"short description of the camp/homestead","members":[{"name":"","sex":"female|male",'
                          '"age":30,"relation":"wife|son|daughter|brother|mother|father|farmhand|...","job":"",'
                          '"temperament":"","doing":"one of: ' + "|".join(DOING) + '","armed":false}],'
                          '"dog":{"has":true,"name":""},"wagon":true,"chickens":false,"secrets":"anything surprising waiting there"}',
                "relative": '{"variant":"alive_hurt|alive_ok|dead|kidnapped","person":{"name":"","sex":"male|female","age":30,'
                            '"relation":"brother|sister|son|...","temperament":""},"kidnappers":0,"leader_name":"",'
                            '"ransom_dollars":0,"what_happened":"short"}',
                "horse": '{"horse_name":"","what_happened":"short","variant":"alone|with_thieves"}',
                "person": '{"place":"where they are (a camp, a shack, a clearing, by a river...)","members":[{"name":"",'
                          '"sex":"female|male","age":30,"relation":"how they know him","job":"","temperament":"",'
                          '"doing":"one of: ' + "|".join(DOING) + '","armed":false,"hostile":false,"note":"what THIS person '
                          'knows, wants, agreed to or was told about the stranger - from what the man said; they keep '
                          'their own will (hostile=true: an enemy who knows trouble may be coming)"}],"campfire":true}',
                "couple": '{"place":"their home","members":[{"name":"","sex":"male","age":35,"relation":"husband",'
                          '"job":"","temperament":"","doing":"one of: ' + "|".join(DOING) + '","note":"what HE likes '
                          '(e.g. watching his wife with a stranger, a third in bed, swapping)"},{"name":"","sex":"female",'
                          '"age":30,"relation":"wife","job":"","temperament":"","doing":"...","note":"what SHE likes"}],'
                          '"arrangement":"one line: what kind of couple they are and what they told the guide"}',
            }[j.kind]
            msgs = [{"role": "system", "content": "You design what is really waiting at a place in a western game set in 1899 "
                                                  "(Red Dead Redemption 2). Be consistent with EVERYTHING this person is and "
                                                  "said: names, how many kids, ages, married/widowed. A widow or widower has NO "
                                                  "living spouse there; someone single has none either. Children under 16 are "
                                                  "kids; a 'son' who works the farm is usually a grown young man (18-25). Use "
                                                  "FIRST names only for family (they share the guide's surname). Make it "
                                                  "specific and alive: everyone is busy with a chore."},
                    {"role": "user", "content": f"The guide ({p.get('sex', 'male')}): {describe_persona(p)}\n"
                                                f"What they said to the stranger:\n{said}\n"
                                                f"He is taking the stranger to: {j.target}. {j.story}\n"
                                                + (f"The REAL place is a {j.where} - describe it as that.\n" if getattr(j, "where", "") else "")
                                                + f"Reply with JSON only: {schema}"}]
            raw, model, errs = await asyncio.to_thread(self.b.ai.chat, msgs, False, 500, 0.8)
            try:
                j.plan = json.loads(re.search(r"\{.*\}", raw or "", re.S).group(0))
            except Exception:
                log.warning("[JOURNEY] plan from AI unusable (%s) - using a procedural one", (raw or "")[:120])
                j.plan = self.fake_plan(j)
            log_turn({"journey_plan": j.id, "plan": j.plan, "raw": raw, "errors": errs})
        forced = self.b.env_journey_variant
        if forced and j.kind == "relative":
            j.plan["variant"] = forced
        log.info("[JOURNEY] %s plan: %s", j.id, json.dumps(j.plan)[:400])

    def fake_plan(self, j: Journey) -> dict:
        p = j.guide_ident.persona
        rng = random.Random(j.guide_ident.id)
        if j.kind == "family":
            fam = p.get("family", "")
            m = re.search(r"(\d+) child", fam)
            kids = int(m.group(1)) if m else rng.choice([0, 1, 2])
            members = [{"name": rng.choice(["Martha", "Ida", "Clara", "Ella"]), "sex": "female", "age": max(20, p["age"] - 3),
                        "relation": "wife", "job": "keeps the camp", "temperament": rng.choice(["fierce", "gentle", "nervous"]),
                        "doing": "laundry", "armed": rng.random() < 0.3}]
            for i in range(min(kids, 3)):
                sex = rng.choice(["male", "female"])
                members.append({"name": rng.choice(["Tommy", "Jack", "Sam"] if sex == "male" else ["Lucy", "Mary", "Rose"]), "sex": sex, "age": rng.randint(6, 13),
                                "relation": "son" if sex == "male" else "daughter", "job": "", "temperament": "curious",
                                "doing": "playing", "armed": False})
            if rng.random() < 0.5:
                members.append({"name": "Elijah", "sex": "male", "age": 40, "relation": "farmhand", "job": "hired hand",
                                "temperament": "quiet", "doing": "sawing wood", "armed": True})
            return {"place": "a small camp by the trees", "members": members, "dog": {"has": rng.random() < 0.6, "name": "Rufus"},
                    "wagon": rng.random() < 0.7, "chickens": rng.random() < 0.3, "secrets": ""}
        if j.kind == "couple":
            return {"place": "their home", "arrangement": "an open couple - he likes to watch, she likes strangers",
                    "members": [{"name": "Walter", "sex": "male", "age": 38, "relation": "husband", "job": "farmer",
                                 "temperament": "sly", "doing": "smoking", "note": "likes to watch his wife with another man"},
                                {"name": "Opal", "sex": "female", "age": 31, "relation": "wife", "job": "seamstress",
                                 "temperament": "flirtatious", "doing": "sweeping", "note": "loves a handsome stranger"}]}
        if j.kind == "person":
            return {"place": "a small camp by the trees", "campfire": True,
                    "members": [{"name": "Rose", "sex": "female", "age": 29, "relation": "an old friend of his",
                                 "job": "seamstress", "temperament": "curious", "doing": "sitting by the fire",
                                 "armed": False, "note": f"{p['first_name']} sent the stranger to you"}]}
        if j.kind == "relative":
            return {"variant": rng.choice(["alive_hurt", "dead", "kidnapped"]),
                    "person": {"name": "Amos", "sex": "male", "age": p["age"] - 4, "relation": "brother", "temperament": "proud"},
                    "kidnappers": 3, "leader_name": "Clyde", "ransom_dollars": 40, "what_happened": "he went hunting and never came back"}
        return {"horse_name": "Biscuit", "what_happened": "spooked by a wolf", "variant": "alone"}

    def cancel(self, j, why: str):
        if j.state in ("done", "failed"):
            return
        log.info("[JOURNEY] %s cancelled: %s", j.id, why)
        self.b.asi.send("route_clear")
        self.b.asi.toast("info", 4, f"Trip to {j.target[:40]} called off ({why}).")
        j.state = "failed"
        if j.conv:
            j.conv.flags["journey"] = False
            j.guide_ident.add_event(f"the trip to {j.target} was called off ({why})", self.b.game.game_minutes_total,
                                    self.b.game.place(), 1)

    def guide_lost(self, ped: int, kind: str):
        j = self.active
        if j and j.guided and j.guide == ped and j.state in ("route", "probing", "spawning"):
            log.info("[JOURNEY] %s: the guide is %s - the trail ends", j.id, "dead" if kind == "ped_dead" else "gone")
            self.b.asi.send("route_clear")
            self.b.asi.toast("info", 4, "Your guide is gone - the trail ends here.")
            j.state = "failed"
            j.conv.flags["journey"] = False

    # ── travelling ──
    async def tick(self):
        for o in list(self.old):
            if self.far_from(o):
                self.free(o)
                self.old.remove(o)
        j = self.active
        if not j or j.state in ("done", "failed", "arrived"):
            self.cleanup()
            return
        g = self.b.game
        if j.state == "looting":
            self.loot_tick(j)
            return
        guide_dead = j.guided and self.b.dead(j.guide) or (j.guide not in self.b.convs and j.state == "route" and
                                              time.time() - j.started > 5 and not g.ped(j.guide))
        if guide_dead and j.state == "route":
            log.info("[JOURNEY] %s: the guide is dead or gone - no more route", j.id)
            self.b.asi.send("route_clear")
            self.b.asi.toast("info", 4, "Your guide is gone - the trail ends here.")
            j.state = "failed"
            j.conv.flags["journey"] = False
            return
        if not j.dest or not g.player:
            return
        d = math.hypot(g.player.get("x", 0) - j.dest[0], g.player.get("y", 0) - j.dest[1])
        if j.state == "route" and d > getattr(j, "start_dist", d) + 1500:      # you went your own way: the trip is off
            self.cancel(j, "you went your own way")
            return
        if j.state == "route" and d < self.b.cfg.journey_spawn_m and j.plan:
            if getattr(j, "place", None) and j.place.get("kind") in BUILDINGS:
                # 0.5.5: a real building - the door's own height is right; the ground probe measured from 300 m up
                # and hit the ROOF (the family stood on top of the shack in Lakay)
                j.state = "spawning"
                self.spawn_all(j)
            else:
                j.state = "probing"
                self.probe(j)
        elif j.state == "spawned" and d < 30:
            j.arrived_at = time.time()
            self.b.asi.send("route_clear")
            if j.kind == "stash":
                j.state = "looting"
                self.b.asi.toast("ok", 6, "The stash should be right here - walk up to the strongbox.")
                log.info("[JOURNEY] %s: arrived at the stash", j.id)
                return
            j.state = "arrived"
            asyncio.create_task(self.arrival(j))

    def loot_tick(self, j: Journey):
        g = self.b.game
        box = next((x for x in j.spawned if x.get("role") == "loot"), None)
        bx, by = (box["x"], box["y"]) if box else (j.dest[0], j.dest[1])
        d = math.hypot(g.player.get("x", 0) - bx, g.player.get("y", 0) - by)
        if d > 400:
            j.state = "done"
            return
        if d > 2.6:
            return
        dollars = float(j.plan.get("dollars", 20))
        self.b.asi.prim(0, "stash", ("money", int(round(dollars * 100))))
        self.b.asi.toast("ok", 8, f"You found the stash (\"{j.target[:50]}\"): ${dollars:.2f}")
        j.state = "arrived"
        world.add_deed(self.b.memory, g.place(), g.zone()["state"], f"THE_STRANGER dug up {j.target}", 1,
                       g.game_minutes_total, 0)
        j.guide_ident.add_event(f"he found {j.target} you told him about (${dollars:.0f})", g.game_minutes_total,
                                g.place(), 2)
        log.info("[JOURNEY] %s: stash looted: $%.2f", j.id, dollars)
        conv = self.b.convs.get(j.guide)
        if j.guided and conv and not conv.ended and not self.b.dead(j.guide):
            conv.flags["journey"] = False
            conv.pending_events.append(("stash_found", f"He opened {j.target} - ${dollars:.0f} inside. React (maybe you "
                                                       "want your share).", 3))
            asyncio.create_task(self.b.run_turn(conv, reaction=True))

    def probe(self, j: Journey):
        """Find dry, solid ground near the destination (spiral outwards)."""
        k = j.probe_tries
        r = 0 if k == 0 else 25 + 15 * (k // 6)
        a = k * 1.05
        x, y = j.dest[0] + math.cos(a) * r, j.dest[1] + math.sin(a) * r
        self.seq += 1
        j.probe_seq = self.seq
        self.b.asi.send("probe", self.seq, round(x, 1), round(y, 1), round(self.b.game.player.get("z", j.dest[2]), 1))

    def on_probe(self, m: dict):
        j = self.active
        if not j or int(m.get("seq", 0)) != j.probe_seq or j.state != "probing":
            return
        if m.get("ok") and not m.get("water"):
            j.dest = [round(m["x"], 1), round(m["y"], 1), round(m["z"], 1)]
            log.info("[JOURNEY] %s: solid ground at %s after %d probe(s)", j.id, j.dest, j.probe_tries + 1)
            self.b.asi.send("route", *j.dest, f"{j.guide_ident.persona['first_name']}: {j.target}"[:40])
            j.state = "spawning"
            self.spawn_all(j)
        else:
            j.probe_tries += 1
            if j.probe_tries > 30:
                log.warning("[JOURNEY] %s: no dry ground found - using the original spot", j.id)
                j.state = "spawning"
                self.spawn_all(j)
            else:
                self.probe(j)

    def spawn(self, j: Journey, kind, model, dx, dy, heading=0.0, flags="ground", **info):
        if getattr(j, "place", None) and j.place.get("kind") in BUILDINGS and flags.startswith("ground"):
            flags = "floor" + flags[len("ground"):]          # the ground under the door, never the roof
        self.seq += 1
        x, y, z = j.dest[0] + dx, j.dest[1] + dy, (info.pop("z", None) if info.get("z") is not None else j.dest[2])
        info.pop("z", None)
        j.pending[self.seq] = dict(info, kind=kind, model=model, x=x, y=y, z=z)
        self.b.asi.send("spawn", self.seq, kind, model, round(x, 2), round(y, 2), round(z, 2), round(heading, 1), flags)

    def spawn_all(self, j: Journey):
        rng = random.Random(j.id)
        P = j.plan
        ring = lambda r, a: (math.cos(a) * r, math.sin(a) * r)
        at_building = bool(getattr(j, "place", None)) and j.place["kind"] in BUILDINGS
        if j.kind == "family" and at_building:          # their real house: the family at the door / in the yard
            if (P.get("dog") or {}).get("has"):
                self.spawn(j, "ped", rng.choice(DOGS), *ring(3.0, 1.2), 0, "ground", role="dog", name=(P["dog"] or {}).get("name", ""))
            if P.get("chickens"):
                for i in range(3):
                    self.spawn(j, "ped", "a_c_chicken_01", *ring(7, 5 + i * 0.3), 0, "ground", role="animal")
            for i, mem in enumerate(P.get("members", [])[:6]):
                self.spawn_person(j, mem, *ring(rng.uniform(1.5, 4.5), i * 1.1 + 0.4), rng)
        elif j.kind == "family":
            self.spawn(j, "obj", "p_campfire02x", 0, 0)
            for i, prop in enumerate(rng.sample(PROPS[1:], 7)):
                dx, dy = ring(rng.uniform(4, 8), i * 0.9 + rng.random() * 0.3)
                self.spawn(j, "obj", prop, dx, dy, rng.uniform(0, 360))
            self.spawn(j, "obj", "p_strongbox01x", *ring(6.5, 4.2), rng.uniform(0, 360), role="loot")
            if P.get("wagon"):
                self.spawn(j, "veh", rng.choice(WAGONS), *ring(11, 2.4), rng.uniform(0, 360), role="wagon")
            if (P.get("dog") or {}).get("has"):
                self.spawn(j, "ped", rng.choice(DOGS), *ring(3.5, 1.2), 0, "ground", role="dog", name=(P["dog"] or {}).get("name", ""))
            if P.get("chickens"):
                for i in range(3):
                    self.spawn(j, "ped", "a_c_chicken_01", *ring(9, 5 + i * 0.3), 0, "ground", role="animal")
            for i, mem in enumerate(P.get("members", [])[:6]):
                self.spawn_person(j, mem, *ring(rng.uniform(3, 6.5), i * 1.25 + 0.4), rng)
        elif j.kind == "relative":
            per = P.get("person", {})
            var = P.get("variant", "alive_hurt")
            mem = dict(per, doing="resting" if var == "alive_hurt" else "waiting", relation=per.get("relation", "brother"))
            if var == "dead":
                self.spawn_person(j, mem, 0, 0, rng, flags="ground,dead")
            elif var == "kidnapped":
                self.spawn(j, "obj", "p_campfire02x", 3, 3)
                self.spawn_person(j, mem, 0, 0, rng, flags="ground,hogtied", hostage=True)
                n = max(2, min(4, int(P.get("kidnappers", 3))))
                for i in range(n):
                    k = {"name": P.get("leader_name", "Clyde") if i == 0 else "", "sex": "male", "age": rng.randint(22, 45),
                         "relation": "kidnapper", "job": "outlaw", "temperament": "cruel", "doing": "keeping watch", "armed": True}
                    self.spawn_person(j, k, *ring(rng.uniform(3, 6), i * 1.6), rng, model=rng.choice(OUTLAWS),
                                      leader=(i == 0), kidnapper=True)
            else:
                self.spawn_person(j, mem, 0, 0, rng)
        elif j.kind == "place":
            pass                          # a real place: nothing to build, it's already there
        elif j.kind == "couple":
            asyncio.create_task(self.spawn_couple(j, rng))       # inside, by their bed (found first)
            return
        elif j.kind == "person":
            if P.get("campfire", True) and not at_building:
                self.spawn(j, "obj", "p_campfire02x", 0, 0)
                for i, prop in enumerate(rng.sample(PROPS[1:], 3)):
                    self.spawn(j, "obj", prop, *ring(rng.uniform(4, 7), i * 1.7), rng.uniform(0, 360))
            for i, mem in enumerate(P.get("members", [])[:4]):
                self.spawn_person(j, mem, *ring(rng.uniform(2.5, 5), i * 1.4 + 0.3), rng)
        elif j.kind == "stash":
            self.spawn(j, "obj", "p_strongbox01x", 0, 0, rng.uniform(0, 360), role="loot")
            self.spawn(j, "obj", "p_crate03x", 1.6, 0.8, rng.uniform(0, 360))
            self.spawn(j, "obj", "p_lantern05x", -1.2, 0.6, 0)
        else:
            self.spawn(j, "ped", rng.choice(HORSES), 0, 0, 0, "ground", role="horse", name=P.get("horse_name", ""))
        log.info("[JOURNEY] %s: spawning %d things at %s", j.id, len(j.pending), j.dest)
        if not j.pending and j.state == "spawning":
            j.state = "spawned"

    def family_models(self, j, sex: str) -> list[str]:
        """0.5.1: the guide's kin look like the guide's people: the same model family (Saint Denis townsfolk with Saint
        Denis townsfolk...), and the plugin matches the skin tone to the guide's (like=<guide>). 0.5.0 picked any
        traveller model: a black woman's family came out white."""
        gm = (j.guide_ident.d.get("model_name") or "")
        if not gm:
            try:
                gm = self.b.peddb.by_hash.get(int(j.guide_ident.d.get("model", 0)) & 0xFFFFFFFF, {}).get("n", "")
            except Exception:
                gm = ""
        parts = gm.split("_")
        if len(parts) < 4 or parts[0].upper() != "A":
            return []
        stem = parts[3].rstrip("0123456789").lower()
        gsex = "M" if parts[1].upper() == "M" else "F"
        out = []
        want = "M" if sex == "male" else "F"
        for n in (p.get("n", "") for p in self.b.peddb.by_hash.values()):
            q = n.split("_")
            if len(q) >= 4 and q[0].upper() == "A" and q[1].upper() == want and q[2].upper() in ("M", "Y") \
                    and q[3].rstrip("0123456789").lower() == stem and not (n.lower() == gm.lower() and want == gsex):
                out.append(n)          # (never the guide's own model for a son/brother: he'd look like his twin)
        return sorted(set(out))

    def kin_candidates(self, j, sex: str, age: int, child: bool) -> list[str]:
        """Models to try, best first, for someone who must look like the guide's family."""
        if child:
            return list(KIDS.get(sex) or [])
        fam = self.family_models(j, sex) if 18 <= age < 58 else []
        rest = [n for n in (p.get("n", "") for p in self.b.peddb.by_hash.values())
                if n.upper().startswith(f"A_{'M' if sex == 'male' else 'F'}_{'O' if age >= 58 else 'M'}_")
                and "TOWNFOLK" in n.upper()]
        rnd = random.Random(f"{j.id}{sex}{age}")
        rnd.shuffle(rest)
        out = []
        for n in fam + (YOUNG[sex] if age < 26 else []) + rest + (FEMALE if sex == "female" else MALE):
            if n not in out:
                out.append(n)
        return out

    def on_tone(self, m: dict):
        """0.5.5: the plugin couldn't give this person the guide's skin with this model's outfits -> another model.
        A black man's wife and kids are black, a white man's white: the family is rebuilt until it fits (3 tries)."""
        j = self.active
        h = int(m.get("ped", 0))
        if not j or m.get("ok"):
            if j and m.get("ok"):
                log.info("[JOURNEY] skin of %d: %s", h, m.get("how"))
            return
        x = next((y for y in j.spawned if y.get("h") == h), None)
        if not x or x.get("role") != "person":
            return
        tried = x.setdefault("tried", [x["model"]])
        if len(tried) >= 4:
            log.warning("[JOURNEY] %s: no model with the guide's skin for %s after %d tries - kept the closest",
                        j.id, x["ident"].persona["name"] if x.get("ident") else h, len(tried))
            return
        mem = x.get("mem") or {}
        sex = "male" if str(mem.get("sex", "male")).startswith("m") else "female"
        nxt = next((n for n in self.kin_candidates(j, sex, int(mem.get("age", 30) or 30), bool(x.get("child")))
                    if n not in tried), None)
        if not nxt:
            return
        tried.append(nxt)
        log.info("[JOURNEY] %s: %s doesn't have the guide's skin (%s) - trying %s", j.id, x["model"], m.get("how"), nxt)
        self.b.asi.send("despawn", h, "delete")
        j.spawned.remove(x)
        self.b.handle_ident.pop(h, None)
        flags = "floor" if (getattr(j, "place", None) and j.place.get("kind") in BUILDINGS) else "ground"
        if x.get("child"):
            flags += ",invincible"
        flags += f",like={j.guide}"
        scen = DOING.get(str(mem.get("doing", "")).lower())
        if scen:
            flags += f",scenario={scen}"
        self.seq += 1
        j.pending[self.seq] = {k: v for k, v in x.items() if k not in ("h",)}
        j.pending[self.seq]["model"] = nxt
        self.b.asi.send("spawn", self.seq, "ped", nxt, round(x["x"], 2), round(x["y"], 2), round(x["z"], 2),
                        round(random.uniform(0, 360), 1), flags)

    async def spawn_couple(self, j, rng):
        """0.5.3: the couple you were sent to is INSIDE, by their bed (a real bed / a sleeping spot of the house, or a
        blanket on the floor) - not standing at the door of an empty cabin."""
        pl = getattr(j, "place", None) or {"x": j.dest[0], "y": j.dest[1], "z": j.dest[2]}
        bed = await self.b.couples.find_bed(pl["x"], pl["y"], pl["z"], 30.0)
        j.bed = bed
        if bed:
            bx, by, bz = float(bed["x"]), float(bed["y"]), float(bed["z"])
            if bed.get("src") == "floor":
                self.spawn(j, "obj", "p_bedrollopen01x", bx - j.dest[0], by - j.dest[1], float(bed.get("hd", 0)), "exact",
                           z=bz)
        else:
            bx, by, bz = j.dest
        for i, mem in enumerate(j.plan.get("members", [])[:2]):
            mem["age"] = max(21, int(mem.get("age") or 30))
            mem.setdefault("doing", "waiting")
            ox, oy = (1.2, 0.6) if i == 0 else (-1.0, 0.9)
            self.spawn_person(j, mem, bx + ox - j.dest[0], by + oy - j.dest[1], rng,
                              flags="exact" if bed else "ground", couple=True, z=bz + 0.3 if bed else None)
        j.couple_in_act = bool(bed)
        log.info("[JOURNEY] %s: the couple is inside on %s%s", j.id, (bed or {}).get("model", "the door (no bed found)"),
                 " - already at it" if bed else "")

    def spawn_person(self, j, mem, dx, dy, rng, flags="ground", model=None, **info):
        sex = "male" if str(mem.get("sex", "male")).startswith("m") else "female"
        try:
            age = int(mem.get("age", 30))
        except (TypeError, ValueError):
            age = 30
        child = age < 16 and not info.get("kidnapper")
        if child and not KIDS.get(sex):          # no little-girl model in the game: she's an older daughter
            child, age = False, 17
            mem["age"] = 17
        kin = j.kind in ("family", "relative") and not info.get("kidnapper")
        if not model:
            fam = self.family_models(j, sex) if kin and not child and 18 <= age < 58 else []
            model = rng.choice(KIDS[sex] if child else fam or (YOUNG[sex] if age < 26 else OLD[sex] if age >= 58 else
                                                               (FEMALE if sex == "female" else MALE)))
        if child:
            flags += ",invincible"          # real children only (the game's own rule for kids)
        if kin and not self.b.dead(j.guide) and j.guided:
            flags += f",like={j.guide}"     # same skin tone as the guide (the plugin tries the model's outfits)
        doing = str(mem.get("doing", "")).lower()
        if doing not in DOING:
            rel = str(mem.get("relation", "")).lower()
            doing = "playing" if child else next((v for k, v in DOING_BY_REL.items() if k in rel), "waiting")
            mem["doing"] = doing
        scen = DOING.get(doing)
        if scen and "dead" not in flags and "hogtied" not in flags:
            flags += f",scenario={scen}"
        if (mem.get("armed") or mem.get("hostile") or getattr(j, "hostile", False) and j.kind == "person") and not child:
            flags += ",weapon=WEAPON_REVOLVER_CATTLEMAN"
        self.spawn(j, "ped", model, dx, dy, rng.uniform(0, 360), flags, role="person", mem=mem, child=child, **info)

    def on_spawned(self, m: dict):
        j = self.active
        if not j:
            return
        info = j.pending.pop(int(m.get("seq", 0)), None)
        if info is None:
            return
        h = int(m.get("h", 0))
        if not h:
            log.warning("[JOURNEY] %s: could not spawn %s (%s)", j.id, info["model"], m.get("why"))
        else:
            info["h"] = h
            if info.get("role") == "person" and info.get("ident") is not None:      # a re-spawn: same person, new look
                self.b.handle_ident[h] = info["ident"].id
                info["ident"].d["model"] = joaat_cached(info["model"])
                info["ident"].d["model_name"] = info["model"]
                info["ident"].dirty()
            elif info.get("role") == "person":
                info["ident"] = self.person_ident(j, info)
            j.spawned.append(info)
            log.info("[JOURNEY] %s: spawned %s %s -> %d %s%s%s", j.id, info.get("role", info["kind"]), info["model"], h,
                     info["ident"].persona["name"] if info.get("ident") else info.get("name", ""),
                     " LEADER" if info.get("leader") else "", " HOSTAGE" if info.get("hostage") else "")
        if not j.pending and j.state == "spawning":
            j.state = "spawned"
            if j.kind == "couple":
                pair = [x for x in j.spawned if x.get("ident")]
                if len(pair) == 2 and getattr(j, "couple_in_act", False) and getattr(j, "bed", None):
                    # 0.5.5: you find them IN THE ACT on their own bed - and since they wanted you to come, they
                    # don't stop when you walk in
                    for x in pair:
                        self.b.asi.send("actor", x["h"], 1)
                        self.b.asi.prim(x["h"], "couple", ("undress",))
                    sc = self.b.couples.start_scene(pair[0]["h"], pair[1]["h"], j.bed, "expecting_you")
                    j.couple_scene = sc.id
                if len(pair) == 2:
                    a, b2 = pair[0]["ident"], pair[1]["ident"]
                    sur = a.persona["name"].split()[-1]
                    b2.persona["name"] = f"{b2.persona['first_name']} {sur}"
                    for me, other in ((a, b2), (b2, a)):
                        rel = "your wife" if other.persona["sex"] == "female" else "your husband"
                        me.d.setdefault("relations", {})[f"id:{other.id}"] = {"rel": rel}
                        me.dirty()
            log.info("[JOURNEY] %s: the place is ready (%d spawned)", j.id, len(j.spawned))

    def person_ident(self, j: Journey, info: dict):
        mem, g = info["mem"], self.b.game
        from .hashing import joaat
        mh = joaat(info["model"])
        cls = self.b.peddb.classify(mh, mem.get("sex", "male") == "male")
        cls.update({"known": True, "child": bool(info.get("child")) or cls.get("child"),
                    "role": "outlaw" if info.get("kidnapper") else (cls.get("role") or "rancher")})
        ident = self.b.memory.create(mh, 0, cls, g.place(), g.game_minutes_total)
        p = ident.persona
        if mem.get("name"):
            first = str(mem["name"]).split()[0]
            if info.get("kidnapper") or j.kind == "person":
                p["name"] = str(mem["name"]) if len(str(mem["name"]).split()) > 1 else f"{first} {p['name'].split()[-1]}"
            else:          # 0.5.1: "Ben Nelson" + "Nelson" was "Ben Nelson Nelson"; kin share the name, a hired hand doesn't
                kin_rel = any(k in str(mem.get("relation", "")).lower() for k in
                              ("wife", "husband", "son", "daughter", "child", "brother", "sister", "mother", "father",
                               "grand", "uncle", "aunt", "cousin", "nephew", "niece", "kid"))
                rest = str(mem["name"]).split()[1:]
                p["name"] = f"{first} {j.guide_ident.persona['name'].split()[-1] if kin_rel else (rest[-1] if rest else p['name'].split()[-1])}"
            p["first_name"] = first
        p["age"] = int(mem.get("age", p["age"]) or p["age"])
        p["child"] = bool(info.get("child"))
        p["job"] = mem.get("job") or p["job"]
        p["temperament"] = mem.get("temperament") or p["temperament"]
        rel = str(mem.get("relation", ""))
        guide = j.guide_ident.persona
        if info.get("kidnapper"):
            p["role_note"] = (f"you and your gang are holding {j.plan.get('person', {}).get('name', 'a man')} for ransom: you want "
                              f"${j.plan.get('ransom_dollars', 40)}" + (". YOU are the leader: you do the talking and decide."
                                                                         if info.get("leader") else ". The leader does the talking."))
            ident.d.setdefault("flags", {})["kidnapper"] = {"leader": bool(info.get("leader")), "journey": j.id}
        elif j.kind == "couple":
            other = next((m2 for m2 in j.plan.get("members", []) if m2 is not mem), {})
            on = str(other.get("name", "your partner")).split()[0]
            p["role_note"] = (f"you and {on} ({other.get('relation', 'your partner')}) are a couple: "
                              f"{j.plan.get('arrangement', 'an open-minded pair')}. {guide['name']} told the stranger about "
                              f"you - you're glad he came. What YOU like: {mem.get('note', '')}. You decide together, out loud, "
                              "and either of you can stop it.")
            p["sexuality"] = str(mem.get("note", "")) or p.get("sexuality", "")
            p["romance_openness"] = max(0.75, float(p.get("romance_openness", 0)))
            p["family"] = f"{'married to' if 'wife' in str(other.get('relation', '')) + str(mem.get('relation', '')) else 'with'} {on}"
            ident.d.setdefault("flags", {})["open_couple"] = j.id
            if getattr(j, "bed", None):
                ident.d["bed"] = j.bed
        elif j.kind == "person":
            p["role_note"] = (f"you know {guide['name']} ({rel or 'an acquaintance'}); you're at {j.plan.get('place', 'your camp')}. "
                              + str(mem.get("note", "")) + " You are your own person: you decide for yourself what you do.")
            if mem.get("hostile") or getattr(j, "hostile", False):
                p["role_note"] += (" You have bad blood with the people who'd send someone after you - you're on guard, "
                                   "armed, and you know why a stranger might come.")
        else:
            gmale = guide["sex"] == "male"
            rl = rel.lower()
            to_me = ("your husband" if rl in ("wife",) else "your wife" if rl in ("husband",) else
                     ("your pa" if gmale else "your ma") if rl in ("son", "daughter", "child", "kid") else
                     ("your son" if gmale else "your daughter") if rl in ("mother", "father") else
                     ("your brother" if gmale else "your sister") if rl in ("brother", "sister") else
                     "your boss" if "hand" in rl or "worker" in rl else f"your kin")
            others = [m2 for m2 in j.plan.get("members", []) if m2 is not mem and m2.get("name")]
            p["role_note"] = (f"you are {guide['name']}'s {rel or 'kin'}; you live at {j.plan.get('place', 'this camp')}. "
                              f"{guide['first_name']} is {to_me}. Living here too: "
                              + (", ".join(f"{str(m2['name']).split()[0]} ({m2.get('relation', '')}, {m2.get('age', '?')})"
                                           for m2 in others) or "nobody else") + ".")
            p["family"] = f"{guide['name']} ({to_me})"
            ident.d.setdefault("relations", {})["guide"] = {"name": guide["name"], "rel": to_me, "job": guide["job"], "male": gmale}
            # and the guide knows them back (0.5.1: Hattie had no idea who the boy next to her was)
            j.guide_ident.d.setdefault("relations", {})[f"id:{ident.id}"] = {"rel": f"your {rl or 'kin'}"}
            j.guide_ident.dirty()
        if info.get("kidnapper") or j.kind == "person":
            ident.d.setdefault("relations", {}).setdefault("guide", {"name": guide["name"], "rel": rel or "someone you know",
                                                                     "job": guide["job"], "male": guide["sex"] == "male"})
        ident.dirty()
        self.b.handle_ident[info["h"]] = ident.id
        return ident

    # ── arrival: everyone reacts to how you show up ──
    def situation(self, j: Journey) -> str:
        g = self.b.game
        gp = g.ped(j.guide) if not self.b.dead(j.guide) else {}
        pl = g.player
        name = j.guide_ident.persona["name"]
        if not j.guided:
            s = f"The stranger comes alone - {name} told him where to find you."
        elif self.b.dead(j.guide) or not gp:
            s = f"{name} is NOT with the stranger. (He's dead or gone - the stranger may know what happened to him.)"
        elif g.player.get("c") and int(g.player.get("ch", 0)) == j.guide:
            s = f"The stranger walks in CARRYING {name} over his shoulder, hogtied."
        elif gp.get("hog"):
            s = f"{name} is hogtied, lying near the stranger."
        elif gp.get("aimed") or j.conv.flags.get("hands_up"):
            s = f"The stranger is holding {name} at GUNPOINT."
        elif j.conv.flags.get("captive") or j.conv.seconds_since("threatened") < 600 or j.conv.seconds_since("hurt_by_player") < 900:
            s = (f"{name} is brought home BY FORCE - the stranger threatened him and made him lead the way"
                 + (" on his horse" if j.conv.flags.get("riding") else "") + ". He's terrified.")
        elif j.conv.flags.get("riding"):
            s = f"{name} rides in on the stranger's horse, behind him - they seem to get along."
        else:
            s = f"{name} walks in with the stranger."
        if pl.get("armed"):
            s += " The stranger has his gun out."
        return s

    async def arrival(self, j: Journey):
        try:
            g = self.b.game
            people = [x for x in j.spawned if x.get("role") == "person" and x.get("ident") and not self.b.dead(x["h"])]
            sit = self.situation(j)
            j.guide_ident.add_event(f"you brought the stranger to {j.target}", g.game_minutes_total, g.place(), 2)
            log.info("[JOURNEY] %s: arrival - %s", j.id, sit)
            j.conv.flags["journey"] = False
            for x in people:
                if j.kind == "couple":      # 0.5.5: how HE treated the guide on the way is not their story
                    x["ident"].add_summary(f"The stranger {j.guide_ident.persona['first_name']} told you about arrived - the "
                                           "one you hoped would come.", g.game_minutes_total, g.place())
                else:
                    x["ident"].add_summary(f"A stranger arrived. {sit}", g.game_minutes_total, g.place())
            if j.kind == "horse":
                await self.horse_found(j)
                return
            if j.kind == "place":
                if j.guided and not self.b.dead(j.guide) and not j.conv.ended:
                    j.conv.pending_events.append(("arrived", f"You're there: the {getattr(j, 'where', '') or j.target}. "
                                                             "Do what you came for (a drink at the bar, a room, a seat...).", 2))
                    asyncio.create_task(self.b.run_turn(j.conv, reaction=True))
                return
            if j.kind == "couple":
                bed = getattr(j, "bed", None)
                if not bed and getattr(j, "place", None):
                    bed = await self.b.couples.find_bed(j.place["x"], j.place["y"], j.place["z"], 30.0)
                for x in people:
                    x["ident"].d["bed"] = bed
                    x["ident"].dirty()
            dead_rel = j.kind == "relative" and j.plan.get("variant") == "dead"
            if dead_rel:
                await self.found_dead(j)
                return
            if not people:
                return
            if j.kind == "couple" and people:
                if j.guided and j.conv and not j.conv.ended and not self.b.dead(j.guide):
                    # his job is done: he steps back, so X goes to the couple (0.5.4: he kept the conversation)
                    j.conv.ident.add_event("you brought the stranger to the couple", g.game_minutes_total, g.place(), 2)
                    self.b.end(j.conv, "he brought you there", release_tasks=True)
                t0 = time.time()
                while time.time() - t0 < 240:            # they talk to you once you're really there (inside, close)
                    near = [x for x in people if (self.b.game.ped(x["h"]) or {}).get("d", 99) < 9 or
                            any(int(q.get("h", 0)) == x["h"] and q.get("d", 99) < 9 for q in self.b.game.near_peds)]
                    if near:
                        break
                    await asyncio.sleep(0.5)
                await self.couple_welcome(j, people)
                return
            script = await self.arrival_script(j, people, sit)
            await self.play(j, people, script)
        except Exception as e:
            log.error("[JOURNEY] arrival crashed: %s\n%s", e, traceback.format_exc())

    async def couple_welcome(self, j, people):
        """0.5.3: the couple talks to you first - they know why you're here (the man who sent you told them about you)."""
        b = self.b
        t0 = time.time()
        while (b.ptt_ped or b.speaking) and time.time() - t0 < 20:
            await asyncio.sleep(0.3)
        host = people[0]
        if b.dead(host["h"]):
            return
        p = b.game.ped(host["h"]) or next((x for x in b.game.near_peds if int(x.get("h", 0)) == host["h"]), {}) or {}
        from .hashing import joaat
        conv = b.on_engage_req({"ped": host["h"], "model": joaat(host["model"]), "outfit": p.get("o", 0),
                                "male": host["mem"].get("sex", "male") == "male", "alive": 1, "human": 1},
                               forced_ident=host["ident"], reason="couple")
        if not conv:
            return
        other = people[1]["ident"].persona["first_name"] if len(people) > 1 else "your partner"
        in_act = bool(getattr(j, "couple_scene", None) and b.couples.scenes.get(j.couple_scene))
        for x in people:
            oc = b.convs.get(x["h"])
            if oc:
                oc.flags["bed"] = getattr(j, "bed", None)
        conv.flags["bed"] = getattr(j, "bed", None)
        if in_act:
            conv.flags["in_scene"] = True
            ev = (f"The stranger {j.guide_ident.persona['name']} told you about just walked in - while you and {other} are "
                  "in the middle of making love on your bed. You WANTED him to come: you don't stop. Talk to him while you "
                  "keep going - tease him, tell him what you two like, invite him to watch or to take your place "
                  "(make_love with him; agree_to_watch for the one who watches). Only what each of you wants; either of "
                  "you can stop it (stop_making_love).")
        else:
            ev = (f"The stranger {j.guide_ident.persona['name']} told you about is HERE, in your home, with you and {other}. "
                  "You know why he came. Greet him, tell him what you two like, and if you both want it, show him to the "
                  "bed (agree_to_make_love / make_love, agree_to_watch for the one who watches). Only what each of you wants.")
        conv.pending_events.append(("couple_home", ev, 3))
        for x in people[1:]:          # 0.5.5: the other one knows too (Clara: "what do you want from me?")
            other_name = host["ident"].persona["first_name"]
            x["ident"].d["on_meet"] = [ev.replace(f"you and {other}", f"you and {other_name}")]
            x["ident"].dirty()
        await b.run_turn(conv, reaction=True)

    async def arrival_script(self, j: Journey, people, sit) -> dict:
        names = [x["ident"].persona["first_name"] for x in people]
        if self.b.cfg.fake_ai:
            def fr(x):
                if x["ident"].d.get("flags", {}).get("kidnapper"):
                    return "draw_weapon"
                if x.get("hostage"):
                    return "beg"
                if x.get("child"):
                    return "hide_with_kids"
                return "draw_weapon" if "GUNPOINT" in sit or "hogtied" in sit else "welcome"
            return {"lines": [{"who": names[0], "say": "Lord, what's going on here?!", "emotion": "fearful", "act": "tremble"},
                              {"who": "GUIDE", "say": "It's alright, he's with me.", "emotion": "calm", "act": "calm_down"}],
                    "reactions": {x["ident"].persona["first_name"]: fr(x) for x in people}}
        cast = "\n".join(f"- {x['ident'].persona['first_name']}: " + describe_persona(x["ident"].persona).replace("\n", " ")
                         + (" (CHILD)" if x.get("child") else "") + (" (armed)" if x["mem"].get("armed") else "")
                         for x in people)
        guide = j.guide_ident.persona
        user = (f"Place: {j.plan.get('place', 'a camp in the wilds')}. Time: {self.b.game.time_text()}.\n"
                f"These people are here:\n{cast}\n"
                f"Their man/kin: {guide['name']} ({describe_persona(guide).splitlines()[0]}).\n"
                f"SITUATION: {sit}\nWhat he told the stranger on the way: " + " | ".join(j.conv.transcript[-8:]) + "\n"
                f"Write how they react in the first seconds: 4-8 short spoken lines (who = EXACTLY one of these first names: "
                f"{', '.join(names)} - or GUIDE when {guide['first_name']} speaks). They talk TO EACH OTHER and to "
                f"{guide['first_name']} as well as to the stranger (questions, answers, a hug, introductions). The STRANGER "
                f"NEVER speaks here - only these people and GUIDE ({guide['first_name']}, who brought him). Kids talk like "
                f"kids, grown-ups like grown-ups; nobody speaks another person's line. Real emotions (tears, rage, relief, "
                f"panic, cursing, warmth), and for EACH person one reaction from: "
                f"{', '.join(REACTIONS)}. Children only ever: stay, welcome, run_to_guide, flee, hide_with_kids, sob.\n"
                'JSON only: {"lines":[{"who":"","say":"","emotion":"happy|sad|angry|fearful|disgusted|surprised|calm|fluent","act":""}],'
                '"reactions":{"<name>":"<reaction>"}}')
        raw, model, errs = await asyncio.to_thread(self.b.ai.chat, [
            {"role": "system", "content": "You write the reactions of real people in 1899 (Red Dead Redemption 2) when a "
                                          "dangerous stranger shows up at their camp. No narration, only spoken lines."},
            {"role": "user", "content": user}], False, 600, 0.9)
        log_turn({"journey_arrival": j.id, "user": user, "raw": raw, "errors": errs})
        try:
            return json.loads(re.search(r"\{.*\}", raw or "", re.S).group(0))
        except Exception:
            return {"lines": [], "reactions": {}}

    async def play(self, j: Journey, people, script: dict):
        by_name = {x["ident"].persona["first_name"].lower(): x for x in people}
        P = lambda h, *p: self.b.asi.prim(h, "journey", tuple(p))
        for x in people:
            self.b.asi.send("actor", x["h"], 1)
            P(x["h"], "look", 15000)
        for i, ln in enumerate((script.get("lines") or [])[:8]):
            who = str(ln.get("who", ""))
            wl = who.lower().strip()
            gfirst = j.guide_ident.persona.get("first_name", "").lower()
            if wl == "guide" or (gfirst and wl.split()[:1] == [gfirst]):
                if self.b.dead(j.guide) or not j.guided:
                    continue
                ped, ident = j.guide, j.guide_ident
            else:
                # 0.5.1: an unknown speaker is SKIPPED - 0.5.0 gave every unmatched line to the first person, so the
                # little boy said his mother's lines ("It's alright, children. Just stay close to me.")
                x = by_name.get(wl) or by_name.get(wl.split()[0] if wl else "")
                if not x:
                    log.info("[JOURNEY] line for unknown speaker %r skipped", who)
                    continue
                ped, ident = x["h"], x["ident"]
            t0 = time.time()
            while (self.b.ptt_ped or (self.b.speaking and not self.b.speaking.get("scene"))) and time.time() - t0 < 20:
                await asyncio.sleep(0.2)         # let whoever is talking finish first
            from .director import EMOTES
            act = str(ln.get("act", ""))
            if act in EMOTES:
                cat, em = EMOTES[act]
                P(ped, "emote", cat, em, 0)
            dur = await self.b.say_line(ped, ident, str(ln.get("say", "")), str(ln.get("emotion", "fluent")))
            await asyncio.sleep(dur + 0.3)
            if i == 1:
                self.react_all(j, people, script.get("reactions") or {})
        if len(script.get("lines") or []) < 2:
            self.react_all(j, people, script.get("reactions") or {})
        await asyncio.sleep(6)
        # 0.5.1: nobody stands frozen afterwards - they go back to what they were doing (they idled like statues)
        for x in people:
            if self.b.dead(x["h"]) or x["h"] in self.b.convs:
                continue
            doing = DOING.get(str(x["mem"].get("doing", "")).lower())
            r = str((script.get("reactions") or {}).get(x["ident"].persona["first_name"], "stay")).lower()
            if doing and r in ("stay", "welcome", "run_to_guide", "sob") and not x.get("kidnapper"):
                P(x["h"], "clear"); P(x["h"], "scenario", doing, -1)
        for x in people:
            self.b.asi.send("actor", x["h"], 0)
        # and the one who brought you home introduces you (0.5.1: Hattie just stood there)
        conv = j.conv
        sit_now = self.situation(j)
        if j.guided and j.kind == "family" and ("get along" in sit_now or "walks in with" in sit_now):
            self.b.drama.go_home_to_family(conv, [x for x in people if not x.get("kidnapper")])
        if j.guided and j.kind in ("family", "person", "couple") and not self.b.dead(j.guide) and conv and not conv.ended:
            who = "; ".join(f"{x['ident'].persona['first_name']} ({x['mem'].get('relation', '')})" for x in people)
            if "get along" in sit_now or "walks in with" in sit_now:
                ev = (f"You're there - your people are right here: {who}. Introduce the stranger to them by name, call them "
                      "over or walk over to one (go_to with their name). You know every one of them.")
            else:   # 0.5.5: a man dragged home at gunpoint doesn't make introductions
                ev = (f"You're home - BY FORCE: {sit_now} Your people are right here and terrified: {who}. Fear for them "
                      "first: plead, bargain, tell them to run or stay calm - whatever a desperate man would do.")
            conv.pending_events.append(("home", ev, 3))
            asyncio.create_task(self.b.run_turn(conv, reaction=True))
        kid = [x for x in people if x["ident"].d.get("flags", {}).get("kidnapper", {}).get("leader")]
        if kid:
            self.b.asi.toast("info", 6, f"Talk to {kid[0]['ident'].persona['first_name']} (focus + X) to negotiate - or not.")

    def react_all(self, j: Journey, people, reactions: dict):
        P = lambda h, *p: self.b.asi.prim(h, "journey", tuple(p))
        for x in people:
            friendly = "get along" in self.situation(j) or "walks in with" in self.situation(j)
            r = str(reactions.get(x["ident"].persona["first_name"], "welcome" if friendly else "stay")).lower()
            if x.get("child") and r not in ("stay", "welcome", "run_to_guide", "flee", "hide_with_kids", "sob"):
                r = "hide_with_kids"
            if not x.get("child") and r == "hide_with_kids":
                r = "stay"
            h = x["h"]
            log.info("[JOURNEY] %s reacts: %s", x["ident"].persona["name"], r)
            if r == "flee" or r == "hide_with_kids":
                P(h, "clear"); P(h, "flee", 40 if r == "hide_with_kids" else 120)
            elif r == "hands_up":
                P(h, "clear"); P(h, "hands_up", 60000)
            elif r == "cower":
                P(h, "clear"); P(h, "cower", 40000)
            elif r in ("draw_weapon", "attack"):
                P(h, "clear"); P(h, "draw"); P(h, "face", 20000)
                if r == "attack":
                    P(h, "block", 0); P(h, "combat")
            elif r in ("run_to_guide", "welcome") and not self.b.dead(j.guide):
                P(h, "clear"); P(h, "goto_player", 1.4, 2.0, f"t={j.guide}")
            elif r in ("beg", "sob", "kneel"):
                P(h, "clear")
                if r == "kneel":
                    P(h, "scenario", "WORLD_HUMAN_GRAVE_MOURNING_KNEEL", 30000)
                else:
                    P(h, "emote", 0, "KIT_EMOTE_REACTION_BEGMERCY_1" if r == "beg" else "KIT_EMOTE_REACTION_SOB_1", 2 if r == "beg" else 0)
            x["ident"].add_event(f"you reacted to the stranger: {r}", self.b.game.game_minutes_total, self.b.game.place(), 1)

    async def found_dead(self, j: Journey):
        body = next((x for x in j.spawned if x.get("role") == "person"), None)
        if self.b.dead(j.guide) or not body:
            return
        P = lambda h, *p: self.b.asi.prim(h, "journey", tuple(p))
        self.b.asi.send("actor", j.guide, 1)
        P(j.guide, "clear"); P(j.guide, "goto_coord", body["x"] + 0.8, body["y"], body["z"], 1.6)
        await asyncio.sleep(6)
        P(j.guide, "scenario", "WORLD_HUMAN_GRAVE_MOURNING_KNEEL", 40000)
        j.conv.pending_events.append(("found_dead", f"You found {j.plan.get('person', {}).get('name', 'him')} - DEAD. "
                                                    "Your own blood. React.", 3))
        self.b.asi.send("actor", j.guide, 0)
        await self.b.run_turn(j.conv, reaction=True)

    async def horse_found(self, j: Journey):
        horse = next((x for x in j.spawned if x.get("role") == "horse"), None)
        if self.b.dead(j.guide) or not horse:
            return
        j.conv.pending_events.append(("found_horse", f"There's your horse {j.plan.get('horse_name', '')}! React - and you can "
                                                     "get on it (mount).", 3))
        await self.b.run_turn(j.conv, reaction=True)

    def release_hostage(self, leader_conv):
        """The kidnapper leader lets the hostage go; his men stand down."""
        j = self.active or (self.done[-1] if self.done else None)
        if not j:
            return []
        prims = []
        for x in j.spawned:
            if x.get("hostage"):
                prims.append(("on", x["h"], "unhogtie"))
            elif x.get("kidnapper") and x["h"] != leader_conv.ped:
                prims += [("on", x["h"], "holster"), ("on", x["h"], "clear"), ("on", x["h"], "wander")]
        g = self.b.game
        world.add_deed(self.b.memory, g.place(), g.zone()["state"],
                       f"THE_STRANGER paid off kidnappers to free {j.plan.get('person', {}).get('name', 'a man')}", 1,
                       g.game_minutes_total, 0)
        if not self.b.dead(j.guide):
            j.conv.pending_events.append(("hostage_freed", f"{j.plan.get('person', {}).get('name', 'Your kin')} is FREE - "
                                                           "the kidnappers let him go.", 3))
        log.info("[JOURNEY] %s: hostage released by %s", j.id, leader_conv.name)
        return prims

    def far_from(self, j: Journey) -> bool:
        g = self.b.game
        return bool(j.dest and g.player) and math.hypot(g.player.get("x", 0) - j.dest[0], g.player.get("y", 0) - j.dest[1]) > 400

    def free(self, j: Journey):
        for x in j.spawned:
            self.b.asi.send("despawn", x["h"], "free")
        log.info("[JOURNEY] %s: you left - %d things handed back to the game", j.id, len(j.spawned))

    def cleanup(self):
        """Once you're far away from a finished place, the game may clean it up (nothing is deleted while you're near)."""
        j = self.active
        if not j or j.state not in ("done", "failed", "arrived"):
            return
        g = self.b.game
        if j.dest and g.player and math.hypot(g.player.get("x", 0) - j.dest[0], g.player.get("y", 0) - j.dest[1]) > 400:
            for x in j.spawned:
                self.b.asi.send("despawn", x["h"], "free")
            log.info("[JOURNEY] %s: you left - %d things handed back to the game", j.id, len(j.spawned))
            self.done.append(j)
            self.active = None
