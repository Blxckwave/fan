"""Per-NPC conversation state."""
from __future__ import annotations

import time


class Conversation:
    def __init__(self, ped: int, ident, cls: dict):
        self.ped = ped
        self.ident = ident
        self.cls = cls
        self.flags: dict = {}
        self.history: list[dict] = []
        self.marks: dict[str, float] = {}
        self.created = time.time()
        self.last_activity = time.time()
        self.far_since = 0.0
        self.gen = 0
        self.busy = False                 # a turn is being generated
        self.listening = False
        self.ending = False
        self.ended = False
        self.explicit_blocked = False
        self.last_user_explicit = False
        self.last_results: list[str] = []
        self.pending_events: list[tuple[str, str, int]] = []
        self.unanswered: list[str] = []
        self.after_actions: list[dict] = []
        self.last_reaction = 0.0
        self.turns = 0
        self.transcript: list[str] = []
        self.prev_ped: dict = {}
        self.prev_player: dict = {}
        self.missing_since = 0.0
        self.engaged_ok = False
        self.no_sex_because: list[str] = []
        self.targets: dict[str, int] = {}      # [P1]/[B1] tags from the last prompt -> ped handles

    @property
    def name(self) -> str:
        return self.ident.persona["name"] if self.ident else "Stranger"

    @property
    def companion(self) -> bool:
        return bool(self.flags.get("following") or self.flags.get("staying") or self.flags.get("journey")
                    or self.flags.get("player_aboard"))

    def mark(self, key: str):
        self.marks[key] = time.time()

    def seconds_since(self, key: str) -> float:
        t = self.marks.get(key)
        return time.time() - t if t else 1e9

    def touch(self):
        self.last_activity = time.time()
