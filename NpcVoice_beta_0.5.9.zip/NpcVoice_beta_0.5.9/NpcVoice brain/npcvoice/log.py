"""Rich logging: console + daily file + per-turn JSONL."""
from __future__ import annotations

import json
import logging
import sys
import threading
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path

log = logging.getLogger("npcvoice")
_turn_lock = threading.Lock()
_turn_path: Path | None = None


def setup(log_dir: Path, debug: bool = False):
    global _turn_path
    log_dir.mkdir(parents=True, exist_ok=True)
    log.setLevel(logging.DEBUG)
    fmt = logging.Formatter("%(asctime)s.%(msecs)03d %(levelname)-7s [%(threadName)s] %(message)s", "%H:%M:%S")
    fh = RotatingFileHandler(log_dir / "npc_brain.log", maxBytes=8_000_000, backupCount=5, encoding="utf-8")
    fh.setFormatter(fmt)
    fh.setLevel(logging.DEBUG)
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(fmt)
    ch.setLevel(logging.DEBUG if debug else logging.INFO)
    log.handlers[:] = [fh, ch]
    _turn_path = log_dir / "turns.jsonl"
    log.info("==== NpcVoice brain log started %s ====", time.strftime("%Y-%m-%d %H:%M:%S"))


def turn(record: dict):
    """Append one full conversation turn (context, prompt, raw reply, actions, timings)."""
    if not _turn_path:
        return
    record = {"ts": time.strftime("%Y-%m-%d %H:%M:%S"), **record}
    with _turn_lock:
        with open(_turn_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
