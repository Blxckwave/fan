"""Reporting the player to the law (0.3.2).

"Go on, report me to the sheriff" -> report_to_law. This is real, not just talk:
  - a lawman within the nearby scan (45 m): the person walks/runs up to him (you see it), they talk (voices +
    subtitles), then the lawman comes over and questions YOU - and he has the 'arrest' action, which reports the
    crime to the game's own law system (the town's law comes after you).
  - no lawman around: the person heads off to the sheriff. The report becomes a witnessed deed in this town, so
    the lawmen here question you the next time one is near (Director: heat >= 3).
Kill the person before they get there and the report never happens.
"""
from __future__ import annotations

import asyncio
import json
import math
import re
import time
import traceback

from . import world
from .log import log, turn as log_turn


def _d(a: dict, b: dict) -> float:
    try:
        return math.hypot(a["x"] - b["x"], a["y"] - b["y"])
    except (KeyError, TypeError):
        return 999.0


class LawDesk:
    def __init__(self, brain):
        self.b = brain
        self.running: dict[int, dict] = {}       # reporter ped -> report

    def lawmen(self, exclude=()) -> list[dict]:
        out = []
        for p in self.b.game.near_peds:
            h = int(p.get("h", 0))
            if not h or h in exclude or not p.get("alive", 1) or p.get("mission"):
                continue
            cls = self.b.peddb.classify(int(p.get("m", 0)), bool(p.get("male")))
            if cls.get("role") == "lawman" and not cls.get("story"):
                out.append(p)
        return sorted(out, key=lambda p: p.get("d", 99))

    def nearest_lawman(self, exclude=()) -> int:
        law = self.lawmen(exclude)
        return int(law[0]["h"]) if law else 0

    # called from Brain.execute
    def start(self, conv, args: dict, law: int):
        g = self.b.game
        what = str(args.get("what") or "").strip() or f"the stranger {args.get('crime', 'threatened me')}"
        crime = str(args.get("crime") or "").strip().lower() or "assault"
        rep = {"reporter": conv.ped, "ident": conv.ident, "name": conv.name, "law": law, "what": what, "crime": crime,
               "t": time.time(), "conv": conv}
        conv.ident.add_event(f"you reported him to the law: {what}", g.game_minutes_total, g.place(), 3)
        world.add_deed(self.b.memory, g.place(), g.zone()["state"],
                       f"{conv.name} reported THE_STRANGER to the law: {what}", 3, g.game_minutes_total, 1)
        if not law:
            log.info("[LAW] %s goes to report the player to the sheriff (no lawman nearby): %s", conv.name, what)
            self.b.asi.toast("warn", 6, f"{conv.name.split()[0]} is going to the sheriff about you.")
            return
        log.info("[LAW] %s runs to lawman %d to report the player: %s", conv.name, law, what)
        self.b.asi.toast("warn", 6, f"{conv.name.split()[0]} is going to the lawman about you!")
        self.running[conv.ped] = rep
        asyncio.create_task(self.run(rep))

    async def run(self, rep: dict):
        b, me, law = self.b, rep["reporter"], rep["law"]
        P = lambda h, *p: b.asi.prim(h, "report_to_law", tuple(p))
        try:
            conv = rep["conv"]
            t0 = time.time()
            while not conv.ended and time.time() - t0 < 15:      # let them finish their line; the talk ends by itself
                await asyncio.sleep(0.3)
            if b.dead(me):
                return
            b.asi.send("actor", me, 1)          # managed again: live position + nobody else may grab them
            P(me, "goto_player", 1.6, 2.0, f"t={law}")
            t0, last = time.time(), time.time()
            while time.time() - t0 < 60:
                await asyncio.sleep(0.4)
                await b.wait_unfrozen()
                if b.dead(me):
                    log.info("[LAW] %s died on the way - the report dies with them", rep["name"])
                    return
                if not self.alive(law):
                    log.info("[LAW] the lawman is gone - %s will tell the sheriff later", rep["name"])
                    b.asi.send("actor", me, 0)
                    return
                if _d(self.pos(me), self.pos(law)) < 3.2:
                    break
                if time.time() - last > 8:          # re-issue: their own AI may have wandered off
                    P(me, "goto_player", 1.6, 2.0, f"t={law}")
                    last = time.time()
            else:
                log.info("[LAW] %s never reached the lawman", rep["name"])
                b.asi.send("actor", me, 0)
                return
            # the two of them talk
            b.asi.send("actor", law, 1)
            P(me, "face", 20000, f"t={law}")
            P(law, "clear"); P(law, "face", 20000, f"t={me}")
            from .director import Cand
            p = next((x for x in b.game.near_peds if int(x.get("h", 0)) == law), {"h": law})
            lcand = Cand(law, p, b.peddb.classify(int(p.get("m", 0)), bool(p.get("male"))))
            law_ident = b.director.ident_for(lcand)
            lines = await self.dialogue(rep, law_ident)
            for ln in lines[:5]:
                while b.ptt_ped or (b.speaking and not b.speaking.get("scene")):
                    await asyncio.sleep(0.2)
                if b.dead(me) or not self.alive(law):
                    break
                who = law if str(ln.get("who", "")).upper().startswith("LAW") else me
                ident = law_ident if who == law else rep["ident"]
                if who == me and ln is lines[0]:
                    P(me, "emote", 1, "KIT_EMOTE_ACTION_POINT_1", 0)       # points at you
                dur = await b.say_line(who, ident, str(ln.get("say", "")), str(ln.get("emotion", "angry")))
                await asyncio.sleep(dur + 0.3)
            g = b.game
            law_ident.add_event(f"{rep['name']} reported the stranger to you: {rep['what']}", g.game_minutes_total, g.place(), 3)
            b.asi.send("actor", me, 0)
            b.asi.send("actor", law, 0)
            P(me, "face", 30000)                    # stays and watches you
            if b.dead(me) or not self.alive(law):
                return
            await b.director.law_questions_player(lcand, reason=f"{rep['name']} just reported you to him: {rep['what']} "
                                                                f"(crime: {rep['crime']})", force=True)
        except Exception as e:
            log.error("[LAW] report crashed: %s\n%s", e, traceback.format_exc())
        finally:
            self.running.pop(me, None)

    def pos(self, h):
        return self.b.director.pos(h)

    def alive(self, h):
        return self.b.director.alive(h)

    async def dialogue(self, rep: dict, law_ident) -> list[dict]:
        if self.b.cfg.fake_ai:
            return [{"who": "REPORTER", "say": f"Sheriff! That man there - {rep['what']}!", "emotion": "angry"},
                    {"who": "LAW", "say": "Easy now. I'll handle him.", "emotion": "calm"}]
        p = rep["ident"].persona
        user = (f"{rep['name']} ({p.get('job', '')}, {p.get('temperament', '')}) runs up to {law_ident.persona['name']}, "
                f"a lawman, and reports a rough stranger standing nearby: {rep['what']} (crime: {rep['crime']}).\n"
                "Write 2-4 short spoken lines between them (who = REPORTER or LAW). The reporter points the stranger out; "
                "the lawman takes it seriously and says he'll deal with him.\n"
                'JSON only: {"lines":[{"who":"REPORTER|LAW","say":"","emotion":"angry|fearful|calm|sad|surprised"}]}')
        raw, model, errs = await asyncio.to_thread(self.b.ai.chat, [
            {"role": "system", "content": "You write short, real spoken lines for people in 1899 (Red Dead Redemption 2). "
                                          "No narration."},
            {"role": "user", "content": user}], False, 300, 0.8)
        log_turn({"law_report": rep["name"], "raw": raw, "errors": errs})
        try:
            lines = json.loads(re.search(r"\{.*\}", raw or "", re.S).group(0)).get("lines") or []
            if lines:
                return lines
        except Exception:
            pass
        return [{"who": "REPORTER", "say": f"Sheriff! That man - {rep['what']}!", "emotion": "angry"},
                {"who": "LAW", "say": "Alright. Stay here, I'll have a word with him.", "emotion": "calm"}]
