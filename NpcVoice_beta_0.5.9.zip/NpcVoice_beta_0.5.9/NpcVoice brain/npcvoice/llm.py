"""STT / LLM / TTS providers with per-key failover (ported from voice_agent v3)."""
from __future__ import annotations

import re
import base64
import hashlib
import json
import os
import threading
import time
import zlib
from pathlib import Path

import requests

from .log import log

DEFAULT_BASES = {
    "openrouter": "https://openrouter.ai/api/v1",
    "minimax": "https://api.minimax.chat/v1",
    "qwen": "https://dashscope.aliyuncs.com/compatible-mode/v1",
    "chatanywhere": "https://api.chatanywhere.tech/v1",
}
ENV_KEYS = {"openrouter": "OPENROUTER_API_KEY", "minimax": "MINIMAX_API_KEY",
            "qwen": "DASHSCOPE_API_KEY", "chatanywhere": "CHATANYWHERE_API_KEY"}

STT_PRIORITY = [
    {"svc": "minimax", "model": "asr-1.0", "path": "/speech_to_text"},
    {"svc": "openrouter", "model": "openai/whisper-1", "path": "/audio/transcriptions"},
    {"svc": "openrouter", "model": "openai/whisper-large-v3-turbo", "path": "/audio/transcriptions"},
]
# 0.5.5: MythoMax-13B (4k context) lost the instructions in NpcVoice's ~3.8k-token prompt and narrated like a novel
# ("Elijah squints at him, his gut twisting...") with no actions. Uncensored models with a long context first;
# the old ones only as a last resort.
EXPLICIT_LLM_PRIORITY = [
    {"svc": "openrouter", "model": "nousresearch/hermes-3-llama-3.1-70b", "json": False},
    {"svc": "openrouter", "model": "sao10k/l3.3-euryale-70b", "json": False},
    {"svc": "openrouter", "model": "sao10k/l3-lunaris-8b", "json": False},
    {"svc": "openrouter", "model": "gryphe/mythomax-l2-13b", "json": False},
]
NORMAL_LLM_PRIORITY = [
    {"svc": "openrouter", "model": "openai/gpt-4o-mini", "json": True},
    {"svc": "chatanywhere", "model": "gpt-4o-mini", "json": True},
    {"svc": "qwen", "model": "qwen-plus", "json": True},
    {"svc": "qwen", "model": "qwen-max", "json": True},
]
TTS_MODEL = "speech-2.6-hd"
TTS_EMOTIONS = ["happy", "sad", "angry", "fearful", "disgusted", "surprised", "calm", "fluent", "whisper"]
# 0.5.8: "every sound is calm and the same" - the AI's own words for how a line sounds, mapped to what the voice can do
# (emotion, speed). "" = no emotion sent: the voice model reads the feeling from the words themselves, which beats
# forcing "calm"/"fluent" on a line that's moaned, sobbed or screamed (0.5.7 forced "fluent" on every unknown word).
EMOTION_STYLE = {
    "passionate": ("", 1.06), "heated": ("", 1.08), "breathless": ("surprised", 1.12), "moan": ("", 0.92),
    "moaning": ("", 0.92), "aroused": ("", 1.0), "lustful": ("", 0.97), "tender": ("happy", 0.93),
    "loving": ("happy", 0.94), "playful": ("happy", 1.04), "teasing": ("happy", 1.03), "flirty": ("happy", 1.0),
    "seductive": ("whisper", 0.94), "sultry": ("whisper", 0.94), "excited": ("happy", 1.1), "laughing": ("happy", 1.08),
    "scared": ("fearful", 1.12), "terrified": ("fearful", 1.18), "panicked": ("fearful", 1.2), "begging": ("fearful", 1.1),
    "pleading": ("fearful", 1.08), "desperate": ("fearful", 1.12), "nervous": ("fearful", 1.05),
    "furious": ("angry", 1.12), "rage": ("angry", 1.14), "enraged": ("angry", 1.14), "annoyed": ("angry", 1.0),
    "shouting": ("angry", 1.12), "screaming": ("fearful", 1.2), "grief": ("sad", 0.9), "grieving": ("sad", 0.9),
    "sobbing": ("sad", 0.9), "crying": ("sad", 0.92), "hurt": ("sad", 0.95), "pain": ("fearful", 1.1),
    "shocked": ("surprised", 1.08), "disgust": ("disgusted", 1.0), "drunk": ("happy", 0.88), "tired": ("calm", 0.9),
    "sleepy": ("whisper", 0.88), "proud": ("happy", 1.0), "sarcastic": ("disgusted", 1.0), "cold": ("calm", 0.97),
    "fearful": ("fearful", 1.1), "angry": ("angry", 1.08), "sad": ("sad", 0.93), "happy": ("happy", 1.02),
    "surprised": ("surprised", 1.05), "disgusted": ("disgusted", 1.0), "whisper": ("whisper", 0.95),
    "calm": ("calm", 1.0), "fluent": ("fluent", 1.0), "": ("", 1.0), "auto": ("", 1.0), "neutral": ("", 1.0),
}


def tts_style(emotion: str) -> tuple[str, float]:
    e = str(emotion or "").lower().strip()
    if e in EMOTION_STYLE:
        return EMOTION_STYLE[e]
    for k, v in EMOTION_STYLE.items():          # "very scared", "angry and hurt" -> the first word we know
        if k and re.search(rf"\b{k}\b", e):
            return v
    return "", 1.0


class ApiError(RuntimeError):
    pass


class KeyManager:
    def __init__(self, keys_file: Path):
        self._lock = threading.Lock()
        self.keys: dict[str, list[dict]] = {}
        self._bad_until: dict[tuple[str, str], float] = {}
        self._turn: dict[str, int] = {}               # round robin: who's next for each service
        self.on_problem = None                        # brain hook: (svc, '…tail', why, seconds) -> screen + log
        self.source = str(keys_file)
        self._load(keys_file)

    def _add(self, svc, key, base=None):
        svc, key = (svc or "").strip().lower(), (key or "").strip()
        if not svc or not key:
            return
        base = (base or DEFAULT_BASES.get(svc, "")).rstrip("/")
        if svc == "chatanywhere" and not base.endswith("/v1"):
            base += "/v1"
        lst = self.keys.setdefault(svc, [])
        if all(k["key"] != key for k in lst):
            lst.append({"key": key, "base": base})

    def _load(self, path: Path):
        if path and path.exists():
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and "keys" in data:
                data = data["keys"]
            if isinstance(data, dict):
                for svc, items in data.items():
                    for it in (items if isinstance(items, list) else [items]):
                        if isinstance(it, str):
                            self._add(svc, it)
                        elif isinstance(it, dict):
                            self._add(svc, it.get("key"), it.get("base"))
            elif isinstance(data, list):
                for e in data:
                    if isinstance(e, dict):
                        self._add(e.get("svc"), e.get("key"), e.get("base"))
        for svc, var in ENV_KEYS.items():
            if os.environ.get(var):
                self._add(svc, os.environ[var])

    def candidates(self, svc):
        now = time.time()
        with self._lock:
            return [k for k in self.keys.get(svc, []) if self._bad_until.get((svc, k["key"]), 0) <= now]

    @staticmethod
    def key_id(key: str) -> str:
        """A stable name for a key that isn't the key (for the logs and per-key bookkeeping)."""
        return hashlib.sha1((key or "").encode()).hexdigest()[:10]

    def rotate(self, svc) -> list[dict]:
        """The usable keys, starting with the next one in turn: the cost is spread over all of them."""
        c = self.candidates(svc)
        if not c:
            return c
        with self._lock:
            i = self._turn.get(svc, 0) % len(c)
            self._turn[svc] = i + 1
        return c[i:] + c[:i]

    def by_id(self, svc, kid: str) -> dict | None:
        return next((k for k in self.keys.get(svc, []) if self.key_id(k["key"]) == kid), None)

    def usable(self, svc, entry) -> bool:
        return self._bad_until.get((svc, entry["key"]), 0) <= time.time()

    def penalize(self, svc, key, seconds, why=""):
        with self._lock:
            self._bad_until[(svc, key)] = time.time() + seconds
        if self.on_problem:
            try:
                self.on_problem(svc, f"…{key[-4:]}", why, seconds)
            except Exception:
                pass
        log.warning("key %s …%s benched for %s s (%s)", svc, key[-4:],
                    "ever" if seconds == float("inf") else int(seconds), why)

    def summary(self):
        return ", ".join(f"{s}×{len(v)}" for s, v in self.keys.items()) or "NONE"


# 0.5.5: speech-to-text "hears" phantom phrases in silence/breath (a Korean TV news sign-off came out of your mic:
# "MBC 뉴스 이덕영입니다") - they're dropped before the NPC ever sees them
_PHANTOM = re.compile(r"(MBC|KBS|SBS)\s*뉴스[^.!?]*[.!?]?|시청해\s*주셔서[^.!?]*[.!?]?|구독[^.!?]*[.!?]?|"
                      r"thanks? (you )?for watching[.!]?|please subscribe[^.!?]*[.!?]?|subtitles? by[^.!?]*[.!?]?|"
                      r"ご視聴ありがとうございました|字幕[^。]*。?", re.I)
_FOREIGN = re.compile(r"[\u1100-\u11ff\u3040-\u30ff\u3130-\u318f\u3400-\u9fff\uac00-\ud7af]+")


def clean_transcript(text: str) -> str:
    t = _PHANTOM.sub(" ", text or "")
    if re.search(r"[A-Za-z]{2,}", t):          # an English sentence with stray Korean/Chinese/Japanese: drop the stray part
        t = _FOREIGN.sub(" ", t)
    t = re.sub(r"\s*\.\.\.\s*", " ... ", t)
    t = re.sub(r"\s+", " ", t).strip(" .")
    return t


class Providers:
    def __init__(self, km: KeyManager):
        self.km = km
        self._no_voice: set[tuple[str, str]] = set()      # (key id, voice) this account doesn't have
        self.http = requests.Session()

    def _headers(self, svc, key):
        h = {"Authorization": f"Bearer {key}"}
        if svc == "openrouter":
            h["HTTP-Referer"] = "https://npcvoice.local"
            h["X-Title"] = "NpcVoice"
        return h

    def _call(self, svc, path, *, json_body=None, files=None, data=None, timeout=40, entries=None) -> dict:
        entries = self.km.candidates(svc) if entries is None else entries
        if not entries:
            raise ApiError(f"no usable {svc} keys (missing or cooling down)")
        last = None
        for entry in entries:
            key = entry["key"]
            tag = f"{svc} …{key[-4:]}"
            t0 = time.time()
            try:
                r = self.http.post(entry["base"] + path, headers=self._headers(svc, key),
                                   json=json_body, files=files, data=data, timeout=timeout)
            except requests.RequestException as e:
                last = ApiError(f"{tag}: network error {e.__class__.__name__}: {str(e)[:120]}")
                log.warning("%s", last)
                continue
            dt = time.time() - t0
            log.debug("HTTP %s %s -> %s in %.2fs", tag, path, r.status_code, dt)
            if r.status_code == 200:
                try:
                    j = r.json()
                except ValueError:
                    last = ApiError(f"{tag}: non-JSON response")
                    continue
                br = j.get("base_resp") if isinstance(j, dict) else None
                code = (br or {}).get("status_code", 0)
                if code:
                    msg = (br or {}).get("status_msg", "")
                    if code == 1008:
                        self.km.penalize(svc, key, 120, "insufficient balance")
                    elif code in (1004, 2049):
                        self.km.penalize(svc, key, float("inf"), "auth failed")
                    elif code == 1002:
                        self.km.penalize(svc, key, 15, "rate limit")
                    last = ApiError(f"{tag}: error {code} {msg}")
                    if code in (1008, 1004, 2049, 1002, 1000, 1001):
                        continue
                    break
                return j
            body = r.text[:220].replace("\n", " ")
            last = ApiError(f"{tag}: HTTP {r.status_code}: {body}")
            if r.status_code in (401, 403):
                self.km.penalize(svc, key, float("inf"), f"HTTP {r.status_code}")
            elif r.status_code == 402:
                self.km.penalize(svc, key, 120, "HTTP 402")
            elif r.status_code == 429:
                self.km.penalize(svc, key, 15, "HTTP 429")
            elif r.status_code < 500:
                break
        raise last or ApiError(f"{svc}: failed")

    # ── STT ──
    def stt(self, wav: bytes) -> tuple[str | None, list[str]]:
        errors = []
        for conf in STT_PRIORITY:
            svc, model, path = conf["svc"], conf["model"], conf["path"]
            try:
                try:
                    j = self._call(svc, path, files={"file": ("audio.wav", wav, "audio/wav")},
                                   data={"model": model}, timeout=30)
                except ApiError:
                    if svc != "openrouter":
                        raise
                    b64 = base64.b64encode(wav).decode()
                    j = self._call(svc, path, json_body={"model": model,
                                   "input_audio": {"data": b64, "format": "wav"}}, timeout=30)
                data = j.get("data") if isinstance(j.get("data"), dict) else {}
                text = clean_transcript(j.get("text") or data.get("text") or "")
                if text:
                    log.info("[STT] ok via %s/%s", svc, model)
                    return text, errors
                errors.append(f"{model}: empty transcript")
            except ApiError as e:
                errors.append(f"{model}: {e}")
                log.warning("[STT] %s -> %s", model, e)
        return None, errors

    # ── LLM ──
    def chat(self, messages, explicit: bool, max_tokens=260, temperature=0.9) -> tuple[str, dict, list[str]]:
        errors = []
        for conf in (EXPLICIT_LLM_PRIORITY if explicit else NORMAL_LLM_PRIORITY):
            body = {"model": conf["model"], "messages": messages, "temperature": temperature,
                    "max_tokens": max_tokens}
            if conf.get("json"):
                body["response_format"] = {"type": "json_object"}
            try:
                try:
                    j = self._call(conf["svc"], "/chat/completions", json_body=body, timeout=45)
                except ApiError as e:
                    if "response_format" in body and "HTTP 400" in str(e):
                        body.pop("response_format")
                        j = self._call(conf["svc"], "/chat/completions", json_body=body, timeout=45)
                    else:
                        raise
                choices = j.get("choices") or []
                text = ((choices[0].get("message") or {}).get("content") or "") if choices else ""
                if text.strip():
                    return text, conf, errors
                errors.append(f"{conf['model']}: empty reply")
            except ApiError as e:
                errors.append(f"{conf['model']}: {e}")
                log.warning("[LLM] %s -> %s", conf["model"], e)
        return "", {}, errors

    # ── TTS ──
    def tts(self, text, voice_id, emotion, pitch=0, speed=1.0) -> tuple[bytes | None, str]:
        # any key, in turn; a key whose account doesn't have this voice (e.g. the China platform without the English
        # stock voices) passes the line on to the next key, and isn't asked for that voice again
        errs = []
        for e in self.km.rotate("minimax"):
            kid = self.km.key_id(e["key"])
            if (kid, voice_id) in self._no_voice:
                continue
            mp3, err = self._tts(text, voice_id, emotion, pitch, speed, [e])
            if mp3:
                return mp3, ""
            errs.append(err)
            if not account_problem(err):
                self._no_voice.add((kid, voice_id))
                log.warning("[TTS] MiniMax key …%s can't speak voice %s (%s) - the other keys will", e["key"][-4:],
                            voice_id, err[:120])
        return None, (errs[-1] if errs else "no usable minimax keys (missing or cooling down)")

    def _tts(self, text, voice_id, emotion, pitch, speed, entries) -> tuple[bytes | None, str]:
        emo, mult = tts_style(emotion)
        speed = max(0.6, min(1.6, float(speed or 1.0) * (mult if emotion not in TTS_EMOTIONS else 1.0)))
        vs = {"voice_id": voice_id, "speed": round(speed, 2), "vol": 1.0, "pitch": int(pitch)}
        if emo in TTS_EMOTIONS:
            vs["emotion"] = emo
        payload = {"model": TTS_MODEL, "text": text, "stream": False, "voice_setting": vs,
                   "audio_setting": {"sample_rate": 32000, "bitrate": 128000, "format": "mp3", "channel": 1}}
        try:
            j = self._call("minimax", "/t2a_v2", json_body=payload, timeout=50, entries=entries)
        except ApiError as e:
            return None, str(e)
        audio_hex = (j.get("data") or {}).get("audio")
        if not audio_hex:
            return None, f"no data.audio (base_resp={j.get('base_resp')})"
        try:
            return bytes.fromhex(audio_hex), ""
        except ValueError:
            return base64.b64decode(audio_hex), ""


ACCOUNT_PROBLEM = re.compile(r"insufficient|balance|error 100[1248]\b|error 2049|HTTP 40[123]|HTTP 429|rate limit|"
                             r"network error|no usable|out of service|no longer in your keys", re.I)


def account_problem(err: str) -> bool:
    """A problem with the key / account / network (try another key) - not with the voice itself."""
    return bool(ACCOUNT_PROBLEM.search(err or ""))


def stable_pick(seq, seed: str):
    return seq[zlib.crc32(seed.encode()) % len(seq)] if seq else None
