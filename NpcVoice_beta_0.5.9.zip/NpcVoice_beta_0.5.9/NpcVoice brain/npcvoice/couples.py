"""Couples (0.5.1): couples at home in bed, walking in on them, a couple who take you home, and the two-voice scene.

Everything here is between ADULTS who want it (the same rule as the rest of NpcVoice): a couple at home are married or
courting and in their own bed; a couple who invite the stranger home both said so themselves (agree_to_make_love /
agree_to_watch); nobody tied up, held at gunpoint, scared of you, a captive or a child is ever part of it, and either of
them can stop it at any moment (stop_making_love, a stop word, walking away).

1. HOUSE COUPLES. Walk up to a real house / shack / cabin / farmhouse from the database at night (or a lazy afternoon):
   sometimes a couple is in bed inside. The plugin finds the real bed (GET_CLOSEST_OBJECT_OF_TYPE over the game's bed
   models), the couple is spawned there (the woman with the man's skin tone), undressed (the Unstrip recipe) and the
   clip pair NpcHookups uses plays ON the bed, run by NpcVoice itself. They murmur to each other now and then.
2. WALKING IN. Within walk_in_metres, in their line of sight and standing up: they see you. The scene stops, they
   scream / curse / cover up, get dressed, the man may grab a gun. Crouched and out of sight: they don't notice.
   Both remember it (and the town may hear of it).
3. TAKE HIM HOME. A person whose partner is right there (on the same horse, arm in arm) can invite you home: they
   lead the way THEMSELVES (riding their own horse - one is brought if they have none - the partner behind), stop at a
   real house, dismount, wait at the door for you. Inside, the real bed is found and kept for whatever they decide.
4. THE TWO-VOICE SCENE. While a couple scene runs and a partner is watching (agree_to_watch, the husband's own
   fantasy) or both partners are in it, the two of them talk - each with their own voice - every so often.
"""
from __future__ import annotations

import asyncio
import json
import math
import random
import re
import time
import traceback

from .log import log

HOME_KINDS = ["house", "shack", "cabin", "farmhouse"]
INVITE_KINDS = ["house", "shack", "cabin", "farmhouse"]   # 0.5.8: a home, never a hotel / saloon
HORSES = ["a_c_horse_americanstandardbred_buckskin", "a_c_horse_americanpaint_overo", "a_c_horse_morgan_bay",
          "a_c_horse_kentuckysaddle_black"]
MALE_HOME = ["A_M_M_RANCHER_01", "A_M_M_ValFarmer_01", "A_M_M_RANCHERTRAVELERS_WARM_01", "A_M_M_FAMILYTRAVELERS_WARM_01"]
FEMALE_HOME = ["A_F_M_FAMILYTRAVELERS_WARM_01", "A_F_M_ValTownfolk_01", "A_F_M_RhdTownfolk_01", "A_F_M_StrTownfolk_01"]
ANIM_FLAGS = 3593            # looping, not interruptible, no collision, physics off, no gravity: held on the bed


class Scene:
    def __init__(self, sid, a, b, bed, kind):
        self.id, self.a, self.b, self.bed, self.kind = sid, a, b, bed, kind   # b == -1: the player
        self.started = time.time()
        self.next_talk = time.time() + random.uniform(8, 14)
        self.watcher = 0                  # a partner who watches (their own wish)
        self.on = False


class Couples:
    def __init__(self, brain):
        self.b = brain
        self.rng = random.Random()
        self.seq = 50000
        self.pending_spawn: dict[int, dict] = {}
        self.bed_waiters: dict[int, asyncio.Future] = {}
        self.checked: dict[str, float] = {}          # place name -> game minute it was checked
        self.house: list[dict] = []                  # live house couples
        self.scenes: dict[str, Scene] = {}
        self.trips: list[dict] = []                  # couples leading the player home

    # ── plumbing ──
    def owns(self, seq: int) -> bool:
        return seq in self.pending_spawn

    def next_seq(self) -> int:
        self.seq += 1
        return self.seq

    def on_bed(self, m: dict):
        fut = self.bed_waiters.pop(int(m.get("seq", 0)), None)
        if fut and not fut.done():
            fut.set_result(m)

    async def find_bed(self, x, y, z, r=25.0, timeout=4.0) -> dict | None:
        seq = self.next_seq()
        fut = asyncio.get_running_loop().create_future()
        self.bed_waiters[seq] = fut
        self.b.asi.send("find_bed", seq, round(x, 2), round(y, 2), round(z, 2), round(r, 1))
        try:
            m = await asyncio.wait_for(fut, timeout)
        except asyncio.TimeoutError:
            return None
        finally:
            self.bed_waiters.pop(seq, None)
        return m if m.get("ok") else None

    def spawn(self, model, x, y, z, h, flags, **info) -> asyncio.Future:
        seq = self.next_seq()
        fut = asyncio.get_running_loop().create_future()
        self.pending_spawn[seq] = dict(info, fut=fut, model=model)
        self.b.asi.send("spawn", seq, "ped", model, round(x, 2), round(y, 2), round(z, 2), round(h, 1), flags)
        return fut

    def on_spawned(self, m: dict):
        info = self.pending_spawn.pop(int(m.get("seq", 0)), None)
        if info and not info["fut"].done():
            info["fut"].set_result(int(m.get("h", 0)))

    async def spawned(self, fut, timeout=10.0) -> int:
        try:
            return await asyncio.wait_for(fut, timeout)
        except asyncio.TimeoutError:
            return 0

    def bed_point(self, bed: dict) -> tuple:
        # a bed OBJECT stands on the floor (+ mattress height); a sleeping SPOT is already where a sleeper lies; the
        # floor fallback is the floor (a blanket is laid there)
        off = float(self.b.cfg.bed_z_offset) if bed.get("src", "object") == "object" else 0.0
        return (float(bed["x"]), float(bed["y"]), float(bed["z"]) + off, float(bed.get("hd", 0)))

    def start_scene(self, a: int, b: int, bed: dict | None, kind: str) -> Scene:
        """a + b (b = -1: the player) on the bed, or - no bed - right where a stands."""
        if bed:
            x, y, z, h = self.bed_point(bed)
        else:
            pa = self.b.game.ped(a) or self.b.game.player
            x, y, z, h = float(pa.get("x", 0)), float(pa.get("y", 0)), float(pa.get("z", 0)), 0.0
        sid = f"C{a}"
        sc = Scene(sid, a, b, bed, kind)
        self.scenes[sid] = sc
        caps = set((self.b.asi_info or {}).get("caps") or [])
        extra = ["pos=1"] if "nh_pos" in caps else []       # 0.5.8: NpcHookups' way - attached, not standing side by side
        self.b.asi.send("couple", self.b.asi.next(a, "couple", "couple"), a, b, round(x, 2), round(y, 2), round(z, 2),
                        round(h, 1), ANIM_FLAGS, *extra)
        log.info("[COUPLES] scene %s: %d + %s (%s) at %.1f %.1f %.1f", sid, a, "the player" if b == -1 else b, kind, x, y, z)
        return sc

    def onlookers(self, a: int, b: int = 0) -> int:
        """0.5.8: how many other adults could see a love scene right here (in the saloon, on the street...)."""
        g = self.b.game
        me = g.ped(a) or {}
        if "x" not in me:
            return 0
        skip = {int(a), int(b or 0)} | {sc.watcher for sc in self.scenes.values() if sc.watcher}
        for c in self.b.convs.values():                      # the people this is with (partner, watcher) aren't strangers
            if not c.ended and (c.flags.get("consent_watch") or c.flags.get("consent_love") or c.flags.get("open_couple")):
                skip.add(c.ped)
        n = 0
        for p in g.near_peds or []:
            h = int(p.get("h", 0))
            if h in skip or not p.get("alive", 1):
                continue
            d = math.hypot(float(p.get("x", 0)) - float(me["x"]), float(p.get("y", 0)) - float(me["y"]))
            dz = abs(float(p.get("z", 0)) - float(me.get("z", 0)))
            if dz > 2.6:
                continue                                     # another floor (the room upstairs)
            if d < 6 or (d < 15 and (p.get("los") or p.get("elos"))):
                n += 1
        return n

    def stop_scene(self, sc: Scene, why: str):
        self.scenes.pop(sc.id, None)
        self.b.asi.send("couple_stop", self.b.asi.next(sc.a, "couple", "couple_stop"), sc.a)
        log.info("[COUPLES] scene %s over: %s", sc.id, why)

    def scene_of(self, ped: int) -> Scene | None:
        return next((s for s in self.scenes.values() if ped in (s.a, s.b, s.watcher)), None)

    # ── 1. couples at home ─────────────────────────────────────────────────────────────────────────────────
    def couple_hour(self) -> float:
        hr = int(self.b.game.world.get("hr", 12))
        return 1.0 if (hr >= 20 or hr < 6) else 0.5 if 12 <= hr < 17 else 0.25

    async def tick(self):
        try:
            await self.house_tick()
            self.walk_in_tick()
            await self.trip_tick()
            await self.talk_tick()
        except Exception:
            log.error("[COUPLES] tick crashed:\n%s", traceback.format_exc())

    async def house_tick(self):
        b, g = self.b, self.b.game
        if not b.cfg.house_couples or not b.asi.up or not g.player or g.world.get("mission"):
            return
        for hc in list(self.house):           # you left: hand them back to the game
            if math.hypot(g.player.get("x", 0) - hc["x"], g.player.get("y", 0) - hc["y"]) > 120:
                for h in (hc["a"], hc["b"]):
                    b.asi.send("actor", h, 0)
                    b.asi.send("despawn", h, "free")
                sc = self.scene_of(hc["a"])
                if sc:
                    self.stop_scene(sc, "the stranger left")
                self.house.remove(hc)
        if any(hc["place"].get("kind") != "quiet spot outdoors" for hc in self.house) or not b.db.ok:
            return
        if getattr(b.cfg, "households", False):
            return                        # every home has its own couple now (household.py)
        chance = self.couple_hour() * float(b.cfg.house_couple_chance)
        if chance <= 0:
            return
        near = b.db.places_near(g.player.get("x", 0), g.player.get("y", 0), HOME_KINDS + ["hotel", "brothel"], 0, 70)
        jn = b.journeys.active
        for pl in near[:3]:
            if jn and jn.kind == "couple" and jn.dest and math.hypot(pl["x"] - jn.dest[0], pl["y"] - jn.dest[1]) < 50:
                continue                  # the couple you were sent to lives there - not a second random one
            day = int(g.game_minutes_total // 1440)
            key = f"{pl['name']}|{day}"
            if key in self.checked:
                continue
            self.checked[key] = g.game_minutes_total
            if self.rng.random() > chance:
                log.info("[COUPLES] %s (%s): nobody in bed right now", pl["name"], pl["kind"])
                continue
            await self.make_house_couple(pl)
            return

    async def make_house_couple(self, pl: dict):
        b, g = self.b, self.b.game
        bed = await self.find_bed(pl["x"], pl["y"], pl["z"], 25.0)
        if not bed:
            log.info("[COUPLES] %s: the plugin didn't answer - no couple", pl["name"])
            return
        x, y, z, h = self.bed_point(bed)
        if bed.get("src") == "floor":
            self.b.asi.send("spawn", self.next_seq(), "obj", "p_bedrollopen01x", round(x, 2), round(y, 2), round(z, 2),
                            round(h, 1), "exact")
        man_m, woman_m = self.rng.choice(MALE_HOME), self.rng.choice(FEMALE_HOME)
        ha = await self.spawned(self.spawn(man_m, x + 0.4, y, z + 0.4, h, "bed"))
        if not ha:
            return
        hb = await self.spawned(self.spawn(woman_m, x - 0.4, y, z + 0.4, h, f"like={ha}"))
        if not hb:
            b.asi.send("despawn", ha, "delete")
            return
        for hh in (ha, hb):
            b.asi.send("actor", hh, 1)
        ia, ib = self.make_idents(ha, man_m, hb, woman_m, pl)
        b.asi.prim(ha, "couple", ("undress",))
        b.asi.prim(hb, "couple", ("undress",))
        await asyncio.sleep(0.6)
        sc = self.start_scene(ha, hb, bed, "house")
        hc = {"a": ha, "b": hb, "ia": ia, "ib": ib, "x": x, "y": y, "z": z, "place": pl, "scene": sc.id,
              "caught": False, "t": time.time()}
        self.house.append(hc)
        log.info("[COUPLES] %s and %s in bed at %s (%s, %s)", ia.persona["name"], ib.persona["name"], pl["name"],
                 pl["kind"], bed.get("model"))

    def make_idents(self, ha, man_m, hb, woman_m, pl):
        from .hashing import joaat
        b, g = self.b, self.b.game
        ca = b.peddb.classify(joaat(man_m), True)
        cb = b.peddb.classify(joaat(woman_m), False)
        ca["known"] = cb["known"] = True
        ca["child"] = cb["child"] = False
        ia = b.memory.create(joaat(man_m), 0, ca, g.place(), g.game_minutes_total)
        ib = b.memory.create(joaat(woman_m), 0, cb, g.place(), g.game_minutes_total)
        sur = ia.persona["name"].split()[-1]
        ib.persona["name"] = f"{ib.persona['first_name']} {sur}"
        married = self.rng.random() < 0.8
        for me, other, rel in ((ia, ib, "your wife" if married else "your sweetheart"),
                               (ib, ia, "your husband" if married else "your sweetheart")):
            p = me.persona
            p["age"] = max(20, p.get("age", 30))
            p["family"] = f"{'married to' if married else 'courting'} {other.persona['name']}"
            p["role_note"] = (f"it's your home ({pl['kind']}); you were in bed making love with {other.persona['first_name']} "
                              f"({rel.replace('your ', '')}) when the stranger turned up")
            me.d.setdefault("relations", {})[f"id:{other.id}"] = {"rel": rel}
            me.add_event(f"you made love with {other.persona['first_name']} at home", g.game_minutes_total, g.place(), 2)
            me.dirty()
        b.handle_ident[ha] = ia.id
        b.handle_ident[hb] = ib.id
        return ia, ib

    async def outdoor(self, ha, hb, ia, ib, x, y, z):
        """Two adults who wanted each other (a director 'lovers' scene) sneak off and do it right there - out of sight
        they think. Walk in on them like a house couple."""
        b = self.b
        for hh in (ha, hb):
            b.asi.send("actor", hh, 1)
            b.asi.prim(hh, "couple", ("undress",))
        await asyncio.sleep(0.6)
        bed = {"x": x, "y": y, "z": z - float(b.cfg.bed_z_offset), "hd": self.rng.uniform(0, 360)}
        sc = self.start_scene(ha, hb, bed, "outdoor")
        self.house.append({"a": ha, "b": hb, "ia": ia, "ib": ib, "x": x, "y": y, "z": z,
                           "place": {"name": "a quiet spot", "kind": "quiet spot outdoors"}, "scene": sc.id,
                           "caught": False, "t": time.time()})
        for me, other in ((ia, ib), (ib, ia)):
            me.add_event(f"you sneaked off with {other.persona['first_name']} to make love", b.game.game_minutes_total,
                         b.game.place(), 2)
        log.info("[COUPLES] %s and %s sneak off together (outdoors)", ia.persona["name"], ib.persona["name"])

    # ── 2. walking in on them ─────────────────────────────────────────────────────────────────────────────
    def walk_in_tick(self):
        b, g = self.b, self.b.game
        pl = g.player
        for hc in self.house:
            if hc["caught"]:
                continue
            pa, pb = g.ped(hc["a"]), g.ped(hc["b"])
            if not pa or not pb:
                continue
            d = min(pa.get("d", 99), pb.get("d", 99))
            seen = pa.get("los") or pb.get("los")
            if d > float(b.cfg.walk_in_m):
                continue
            if pl.get("crouch") and (not seen or d > 2.5):
                continue                # sneaking, out of sight: they carry on
            if not seen and d > 2.0:
                continue
            hc["caught"] = True
            asyncio.create_task(self.caught(hc))

    async def caught(self, hc: dict):
        b, g = self.b, self.b.game
        sc = self.scenes.get(hc["scene"])
        if sc:
            self.stop_scene(sc, "the stranger walked in on them")
        ia, ib = hc["ia"], hc["ib"]
        log.info("[COUPLES] the stranger walked in on %s and %s", ia.persona["name"], ib.persona["name"])
        for ident in (ia, ib):
            ident.add_event("the stranger walked in on you in bed", g.game_minutes_total, g.place(), 3)
            ident.adjust({"anger": 25, "fear": 15, "trust": -20}, "walked in on")
        brave = float(ia.persona.get("bravery", 0.5))
        # the first seconds, before any AI: she covers up and screams, he jumps up
        b.asi.prim(hc["b"], "caught", ("clear",))
        b.asi.prim(hc["b"], "caught", ("pain", 2))
        b.asi.prim(hc["b"], "caught", ("cower", 15000))
        b.asi.prim(hc["a"], "caught", ("clear",))
        b.asi.prim(hc["a"], "caught", ("face", 15000))
        lines = await self.caught_lines(hc, brave)
        for who, text, emo in lines:
            h, ident = (hc["a"], ia) if who == "a" else (hc["b"], ib)
            dur = await b.say_line(h, ident, text, emo)
            await asyncio.sleep(dur + 0.2)
        for h in (hc["a"], hc["b"]):
            b.asi.prim(h, "caught", ("dress",))
        if brave >= 0.6:
            b.asi.prim(hc["a"], "caught", ("give_weapon", "WEAPON_REVOLVER_CATTLEMAN"))
            b.asi.prim(hc["a"], "caught", ("face", 20000))
        from . import world
        world.add_deed(b.memory, g.place(), g.zone()["state"],
                       f"THE_STRANGER barged into {ia.persona['name']}'s bedroom", 1, g.game_minutes_total, 2)
        b.asi.toast("info", 6, f"Talk to {ia.persona['first_name']} or {ib.persona['first_name']} (focus + X) - or get out.")

    async def caught_lines(self, hc, brave) -> list[tuple[str, str, str]]:
        ia, ib = hc["ia"], hc["ib"]
        if self.b.cfg.fake_ai:
            return [("b", "Oh my Lord! Get out! GET OUT!", "fearful"),
                    ("a", "What in the hell are you doing in my house?!", "angry")]
        user = (f"A man ({ia.persona['name']}, {ia.persona['temperament']}, bravery {brave:.1f}) and a woman "
                f"({ib.persona['name']}, {ib.persona['temperament']}) were in bed together in their own home "
                f"({hc['place']['kind']}) in 1899, naked, when a rough stranger walked in on them. Write their first 2-3 "
                "spoken lines: shock, screaming, covering up, cursing, ordering him out (or a brave man reaching for his gun). "
                'JSON only: {"lines":[{"who":"a|b","say":"","emotion":"angry|fearful|surprised|disgusted"}]}')
        raw, _, _ = await asyncio.to_thread(self.b.ai.chat, [{"role": "system", "content": "You write short, raw spoken "
                                                                                           "lines for a western game."},
                                                             {"role": "user", "content": user}], False, 220, 0.9)
        try:
            j = json.loads(re.search(r"\{.*\}", raw or "", re.S).group(0))
            return [(str(x.get("who", "a"))[:1].lower(), str(x.get("say", ""))[:200], str(x.get("emotion", "angry")))
                    for x in j.get("lines", [])[:3] if x.get("say")]
        except Exception:
            return [("b", "Get out! Get out of here!", "fearful"), ("a", "Who the hell are you?!", "angry")]

    # ── 3. a couple takes you home ────────────────────────────────────────────────────────────────────────
    def lead_home(self, conv, partner: int, why: str = ""):
        b, g = self.b, self.b.game
        me = g.ped(conv.ped) or {}
        x0, y0 = float(me.get("x", g.player.get("x", 0))), float(me.get("y", g.player.get("y", 0)))
        place = b.db.pick_destination(x0, y0, why + " " + " ".join(conv.transcript[-3:]), INVITE_KINDS, 150, 700, self.rng) \
            if b.db.ok else None
        if not place:
            conv.last_results.append("invite_home: no house near enough - say so, or take him somewhere else")
            return
        dx, dy, dz = place["x"], place["y"], place["z"]
        door = min((d for d in b.db._load("doors", []) if math.hypot(d["x"] - dx, d["y"] - dy) < 45), default=None,
                   key=lambda d: math.hypot(d["x"] - dx, d["y"] - dy))
        if door:
            dx, dy, dz = door["x"], door["y"], door["z"]
        trip = {"conv": conv, "guide": conv.ped, "partner": partner, "dest": (dx, dy, dz), "place": place, "state": "mount",
                "t": time.time(), "horse": 0, "bed": None}
        self.trips.append(trip)
        conv.flags["journey"] = "home"
        conv.flags["following"] = False
        dist = math.hypot(dx - g.player.get("x", 0), dy - g.player.get("y", 0))
        b.asi.send("route", round(dx, 1), round(dy, 1), round(dz, 1), f"{conv.ident.persona['first_name']}'s place"[:40])
        b.asi.toast("ok", 7, f"{conv.name} is taking you home ({place['kind']}, {dist:.0f} m) - they lead the way, follow them.")
        conv.last_results.append(f"invite_home: you lead him to your {place['kind']} ({dist:.0f} m) - you go first"
                                 + (", your partner with you" if partner else ""))
        conv.ident.add_event(f"you took the stranger home to your {place['kind']}", g.game_minutes_total, g.place(), 2)
        if partner:
            b.asi.send("actor", partner, 1)
        asyncio.create_task(self.get_mounted(trip))
        log.info("[COUPLES] %s leads the player home to %s (%s) %.0f m, partner %s", conv.name, place["name"],
                 place["kind"], dist, partner or "-")

    async def get_mounted(self, trip):
        b, g = self.b, self.b.game
        guide, partner = trip["guide"], trip["partner"]
        gp = g.ped(guide) or {}
        if not gp.get("mnt"):
            # a horse of their own nearby? else one is brought (their horse, tied up close by)
            b.asi.prim(guide, "invite_home", ("clear",))
            b.asi.prim(guide, "invite_home", ("mount_near",))
            await asyncio.sleep(1.5)
            if trip.get("mount_failed"):
                x, y, z = float(gp.get("x", 0)) + 3, float(gp.get("y", 0)) + 1, float(gp.get("z", 0))
                horse = await self.spawned(self.spawn(self.rng.choice(HORSES), x, y, z, 0, "ground"))
                trip["horse"] = horse
                await asyncio.sleep(0.5)
                b.asi.prim(guide, "invite_home", ("mount_near",))
            await asyncio.sleep(8)
        if partner and not self.b.dead(partner):
            b.asi.prim(partner, "invite_home", ("clear",))
            b.asi.prim(partner, "invite_home", ("ride_behind", f"t={guide}"))
            await asyncio.sleep(7)
        trip["state"] = "ride"
        x, y, z = trip["dest"]
        b.asi.prim(guide, "invite_home", ("goto_any", round(x, 2), round(y, 2), round(z, 2), 2.0))

    def on_act_result(self, action: str, prim: str, ok: bool, ped: int):
        if action == "invite_home" and prim == "mount_near" and not ok:
            for t in self.trips:
                if t["guide"] == ped:
                    t["mount_failed"] = True

    async def trip_tick(self):
        b, g = self.b, self.b.game
        for t in list(self.trips):
            conv = t["conv"]
            if b.dead(t["guide"]) or conv.ended and not conv.companion:
                self.trips.remove(t)
                b.asi.send("route_clear")
                continue
            gp = g.ped(t["guide"]) or {}
            x, y, z = t["dest"]
            dg = math.hypot(float(gp.get("x", 0)) - x, float(gp.get("y", 0)) - y) if gp else 999
            dp = math.hypot(g.player.get("x", 0) - x, g.player.get("y", 0) - y)
            if t["state"] == "ride":
                if gp and gp.get("d", 0) > 60 and time.time() - t.get("waited", 0) > 20:
                    t["waited"] = time.time()            # don't lose him: wait up, then go on
                    b.asi.prim(t["guide"], "invite_home", ("face", 6000))
                    await asyncio.sleep(5)
                    b.asi.prim(t["guide"], "invite_home", ("goto_any", round(x, 2), round(y, 2), round(z, 2), 2.0))
                if dg < 14:
                    t["state"] = "door"
                    for h in (t["guide"], t["partner"]):
                        if h and not b.dead(h):
                            b.asi.prim(h, "invite_home", ("dismount",))
                    await asyncio.sleep(3)
                    for h in (t["guide"], t["partner"]):
                        if h and not b.dead(h):
                            b.asi.prim(h, "invite_home", ("goto_coord", round(x, 2), round(y, 2), round(z, 2), 1.0))
                    log.info("[COUPLES] %s is at the door, waiting for the player", conv.name)
            elif t["state"] == "door" and dp < 10:
                t["state"] = "home"
                b.asi.send("route_clear")
                bed = await self.find_bed(t["place"]["x"], t["place"]["y"], t["place"]["z"], 25.0)
                t["bed"] = bed
                conv.flags["bed"] = bed
                conv.flags["journey"] = False
                conv.flags["following"] = True
                inside = "There's a bed inside." if bed else "There's no proper bed - a blanket on the floor will do."
                conv.pending_events.append(("home", f"You're home with him{' and your partner' if t['partner'] else ''}. "
                                                    f"{inside} You lead him in. What happens now is up to you two (or you "
                                                    "three) - only what each of you wants.", 3))
                asyncio.create_task(b.run_turn(conv, reaction=True))
                pc = b.convs.get(t["partner"]) if t["partner"] else None
                if pc:
                    pc.flags["bed"] = bed
                self.trips.remove(t)

    # ── love scene through NpcVoice's own runner ──
    def make_love(self, conv, other: int) -> bool:
        """Called for make_love (both said yes). On a known bed - or wherever they are when NpcHookups is missing.
        0.5.5: if she's already in it with her husband and now wants YOU, the scene switches to you and he watches
        (when that's his kink - an open couple); otherwise he steps back."""
        bed = conv.flags.get("bed")
        oc = self.b.convs.get(other) if other else None
        if not bed and oc:
            bed = oc.flags.get("bed")
        b2 = other or -1
        cur = self.scene_of(conv.ped)
        old_partner = 0
        if cur:
            old_partner = cur.b if cur.a == conv.ped else cur.a
            if old_partner == b2:
                return True                       # already doing it with them
            bed = bed or cur.bed
            self.scenes.pop(cur.id, None)
        else:
            self.b.asi.prim(conv.ped, "make_love", ("undress",))
        if other:
            self.b.asi.prim(other, "make_love", ("undress",))
        sc = self.start_scene(conv.ped, b2, bed, "invited")
        if old_partner and old_partner != -1:
            pid = self.b.handle_ident.get(old_partner)
            pi = self.b.memory.ids.get(pid) if pid else None
            self.b.asi.prim(old_partner, "make_love", ("clear",))
            if pi and (pi.d.get("flags", {}).get("open_couple") or "watch" in pi.persona.get("sexuality", "")):
                sc.watcher = old_partner
                self.b.asi.prim(old_partner, "make_love", ("scenario", "WORLD_HUMAN_SIT_GROUND", -1))
                pi.add_event("you watched your wife with the stranger - your own wish", self.b.game.game_minutes_total,
                             self.b.game.place(), 3)
            else:
                self.b.asi.prim(old_partner, "make_love", ("dress",))
                self.b.asi.prim(old_partner, "make_love", ("face", 20000))
        # the partner who wanted to watch
        for c in self.b.convs.values():
            if c is not conv and c.ped != other and not c.ended and c.flags.get("consent_watch"):
                sc.watcher = c.ped
                c.flags["watching"] = True
        return True

    def stop_for(self, ped: int, why: str):
        sc = self.scene_of(ped)
        if sc:
            self.stop_scene(sc, why)
            for h in (sc.a, sc.b):
                if h and h != -1:
                    self.b.asi.prim(h, "make_love", ("dress",))

    # ── 4. the two voices ──────────────────────────────────────────────────────────────────────────────────
    async def talk_tick(self):
        b = self.b
        now = time.time()
        for sc in list(self.scenes.values()):
            if now < sc.next_talk or b.ptt_ped or b.speaking or b.frozen:
                continue
            sc.next_talk = now + random.uniform(8, 14)      # 0.5.5: they're never quiet for long
            speakers = [h for h in (sc.a, sc.b, sc.watcher) if h and h != -1 and not b.dead(h)]
            if not speakers:
                continue
            gp = b.game.ped(speakers[0]) or {}
            if gp.get("d", 99) > 18:
                continue
            idents = [(h, b.memory.ids.get(b.handle_ident.get(h, ""))) for h in speakers]
            idents = [(h, i) for h, i in idents if i is not None]
            if not idents or any(i.persona.get("child") for _, i in idents):
                continue
            lines = await self.scene_lines(sc, idents)
            for h, ident, text, emo in lines:
                if b.ptt_ped or sc.id not in self.scenes:
                    break
                dur = await b.say_line(h, ident, text, emo, gesture=False)
                await asyncio.sleep(dur + 0.4)

    async def scene_lines(self, sc: Scene, idents) -> list:
        b = self.b
        names = {h: i.persona["first_name"] for h, i in idents}
        if b.cfg.fake_ai:
            return [(h, i, "Mmm... don't stop.", "whisper") for h, i in idents[:2]]
        who = "; ".join(f"{i.persona['first_name']} ({i.persona['sex']}, {i.persona['age']}, {i.persona['temperament']})"
                        + (" - watching, it's their own fantasy" if h == sc.watcher else "") for h, i in idents)
        partner_of_player = sc.b == -1
        setting = ("a married couple in bed in their own home, who don't know anyone is near" if sc.kind == "house" else
                   "adults who all chose this: making love" + (" with the stranger" if partner_of_player else "") +
                   (", while a partner watches because they want to" if sc.watcher else ""))
        user = (f"1899, the American frontier. {setting}. Speakers: {who}. Write 1-3 short intimate spoken lines between "
                f"them - moans that rise and fall (slower, faster, 'mmm', 'ahh', 'don't stop'), whispers, teasing, what "
                f"they feel - each by one of: {', '.join(names.values())}. They are "
                "consenting adults and they talk to each other (and to the stranger if he's with them). "
                'JSON only: {"lines":[{"who":"<first name>","say":"","emotion":"passionate|breathless|moan|tender|'
                'playful|seductive|whisper"}]} - the emotion is how the line SOUNDS (heated = passionate/breathless/moan).')
        raw, _, _ = await asyncio.to_thread(b.ai.chat, [{"role": "system", "content": "You write short spoken lines for "
                                                                                      "adult characters in a mature western game."},
                                                        {"role": "user", "content": user}], True, 220, 0.95)
        out = []
        try:
            j = json.loads(re.search(r"\{.*\}", raw or "", re.S).group(0))
            by = {v.lower(): (h, i) for (h, i), v in zip(idents, names.values())}
            for x in j.get("lines", [])[:3]:
                hi = by.get(str(x.get("who", "")).split()[0].lower() if x.get("who") else "")
                if hi and x.get("say"):
                    out.append((hi[0], hi[1], str(x["say"])[:220], str(x.get("emotion", "whisper"))))
        except Exception:
            pass
        return out
