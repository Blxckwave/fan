"""Households: every home on the map has its own couple, living a whole day of their own.

WHO
- Every lived-in house / shack / cabin / farmhouse in the database gets ONE couple the first time you come near it,
  kept for good (households.json + their memories in npc_memory): the same two people every visit, who remember you.
  Locals of the region (Lagras/Lakay folk in the bayou, Valentine folk around Valentine...), adults, married or courting
  for a number of years, with their own temperaments, how they met, a shared memory, and their own way together
  (tender, playful, one takes the lead, they take turns...) and what each of them secretly fancies.

THEIR DAY (25-30 things each, seeded per house and weekday - no two houses and no two days alike)
- wake up in bed, wash up, coffee; one cooks breakfast while the other feeds the chickens / pumps water;
  breakfast together at their own table; morning chores (sweeping, laundry on the washboard, dishes, windows, sewing,
  knitting, writing a letter / chopping and sawing wood, mending, hay, the pigs, whittling, cleaning the rifle...);
  lunch together; afternoon chores and a rest (reading, a smoke, coffee); one cooks supper; supper together;
  dishes; an evening on the porch (music, a drink, a smoke, knitting); getting close as it gets dark;
- THE NIGHT, from dark to dawn, in their own bed: they make love in sessions, change positions every minute or two,
  talk the whole time - sweet talk, teasing, what they want, stories of their fantasies and their past - catch their
  breath in between (pillow talk, a drink of water) and start again, until dawn; then they sleep until morning.
- Some days: he works away (the mill, the docks, the store), Sunday church, a lazy afternoon or a morning in bed.
- With the updated NpcVoice.asi they use their REAL furniture: the game's own scenario points inside the house (the
  chairs at their table, the stove, the wash basin, the porch bench, the woodpile, their bed). Without it they do
  the same chores in place around the house.
- Only near you (the game only has the people near you): within household_metres they're spawned at whatever their
  day says they're doing right now; you leave, they're taken away; the day goes on without you (their journal knows).

RULES (as everywhere in NpcVoice)
- Adults (21+), a couple who chose each other, at home, alone. Nothing happens while either is hurt, tied up, lassoed,
  held at gunpoint, fleeing, fighting or scared of you; it stops the moment any of that happens.
- Walk in on them standing up and in sight: they stop, cover up, are furious (the 0.5.1 walk-in). Crouched and out of
  sight they don't notice you.
"""
from __future__ import annotations

import asyncio
import json
import math
import os
import random
import re
import time
import traceback
from pathlib import Path

from .hashing import joaat
from .log import log

HOME_KINDS = ["house", "shack", "cabin", "farmhouse", "mansion"]
# a bed near one of these is not a home (hotel rooms, the doctor's cot, the cells, the girls upstairs...)
NOT_HOME_NEAR = ["saloon", "hotel", "brothel", "doctor", "jail", "sheriff office", "police station", "bank", "church",
                 "general store", "train station", "station", "theater", "barber", "tailor", "gunsmith", "fort", "camp",
                 "gambling hall", "photo studio", "stable", "fence", "school"]
BED_RE = re.compile(r"PROP_HUMAN_SLEEP_BED|PROP_PLAYER_SLEEP_BED")
ANIM_FLAGS = 3593

# ── who lives where ─────────────────────────────────────────────────────────────────────────────────────────────────
TOWN_CODES = {
    "lakay": ["lag"], "lagras": ["lag"], "valentine": ["val"], "rhodes": ["rhd"], "braithwaite manor": ["rhd"],
    "strawberry": ["str"], "saint denis": ["low", "mid"], "annesburg": ["asb"], "van horn": ["vht"],
    "blackwater": ["blw"], "emerald ranch": ["val"], "butcher creek": ["btc"], "aguasdulces": ["gua"],
    "armadillo": ["arm"], "tumbleweed": ["tum"], "wapiti": ["wap"], "macfarlane's ranch": ["arm", "tum"],
    "pronghorn ranch": ["val"], "beecher's hope": ["blw"], "wallace station": ["val"], "doverhill": ["asb"],
    "cornwall kerosene": ["asb"], "colter": ["val"],
}
MALE_FALLBACK = ["A_M_M_RANCHER_01", "A_M_M_ValFarmer_01", "A_M_M_ValTownfolk_01", "A_M_M_RhdTownfolk_01",
                 "A_M_M_StrTownfolk_01"]
FEMALE_FALLBACK = ["A_F_M_ValTownfolk_01", "A_F_M_RhdTownfolk_01", "A_F_M_StrTownfolk_01", "A_F_M_LagTownfolk_01"]
NOT_HOME = re.compile(r"corpse|dead|kid|child|teen|cholera|beggar|hobo|vagrant|drunk|prisoner|convict|guard|soldier|army|"
                      r"law|deputy|gang|odriscoll|lemoyne|murfree|skinner|delloboparty|laramie|bandit|thug|robber|"
                      r"upperclass|fancy|highsociety|travel|tourist|train|passenger|showgirl|prostitute|whore|bath|"
                      r"boatcrew|criminal|warrior|gunslinger|survivalist|player|cardgame|dominoes|fivefinger|chelonian|"
                      r"skpprison|obese", re.I)

# ── what they do: the game's own scenario points to look for in the house (regex over the point's type name), and
# a standalone scenario to play in place when there's no such point ────────────────────────────────────────────────
ACTS = {
    # id:            label (journal / prompt),                       where,   points,                                   in place
    "sleep":        ("sleeping",                                     "bed",   r"SLEEP_BED|_SLEEP$",                     ["WORLD_HUMAN_SLEEP_GROUND_PILLOW"]),
    "wake":         ("waking up slowly in bed",                      "bed",   r"SLEEP_BED|_SLEEP$",                     ["WORLD_HUMAN_SLEEP_GROUND_PILLOW"]),
    "wash_face":    ("washing up at the basin",                      "in",    r"WASH_FACE|WASHBASIN",                   ["WORLD_HUMAN_WASH_FACE_BUCKET_GROUND"]),
    "coffee":       ("having the first coffee",                      "porch", r"COFFEE|SEAT_CHAIR_PORCH|BENCH_PORCH",   ["WORLD_HUMAN_COFFEE_DRINK"]),
    "cook":         ("cooking at the stove",                         "stove", r"COOK|CAULDRON|STEW_POT|KETTLE|STOVE",   ["WORLD_HUMAN_CAULDRON_STIR_NO_POT", "WORLD_HUMAN_CANNED_FOOD_COOKING"]),
    "eat":          ("eating together at the table",                 "table", r"TABLE_EATING|SIT_SUPPER|TABLE_STEW|SEAT_CHAIR_TABLE$|DYNAMIC_SEAT_CHAIR_TABLE", ["WORLD_CAMP_SIT_GROUND_STEW", "WORLD_CAMP_SIT_GROUND_STEW_LAZY"]),
    "wash_dishes":  ("washing the dishes",                           "in",    r"WASH_DISHES|CLEAN_TABLE",               ["WORLD_HUMAN_WASH_DISHES_TABLE_LEFT", "WORLD_HUMAN_CLEAN_TABLE"]),
    "sweep":        ("sweeping the floor",                           "in",    r"BROOM",                                 ["WORLD_HUMAN_BROOM_WORKING", "WORLD_HUMAN_STRAW_BROOM_WORKING"]),
    "laundry":      ("doing the laundry on the washboard",           "out",   r"WASHBOARD",                             ["WORLD_HUMAN_WASHBOARD", "WORLD_HUMAN_WASHBOARD_BASIN"]),
    "clean_window": ("cleaning the windows",                         "in",    r"CLEAN_WINDOW",                          ["WORLD_HUMAN_CLEAN_WINDOW"]),
    "clean_table":  ("wiping down the table",                        "in",    r"CLEAN_TABLE",                           ["WORLD_HUMAN_CLEAN_TABLE"]),
    "sew":          ("sewing by the window",                         "in",    r"SEWING",                                ["WORLD_HUMAN_SIT_GROUND_SKETCHING"]),
    "knit":         ("knitting",                                     "in",    r"KNITTING",                              ["WORLD_HUMAN_SIT_GROUND_READING_BOOK"]),
    "tend_fire":    ("tending the fire",                             "in",    r"TEND_FIRE|FIRE_TEND",                   ["WORLD_HUMAN_FIRE_TEND_KNEEL"]),
    "write_letter": ("writing a letter to family",                   "in",    r"DESK_WRITING|WRITE",                    ["WORLD_HUMAN_WRITE_NOTEBOOK"]),
    "groom":        ("fixing up in the mirror",                      "in",    r"GROOMING|SHAVE|MIRROR",                 ["WORLD_HUMAN_POCKET_MIRROR"]),
    "read":         ("reading",                                      "in",    r"READ",                                  ["WORLD_HUMAN_SIT_GROUND_READING_BOOK", "WORLD_HUMAN_LEAN_READ_PAPER"]),
    "feed_chickens":("feeding the chickens",                         "out",   r"FEED_CHICKEN",                          ["WORLD_HUMAN_FEED_CHICKEN"]),
    "feed_pigs":    ("feeding the pigs",                             "out",   r"FEED_PIGS",                             ["WORLD_HUMAN_FEED_PIGS"]),
    "pump_water":   ("pumping water and hauling buckets",            "out",   r"PUMP_WATER|BUCKET_FILL",                ["WORLD_HUMAN_BUCKET_FILL", "WORLD_HUMAN_BUCKET_POUR_LOW"]),
    "chop_wood":    ("chopping firewood",                            "out",   r"WOOD_CHOP|TREE_CHOP",                   ["WORLD_HUMAN_SLEDGEHAMMER", "WORLD_HUMAN_HAMMER_GROUND"]),
    "saw_wood":     ("sawing planks",                                "out",   r"SAW_WOOD|PLANE_WOOD",                   ["WORLD_HUMAN_SAW_WOOD", "WORLD_HUMAN_PLANE_WOOD"]),
    "mend":         ("mending the fence and the shutters",           "out",   r"HAMMER",                                ["WORLD_HUMAN_HAMMER_WALL", "WORLD_HUMAN_HAMMER_KNEEL"]),
    "hay":          ("forking hay",                                  "out",   r"PITCH_HAY|RAKE",                        ["WORLD_HUMAN_PITCH_HAY_SCOOP", "WORLD_HUMAN_FARMER_RAKE"]),
    "haul_sacks":   ("hauling feed sacks",                           "out",   r"SACK_PICKUP|SACK_PUT",                  ["WORLD_HUMAN_SACK_PICKUP_1", "WORLD_HUMAN_SACK_PUT_DOWN_1"]),
    "whittle":      ("whittling on the porch",                       "porch", r"WHITTLE",                               ["WORLD_HUMAN_SIT_GROUND_WHITTLE", "WORLD_HUMAN_LEAN_BACK_WHITTLE"]),
    "clean_rifle":  ("cleaning the rifle",                           "porch", r"CLEAN_RIFLE|CLEAN_PISTOL",              ["WORLD_HUMAN_SIT_GROUND_WHITTLE"]),
    "sharpen_axe":  ("sharpening the axe",                           "porch", r"SHARPEN_AXE|SHARPEN_KNIFE",             ["WORLD_HUMAN_LEAN_TABLE_SHARPEN_KNIFE"]),
    "smoke":        ("having a smoke on the porch",                  "porch", r"SMOK|CIGAR|PIPE",                       ["WORLD_HUMAN_SMOKE", "WORLD_HUMAN_LEAN_BACK_WALL_SMOKING"]),
    "music":        ("playing music on the porch",                   "porch", r"GUITAR|BANJO|HARMONICA|FIDDLE|MANDOLIN|CONCERTINA|JAW_HARP", ["WORLD_HUMAN_SIT_GUITAR", "WORLD_HUMAN_SEAT_LEDGE_HARMONICA"]),
    "drink":        ("sharing a drink",                              "porch", r"DRINKING|PORCH_DRINKING",               ["WORLD_HUMAN_DRINKING", "WORLD_HUMAN_LEAN_RAILING_DRINKING"]),
    "porch_rest":   ("resting on the porch",                         "porch", r"SEAT_CHAIR_PORCH|BENCH_PORCH|SEAT_BENCH$|SEAT_CHAIR$", ["WORLD_HUMAN_LEAN_RAILING", "WORLD_HUMAN_SEAT_STEPS"]),
    "cozy":         ("getting close, the day's work done",           "near",  "",                                       []),
    "love":         ("making love in their bed",                     "bed",   "",                                       []),
    "away":         ("away at work",                                 "away",  "",                                       []),
    "away_lunch":   ("lunch break with the others at work",          "away",  "",                                       []),
    "away_home":    ("on the way home from work",                    "away",  "",                                       []),
    "church":       ("at church in town",                            "away",  "",                                       []),
}
OUT_CHORES = ["feed_chickens", "feed_pigs", "pump_water", "chop_wood", "saw_wood", "mend", "hay", "haul_sacks",
              "whittle", "clean_rifle", "sharpen_axe"]
IN_CHORES = ["sweep", "wash_dishes", "laundry", "clean_window", "clean_table", "sew", "knit", "tend_fire",
             "write_letter", "groom", "read", "pump_water", "feed_chickens"]
REST = ["read", "smoke", "coffee", "porch_rest", "whittle", "music"]
EVENING_A = ["music", "drink", "smoke", "porch_rest"]
EVENING_B = ["drink", "knit", "read", "porch_rest"]
JOINT = {"eat", "porch", "cozy", "love", "sleep", "wake", "church"}

# ── who they are together ───────────────────────────────────────────────────────────────────────────────────────────
STYLES = ["tender and slow, all whispers and long kisses", "playful - they tease and laugh the whole time",
          "passionate and loud, they can't keep their hands off each other", "{a} likes to take the lead",
          "{b} likes to take the lead", "they take turns leading", "romantic - sweet talk and pet names, always",
          "bold and adventurous, always trying something new", "hungry for each other after years, like newlyweds"]
LIKES = ["talking dirty to each other", "a little role-play (strangers meeting at the door, a traveller and a lonely "
         "farmer's wife...)", "slow teasing until one of them begs", "being told exactly what to do",
         "describing what they'll do before they do it", "a bit of roughness, always asked for first",
         "making each other wait", "massages and taking their time", "trying a new position every night",
         "telling each other their fantasies as stories", "being praised and adored", "candlelight and whiskey first",
         "being loud, not caring who hears", "taking it slow, then not slow at all"]
MET = ["at a barn dance in Valentine", "when he fixed her father's wagon", "at church, passing notes in the hymn book",
       "she nursed him through a fever", "on a riverboat to Saint Denis", "he came to buy a horse and stayed",
       "they grew up on neighbouring farms", "at a county fair, he lost every shooting contest to her",
       "she was a schoolteacher, he chopped the school's firewood", "a stagecoach broke down in the rain"]
MEMORIES = ["their wedding night in a thunderstorm that took the roof off the barn",
            "the summer they spent half naked at the creek", "the first winter, so cold they never left the bed",
            "the night they got drunk on blackberry wine and danced till sunrise",
            "the time they nearly got caught in the hayloft", "the night of the big fire, when they thought they'd lost each other",
            "the first time they saw Saint Denis together", "the letter he wrote her when he was away a whole season"]
FANTASIES = ["being taken somewhere they could get caught", "a whole lazy day in bed with no chores",
             "a fancy hotel room in Saint Denis with a bathtub", "being blindfolded and teased",
             "being in charge for one whole night", "making love under the stars by the river",
             "dressing up and pretending to be strangers", "being watched by someone who can't touch",
             "doing it in the barn in broad daylight", "being worshipped slowly from head to toe"]
TOPICS = ["the day's work and what's left to do", "money and the price of feed", "the neighbours and town gossip",
          "a memory from when they first met", "plans for Sunday", "teasing each other about something silly",
          "what they want to do to each other tonight", "the weather and the crops", "the animals",
          "a letter from family back east", "what's for supper", "a small argument about chores that ends in a kiss",
          "a dream one of them had", "the stranger who rides around these parts", "getting old together",
          "something they've never told each other"]
DAY_CUES = {
    "eat": "they talk over the meal", "porch": "a quiet evening on the porch - stories, flirting, plans",
    "cozy": "it's getting dark: they get close, flirting, touching, saying what they want tonight",
    "wake": "waking up together, still warm and sleepy, a little flirting",
}


def stable(seed, *salt) -> random.Random:
    return random.Random(f"{seed}:{':'.join(map(str, salt))}")


def hours_label(h: float) -> str:
    h = h % 24
    return f"{int(h):02d}:{int(round((h % 1) * 60)) % 60:02d}"


# ── the day plan (pure: the same household, role and weekday always give the same day) ─────────────────────────────
def love_window(seed: int, weekday: int) -> tuple[float, float]:
    r = stable(seed, "night")
    start = r.choice([20.5, 20.75, 21.0, 21.25, 21.5, 22.0]) + stable(seed, "night", weekday).choice([-0.25, 0, 0, 0.25])
    end = r.choice([4.0, 4.25, 4.5, 4.75, 5.0])
    return start, end


def day_plan(seed: int, role: str, weekday: int, away: bool = False, pious: bool = False) -> list[tuple[float, str]]:
    """[(start hour, act id), ...] from 00:00 to 24:00 for one partner. role 'a' = the outdoor chores, 'b' = the house."""
    d = stable(seed, "day", weekday)                       # shared by both partners: meals, evenings, the night
    wake = d.choice([5.0, 5.25, 5.5, 5.75, 6.0, 6.25]) + (0.75 if weekday == 0 else 0)
    start, end = love_window(seed, weekday)
    _, prev_end = love_window(seed, (weekday - 1) % 7)
    breakfast = wake + d.choice([1.0, 1.25])
    lunch = d.choice([12.0, 12.25, 12.5])
    cook2 = d.choice([16.75, 17.0, 17.25])
    supper = cook2 + 1.25
    porch = supper + 1.0
    cozy = start - 0.5
    church = weekday == 0 and (pious or d.random() < 0.4)
    morning_love = not church and d.random() < 0.2 and wake - 0.75 > prev_end + 0.25
    lazy_afternoon = not away and not church and d.random() < 0.15
    me = stable(seed, "me", role, weekday)
    pool = OUT_CHORES if role == "a" else IN_CHORES
    plan = [(0.0, "love" if prev_end > 0.5 else "sleep"), (prev_end, "sleep")]
    if morning_love:
        plan += [(wake - 0.75, "wake"), (wake - 0.5, "love"), (wake, "wake")]
    else:
        plan += [(wake, "wake")]
    plan += [(wake + 0.25, "wash_face")]
    if role == "b":
        plan += [(wake + 0.5, "cook")]
    else:
        plan += [(wake + 0.5, me.choice(["feed_chickens", "pump_water"])), (wake + 0.75, "coffee")]
    plan += [(breakfast, "eat")]

    bag: list[str] = []

    def chores(t0, t1, kinds, rest_once=False):
        """Chores from a shuffled bag: everything gets done before anything is done twice."""
        out, t, last, rested = [], t0, None, False
        while t < t1 - 0.2:
            dur = me.choice([0.25, 0.5, 0.5, 0.75])
            if rest_once and not rested and t > t0 + (t1 - t0) / 2:
                a, rested = me.choice(REST), True
            else:
                if not bag:
                    bag.extend(kinds)
                    me.shuffle(bag)
                a = bag.pop()
                if a == last and bag:
                    a, bag[-1] = bag[-1], a
            out.append((round(t, 2), a))
            last, t = a, t + dur
        return out

    if church:
        plan += [(breakfast + 0.75, me.choice(["groom", "wash_face"])), (9.0, "church"),
                 (11.5, me.choice(pool)), (lunch, "eat")]
    elif away and role == "a" and weekday != 0:
        plan += [(breakfast + 0.5, me.choice(["groom", "sharpen_axe"])), (breakfast + 0.75, "away"), (lunch, "away_lunch"),
                 (lunch + 0.75, "away"), (cook2 - 0.25, "away_home"), (cook2 + 0.25, "feed_chickens"),
                 (cook2 + 0.5, "wash_face")]
    else:
        plan += chores(breakfast + 0.75, lunch, pool)
        plan += [(lunch, "eat")]
    if not (away and role == "a" and weekday != 0):
        aft0 = lunch + 0.75
        if lazy_afternoon:
            plan += chores(aft0, 14.25, pool) + [(14.25, "love"), (15.0, "porch_rest")]
            aft0 = 15.5
        if role == "b":
            plan += chores(aft0, cook2, pool, rest_once=True) + [(cook2, "cook")]
        else:
            plan += chores(aft0, cook2 + 0.75, pool, rest_once=True) + [(cook2 + 0.75, "wash_face")]
    plan += [(supper, "eat"), (supper + 0.75, "wash_dishes" if role == "b" else "smoke"),
             (porch, "porch"), (cozy, "cozy"), (start, "love")]
    plan.sort(key=lambda b: b[0])
    clean = []
    for t, a in plan:                                     # later blocks win when two start at the same time
        if clean and abs(clean[-1][0] - t) < 1e-6:
            clean[-1] = (t, a)
        elif not clean or clean[-1][1] != a:
            clean.append((t, a))
    return clean


def block_at(plan, hour: float) -> tuple[float, str]:
    cur = plan[0]
    for b in plan:
        if b[0] <= hour:
            cur = b
    return cur


def evening_act(seed, role, weekday) -> str:
    return stable(seed, "eve", role, weekday).choice(EVENING_A if role == "a" else EVENING_B)


def label(act: str, seed=0, role="a", weekday=0) -> str:
    if act == "porch":
        return f"an evening on the porch together ({ACTS[evening_act(seed, role, weekday)][0]})"
    return ACTS.get(act, (act,))[0]


def routine_for_ident(ident, weekday: int) -> list[tuple[float, str]]:
    """daylife's journal for a household member: their real day."""
    hh = ident.d.get("household") or {}
    plan = day_plan(hh.get("seed", 0), hh.get("role", "a"), weekday, hh.get("away", False), hh.get("pious", False))
    partner = hh.get("partner", "my partner")
    out = []
    for t, a in plan:
        if t <= 0 and a == "love":
            out.append((0.0, f"still making love with {partner} after midnight"))
        elif a == "love":
            out.append((t, f"went to bed with {partner} - made love" + (" through the night" if t >= 19 else "")))
        elif a == "away":
            out.append((t, f"went to work at {hh.get('work', 'the mill')}"))
        elif a in ("eat",):
            out.append((t, f"ate with {partner}"))
        else:
            out.append((t, label(a, hh.get("seed", 0), hh.get("role", "a"), weekday)))
    return out


# ── the engine ──────────────────────────────────────────────────────────────────────────────────────────────────────
class Households:
    def __init__(self, brain):
        self.b = brain
        self.cfg = brain.cfg
        self.path = Path(brain.root) / "households.json"
        self.data = {"version": 1, "homes": {}}
        self.live: dict[str, dict] = {}                   # place key -> live state
        self.scan_waiters: dict[int, asyncio.Future] = {}
        self.poses = self._load_poses(Path(brain.root) / "data" / "love_poses.json")
        self.point_names = self._point_names(Path(brain.root) / "data" / "scenarios.json")
        self._busy: set[str] = set()
        self._occupied: dict[str, float] = {}          # homes the game populates itself right now (gang camp, story)
        self._last_discover = (0.0, 0.0, 0.0)          # where / when we last looked for beds
        self._load()

    @property
    def enabled(self) -> bool:
        return bool(getattr(self.cfg, "households", False))

    def caps(self) -> set:
        return set((self.b.asi_info or {}).get("caps") or [])

    # ── storage ──
    def _load(self):
        try:
            if self.path.exists():
                d = json.loads(self.path.read_text(encoding="utf-8"))
                if isinstance(d.get("homes"), dict):
                    self.data = d
        except Exception as e:
            log.error("[HOME] cannot read %s: %s", self.path, e)

    def save(self):
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, self.path)

    @staticmethod
    def _load_poses(p: Path) -> list[dict]:
        try:
            poses = [x for x in json.loads(p.read_text(encoding="utf-8")).get("poses", []) if x.get("name")]
            if poses:
                return poses
        except Exception as e:
            log.warning("[HOME] %s unreadable (%s) - built-in positions", p.name, e)
        return [{"name": "close", "desc": "{a} leads, face to face", "swap": 0},
                {"name": "other_leads", "desc": "{b} on top, leading", "swap": 1}]

    @staticmethod
    def _point_names(p: Path) -> dict[int, str]:
        names = {}
        try:
            for n in json.loads(p.read_text(encoding="utf-8")):
                names[joaat(n)] = n
        except Exception:
            pass
        for n in ("PROP_HUMAN_SLEEP_BED_PILLOW", "PROP_HUMAN_SLEEP_BED_PILLOW_HIGH", "PROP_HUMAN_SLEEP_BED_PILLOW_LEFT",
                  "PROP_HUMAN_SLEEP_BED_PILLOW_RIGHT", "PROP_HUMAN_SEAT_CHAIR", "PROP_HUMAN_SEAT_BENCH"):
            names[joaat(n)] = n
        return names

    # ── a couple for a home ──
    def models_for(self, place: dict, rng: random.Random) -> tuple[list[str], list[str]]:
        town = (place.get("town") or "").lower()
        codes = TOWN_CODES.get(town)
        if not codes and self.b.db.ok:                    # out of town: the nearest town's folk
            for p in self.b.db.places_near(place["x"], place["y"], None, 0, 2500):
                c = TOWN_CODES.get((p.get("town") or "").lower())
                if c:
                    codes = c
                    break
        men, women = [], []
        for p in self.b.peddb.by_hash.values():
            n = (p.get("n") or "").split("=")[-1].strip()
            parts = n.split("_")
            if len(parts) < 4 or NOT_HOME.search(n) or not re.match(r"^A_[MF]_[MYO]_", n, re.I):
                continue
            if codes and not any(parts[3].lower().startswith(c) for c in codes):
                continue
            (men if parts[1].upper() == "M" else women).append(n)
        return sorted(men) or MALE_FALLBACK, sorted(women) or FEMALE_FALLBACK

    def household_for(self, place: dict) -> dict:
        key = place["name"]
        rec = self.data["homes"].get(key)
        if rec and rec.get("a") in self.b.memory.ids and rec.get("b") in self.b.memory.ids:
            return rec
        seed = joaat(key) ^ int(self.data.get("salt", 0))
        r = stable(seed, "who")
        men, women = self.models_for(place, r)
        ss = float(getattr(self.cfg, "same_sex_chance", 0.08))
        pair = "mf" if r.random() >= ss else r.choice(["mm", "ff"])
        ma = r.choice(men if pair[0] == "m" else women)
        mb = r.choice([m for m in (women if pair[1] == "f" else men) if m != ma] or (women if pair[1] == "f" else men))
        married = r.random() < 0.8
        years = r.choice([1, 2, 3, 5, 7, 9, 12, 15, 20]) if married else r.choice([0, 1, 2])
        ia, ib = self._make_idents(place, ma, mb, pair, married, years)
        a_out = pair != "mf" or r.random() < 0.75          # who does the outdoor work
        if not a_out:
            ia, ib, ma, mb = ib, ia, mb, ma
        style = r.choice(STYLES).format(a=ia.persona["first_name"], b=ib.persona["first_name"])
        rec = {
            "key": key, "place": {k: place.get(k) for k in ("name", "kind", "town", "x", "y", "z")}, "seed": seed,
            "a": ia.id, "b": ib.id, "ma": ma, "mb": mb, "pair": pair, "married": married, "years": years,
            "away": r.random() < 0.3, "work": r.choice(["the sawmill", "the docks", "the general store", "the stables",
                                                        "the railroad", "a ranch down the road"]),
            "profile": {"style": style, "likes": r.sample(LIKES, 3), "met": r.choice(MET), "memory": r.choice(MEMORIES),
                        "fantasy_a": r.choice(FANTASIES), "fantasy_b": r.choice(FANTASIES)},
            "diary": [], "points": None, "bed": None, "created": time.time(),
        }
        pious = any("pious" in (i.persona.get("temperament") or "") for i in (ia, ib))
        for role, me, other in (("a", ia, ib), ("b", ib, ia)):
            me.d["household"] = {"seed": seed, "role": role, "partner": other.persona["first_name"], "away": rec["away"] and role == "a",
                                 "work": rec["work"], "pious": pious, "place": key, "kind": place.get("kind")}
            me.dirty()
        rec["pious"] = pious
        self.data["homes"][key] = rec
        self.save()
        log.info("[HOME] %s (%s, %s): %s and %s, %s - %s", key, place.get("kind"), place.get("town") or "out of town",
                 ia.persona["name"], ib.persona["name"], ("married" if married else "courting") +
                 (f" for {years} years" if years > 1 else " for a year" if years == 1 else ", just started"), style)
        return rec

    def _make_idents(self, place, ma, mb, pair, married, years):
        b, g = self.b, self.b.game
        ids = []
        for m, male in ((ma, pair[0] == "m"), (mb, pair[1] == "m")):
            c = b.peddb.classify(joaat(m), male)
            c["known"], c["child"] = True, False
            ids.append(b.memory.create(joaat(m), 0, c, g.place(), g.game_minutes_total))
        ia, ib = ids
        if married and pair == "mf":
            ib.persona["name"] = f"{ib.persona['first_name']} {ia.persona['name'].split()[-1]}"
        for me, other in ((ia, ib), (ib, ia)):
            p = me.persona
            p["age"] = max(21, int(p.get("age", 30)))
            p["child"] = False
            word = ("husband" if other.persona["sex"] == "male" else "wife") if married else "sweetheart"
            p["family"] = f"{'married to' if married else 'courting'} {other.persona['name']}" + (f" for {years} years" if years else "")
            p["role_note"] = (f"you live at this {place.get('kind', 'house')} with {other.persona['first_name']} ({word}); "
                              f"you share the chores, the meals, the porch in the evening and the bed every night")
            me.d.setdefault("relations", {})[f"id:{other.id}"] = {"rel": f"your {word}"}
            me.d["home_place"] = {k: place.get(k) for k in ("name", "kind", "town", "x", "y", "z")}
            me.dirty()
        return ia, ib

    # ── plugin answers ──
    def on_home(self, m: dict):
        fut = self.scan_waiters.pop(int(m.get("seq", 0)), None)
        if fut and not fut.done():
            fut.set_result(m)

    async def scan(self, rec: dict, timeout=4.0):
        """The house's scenario points, once (kept in households.json)."""
        if rec.get("points") is not None or "home_scan" not in self.caps():
            return
        pl = rec["place"]
        seq = self.b.couples.next_seq()
        fut = asyncio.get_running_loop().create_future()
        self.scan_waiters[seq] = fut
        self.b.asi.send("home_scan", seq, round(pl["x"], 2), round(pl["y"], 2), round(pl["z"], 2),
                        float(getattr(self.cfg, "home_scan_metres", 22)))
        try:
            m = await asyncio.wait_for(fut, timeout)
        except asyncio.TimeoutError:
            return
        finally:
            self.scan_waiters.pop(seq, None)
        # houses stand close together (Lakay: ~20 m) and a scan reaches into the neighbours' yards: a spot belongs to
        # the home it's nearest to, so two households never share a chair or a bed
        others = [(q["x"], q["y"]) for q in self.b.db.places_near(pl["x"], pl["y"], HOME_KINDS, 0, 80)
                  if q["name"] != rec["key"]]
        pts, theirs = [], 0
        for p in m.get("pts") or []:
            try:
                ty, x, y, z, h = int(p[0]) & 0xFFFFFFFF, float(p[1]), float(p[2]), float(p[3]), float(p[4])
            except (TypeError, ValueError, IndexError):
                continue
            mine = math.hypot(x - pl["x"], y - pl["y"])
            if any(math.hypot(x - ox, y - oy) < mine for ox, oy in others):
                theirs += 1
                continue
            pts.append([self.point_names.get(ty, f"0x{ty:08X}"), round(x, 2), round(y, 2), round(z, 2), round(h)])
        rec["points"] = pts
        self.save()
        kinds = sorted({p[0] for p in pts})
        log.info("[HOME] %s: %d furniture/chore spots%s: %s", rec["key"], len(pts),
                 f" ({theirs} more belong to the neighbours)" if theirs else "", ", ".join(kinds)[:400])

    async def bed_for(self, rec: dict):
        if rec.get("bed"):
            return rec["bed"]
        pl = rec["place"]
        bed = await self.b.couples.find_bed(pl["x"], pl["y"], pl["z"], 25.0)
        if bed:
            rec["bed"] = {k: bed.get(k) for k in ("x", "y", "z", "hd", "src", "model")}
            self.save()
        return rec.get("bed")

    # ── where an act happens ──
    def spot(self, rec: dict, act: str, role: str, taken: set, weekday: int) -> dict:
        if act == "porch":
            act = evening_act(rec["seed"], role, weekday)
        lbl, where, pat, scen = ACTS.get(act, ACTS["porch_rest"])
        pl = rec["place"]
        if pat and rec.get("points"):
            hits = [p for p in rec["points"] if re.search(pat, p[0]) and (p[1], p[2]) not in taken]
            if hits:
                hits.sort(key=lambda p: (math.hypot(p[1] - pl["x"], p[2] - pl["y"]), p[0]))
                p = hits[stable(rec["seed"], act, role).randrange(len(hits[:3]))] if len(hits) > 1 else hits[0]
                return {"kind": "point", "act": act, "x": p[1], "y": p[2], "z": p[3], "h": p[4], "name": p[0]}
        r = stable(rec["seed"], "place", act, role)
        if where in ("out", "porch"):
            ang = r.uniform(0, 2 * math.pi) if where == "out" else stable(rec["seed"], "porch").uniform(0, 2 * math.pi)
            dist = r.uniform(6, 10) if where == "out" else r.uniform(3.5, 5)
            x, y, flag = pl["x"] + math.cos(ang) * dist, pl["y"] + math.sin(ang) * dist, "ground"
        else:
            x, y, flag = pl["x"] + r.uniform(-1.5, 1.5), pl["y"] + r.uniform(-1.5, 1.5), "floor"
        return {"kind": "place", "act": act, "x": round(x, 2), "y": round(y, 2), "z": pl["z"], "h": round(r.uniform(0, 360)),
                "scen": r.choice(scen) if scen else "", "flag": flag}

    async def bed_spot(self, lv: dict, role: str, act: str) -> dict:
        """Where they sleep: one of the house's own pillow spots (the other partner gets the other), else the bed."""
        rec = lv["rec"]
        if rec.get("points"):
            other = lv["b" if role == "a" else "a"].get("spot") or {}
            pts = [q for q in rec["points"] if re.search(r"SLEEP_BED", q[0]) and (q[1], q[2]) != (other.get("x"), other.get("y"))]
            if pts:
                pl = rec["place"]
                pts.sort(key=lambda q: (math.hypot(q[1] - pl["x"], q[2] - pl["y"]), q[0]))
                q = pts[0]
                return {"kind": "point", "act": act, "x": q[1], "y": q[2], "z": q[3], "h": q[4], "name": q[0]}
        bed = await self.bed_for(rec)
        return {"kind": "bed", "act": act, **(bed or {k: rec["place"][k] for k in ("x", "y", "z")})}

    # ── the clock ──
    def now(self) -> tuple[int, float]:
        w = self.b.game.world
        return int(w.get("dow", 1)) % 7, int(w.get("hr", 12)) + int(w.get("mn", 0)) / 60.0

    def current(self, rec: dict, role: str) -> tuple[float, str]:
        dow, hr = self.now()
        ident = self.b.memory.ids.get(rec[role])
        hh = (ident.d.get("household") if ident else None) or {}
        plan = day_plan(rec["seed"], role, dow, hh.get("away", False), rec.get("pious", False))
        t, act = block_at(plan, hr)
        if act in ("love", "cozy") and self.b.game.game_minutes_total < rec.get("disturbed_until", -1):
            act = "porch_rest" if act == "cozy" else "sleep"     # you barged in earlier: not tonight
        return t, act

    # ── the main loop (called every second from the brain's housekeeping) ──
    async def tick(self):
        if not self.enabled:
            return
        try:
            await self._tick()
        except Exception:
            log.error("[HOME] tick crashed:\n%s", traceback.format_exc())

    async def _tick(self):
        b, g = self.b, self.b.game
        if not b.asi.up or not g.player or not b.db.ok:
            return
        px, py = g.player.get("x", 0), g.player.get("y", 0)
        for key, lv in list(self.live.items()):
            pl = lv["rec"]["place"]
            if math.hypot(px - pl["x"], py - pl["y"]) > float(getattr(self.cfg, "household_despawn_metres", 140)):
                self.leave(key, "the stranger rode off")
        if g.world.get("mission"):
            return
        radius = float(getattr(self.cfg, "household_metres", 70))
        await self.discover(px, py, g.player.get("z", 0))
        near = b.db.places_near(px, py, HOME_KINDS, 0, radius, lived_in=True)
        for f in self.data.get("found", {}).values():
            if math.hypot(f["x"] - px, f["y"] - py) <= radius:
                near.append(dict(f, d=round(math.hypot(f["x"] - px, f["y"] - py))))
        near.sort(key=lambda p: p["d"])
        for pl in near:
            if pl["name"] in self.live or pl["name"] in self._busy:
                continue
            if time.time() < self._occupied.get(pl["name"], 0):
                continue
            if self.occupied(pl):
                self._occupied[pl["name"]] = time.time() + 600
                continue
            if len(self.live) >= int(getattr(self.cfg, "household_max_live", 2)):
                break
            self._busy.add(pl["name"])
            try:
                await self.arrive(pl)
            finally:
                self._busy.discard(pl["name"])
        for key, lv in list(self.live.items()):
            await self.run(lv)

    # ── every house with a bed, whatever the database knows ──
    async def discover(self, px, py, pz):
        """Look for the game's own BEDS around you (its scenario points); a bed away from any home we know and away from
        hotels, saloons, the doctor's, the jail... is somebody's home -> remembered (households.json) and lived in."""
        if "home_scan" not in self.caps() or not getattr(self.cfg, "discover_homes", True):
            return
        lx, ly, lt = self._last_discover
        if math.hypot(px - lx, py - ly) < 30 and time.time() - lt < 120:
            return
        self._last_discover = (px, py, time.time())
        seq = self.b.couples.next_seq()
        fut = asyncio.get_running_loop().create_future()
        self.scan_waiters[seq] = fut
        self.b.asi.send("home_scan", seq, round(px, 2), round(py, 2), round(pz, 2), 60.0)
        try:
            m = await asyncio.wait_for(fut, 4.0)
        except asyncio.TimeoutError:
            return
        finally:
            self.scan_waiters.pop(seq, None)
        beds = []
        for p in m.get("pts") or []:
            try:
                name = self.point_names.get(int(p[0]) & 0xFFFFFFFF, "")
                if BED_RE.search(name):
                    beds.append((float(p[1]), float(p[2]), float(p[3])))
            except (TypeError, ValueError, IndexError):
                continue
        found = self.data.setdefault("found", {})
        added = []
        for x, y, z in beds:
            known = self.b.db.places_near(x, y, HOME_KINDS, 0, 22, lived_in=True) or \
                [f for f in found.values() if math.hypot(f["x"] - x, f["y"] - y) < 18]
            if known:
                continue
            if self.b.db.places_near(x, y, NOT_HOME_NEAR, 0, 30):
                continue
            town = ""
            for p in self.b.db.places_near(x, y, None, 0, 600):
                if p.get("town"):
                    town = p["town"]
                    break
            key = f"home_{int(round(x))}_{int(round(y))}"
            found[key] = {"name": key, "kind": "house", "town": town, "x": round(x, 2), "y": round(y, 2), "z": round(z, 2),
                          "lived_in": True, "src": "beds"}
            added.append(key)
        if added:
            self.save()
            log.info("[HOME] found %d more home(s) by their beds: %s", len(added), ", ".join(added))

    def occupied(self, pl) -> bool:
        """The game already has people living here (a gang camp, a story family, a mission): it's theirs."""
        n, who = 0, []
        for p in self.b.game.near_peds or []:
            if not p.get("alive", 1) or math.hypot(p.get("x", 0) - pl["x"], p.get("y", 0) - pl["y"]) > 18:
                continue
            info = self.b.peddb.by_hash.get(int(p.get("m", 0)) & 0xFFFFFFFF) or {}
            name = (info.get("n") or "").upper()
            if p.get("mission") or name.startswith(("CS_", "G_", "U_")) or "GANG" in name:
                n += 1
                who.append(name or "someone")
        if n >= 2:
            log.info("[HOME] %s: the game has its own people living here (%s) - left to them", pl["name"], ", ".join(who[:4]))
            return True
        return False

    def leave(self, key: str, why: str):
        lv = self.live.pop(key, None)
        if not lv:
            return
        if lv.get("love", {}).get("on"):
            self.b.asi.send("couple_stop", self.b.asi.next(lv["a"]["h"], "household", "couple_stop"), lv["a"]["h"])
        for role in ("a", "b"):
            h = lv[role].get("h")
            if h:
                self.b.asi.send("actor", h, 0)
                self.b.asi.send("despawn", h, "delete")
                self.b.handle_ident.pop(h, None)
        log.info("[HOME] %s: %s - the couple goes on with their day without you", key, why)

    async def arrive(self, pl: dict):
        rec = self.household_for(pl)
        await self.scan(rec)
        lv = {"rec": rec, "a": {}, "b": {}, "love": {}, "next_chat": time.time() + random.uniform(6, 14),
              "caught": False, "t": time.time()}
        self.live[rec["key"]] = lv
        dow, _ = self.now()
        taken = set()
        for role in ("a", "b"):
            t, act = self.current(rec, role)
            p = lv[role]
            p["act"], p["block"] = act, t
            if act in ("away", "church"):
                p["h"] = 0
                continue
            if act in ("love", "sleep", "wake"):
                sp = await self.bed_spot(lv, role, act)
                if sp["kind"] == "point":
                    x, y, z, h, flags = sp["x"], sp["y"], sp["z"], sp["h"], "exact"
                else:
                    x, y = sp["x"] + (0.4 if role == "a" else -0.4), sp["y"]
                    z, h, flags = float(sp["z"]) + 0.4, float(sp.get("hd", 0) or 0), "bed"
            else:
                sp = self.spot(rec, act, role, taken, dow)
                taken.add((sp["x"], sp["y"]))
                x, y, z, h = sp["x"], sp["y"], sp["z"], sp["h"]
                flags = "exact" if sp["kind"] == "point" else sp.get("flag", "floor")
            model = rec["ma"] if role == "a" else rec["mb"]
            if role == "b" and lv["a"].get("h"):
                flags += f",like={lv['a']['h']}"           # same skin as their partner (the plugin picks the outfit)
            hnd = await self.b.couples.spawned(self.b.couples.spawn(model, x, y, z, h, flags))
            if not hnd:
                log.info("[HOME] %s: %s didn't spawn - nobody home right now", rec["key"], model)
                self.live.pop(rec["key"], None)
                return
            p["h"], p["spot"], p["since"] = hnd, sp, time.time()
            ident = self.b.memory.ids[rec[role]]
            self.b.handle_ident[hnd] = ident.id
            self.b.asi.send("actor", hnd, 1)
            if act not in ("love",):
                self.do(lv, role, sp, warp=True)
        if all(lv[r].get("act") == "love" for r in ("a", "b")) and lv["a"].get("h") and lv["b"].get("h"):
            await self.love_start(lv)
        ia, ib = (self.b.memory.ids[rec[r]] for r in ("a", "b"))
        log.info("[HOME] you're near %s's and %s's %s (%s): %s / %s", ia.persona["first_name"], ib.persona["first_name"],
                 pl["kind"], rec["key"], lv["a"].get("act"), lv["b"].get("act"))

    def do(self, lv, role, sp, warp=False):
        """Start the act at its spot: walk there and do it (warp: already there)."""
        h = lv[role].get("h")
        if not h:
            return
        b = self.b
        b.asi.send("actor", h, 1)                         # a conversation's end may have released them
        lv[role]["stage"] = "doing"
        lv[role]["since"] = time.time()
        lv[role]["fallback"] = False
        if sp.get("kind") == "point" and "use_point" in self.caps():
            b.asi.prim(h, "household", ("use_point", sp["x"], sp["y"], sp["z"], 1.0, 1 if warp else 0, -1))
            return
        if sp.get("kind") == "bed":
            scen = ACTS.get(sp.get("act"), ACTS["sleep"])[3]
            b.asi.prim(h, "household", ("scenario", scen[0] if scen else "WORLD_HUMAN_SLEEP_GROUND_PILLOW", -1))
            return
        if not warp:
            p = b.game.ped(h)
            if p and "x" in p and math.hypot(p["x"] - sp["x"], p["y"] - sp["y"]) > 1.5:
                b.asi.prim(h, "household", ("goto_coord", sp["x"], sp["y"], sp["z"], 1.0))
                lv[role]["stage"] = "walking"
                lv[role]["walk_until"] = time.time() + 25
                return
        if sp.get("scen"):
            b.asi.prim(h, "household", ("scenario", sp["scen"], -1))
        elif sp.get("act") == "cozy":
            other = lv["b" if role == "a" else "a"].get("h")
            if other:
                b.asi.prim(h, "household", ("face", 600000, f"t={other}"))

    async def run(self, lv: dict):
        b, rec = self.b, lv["rec"]
        dow, hr = self.now()
        if lv.get("caught") or lv.get("alarm"):
            self.alarm_tick(lv)
            return
        busy = {c.ped for c in b.convs.values() if not c.ended}
        for role in ("a", "b"):
            p = lv[role]
            h = p.get("h")
            t, act = self.current(rec, role)
            if h and b.dead(h):
                continue
            if p.get("stage") == "walking" and h:
                gp = b.game.ped(h)
                sp = p.get("spot") or {}
                if time.time() > p.get("walk_until", 0) or (gp and "x" in gp and math.hypot(gp["x"] - sp.get("x", 0), gp["y"] - sp.get("y", 0)) < 1.6):
                    self.do(lv, role, sp, warp=True)
            sp = p.get("spot") or {}
            if (h and p.get("stage") == "doing" and sp.get("kind") == "point" and not p.get("fallback")
                    and time.time() - p.get("since", 0) > 10 and h not in busy):
                gp = b.game.ped(h)
                if gp and not gp.get("scen") and not gp.get("sit"):   # the spot was taken / didn't work: do it in place
                    p["fallback"] = True
                    scen = ACTS.get(sp.get("act"), ACTS["porch_rest"])[3]
                    if scen:
                        b.asi.prim(h, "household", ("scenario", stable(rec["seed"], sp.get("act")).choice(scen), -1))
                        log.info("[HOME] %s: %s's spot (%s) didn't take - %s in place", rec["key"],
                                 b.memory.ids[rec[role]].persona["first_name"], sp.get("name"), sp.get("act"))
            if (t, act) == (p.get("block"), p.get("act")):
                continue
            if h in busy:
                continue                                       # you're talking with them: the chore can wait
            old = p.get("act")
            p["block"], p["act"] = t, act
            log.info("[HOME] %s: %s %s -> %s (%s)", rec["key"], b.memory.ids[rec[role]].persona["first_name"], old, act,
                     hours_label(hr))
            if act in ("away", "church"):
                if h:
                    pl = rec["place"]
                    b.asi.prim(h, "household", ("goto_coord", pl["x"] + 45, pl["y"] + 45, pl["z"], 1.2))
                    asyncio.get_running_loop().call_later(30, lambda hh=h: (b.asi.send("actor", hh, 0), b.asi.send("despawn", hh, "delete")))
                    p["h"] = 0
                continue
            if not h:                                          # back from work / church: walks up to the house
                pl = rec["place"]
                ang = stable(rec["seed"], "porch").uniform(0, 2 * math.pi)
                fut = b.couples.spawn(rec["ma"] if role == "a" else rec["mb"], pl["x"] + math.cos(ang) * 30,
                                      pl["y"] + math.sin(ang) * 30, pl["z"], 0, "ground")
                h = await b.couples.spawned(fut)
                if not h:
                    continue
                p["h"] = h
                b.handle_ident[h] = rec[role]
                b.asi.send("actor", h, 1)
            if old == "love" and act != "love":
                self.love_stop(lv, "the night is over" if act == "sleep" else "they get up")
            if act == "love":
                continue                                       # both partners: started below once both are 'love'
            if act in ("sleep", "wake"):
                sp = await self.bed_spot(lv, role, act)
            else:
                taken = {((lv[o].get("spot") or {}).get("x"), (lv[o].get("spot") or {}).get("y")) for o in ("a", "b") if o != role}
                sp = self.spot(rec, act, role, taken, dow)
            p["spot"] = sp
            self.do(lv, role, sp)
        if self.alarm_tick(lv):
            return                                       # 0.5.8: someone got hurt / shot at: no chores, no love, no chat
        both_love = all(lv[r].get("act") == "love" and lv[r].get("h") for r in ("a", "b"))
        if both_love and not lv["love"].get("on"):
            await self.love_start(lv)
        if lv["love"].get("on"):
            await self.love_tick(lv)
        self.walk_in(lv)
        self.intruder(lv)
        await self.chat_tick(lv)

    # ── the night ──
    def safe(self, lv) -> tuple[bool, str]:
        b = self.b
        for role in ("a", "b"):
            h = lv[role].get("h")
            if not h or b.dead(h):
                return False, "someone is gone"
            st = b.game.ped(h)
            for k, why in (("hog", "tied up"), ("lasso", "lassoed"), ("aimed", "a gun on them"), ("flee", "running"),
                           ("comb", "fighting"), ("rag", "knocked down")):
                if st.get(k):
                    return False, why
            ident = b.memory.ids.get(lv["rec"][role])
            if ident and (ident.stats.get("fear", 0) >= 50 or ident.persona.get("child") or ident.persona.get("age", 30) < 21):
                return False, "scared of you"
        return True, ""

    async def love_start(self, lv):
        rec, b = lv["rec"], self.b
        ok, why = self.safe(lv)
        if not ok or lv.get("alarm"):
            if not lv.get("love_refused"):
                log.info("[HOME] %s: no night together now (%s) - they just go to bed", rec["key"], why or "alarmed")
                lv["love_refused"] = True
                self.no_love(lv)
            return
        bed = await self.bed_for(rec)
        if not bed:                                   # 0.5.8: 0.5.7 just returned here - both stood there, dressed
            pl = rec["place"]
            bed = {"x": pl["x"], "y": pl["y"], "z": pl["z"], "hd": 0.0, "src": "floor", "model": "floor"}
            log.info("[HOME] %s: the plugin found no bed in time - a blanket on the floor of the house", rec["key"])
        x, y, z, h = b.couples.bed_point(bed)
        a, bb = lv["a"]["h"], lv["b"]["h"]
        for hh in (a, bb):
            b.asi.prim(hh, "household", ("undress",))
        await asyncio.sleep(0.6)
        r = stable(rec["seed"], "poses", int(b.game.game_minutes_total // 1440))
        order = list(range(len(self.poses)))
        r.shuffle(order)
        lv["love"] = {"on": True, "phase": "love", "order": order, "i": 0, "x": x, "y": y, "z": z, "h": h,
                      "until": time.time() + self._pose_secs(), "left": r.randint(3, 6), "session": 1,
                      "changed": "", "next_talk": time.time() + random.uniform(5, 9), "talks": 0}
        pose = self.poses[order[0]]
        b.asi.send("couple", b.asi.next(a, "household", "couple"), a, bb, round(x, 2), round(y, 2), round(z, 2),
                   round(h, 1), ANIM_FLAGS, *self.pose_tokens(pose))
        log.info("[HOME] %s: night together - session 1, %s", rec["key"], pose["name"])

    def no_love(self, lv):
        """They can't / won't tonight: they lie down to sleep instead of standing at the bed (0.5.7 left them standing)."""
        for role in ("a", "b"):
            h = lv[role].get("h")
            if h and not self.b.dead(h):
                self.b.asi.prim(h, "household", ("scenario", "WORLD_HUMAN_SLEEP_GROUND_PILLOW", -1))
                lv[role]["act"] = "sleep"

    def _pose_secs(self) -> float:
        m = float(getattr(self.cfg, "pose_seconds", 90))
        return random.uniform(m * 0.6, m * 1.4)

    def pose_tokens(self, pose: dict) -> list[str]:
        if "couple_pose" not in self.caps():
            return []
        t = []
        if pose.get("pos") and not pose.get("anim") and "nh_pos" in self.caps():
            t.append(f"pos={int(pose['pos'])}")           # 0.5.8: NpcHookups' way (attached to his hip bone)
            if pose.get("swap"):
                t.append("swap=1")
            return t
        if pose.get("anim"):
            t.append("anim=" + ",".join(pose["anim"]))
        turn = float(pose.get("turn", 0))
        pa = list(pose.get("pa") or [0, 0, 0, 0, 0, 0])
        pb = list(pose.get("pb") or [0, 0, 0, 0, 0, 0])
        pa[5] += turn
        pb[5] += turn
        if any(pa):
            t.append("pa=" + ",".join(f"{v:g}" for v in pa))
        if any(pb):
            t.append("pb=" + ",".join(f"{v:g}" for v in pb))
        if pose.get("swap"):
            t.append("swap=1")
        return t

    def pose_desc(self, lv, pose) -> str:
        ia, ib = (self.b.memory.ids[lv["rec"][r]] for r in ("a", "b"))
        return pose.get("desc", pose["name"]).format(a=ia.persona["first_name"], b=ib.persona["first_name"])

    async def love_tick(self, lv):
        b, L = self.b, lv["love"]
        ok, why = self.safe(lv)
        if not ok:
            self.love_stop(lv, why)
            lv["rec"]["disturbed_until"] = b.game.game_minutes_total + 120
            return
        if time.time() < L["until"]:
            return
        a, bb = lv["a"]["h"], lv["b"]["h"]
        if L["phase"] == "love":
            L["left"] -= 1
            if L["left"] <= 0:                                 # catch their breath: lie together, talk, a drink
                L["phase"], L["until"] = "rest", time.time() + random.uniform(45, 100)
                L["changed"] = "rest"
                b.asi.send("couple_stop", b.asi.next(a, "household", "couple_stop"), a)
                for hh in (a, bb):
                    b.asi.prim(hh, "household", ("scenario", "WORLD_HUMAN_SLEEP_GROUND_PILLOW", -1))
                log.info("[HOME] %s: catching their breath after session %d", lv["rec"]["key"], L["session"])
                return
            L["i"] = (L["i"] + 1) % len(L["order"])
            pose = self.poses[L["order"][L["i"]]]
            if "couple_pose" in self.caps():
                b.asi.send("couple_pose", b.asi.next(a, "household", "couple_pose"), a, *self.pose_tokens(pose))
                L["changed"] = self.pose_desc(lv, pose)
                log.info("[HOME] %s: they change position -> %s", lv["rec"]["key"], pose["name"])
            L["until"] = time.time() + self._pose_secs()
            return
        # rest is over: again
        L["phase"], L["session"], L["left"] = "love", L["session"] + 1, random.randint(3, 6)
        L["i"] = (L["i"] + 1) % len(L["order"])
        pose = self.poses[L["order"][L["i"]]]
        b.asi.send("couple", b.asi.next(a, "household", "couple"), a, bb, round(L["x"], 2), round(L["y"], 2),
                   round(L["z"], 2), round(L["h"], 1), ANIM_FLAGS, *self.pose_tokens(pose))
        L["until"], L["changed"] = time.time() + self._pose_secs(), "again: " + self.pose_desc(lv, pose)
        log.info("[HOME] %s: session %d - %s", lv["rec"]["key"], L["session"], pose["name"])

    def love_stop(self, lv, why: str):
        L = lv.get("love") or {}
        if not L.get("on"):
            return
        a = lv["a"].get("h")
        if a:
            self.b.asi.send("couple_stop", self.b.asi.next(a, "household", "couple_stop"), a)
        for role in ("a", "b"):
            if lv[role].get("h"):
                self.b.asi.prim(lv[role]["h"], "household", ("dress",))
        L["on"] = False
        log.info("[HOME] %s: night scene over: %s", lv["rec"]["key"], why)

    # ── 0.5.8: danger - one of them is shot, hurt, threatened, or shots ring out right by the house ──
    def alarm_tick(self, lv) -> bool:
        """-> True while the household is in alarm. 0.5.7: you shot one of the old couple and the other went on
        chatting in a calm voice. Now everything stops at once, the voice lines are cut, and the other one reacts."""
        b, rec = self.b, lv["rec"]
        if lv.get("alarm"):
            if time.time() < lv.get("alarm_until", 0):
                return True
            if any(lv[r].get("h") and not b.dead(lv[r]["h"]) for r in ("a", "b")) and not lv.get("widowed"):
                lv["alarm"] = False                      # it's over (they still remember)
                for role in ("a", "b"):
                    lv[role]["block"] = None
                return False
            return True
        pl = b.game.player or {}
        why, hurt, dead = "", None, None
        for role in ("a", "b"):
            h = lv[role].get("h")
            if not h:
                continue
            if b.dead(h):
                dead = role
                why = "killed"
                break
            st = b.game.ped(h) or {}
            hp, last = st.get("hp"), lv[role].get("hp")
            if hp is not None:
                lv[role]["hp"] = hp
            if st.get("dmg") or (hp is not None and last is not None and hp < last - 1):
                hurt, why = role, "hurt"
            elif st.get("aimed") and st.get("d", 99) < 25:
                hurt, why = role, why or "gun"
            elif st.get("hog") or st.get("lasso"):
                hurt, why = role, why or "tied"
        if not why and pl.get("shoot"):
            pa = b.game.ped(lv["a"].get("h") or 0) or {}
            pb = b.game.ped(lv["b"].get("h") or 0) or {}
            if min(pa.get("d", 999), pb.get("d", 999)) < 60:
                why = "shots"
        if not why:
            return False
        lv["alarm"], lv["alarm_until"] = True, time.time() + 90
        rec["disturbed_until"] = b.game.game_minutes_total + 24 * 60
        if b.speaking and b.speaking.get("ped") in (lv["a"].get("h"), lv["b"].get("h")):
            b.voice.stop()                               # the line in their mouth is cut off
            b.speaking = {}
        if lv["love"].get("on"):
            lv["love"]["on"] = False
            a = lv["a"].get("h")
            if a:
                b.asi.send("couple_stop", b.asi.next(a, "household", "couple_stop"), a)
        victim = dead or hurt
        other = ("b" if victim == "a" else "a") if victim else None
        log.info("[HOME] %s: ALARM - %s%s", rec["key"], why,
                 f" ({b.memory.ids[rec[victim]].persona['first_name']})" if victim else "")
        if dead:
            lv["widowed"] = True
            ident = b.memory.ids.get(rec[dead])
            if ident:
                ident.d["dead"] = True
                ident.dirty()
        asyncio.create_task(self._alarm_react(lv, why, victim, other))
        return True

    async def _alarm_react(self, lv, why, victim, other):
        b, rec = self.b, lv["rec"]
        try:
            g = b.game
            roles = [other] if other else ["a", "b"]
            vname = b.memory.ids[rec[victim]].persona["first_name"] if victim else ""
            for role in roles:
                h = lv[role].get("h")
                if not h or b.dead(h):
                    continue
                ident = b.memory.ids[rec[role]]
                rel = "husband" if ident.persona.get("sex") == "female" else "wife"
                if victim:
                    pr = await b.perception.death(h, lv[victim].get("h") or 0) if why == "killed" else \
                        {"saw": True, "heard": "", "d": 0}
                else:
                    pr = {"saw": False, "heard": "shot", "d": 0}
                if why == "killed" and pr["saw"]:
                    ev = (f"!! The stranger just SHOT your {rel} {vname} DEAD, right here in your own home. You saw it. "
                          "React as a real person in this second: screaming, sobbing, begging, cursing him, running - or "
                          "going for a gun if you're the kind who would.")
                    ident.add_event(f"the stranger killed your {rel} {vname} in your home", g.game_minutes_total, g.place(), 3)
                    ident.adjust({"fear": 45, "anger": 40, "trust": -60}, "killed my partner", cap=60)
                elif why == "killed" or why == "shots":
                    ev = ("!! A GUNSHOT just went off right by your house" + (f" - where {vname} was" if vname else "") +
                          ". You didn't see it. You're terrified: you call out" + (f" for {vname}" if vname else "") +
                          ", ask who's there. Never say anyone is dead - you don't know.")
                    ident.add_event("shots right by the house", g.game_minutes_total, g.place(), 2)
                    ident.adjust({"fear": 25}, "shots at home", cap=30)
                elif why == "hurt":
                    ev = (f"!! The stranger just HURT your {rel} {vname} in your own home" if role != victim else
                          "!! The stranger just HURT you in your own home") + ". React right now - pain, fear, rage."
                    ident.adjust({"fear": 30, "anger": 30, "trust": -40}, "hurt at home", cap=40)
                elif why == "gun":
                    ev = ("!! The stranger has a GUN pointed at " + ("you" if role == victim else f"your {rel} {vname}") +
                          " in your own home. React right now.")
                    ident.adjust({"fear": 30, "trust": -30}, "gun at home", cap=35)
                else:
                    ev = (f"!! The stranger tied up " + ("you" if role == victim else f"your {rel} {vname}") +
                          " in your own home. React right now.")
                b.asi.prim(h, "household", ("clear",))
                if why in ("killed", "hurt", "shots") and float(ident.persona.get("bravery", 0.5)) < 0.55:
                    b.asi.prim(h, "household", ("cower", 15000))
                others = any(not c.ended and c.ped not in (lv["a"].get("h"), lv["b"].get("h")) for c in b.convs.values())
                conv = b.on_engage_req({"ped": h, "model": joaat(rec["ma"] if role == "a" else rec["mb"]), "outfit": 0,
                                        "male": ident.persona.get("sex") == "male", "alive": 1, "human": 1},
                                       forced_ident=ident, reason="household_alarm", side=others)
                if conv:
                    conv.pending_events.append(("home_alarm", ev, 3))
                    conv.mark("threatened")
                    await b.run_turn(conv, reaction=True)
                break                                    # one of them speaks first; the other is in the conversation too
        except Exception:
            log.error("[HOME] alarm reaction crashed:\n%s", traceback.format_exc())

    # ── 0.5.8: a stranger walks into their house (any time) ──
    def intruder(self, lv):
        """0.5.7: you walked into the house at night and they never noticed you. Now: you inside their home and in
        their sight (or right next to them) - they notice, stop what they're doing and ask what you want."""
        b, pl = self.b, self.b.game.player or {}
        if lv.get("caught") or lv.get("alarm") or lv["love"].get("on"):
            return
        if time.time() < lv.get("intruder_next", 0):
            return
        rec = lv["rec"]
        place = rec["place"]
        dhome = math.hypot(pl.get("x", 0) - place["x"], pl.get("y", 0) - place["y"])
        inside_m = float(getattr(self.cfg, "intruder_metres", 4.5))
        if dhome > inside_m:                     # in the yard / on the porch is not inside their house
            lv["intruded"] = False
            return
        if lv.get("intruded"):
            return
        busy = {c.ped for c in b.convs.values() if not c.ended}
        if busy or b.ptt_ped:
            return                       # you're talking with someone (maybe the one who brought you): not now
        notice = None
        for role in ("a", "b"):
            h = lv[role].get("h")
            if not h or b.dead(h):
                continue
            st = b.game.ped(h) or {}
            d = st.get("d", 99)
            if "x" in st and math.hypot(st["x"] - place["x"], st["y"] - place["y"]) > inside_m + 2.0:
                continue                         # they're out in the yard: they didn't see you go in
            asleep = lv[role].get("act") == "sleep"
            if d < 1.8 or (st.get("los") and d < (4.0 if asleep else 9.0) and not (pl.get("crouch") and d > 3.0)):
                notice = role
                break
        if not notice:
            return
        lv["intruded"], lv["intruder_next"] = True, time.time() + 120
        h = lv[notice]["h"]
        ident = b.memory.ids[rec[notice]]
        night = lv[notice].get("act") in ("sleep", "wake", "love", "cozy")
        met = int(ident.d.get("times_met", 0) or 0) > 0
        ev = (("!! You wake up / look up and there's a man INSIDE your house in the dark. " if night else
               "!! A man just walked into your house, uninvited. ") +
              ("You know him - you've met. " if met else "You've never seen him. ") +
              "React as a real person in your own home: startled, suspicious, demanding what he wants - or welcoming if "
              "you know him and like him. Your partner is here too.")
        log.info("[HOME] %s: %s noticed the stranger in the house (%.1f m inside)", rec["key"], ident.persona["first_name"], dhome)
        b.asi.prim(h, "household", ("clear",))
        conv = b.on_engage_req({"ped": h, "model": joaat(rec["ma"] if notice == "a" else rec["mb"]), "outfit": 0,
                                "male": ident.persona.get("sex") == "male", "alive": 1, "human": 1},
                               forced_ident=ident, reason="household_intruder")
        if conv:
            conv.pending_events.append(("intruder", ev, 3))
            asyncio.create_task(b.run_turn(conv, reaction=True))

    # ── walking in on them ──
    def walk_in(self, lv):
        b, pl = self.b, self.b.game.player
        if lv.get("caught") or not lv["love"].get("on"):
            return
        pa, pb = b.game.ped(lv["a"]["h"]), b.game.ped(lv["b"]["h"])
        if not pa or not pb:
            return
        d = min(pa.get("d", 99), pb.get("d", 99))
        seen = pa.get("los") or pb.get("los")
        if d > float(b.cfg.walk_in_m) or (pl.get("crouch") and (not seen or d > 2.5)) or (not seen and d > 2.0):
            return
        lv["caught"] = True
        lv["love"]["on"] = False
        rec = lv["rec"]
        rec["disturbed_until"] = b.game.game_minutes_total + 180
        a = lv["a"]["h"]
        b.asi.send("couple_stop", b.asi.next(a, "household", "couple_stop"), a)
        hc = {"a": lv["a"]["h"], "b": lv["b"]["h"], "ia": b.memory.ids[rec["a"]], "ib": b.memory.ids[rec["b"]],
              "place": rec["place"], "scene": f"H{a}", "caught": True}
        asyncio.create_task(self._caught(lv, hc))

    async def _caught(self, lv, hc):
        try:
            await self.b.couples.caught(hc)
        finally:
            await asyncio.sleep(45)
            lv["caught"] = False                          # they go on with the routine (and remember you)
            for role in ("a", "b"):
                lv[role]["block"] = None

    # ── talking to each other ──
    async def chat_tick(self, lv):
        b, rec = self.b, lv["rec"]
        if b.ptt_ped or b.speaking or b.frozen:
            return
        a, bb = lv["a"].get("h"), lv["b"].get("h")
        if not a or not bb or b.dead(a) or b.dead(bb):
            return
        if any(c.ped in (a, bb) and not c.ended for c in b.convs.values()):
            return
        L = lv["love"]
        night = bool(L.get("on"))
        acts = (lv["a"].get("act"), lv["b"].get("act"))
        if night:
            if time.time() < L.get("next_talk", 0):
                return
            radius, gap = float(getattr(self.cfg, "love_talk_metres", 18)), float(getattr(self.cfg, "love_talk_seconds", 10))
        else:
            if time.time() < lv["next_chat"] or "sleep" in acts:
                return
            radius, gap = float(getattr(self.cfg, "chat_metres", 25)), float(getattr(self.cfg, "chat_seconds", 35))
        pa, pb = b.game.ped(a), b.game.ped(bb)
        if min(pa.get("d", 99), pb.get("d", 99)) > radius:
            return
        if not night and math.hypot(pa.get("x", 0) - pb.get("x", 0), pa.get("y", 0) - pb.get("y", 0)) > 12:
            lv["next_chat"] = time.time() + 8               # too far apart to talk (one's out at the woodpile)
            return
        if night:
            L["next_talk"] = time.time() + 999            # set properly once the lines are said
        else:
            lv["next_chat"] = time.time() + 999
        ia, ib = b.memory.ids[rec["a"]], b.memory.ids[rec["b"]]
        lines = await self.lines(lv, ia, ib, night)
        for who, text, emo in lines:
            if b.ptt_ped or (night and not L.get("on")) or lv.get("alarm") or lv.get("caught") or lv.get("intruded"):
                break
            if b.dead(a) or b.dead(bb):
                break
            h, ident = (a, ia) if who == "a" else (bb, ib)
            dur = await b.say_line(h, ident, text, emo, gesture=not night)
            await asyncio.sleep(dur + 0.35)
        if night:
            L["next_talk"] = time.time() + random.uniform(gap * 0.7, gap * 1.3)
            L["talks"] = L.get("talks", 0) + 1
            L["changed"] = ""
        else:
            lv["next_chat"] = time.time() + random.uniform(gap * 0.7, gap * 1.4)

    def who_text(self, rec, ia, ib) -> str:
        def one(i):
            p = i.persona
            return (f"{p['first_name']} ({p['sex']}, {p['age']}, {p.get('temperament', '')}, speaks: {p.get('speech', '')}"
                    + (f", {p['wildcard']}" if p.get("wildcard") else "") + ")")
        rel = ("married" if rec["married"] else "courting") + (f" for {rec['years']} years" if rec["years"] else "")
        return f"{one(ia)} and {one(ib)}, {rel}; they met {rec['profile']['met']}"

    async def lines(self, lv, ia, ib, night: bool) -> list[tuple[str, str, str]]:
        b, rec = self.b, lv["rec"]
        A, B = ia.persona["first_name"], ib.persona["first_name"]
        if b.cfg.fake_ai:
            return ([("b", f"Come here, {A}...", "whisper"), ("a", f"Mmm, {B}.", "whisper")] if night else
                    [("a", f"Fine morning, {B}.", "happy"), ("b", "It is. Fetch me some water, would you?", "calm")])
        dow, hr = self.now()
        pr = rec["profile"]
        who = self.who_text(rec, ia, ib)
        diary = "; ".join(rec.get("diary", [])[-5:]) or "nothing yet"
        if night:
            L = lv["love"]
            k = L.get("talks", 0)
            if L.get("phase") == "rest":
                cue = random.choice(["they lie tangled together catching their breath - laughing, tender pillow talk",
                                     "resting in each other's arms, one of them tells a story: " + random.choice([pr["memory"], "a fantasy - " + random.choice([pr["fantasy_a"], pr["fantasy_b"]])]),
                                     "resting, sweet talk and teasing about how good that was and what's next"])
            elif L.get("changed"):
                cue = f"they just changed position ({L['changed']}) - one says what they want, the other answers"
            elif k % 4 == 3:
                who_tells = random.choice([(A, pr["fantasy_a"]), (B, pr["fantasy_b"])])
                cue = f"{who_tells[0]} whispers a fantasy as a little story while they move: {who_tells[1]}"
            else:
                cue = random.choice(["heated - moans that rise and fall, saying each other's names",
                                     "slow and loving - pet names, how much they want each other",
                                     "teasing - asking for more, faster or slower",
                                     "dirty talk, the way they both like it", "close to the edge - short breathless words"])
            setting = (f"Night, {hours_label(hr)}, in their own {rec['place']['kind']}, alone in their own bed - session "
                       f"{L.get('session', 1)} tonight. Their way together: {pr['style']}. What they both enjoy: "
                       f"{', '.join(pr['likes'])}. {A}'s secret fantasy: {pr['fantasy_a']}. {B}'s: {pr['fantasy_b']}.")
            user = (f"1899, the American frontier. {who}. {setting} Right now: {cue}. They are consenting adults who love "
                    f"and want each other. Write 1-3 short spoken lines between them (only what they SAY - no narration), "
                    f"each by {A} or {B}. "
                    'JSON only: {"lines":[{"who":"<first name>","say":"","emotion":"passionate|breathless|moan|whisper|'
                    'tender|playful|happy|surprised"}]} - the emotion is how the line SOUNDS right now: heated and '
                    'close to the edge = passionate/breathless/moan, slow = tender/whisper, teasing = playful.')
            explicit = True
        else:
            acts = [label(lv[r].get("act") or "", rec["seed"], r, dow) for r in ("a", "b")]
            joint = lv["a"].get("act") if lv["a"].get("act") == lv["b"].get("act") else ""
            topic = random.choice(TOPICS)
            cue = DAY_CUES.get(joint, "they talk while they work")
            user = (f"1899, the American frontier. {who}. It's {hours_label(hr)} at their {rec['place']['kind']}"
                    f"{' near ' + rec['place']['town'] if rec['place'].get('town') else ''}. {A} is {acts[0]}; {B} is "
                    f"{acts[1]}. {cue}. Topic: {topic}. Earlier today they talked about: {diary}. Write 2-4 short, "
                    f"natural spoken lines between them (only what they SAY), true to their personalities - warm, real, "
                    f"sometimes funny, sometimes flirting, sometimes bickering. Each by {A} or {B}. "
                    'JSON only: {"lines":[{"who":"<first name>","say":"","emotion":"happy|calm|sad|angry|surprised|whisper"}]}')
            explicit = joint == "cozy"
            rec.setdefault("diary", []).append(topic)
            rec["diary"] = rec["diary"][-12:]
        raw, _, _ = await asyncio.to_thread(b.ai.chat, [{"role": "system", "content": "You write short spoken lines for "
                                                         "adult characters in a mature western game."},
                                                        {"role": "user", "content": user}], explicit, 260, 0.95)
        out = []
        try:
            j = json.loads(re.search(r"\{.*\}", raw or "", re.S).group(0))
            for x in j.get("lines", [])[:4]:
                w = str(x.get("who", "")).split()[0].lower() if x.get("who") else ""
                role = "a" if w == A.lower() else "b" if w == B.lower() else ""
                say = re.sub(r"\*[^*]*\*|\([^)]*\)", "", str(x.get("say", ""))).strip()
                if role and say:
                    out.append((role, say[:240], str(x.get("emotion", "whisper" if night else "calm"))))
        except Exception:
            pass
        return out
