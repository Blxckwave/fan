"""The Director: makes the world feel alive with NPC-to-NPC scenes you can overhear.

Every second it looks at the people around the player. Now and then it casts two of them into a scene
(gossip, a married couple bickering, workers coming to blows, a cop stopping someone, a kid pestering a
neighbour, old friends going for a drink, a body being found...), asks the AI to write the dialogue for
exactly those two people (their personas, how they know each other, the town, the time, the rumours going
round), then plays it: walking up to each other, facing each other, voices + subtitles + facial moods +
gestures line by line, and an ending (part ways, walk off together, drink, fight, arrest, flee, kneel...).

Rare dark scenes: a serial killer lures a victim away and pulls a knife (adults only, never children).
Lawmen come and question the player when he's wanted for something people saw.

The player always has priority: pressing X pauses every scene; talking to an actor ends their scene and
they remember what they were doing.
"""
from __future__ import annotations

import asyncio
import json
import math
import random
import re
import time
import traceback
from dataclasses import dataclass
from typing import Callable

from . import world
from .log import log, turn as log_turn
from .persona import describe as describe_persona
from .surroundings import ERA, lore_line

ACTS = ["", "nod", "shake_head", "laugh", "point", "angry_gesture", "wave", "shrug", "sob", "tremble", "beckon",
        "spit", "calm_down", "thank", "tip_hat", "blow_kiss"]
EMOTES = {
    "nod": (0, "KIT_EMOTE_REACTION_NOD_HEAD_1"), "shake_head": (0, "KIT_EMOTE_REACTION_SHAKEHEAD_1"),
    "laugh": (0, "KIT_EMOTE_REACTION_JOVIAL_LAUGH_1"), "point": (1, "KIT_EMOTE_ACTION_POINT_1"),
    "angry_gesture": (0, "KIT_EMOTE_REACTION_HOW_DARE_YOU_1"), "wave": (3, "KIT_EMOTE_GREET_GENTLEWAVE_1"),
    "shrug": (0, "KIT_EMOTE_REACTION_SHRUG_1"), "sob": (0, "KIT_EMOTE_REACTION_SOB_1"),
    "tremble": (0, "KIT_EMOTE_REACTION_SCARED_1"), "beckon": (1, "KIT_EMOTE_ACTION_BECKON_1"),
    "spit": (1, "KIT_EMOTE_ACTION_SPIT_1"), "calm_down": (0, "KIT_EMOTE_REACTION_PHEW_1"),
    "thank": (0, "KIT_EMOTE_REACTION_THANKS_1"), "tip_hat": (3, "KIT_EMOTE_GREET_HAT_TIP_1"),
    "blow_kiss": (1, "KIT_EMOTE_ACTION_BLOW_KISS_1"),
}
SCRIPT_FORMAT = """Reply with ONE JSON object only:
{"lines": [{"who": "A" or "B", "say": "<spoken words, max 25 words>", "emotion": "<happy|sad|angry|fearful|disgusted|surprised|calm|fluent|whisper>", "act": "<one of: %s or empty>"}],
 "outcome": "<one of: %s>",
 "summary": "<one sentence: what happened, neutral>"}""" % ("|".join(a for a in ACTS if a), "%s")


@dataclass
class Cand:
    h: int
    p: dict           # raw nearby entry
    cls: dict         # PedDB.classify

    @property
    def adult(self):
        return not self.cls.get("child")

    @property
    def male(self):
        return bool(self.p.get("male"))

    @property
    def role(self):
        return self.cls.get("role") or "townsfolk"

    @property
    def busy(self):            # sitting / working in a scenario: don't drag them around
        return bool(self.p.get("scen"))


@dataclass
class Tpl:
    name: str
    weight: float
    desc: str
    outcomes: list
    cast: Callable
    rel: Callable              # (a, b) -> (A's view of B, B's view of A)
    lines: tuple = (4, 7)
    night_only: bool = False
    solo_ok: bool = False


def _d(a: dict, b: dict) -> float:
    try:
        return math.hypot(a["x"] - b["x"], a["y"] - b["y"])
    except (KeyError, TypeError):
        return 99.0


def pair(cands, pa, pb, maxd=14.0, rng=random):
    opts = [(a, b) for a in cands for b in cands
            if a.h != b.h and pa(a) and pb(b) and _d(a.p, b.p) <= maxd and not (a.busy and b.busy and _d(a.p, b.p) > 4)]
    return rng.choice(opts) if opts else None


ADULT = lambda c: c.adult and c.role not in ("lawman", "corpse")
LOCAL = lambda c: ADULT(c) and c.role not in ("outlaw", "drifter", "backwoods", "prostitute")


def rel_fixed(a_view, b_view):
    """(how A sees B, how B sees A); callables get (me, other)."""
    return lambda a, b: (a_view(a, b) if callable(a_view) else a_view, b_view(b, a) if callable(b_view) else b_view)


def spouse(x, y):
    return "your husband" if y.male else "your wife"


TEMPLATES = [
    Tpl("gossip", 10, "Two locals gossiping: town news, rumours, scandal, prices, the weather, the law, maybe the "
                      "rough stranger standing nearby. Lively, specific, a bit nosy.",
        ["part_ways", "walk_off_together"], lambda c, r: pair(c, LOCAL, LOCAL, rng=r),
        lambda a, b: (random.choice(["your neighbour", "a friend of yours", "someone you know from church"]),) * 2),
    Tpl("banter", 8, "Two friends joking around, teasing each other, telling a funny story, laughing.",
        ["part_ways", "walk_off_together", "go_drink"], lambda c, r: pair(c, ADULT, ADULT, rng=r),
        rel_fixed("your old friend", "your old friend")),
    Tpl("couple", 7, "A married couple out in town. Pick one: she nags him about drinking/money/the house, or they "
                     "argue about the kids, or they're sweet and teasing. Real marriage talk.",
        ["part_ways", "walk_off_together", "storm_off"],
        lambda c, r: pair(c, lambda x: LOCAL(x) and x.male, lambda x: LOCAL(x) and not x.male, rng=r),
        rel_fixed(spouse, spouse)),
    Tpl("kid_pester", 5, "A kid pestering a grown-up neighbour: cheeky questions, asking for a penny or candy, a prank, "
                         "teasing. The adult grumbles or scolds. Harmless and funny. Nothing violent.",
        ["kid_runs_off", "part_ways"], lambda c, r: pair(c, lambda x: not x.adult, LOCAL, rng=r),
        rel_fixed("a grumpy grown-up from your street", "a neighbour's brat")),
    Tpl("worker_quarrel", 4, "Two working men quarrel: unpaid money, a cheated card game, an insult to one's sister or "
                             "daughter, laziness on the job. It escalates. They may come to blows.",
        ["fight", "storm_off", "part_ways"],
        lambda c, r: pair(c, lambda x: ADULT(x) and x.male, lambda x: ADULT(x) and x.male, rng=r),
        rel_fixed("your workmate", "your workmate")),
    Tpl("reunion_drink", 4, "Two old friends meet again after years apart. Surprise, catching up on life, wives, kids, "
                            "the war, gold, troubles - and they decide to go have a drink.",
        ["go_drink", "walk_off_together"], lambda c, r: pair(c, ADULT, ADULT, maxd=18, rng=r),
        rel_fixed("an old friend you haven't seen in years", "an old friend you haven't seen in years")),
    Tpl("flirt", 4, "A man tries to court a woman: compliments, awkward charm. She's amused, flattered or annoyed.",
        ["walk_off_together", "part_ways", "storm_off"],
        lambda c, r: pair(c, lambda x: LOCAL(x) and x.male, lambda x: ADULT(x) and not x.male, rng=r),
        rel_fixed("a woman you fancy", "a man who keeps sweet-talking you")),
    Tpl("lovers", 4, "Two adults who fancy each other (lovers, a married pair, or strangers who just clicked): flirting, "
                     "teasing, touching, whispering what they want - and they decide to sneak off somewhere quiet together "
                     "right now. Sensual, playful, honest about desire.",
        ["sneak_off_love", "walk_off_together", "part_ways"],
        lambda c, r: pair(c, lambda x: ADULT(x) and x.role not in ("lawman", "guard", "clergy"),
                          lambda x: ADULT(x) and x.role not in ("lawman", "guard", "clergy"), rng=r),
        rel_fixed("someone you want", "someone you want")),
    Tpl("preacher", 3, "A preacher or zealot corners a passer-by about sin, drink and salvation. The other is "
                       "polite, mocking or moved.",
        ["part_ways", "storm_off"],
        lambda c, r: pair(c, lambda x: x.role == "clergy" or (ADULT(x) and r.random() < 0.08), LOCAL, rng=r),
        rel_fixed("a sinner you're trying to save", "a preacher who won't leave you alone")),
    Tpl("beggar", 3, "A poor, desperate person begs a passer-by for a few cents or work. The other gives, refuses or "
                     "lectures.",
        ["give_coin", "part_ways", "storm_off"],
        lambda c, r: pair(c, lambda x: x.role in ("drifter", "backwoods") or (ADULT(x) and r.random() < 0.06), LOCAL, rng=r),
        rel_fixed("a stranger with money", "a beggar")),
    Tpl("lawman_stop", 4, "A lawman stops someone in the street: questions about a theft, a missing horse, a fight, "
                          "where they were last night. The person sweats, lies, protests or tells the truth.",
        ["let_go", "frisk", "arrest", "suspect_flees"],
        lambda c, r: pair(c, lambda x: x.role in ("lawman", "guard"), ADULT, maxd=20, rng=r),
        rel_fixed("a suspect you stopped", "the lawman stopping you")),
    Tpl("drunk_trouble", 3, "A drunk man pesters someone at night: slurring, picking a fight or crying about his life.",
        ["fight", "part_ways", "storm_off"],
        lambda c, r: pair(c, lambda x: ADULT(x) and x.male, ADULT, rng=r),
        rel_fixed("someone you're bothering", "a drunk who's bothering you"), night_only=True),
    Tpl("haggle", 3, "A shopkeeper and a customer haggle over a price, a debt or bad goods.",
        ["part_ways", "storm_off"],
        lambda c, r: pair(c, lambda x: x.role in ("shopkeeper", "bartender"), LOCAL, rng=r),
        rel_fixed("a customer", "the shopkeeper")),
    Tpl("strangers_meet", 6, "Two strangers strike up a conversation: where are you from, what brings you here, a "
                             "shared complaint, an odd coincidence. By the end they know each other's names.",
        ["part_ways", "walk_off_together", "go_drink"], lambda c, r: pair(c, ADULT, ADULT, rng=r),
        rel_fixed("someone you just met", "someone you just met")),
    Tpl("outlaws_plan", 3, "Two outlaws plotting quietly: a stagecoach, a bank, a rival gang, a debt to settle - maybe "
                           "the stranger looks like an easy mark. They whisper.",
        ["walk_off_together", "part_ways"],
        lambda c, r: pair(c, lambda x: x.role == "outlaw", lambda x: x.role == "outlaw", maxd=18, rng=r),
        rel_fixed("your partner in crime", "your partner in crime")),
]
TPL = {t.name: t for t in TEMPLATES}


class Scene:
    def __init__(self, tpl, a: Cand, b: Cand | None, extra=None):
        self.tpl, self.a, self.b = tpl, a, b
        self.extra = extra or {}
        self.id = f"{tpl.name}-{int(time.time() * 1000) % 100000}"
        self.talking = True
        self.aborted = ""
        self.summary = ""
        self.ia = self.ib = None
        self.started = time.time()

    @property
    def actors(self):
        return [x.h for x in (self.a, self.b) if x]


class Director:
    def __init__(self, brain):
        self.b = brain
        self.rng = random.Random()
        self.scenes: list[Scene] = []
        self.last_scene = 0.0
        self.used: dict[int, float] = {}
        self.found_bodies: set[int] = set()
        self.kills: dict[int, dict] = {}          # ped handle -> info about a killing the player did
        self.killer_victims: dict[int, dict] = {}
        self.last_killer_day = -1.0
        self.last_law_call = 0.0

    # ── config ──
    @property
    def cfg(self):
        return self.b.cfg

    def talking_scene(self):
        return next((s for s in self.scenes if s.talking), None)

    def actor_scene(self, ped: int):
        return next((s for s in self.scenes if ped in s.actors), None)

    # ── called by the brain ──
    def on_player_engage(self, ped: int):
        s = self.actor_scene(ped)
        if s and not s.aborted:
            s.aborted = "the stranger walked up and spoke to them"
            log.info("[SCENE] %s interrupted by the player (talking to %d)", s.id, ped)
            return s
        return None

    def note_kill(self, h: int, desc: str, witnesses: int, seen_by=None):
        self.kills[h] = {"desc": desc, "witnesses": witnesses, "t": time.time(), "seen_by": set(seen_by or ())}

    # ── main loop (1 Hz) ──
    async def tick(self):
        if not self.cfg.scenes or not self.b.asi.up:
            return
        g = self.b.game
        if g.world.get("pause") or g.world.get("mission"):
            return
        now = time.time()
        # victims of the killer: discovered dead?
        for h, info in list(self.killer_victims.items()):
            p = next((x for x in g.near_peds if int(x.get("h", 0)) == h), None)
            if p and not p.get("alive", 1) and not info.get("dead"):
                info["dead"] = True
                world.add_deed(self.b.memory, g.place(), g.zone()["state"],
                               f"{info['name']} was found knifed to death outside {g.place()} - a killer is about",
                               3, g.game_minutes_total, 0, about_player=False)
                if info.get("killer_ident"):
                    k = info["killer_ident"]
                    k.d.setdefault("flags", {})["kills"] = k.d.get("flags", {}).get("kills", 0) + 1
                    k.dirty()
        if self.talking_scene():
            return
        if self.b.ptt_ped or self.b.talking_recently(45):
            return
        cands = self.candidates()
        # 0.5.1: when the game's OWN law is after you (wanted / lawmen fighting you) or people are still screaming and
        # running from a shooting, the game is already doing the talking - an AI lawman or AI bystanders on top of it
        # was a confusing double soundtrack ("lawmen talking vanilla and talking AI").
        if self.vanilla_busy():
            return
        # urgent: lawmen asking about what the player did
        if self.cfg.lawmen_question and now - self.last_law_call > 600:
            heat = world.heat(self.b.memory, g.place(), g.game_minutes_total)
            # 0.5.0: a lawman who just stopped someone in a scene can still come for YOU
            law = [c for c in self.candidates(ignore_used=True) if c.role == "lawman" and c.p.get("d", 99) < 35]
            if heat >= 3 and law:
                self.last_law_call = now
                asyncio.create_task(self.law_questions_player(self.rng.choice(law)))
                return
        # urgent: a body lying around that nobody has found yet
        body = self.body_to_find(cands)
        if body and now - self.last_scene > 8:
            self.start(*body)
            return
        cooldown = float(self.cfg.scene_cooldown)
        if now - self.last_scene < cooldown:
            return
        if self.rng.random() > 0.35:      # don't start a scene the very second the cooldown ends
            return
        night = (g.world.get("hr", 12) >= 20 or g.world.get("hr", 12) < 4)
        forced = [x for x in (self.b.env_force_scenes or []) if x]
        if forced:
            names = [forced[0]]
        else:
            names = [t.name for t in TEMPLATES if not t.night_only or night]
            if night and self.cfg.serial_killer and g.game_minutes_total - self.last_killer_day > 1200:
                names.append("serial_killer")
        weights = [TPL[n].weight if n in TPL else 2.5 for n in names]
        tried = set()
        for _ in range(6):
            name = self.rng.choices(names, weights)[0]
            if name in tried:
                continue
            tried.add(name)
            if name == "serial_killer":
                cast = self.cast_killer(cands)
                if cast:
                    if forced:
                        self.b.env_force_scenes.pop(0)
                    self.last_killer_day = g.game_minutes_total
                    self.start(KILLER_TPL, *cast)
                    return
                continue
            t = TPL[name]
            cast = t.cast(cands, self.rng)
            if cast:
                if forced:
                    self.b.env_force_scenes.pop(0)
                self.start(t, *cast)
                return

    def vanilla_busy(self) -> bool:
        g = self.b.game
        if g.player.get("wanted") or g.player.get("shoot"):
            self.last_chaos = time.time()
        fleeing = sum(1 for p in g.near_peds if p.get("alive", 1) and (p.get("flee") or p.get("comb")) and p.get("d", 99) < 40)
        if fleeing >= 2:
            self.last_chaos = time.time()
        return time.time() - getattr(self, "last_chaos", 0) < 20

    def candidates(self, ignore_used: bool = False) -> list[Cand]:
        g, now = self.b.game, time.time()
        busy = {c.ped for c in self.b.convs.values() if not c.ended}
        busy |= {h for s in self.scenes for h in s.actors}
        out = []
        for p in g.near_peds:
            h = int(p.get("h", 0))
            if not h or h in busy or (not ignore_used and now - self.used.get(h, 0) < 240):
                continue
            if not p.get("alive", 1) or p.get("flee") or p.get("comb") or p.get("mnt"):
                continue
            if p.get("d", 99) > self.cfg.scene_radius:
                continue
            cls = self.b.peddb.classify(int(p.get("m", 0)), bool(p.get("male")))
            if cls["story"] or cls["nonhuman"] or p.get("mission"):     # never touch script-owned people
                continue
            out.append(Cand(h, p, cls))
        return out

    def body_to_find(self, cands):
        g = self.b.game
        carried = {int(g.player.get("ch", 0)), int(g.player.get("hbh", 0))} - {0}
        for p in g.near_peds:
            h = int(p.get("h", 0))
            if p.get("alive", 1) or h in self.found_bodies or h in carried or p.get("d", 99) > 40:
                continue
            cls = self.b.peddb.classify(int(p.get("m", 0)), bool(p.get("male")))
            if cls["nonhuman"]:
                continue
            # 0.5.1: only someone you can actually SEE and hear finds it (close to you, in your line of sight) - 0.5.0
            # had voices from people you couldn't see talking about bodies; and one body scene every few minutes, not
            # four in a row after a shootout
            if time.time() - getattr(self, "last_body_scene", 0) < 150:
                return None
            finders = [c for c in cands if c.adult and _d(c.p, p) < 20 and c.role != "outlaw"
                       and c.p.get("d", 99) < 18 and c.p.get("los")]
            if not finders:
                continue
            self.last_body_scene = time.time()
            self.found_bodies.add(h)
            civil = [c for c in finders if c.role not in ("lawman", "guard")]
            a = min(civil or finders, key=lambda c: _d(c.p, p))      # ordinary folk find bodies; lawmen come to look
            law = [c for c in cands if c.role == "lawman" and c.h != a.h and _d(c.p, p) < 40]
            b = law[0] if law else None
            kill = self.kills.get(h)
            return (BODY_TPL, a, b, {"body": p, "body_cls": cls, "kill": kill})
        return None

    def cast_killer(self, cands):
        killers = [c for c in cands if c.adult and c.male and c.role not in ("lawman", "guard", "clergy", "outlaw")]
        victims = [c for c in cands if c.adult and c.role not in ("lawman", "guard", "outlaw")]
        self.rng.shuffle(killers)
        for k in killers:
            vs = [v for v in victims if v.h != k.h and _d(v.p, k.p) < 20]
            if vs:
                vs.sort(key=lambda v: (v.male, _d(v.p, k.p)))     # prefers a woman, then the closest
                return k, vs[0]
        return None

    # ── running a scene ──
    def start(self, tpl, a: Cand, b: Cand | None, extra=None):
        s = Scene(tpl, a, b, extra)
        self.scenes.append(s)
        self.last_scene = time.time()
        for x in s.actors:
            self.used[x] = time.time()
        log.info("[SCENE] start %s: A=%d(%s) B=%s", s.id, a.h, a.cls["model_name"],
                 f"{b.h}({b.cls['model_name']})" if b else "-")
        asyncio.create_task(self.run(s))

    def ident_for(self, c: Cand):
        g, mem = self.b.game, self.b.memory
        hid = self.b.handle_ident.get(c.h)
        if hid and hid in mem.ids:
            return mem.ids[hid]
        ident = mem.find(int(c.p.get("m", 0)), int(c.p.get("o", 0)), g.place(), set()) or \
            mem.create(int(c.p.get("m", 0)), int(c.p.get("o", 0)), c.cls, g.place(), g.game_minutes_total)
        self.b.handle_ident[c.h] = ident.id
        return ident

    def pos(self, h):
        return self.b.game.ped(h) or next((x for x in self.b.game.near_peds if int(x.get("h", 0)) == h), {})

    def alive(self, h):
        """Live tick data once they're an actor; until then (first moments) the surroundings scan."""
        p = self.b.game.ped(h)
        if p and time.time() - p.get("_t", 0) < 4:
            return bool(p.get("alive", 1))
        q = next((x for x in self.b.game.near_peds if int(x.get("h", 0)) == h), None)
        return bool(q) and bool(q.get("alive", 1))

    def prim(self, h, *p):
        self.b.asi.prim(h, "scene", tuple(p))

    async def wait_player_quiet(self, s, limit=25.0):
        t0 = time.time()
        while not s.aborted:
            sp = self.b.speaking
            player_busy = self.b.ptt_ped or (sp and not sp.get("scene")) or any(c.busy for c in self.b.convs.values())
            if not player_busy:
                return True
            if time.time() - t0 > limit:
                s.aborted = "the player kept talking"
                return False
            await asyncio.sleep(0.15)
        return False

    def check(self, s):
        if s.aborted:
            return False
        for h in s.actors:
            if not self.alive(h):
                s.aborted = "an actor is gone or dead"
                return False
            p = self.b.game.ped(h)
            if not p:
                continue
            if p.get("flee") or p.get("comb"):
                if s.tpl.name not in ("worker_quarrel", "drunk_trouble", "serial_killer") or s.talking:
                    s.aborted = "an actor panicked or started fighting"
                    log.info("[SCENE] %s: actor %d is %s", s.id, h, "fleeing" if p.get("flee") else "fighting")
                    return False
            if p.get("d", 0) > 70:
                s.aborted = "the player went too far away"
                return False
        return True

    async def run(self, s: Scene):
        rec = {"scene": s.id, "tpl": s.tpl.name}
        try:
            s.ia = self.ident_for(s.a)
            s.ib = self.ident_for(s.b) if s.b else None
            for h in s.actors:
                self.b.asi.send("actor", h, 1)
            # relationships, written into both memories
            if s.b:
                ra, rb = s.tpl.rel(s.a, s.b)
                self.relate(s.ia, s.ib, s.b, ra)
                self.relate(s.ib, s.ia, s.a, rb)
                rec["rel"] = [ra, rb]
            script_task = asyncio.create_task(self.write_script(s))
            await self.approach(s)
            script = await asyncio.wait_for(script_task, 25)
            rec["script"] = script
            if not script or not script.get("lines"):
                s.aborted = s.aborted or "no script"
            lines = script.get("lines", []) if script else []
            s.summary = (script or {}).get("summary", "")
            for i, ln in enumerate(lines):
                if not await self.wait_player_quiet(s) or not self.check(s):
                    break
                who = s.a if ln.get("who", "A") == "A" or not s.b else s.b
                other = s.b if who is s.a else s.a
                ident = s.ia if who is s.a else s.ib
                act = ln.get("act", "")
                if act in EMOTES and not (s.tpl.name == "serial_killer" and act == "blow_kiss"):
                    cat, em = EMOTES[act]
                    self.prim(who.h, "emote", cat, em, 0)
                if other:
                    self.prim(who.h, "look", 6000, f"t={other.h}")
                dur = await self.b.say_line(who.h, ident, ln.get("say", ""), ln.get("emotion", "fluent"),
                                            gesture=not act and not who.busy)
                t_end = time.time() + dur + 0.35
                while time.time() < t_end and not s.aborted:
                    if self.b.ptt_ped:              # the player started talking: stop this line now
                        break
                    if self.b.frozen:               # paused: the line waits with the game
                        f0 = time.time()
                        await self.b.wait_unfrozen()
                        t_end += time.time() - f0
                    await asyncio.sleep(0.1)
            s.talking = False
            outcome = (script or {}).get("outcome", "part_ways")
            allowed = [o for o in s.tpl.outcomes
                       if not (o == "accuse" and not (s.extra.get("kill") or {}).get("witnesses"))]
            if outcome not in allowed:
                outcome = allowed[0]
            rec["outcome"] = outcome
            if not s.aborted:
                await self.outcome(s, outcome)
            self.remember(s, outcome)
        except asyncio.TimeoutError:
            s.aborted = "script timed out"
        except Exception as e:
            log.error("[SCENE] %s crashed: %s\n%s", s.id, e, traceback.format_exc())
            rec["crash"] = repr(e)
        finally:
            s.talking = False
            rec["aborted"] = s.aborted
            log.info("[SCENE] end %s (%s)%s", s.id, s.tpl.name, f" – aborted: {s.aborted}" if s.aborted else "")
            for h in s.actors:
                c = self.b.convs.get(h)
                if c and not c.ended:      # the player is talking to them now: keep them
                    c.pending_events.append(("scene", f"You were in the middle of something ({s.tpl.name.replace('_', ' ')}"
                                                      f"{' with ' + (s.ib if h == s.a.h else s.ia).persona['name'] if s.b else ''})"
                                                      f" when this stranger interrupted you.", 2))
                if not self.b.couples.scene_of(h):      # 0.5.1: lovers who sneaked off stay in the couples' hands
                    self.b.asi.send("actor", h, 0)
            if s in self.scenes:
                self.scenes.remove(s)
            log_turn(rec)

    def relate(self, me, other_ident, other: Cand, rel: str):
        key = f"{int(other.p.get('m', 0)) & 0xFFFFFFFF:08x}-{int(other.p.get('o', 0)) & 0xFFFFFFFF:08x}"
        me.d.setdefault("relations", {})[key] = {"name": other_ident.persona["name"], "rel": rel,
                                                  "job": other_ident.persona["job"], "male": other.male}
        me.dirty()

    async def approach(self, s: Scene):
        if not s.b:
            return
        a, b = s.a, s.b
        mover, still = (b, a) if a.busy and not b.busy else (a, b)
        if _d(self.pos(a.h), self.pos(b.h)) > 2.4:
            self.prim(mover.h, "goto_player", 1.4, 1.0, f"t={still.h}")
            t0 = time.time()
            while time.time() - t0 < 14 and self.check(s):
                if _d(self.pos(a.h), self.pos(b.h)) <= 2.6:
                    break
                await asyncio.sleep(0.25)
        for x, y in ((a, b), (b, a)):
            if not x.busy:
                self.prim(x.h, "face", -1, f"t={y.h}")
            self.prim(x.h, "look", 10000, f"t={y.h}")

    async def write_script(self, s: Scene) -> dict:
        g = self.b.game
        if self.b.cfg.fake_ai:
            return self.fake_script(s)
        place, z = g.place(), g.zone()
        def who(c, ident, label):
            return (f"{label}: " + describe_persona(ident.persona).replace("\n", " ") +
                    (" Right now: busy working / sitting." if c.busy else ""))
        rel = ""
        if s.b:
            ra, rb = s.tpl.rel(s.a, s.b)
            rel = f"A sees B as {ra}. B sees A as {rb}."
        rum = world.rumours(self.b.memory, place, z["state"], g.game_minutes_total, s.ia.id, 3)
        stranger = ""
        pd = s.a.p.get("d", 20)
        if pd < 25:
            heat = world.heat(self.b.memory, place, g.game_minutes_total)
            stranger = (f"A rough-looking stranger (the player) stands about {pd:.0f} m away and can probably hear them"
                        + ("; people say he matches the description of someone who did something terrible here - they "
                           "might whisper about him or fall silent." if heat >= 3 else "."))
        lines_n = s.tpl.lines
        extra = body_prompt(s) if s.tpl.name == "body_found" else s.extra.get("prompt", "")
        sys_msg = ("You write short, natural, overheard dialogue for real people in 1899 America (the world of Red Dead "
                   "Redemption 2). Make it alive: specific names, places, small jokes, period slang, real emotions, "
                   "interruptions. No narration, no stage directions. Each line is something said out loud.")
        user = "\n".join(x for x in [
            f"Scene: {s.tpl.desc}", extra,
            who(s.a, s.ia, "A"), who(s.b, s.ib, "B") if s.b else "(A is alone, talking to themselves or calling out.)",
            rel,
            f"Where: {place}{', ' + z['state'] if z['state'] and z['state'] != place else ''}. {lore_line(place)}",
            f"When: {g.time_text()}. Weather: {z['weather'] or 'fair'}. {ERA}",
            ("Rumours going around: " + "; ".join(rum)) if rum else "",
            stranger,
            f"Write {lines_n[0]}-{lines_n[1]} lines.",
            SCRIPT_FORMAT % "|".join(s.tpl.outcomes),
        ] if x)
        raw, model, errs = await asyncio.to_thread(self.b.ai.chat, [{"role": "system", "content": sys_msg},
                                                                    {"role": "user", "content": user}],
                                                   s.tpl.name in ("lovers", "flirt"), 700, 0.95)    # lovers: the uncensored model
        log_turn({"scene_prompt": s.id, "user": user, "raw": raw, "model": model.get("model"), "errors": errs})
        try:
            j = json.loads(re.search(r"\{.*\}", raw or "", re.S).group(0))
        except Exception:
            log.warning("[SCENE] %s: unusable script: %r", s.id, (raw or "")[:200])
            return {}
        lines = []
        for ln in j.get("lines", [])[:lines_n[1] + 1]:
            if isinstance(ln, dict) and str(ln.get("say", "")).strip():
                lines.append({"who": "B" if str(ln.get("who", "A")).upper().startswith("B") and s.b else "A",
                              "say": re.sub(r"\*[^*]*\*|\([^)]*\)", "", str(ln["say"])).strip()[:220],
                              "emotion": str(ln.get("emotion", "fluent")).lower(), "act": str(ln.get("act", "")).lower()})
        return {"lines": lines, "outcome": str(j.get("outcome", "")), "summary": str(j.get("summary", ""))[:300]}

    def fake_script(self, s: Scene) -> dict:
        canned = {
            "worker_quarrel": [("A", "You owe me two dollars, Silas!", "angry", "angry_gesture"),
                               ("B", "I paid you Sunday, you drunk liar.", "angry", "spit"),
                               ("A", "Say that again!", "angry", "")],
            "serial_killer": [("A", "Evenin' miss, my wagon's stuck just past the trees. Could you lend a hand?", "calm", "beckon"),
                              ("B", "Well... alright, but quickly.", "calm", "nod")],
        }
        lines = canned.get(s.tpl.name, [("A", "Did you hear about the Braithwaites?", "whisper", "point"),
                                        ("B", "Lord, who hasn't. Shameful.", "surprised", "shake_head"),
                                        ("A", "And with the price of flour these days!", "angry", ""),
                                        ("B", "Ha! Don't get me started.", "happy", "laugh")])
        out = {"worker_quarrel": "fight", "serial_killer": "lure_kill", "reunion_drink": "go_drink",
               "lawman_stop": "arrest", "kid_pester": "kid_runs_off", "body_found": "kneel_grieve"}.get(s.tpl.name, s.tpl.outcomes[0])
        return {"lines": [{"who": w if s.b or w == "A" else "A", "say": t, "emotion": e, "act": a} for w, t, e, a in lines],
                "outcome": out, "summary": f"a {s.tpl.name.replace('_', ' ')}"}

    # ── endings ──
    async def outcome(self, s: Scene, oc: str):
        a, b = s.a, s.b
        P = self.prim
        log.info("[SCENE] %s outcome: %s", s.id, oc)
        if oc in ("part_ways", "let_go"):
            for x in s.actors:
                if not self.cand(s, x).busy:
                    P(x, "clear"); P(x, "wander")
        elif oc == "storm_off":
            P(a.h, "clear"); P(a.h, "wander")
            if b:
                P(b.h, "look", 4000, f"t={a.h}")
        elif oc == "walk_off_together":
            P(a.h, "clear"); P(a.h, "wander")
            if b:
                P(b.h, "clear"); P(b.h, "follow", 0.9, -0.6, 1.0, f"t={a.h}")
            await self.hold(s, 45)
            if b:
                P(b.h, "clear"); P(b.h, "wander")
        elif oc == "go_drink":
            dest = self.away_point(a.h, 14)
            P(a.h, "clear"); P(a.h, "goto_coord", *dest, 1.0)
            if b:
                P(b.h, "clear"); P(b.h, "follow", 0.9, -0.6, 1.0, f"t={a.h}")
            await self.hold(s, 18)
            for x in s.actors:
                P(x, "scenario", "WORLD_HUMAN_DRINKING", 70000)
            await self.hold(s, 70)
        elif oc == "fight" and b:
            for x in s.actors:
                P(x, "holster")
            P(a.h, "combat", f"t={b.h}"); P(b.h, "combat", f"t={a.h}")
            world.add_deed(self.b.memory, self.b.game.place(), self.b.game.zone()["state"],
                           f"{s.ia.persona['name']} and {s.ib.persona['name']} came to blows in the street", 1,
                           self.b.game.game_minutes_total, 1, about_player=False)
            await self.hold(s, 14)
            for x in s.actors:
                if self.alive(x):
                    P(x, "clear"); P(x, "wander")
        elif oc == "kid_runs_off":
            kid = a if not a.adult else b
            P(kid.h, "flee", 40, f"t={(b if kid is a else a).h}")
        elif oc == "give_coin" and b:
            self.b.asi.prim(b.h, "scene", ("emote", 0, "KIT_EMOTE_REACTION_THANKS_1", 0))
            self.b.asi.prim(a.h, "scene", ("emote", 0, "KIT_EMOTE_REACTION_NOD_HEAD_1", 0))
            await self.hold(s, 3)
            for x in s.actors:
                P(x, "clear"); P(x, "wander")
        elif oc == "frisk" and b:
            P(b.h, "hands_up", 8000, f"t={a.h}")
            await self.hold(s, 8)
            for x in s.actors:
                P(x, "clear"); P(x, "wander")
        elif oc == "arrest" and b:
            P(b.h, "hands_up", 6000, f"t={a.h}")
            await self.hold(s, 6)
            dest = self.away_point(a.h, 40)
            P(a.h, "clear"); P(a.h, "goto_coord", *dest, 1.0)
            P(b.h, "clear"); P(b.h, "follow", 0.0, -1.6, 1.0, f"t={a.h}")
            await self.hold(s, 40)
            for x in s.actors:
                P(x, "clear"); P(x, "wander")
        elif oc == "suspect_flees" and b:
            P(b.h, "flee", 120, f"t={a.h}")
            P(a.h, "goto_player", 1.5, 2.5, f"t={b.h}")
            await self.hold(s, 20)
            P(a.h, "clear"); P(a.h, "wander")
        elif oc == "kneel_grieve":
            body = s.extra.get("body") or {}
            law = next((x for x in (a, b) if x and x.role in ("lawman", "guard")), None)
            for i, x in enumerate(y for y in (a, b) if y):
                if body:
                    P(x.h, "goto_coord", body["x"] + 1.2 * i, body["y"], body["z"], 1.2)
            await self.hold(s, 8)
            for x in (y for y in (a, b) if y):
                self.b.asi.prim(x.h, "scene", ("scenario", "WORLD_HUMAN_CROUCH_INSPECT" if x is law
                                               else "WORLD_HUMAN_GRAVE_MOURNING_KNEEL", 25000))
            await self.hold(s, 20)
            kill = s.extra.get("kill") or {}
            if law and kill.get("witnesses") and time.time() - self.last_law_call > 60:
                self.last_law_call = time.time()
                asyncio.create_task(self.law_questions_player(law, reason=f"witnesses say you killed {kill.get('desc', 'this person')}"))
        elif oc == "accuse":
            body = s.extra.get("body") or {}
            accuser = a
            P(accuser.h, "look", 8000)            # at the player
            self.b.asi.prim(accuser.h, "scene", ("emote", 1, "KIT_EMOTE_ACTION_POINT_1", 0))
            law = b if b and b.role == "lawman" else None
            await self.hold(s, 3)
            if law:
                asyncio.create_task(self.law_questions_player(law, reason=f"{s.ia.persona['name']} just pointed at you and "
                                                              f"said you killed {s.extra.get('kill', {}).get('desc', 'someone')}"))
            else:
                P(accuser.h, "flee", 60)
        elif oc == "sneak_off_love" and b and s.ia and s.ib:
            dest = self.away_point(a.h, 22)
            P(a.h, "clear"); P(a.h, "goto_coord", *dest, 1.0)
            P(b.h, "clear"); P(b.h, "follow", 0.6, -0.5, 1.0, f"t={a.h}")
            await self.hold(s, 16)
            if self.alive(a.h) and self.alive(b.h) and not s.aborted:
                self.b.handle_ident[a.h] = s.ia.id
                self.b.handle_ident[b.h] = s.ib.id
                await self.b.couples.outdoor(a.h, b.h, s.ia, s.ib, *dest)
        elif oc == "lure_kill" and b:
            await self.serial_kill(s)

    def cand(self, s, h):
        return s.a if s.a.h == h else s.b

    async def hold(self, s, secs):
        t0 = time.time()
        while time.time() - t0 < secs and not s.aborted:
            if any(not self.alive(h) for h in s.actors):
                return
            await asyncio.sleep(0.25)

    def away_point(self, h, dist):
        """A point `dist` m from this ped, away from the player."""
        p, pl = self.pos(h), self.b.game.player
        try:
            dx, dy = p["x"] - pl["x"], p["y"] - pl["y"]
            ang = math.atan2(dy, dx) + self.rng.uniform(-0.5, 0.5)
            return (round(p["x"] + math.cos(ang) * dist, 2), round(p["y"] + math.sin(ang) * dist, 2), round(p["z"], 2))
        except (KeyError, TypeError):
            return (0.0, 0.0, 0.0)

    async def serial_kill(self, s: Scene):
        """The killer leads the victim somewhere quiet, pulls a knife and attacks. Adults only."""
        k, v = s.a, s.b
        P = self.prim
        dest = self.away_point(k.h, 70)
        P(k.h, "clear"); P(k.h, "goto_coord", *dest, 1.0)
        P(v.h, "clear"); P(v.h, "follow", 0.6, -1.8, 1.0, f"t={k.h}")
        log.info("[SCENE] %s: the killer leads %s towards %s", s.id, s.ib.persona["name"], dest)
        flags = s.ia.d.setdefault("flags", {})
        flags["serial_killer"] = True
        s.ia.dirty()
        self.killer_victims[v.h] = {"name": s.ib.persona["name"], "killer_ident": s.ia}
        t0 = time.time()
        while time.time() - t0 < 55 and self.alive(k.h) and self.alive(v.h):
            kp = self.pos(k.h)
            if _d(kp, {"x": dest[0], "y": dest[1]}) < 4:
                break
            await asyncio.sleep(0.5)
        if not (self.alive(k.h) and self.alive(v.h)):
            return
        P(k.h, "give_weapon", "WEAPON_MELEE_KNIFE")
        await asyncio.sleep(0.6)
        P(v.h, "clear")
        P(k.h, "combat", f"t={v.h}")
        P(v.h, "flee", 80, f"t={k.h}")
        log.info("[SCENE] %s: the killer pulls a knife on %s", s.id, s.ib.persona["name"])
        await self.hold(s, 25)
        if self.alive(k.h):
            P(k.h, "clear"); P(k.h, "wander")

    def remember(self, s: Scene, oc: str):
        g = self.b.game
        txt = s.summary or s.tpl.name.replace("_", " ")
        if s.aborted:
            txt += f" (cut short: {s.aborted})"
        for ident, other in ((s.ia, s.ib), (s.ib, s.ia)):
            if ident:
                ident.add_summary(f"[{s.tpl.name.replace('_', ' ')}{' with ' + other.persona['name'] if other else ''}] {txt} -> {oc}",
                                  g.game_minutes_total, g.place())

    # ── a lawman comes to question the player ──
    async def law_questions_player(self, law: Cand, reason: str = "", force: bool = False):
        g = self.b.game
        if not force:          # 0.4.0: never barge into a conversation you're having (cut off the wagon driver in 0.3.1)
            t0 = time.time()
            while self.b.talking_recently(30) and time.time() - t0 < 120:
                await asyncio.sleep(1)
            if self.b.talking_recently(30):
                log.info("[SCENE] lawman %d gives up waiting - you're busy talking", law.h)
                self.last_law_call = time.time() - 420      # try again in ~3 minutes
                return
        if not reason:
            deeds = [d for d in reversed(self.b.memory.player.get("deeds", []))
                     if d.get("player") and d["place"] == g.place() and d["witnessed"]]
            reason = ("people say a man matching his description " +
                      deeds[0]["what"].replace("THE_STRANGER ", "").replace("THE_STRANGER", "")) if deeds else "trouble"
        log.info("[SCENE] lawman %d comes to question the player: %s", law.h, reason)
        self.b.asi.send("actor", law.h, 1)
        self.prim(law.h, "goto_player", 2.2, 1.6)
        t0 = time.time()
        while time.time() - t0 < 25 and self.alive(law.h):
            if self.b.game.ped(law.h).get("d", 99) < 3.5:
                break
            await asyncio.sleep(0.3)
        self.b.asi.send("actor", law.h, 0)
        if not self.alive(law.h) or self.b.ptt_ped or (not force and self.b.talking_recently(8)):
            return
        conv = self.b.on_engage_req({"ped": law.h, "model": law.p.get("m"), "outfit": law.p.get("o"),
                                     "male": law.p.get("male"), "alive": 1, "human": 1}, reason="lawman")
        if conv:
            self.b.asi.send("engage_ok", law.h, conv.name)
            conv.pending_events.append(("questioning", f"You walked up to this stranger because {reason}. You are the law: "
                                                       "question him, watch his hands, decide if you take him in.", 3))
            await self.b.run_turn(conv, reaction=True)


BODY_TPL = Tpl("body_found", 30, "Someone finds a dead body lying in the open. Shock, fear, grief if they knew the dead; "
                                 "calling for help, wondering who did it.",
               ["kneel_grieve", "accuse", "part_ways"], lambda c, r: None,
               rel_fixed("someone who came running", "someone who found the body"), lines=(2, 3), solo_ok=True)
KILLER_TPL = Tpl("serial_killer", 2, "A quiet, friendly-seeming man (A) is secretly a serial killer. He sweet-talks B, "
                                     "a stranger, into coming with him to somewhere quiet (a broken wagon, a lost dog, "
                                     "a sick wife, work). B hesitates, then agrees. Nothing violent is said out loud.",
                 ["lure_kill"], lambda c, r: None, rel_fixed("your next victim", "a friendly stranger"), lines=(3, 5))


def body_prompt(s: Scene) -> str:
    body = s.extra.get("body_cls", {})
    kill = s.extra.get("kill")
    who = "a man" if (s.extra.get("body") or {}).get("male") else "a woman"
    from .surroundings import NAMES, key_of
    nm = (NAMES.get(key_of(s.extra.get("body") or {})) or {}).get("name", "")
    txt = f"The body is {who} ({body.get('model_job') or body.get('role') or 'a local'})" + \
          (f", {nm} - if A knew them, use exactly that name; never another one" if nm else
           " - nobody here knows the name: don't invent one") + ". Max 3 short lines, no speeches."
    if kill:
        saw = s.a.h in (kill.get("seen_by") or set())
        if saw:
            txt += (f" A SAW the stranger standing nearby kill them ({kill['desc']}) and may POINT at him and accuse him "
                    "out loud (outcome 'accuse').")
        else:
            txt += (" Nobody here saw who did it. The armed stranger nearby looks suspicious, but A is NOT sure and "
                    "doesn't accuse him outright.")
    return txt


