"""Brain settings from NpcVoice_brain.ini (created with defaults on first run)."""
from __future__ import annotations

import configparser
import os
from pathlib import Path

DEFAULTS = """\
; NpcVoice brain settings. Edit while the game runs, then restart npc_brain (the game can stay open).

[general]
; port the in-game NpcVoice.asi connects to (must match NpcVoice.ini)
port = 47812
; folder of your audio_interest_keys.json (relative to this file or absolute)
keys_file = audio_interest_keys.json
; 1 = more console output (the log file always has everything)
debug = 0
; 1 = no real STT/LLM/TTS calls (for testing the game side only)
fake_ai = 0

[conversation]
; conversation ends if you are further than this (metres) for end_far_seconds
end_far_metres = 20
end_far_seconds = 8
; conversation ends after this many seconds with no talking or events
end_idle_seconds = 45
; NPCs react on their own to big changes (gun drawn, hogtied, freed, hurt...)
reactions = 1
; minimum seconds between two unprompted reactions
reaction_cooldown = 7
; NPCs you met before may call out to you when they see you
recognition = 1
recognition_radius = 14
; chance (0-1) that a known NPC with strong feelings calls out when they see you
recognition_chance = 0.6

[world]
; NPC-to-NPC scenes you can overhear (gossip, couples, fights, cops, drinks, a body found...). Each line
; costs one AI voice call, so scenes use your MiniMax credit.
scenes = 1
; seconds between two scenes (a new scene never starts while another is still talking)
scene_cooldown = 40
; only people within this distance of you take part (so you can hear them)
scene_radius = 30
; very rare, at night: a man lures someone away and pulls a knife (adult victims only)
serial_killer = 1
; lawmen come and question you when people saw you do something bad in this town
lawmen_question = 1

[journeys]
; "lead me to your wife" / "let's find your brother": how far away the place can be (metres)
; 0.5.1: medium distance (was 700-2200, too far)
journey_min_metres = 250
journey_max_metres = 900
; the place is built when you get this close (the game only has the ground loaded near you)
journey_spawn_metres = 220

[couples]
; 0.5.1: couples you can find at home in bed (only at night or on a lazy afternoon, only in real houses/shacks/
; cabins from the database that are close to you). 0 = off
house_couples = 1
; chance (0-1) that a house you walk up to has a couple in bed (checked once per house per in-game day)
house_couple_chance = 0.35
; height of the mattress above the bed's own position (the clips are made for the floor); tune if they float/sink
bed_z_offset = 0.55
; crouch and stay out of sight and they don't notice you; walk in on them and they do
walk_in_metres = 6

[households]
; EVERY home on the map (house / shack / cabin / farmhouse) has its own couple with a whole day of their own:
; chores, meals at their own table, evenings on the porch, and from dark to dawn the night together in their bed
; (positions, breaks, pillow talk). Replaces the random house_couples above. 0 = off
households = 1
; their home is "lived" when you're this close (metres); you ride this far away and they're taken away again
household_metres = 70
household_despawn_metres = 140
; at most this many homes active around you at once (2 = four people)
household_max_live = 2
; also every house the database doesn't know: found by the game's own beds around you (not in hotels, saloons...)
discover_homes = 1
; how far around the house its furniture / chore spots are looked for
home_scan_metres = 22
; chance a home is two men or two women
same_sex_chance = 0.08
; daytime talk between them: every ~chat_seconds while you're within chat_metres (each line = one AI voice call)
chat_seconds = 35
chat_metres = 25
; at night: every ~love_talk_seconds while you're within love_talk_metres
love_talk_seconds = 10
love_talk_metres = 18
; average seconds in one position before they change (data/love_poses.json lists the positions)
pose_seconds = 90
; 0.5.8: you walk INTO their house (this close to its middle - the yard and porch don't count) in their sight:
; they notice you and speak up
intruder_metres = 4.5

[audio]
; NPC voice is full volume up to near_metres, silent at far_metres
near_metres = 3
far_metres = 35
master_volume = 1.0
; microphone: leave empty for the Windows default device
input_device =

[safety]
; These cannot be switched off. Listed here so you know they exist:
; - sexual content only with verified adult NPCs and never while they are tied,
;   held at gunpoint, surrendering, captive, scared of you, or very drunk
; - children: normal conversation only; threats make them run off
"""


class Config:
    def __init__(self, path: Path):
        self.path = path
        if not path.exists():
            path.write_text(DEFAULTS, encoding="utf-8")
        cp = configparser.ConfigParser(inline_comment_prefixes=(";",))
        cp.read_string(DEFAULTS)
        cp.read(path, encoding="utf-8")
        g, c, a = cp["general"], cp["conversation"], cp["audio"]
        self.port = g.getint("port")
        kf = Path(g.get("keys_file"))
        self.keys_file = kf if kf.is_absolute() else (path.parent / kf)
        self.debug = g.getboolean("debug")
        self.fake_ai = g.getboolean("fake_ai")
        self.end_far_m = c.getfloat("end_far_metres")
        self.end_far_s = c.getfloat("end_far_seconds")
        self.end_idle_s = c.getfloat("end_idle_seconds")
        self.reactions = c.getboolean("reactions")
        self.reaction_cooldown = c.getfloat("reaction_cooldown")
        self.recognition = c.getboolean("recognition")
        self.recognition_radius = c.getfloat("recognition_radius")
        self.recognition_chance = c.getfloat("recognition_chance")
        w = cp["world"]
        self.scenes = w.getboolean("scenes") if "NPCVOICE_SCENES" not in os.environ else os.environ["NPCVOICE_SCENES"] == "1"
        self.scene_cooldown = float(os.environ.get("NPCVOICE_SCENE_COOLDOWN", w.getfloat("scene_cooldown")))
        self.scene_radius = w.getfloat("scene_radius")
        self.serial_killer = w.getboolean("serial_killer")
        self.lawmen_question = w.getboolean("lawmen_question")
        jn = cp["journeys"]
        self.journey_min_m = float(os.environ.get("NPCVOICE_JOURNEY_MIN", jn.getfloat("journey_min_metres")))
        self.journey_max_m = float(os.environ.get("NPCVOICE_JOURNEY_MAX", jn.getfloat("journey_max_metres")))
        self.journey_spawn_m = jn.getfloat("journey_spawn_metres")
        cu = cp["couples"]
        self.house_couples = cu.getboolean("house_couples")
        self.house_couple_chance = float(os.environ.get("NPCVOICE_HOUSE_COUPLE_CHANCE", cu.getfloat("house_couple_chance")))
        self.bed_z_offset = cu.getfloat("bed_z_offset")
        self.walk_in_m = cu.getfloat("walk_in_metres")
        hh = cp["households"]
        self.households = hh.getboolean("households") if "NPCVOICE_HOUSEHOLDS" not in os.environ else os.environ["NPCVOICE_HOUSEHOLDS"] == "1"
        self.household_metres = hh.getfloat("household_metres")
        self.household_despawn_metres = hh.getfloat("household_despawn_metres")
        self.household_max_live = hh.getint("household_max_live")
        self.discover_homes = hh.getboolean("discover_homes")
        self.home_scan_metres = hh.getfloat("home_scan_metres")
        self.same_sex_chance = hh.getfloat("same_sex_chance")
        self.chat_seconds = hh.getfloat("chat_seconds")
        self.chat_metres = hh.getfloat("chat_metres")
        self.love_talk_seconds = hh.getfloat("love_talk_seconds")
        self.love_talk_metres = hh.getfloat("love_talk_metres")
        self.pose_seconds = float(os.environ.get("NPCVOICE_POSE_SECONDS", hh.getfloat("pose_seconds")))
        self.intruder_metres = hh.getfloat("intruder_metres", fallback=4.5)
        self.near_m = a.getfloat("near_metres")
        self.far_m = a.getfloat("far_metres")
        self.master_volume = a.getfloat("master_volume")
        self.input_device = a.get("input_device").strip() or None

    def dump(self) -> dict:
        return {k: (str(v) if isinstance(v, Path) else v) for k, v in vars(self).items()}
