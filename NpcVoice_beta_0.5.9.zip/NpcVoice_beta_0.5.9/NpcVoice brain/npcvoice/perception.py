"""Perception (0.5.8): what a person can really know about something that just happened.

From your 00:51+ game: you killed a woman inside, her husband was far away behind a wall, not looking - and he talked
about his wife's death as if he had watched it. Nobody knows what they can't see or hear:

- SAW IT: the game says this person has a clear line of sight to the victim (or to you, standing over the victim) and
  is close enough to make it out (< 60 m). They know who it was and who did it.
- HEARD IT: a loud weapon (a gun) within earshot (~160 m outside, less through walls), or a scream close by (< 25 m).
  They know there was a shot / a scream, roughly where - NOT who was hit. Kin close to the victim fear for them.
- NOTHING: a knife, a bow, a lasso far away, or simply too far: they don't know. They find out when they see the body
  (the director's body scenes) or someone tells them.

The line of sight comes from the plugin (`los` command, HAS_ENTITY_CLEAR_LOS_TO_ENTITY). An older plugin without it:
the last LOS the nearby scan saw (los / elos), else distance only.
"""
from __future__ import annotations

import asyncio
import math
import re

from .log import log

QUIET = re.compile(r"melee|knife|machete|hatchet|tomahawk|bow|arrow|lasso|thrown|unarmed|fishing|lantern|torch|binocular|"
                   r"kit_|camera|moonshine|bolas", re.I)
SEE_M = 60.0
GUN_HEAR_M = 160.0
SCREAM_HEAR_M = 25.0


def weapon_is_loud(brain, wpn) -> bool:
    """A gun is loud; knives, bows, lassos, fists are not."""
    try:
        h = int(wpn or 0) & 0xFFFFFFFF
    except (TypeError, ValueError):
        return True
    if not h:
        return True
    db = getattr(brain, "db", None)
    name = ""
    try:
        from .hashing import joaat
        cache = getattr(brain, "_wpn_names", None)
        if cache is None:
            cache = {}
            if db is not None and db.ok:
                for n, grp in (db._load("weapons", {}) or {}).items():
                    cache[joaat(n) & 0xFFFFFFFF] = f"{n} {grp}"
            brain._wpn_names = cache
        name = cache.get(h, "")
    except Exception:
        name = ""
    if not name:
        return True                                      # unknown: assume a gun (most kills are)
    return not QUIET.search(name)


class Perception:
    def __init__(self, brain):
        self.b = brain
        self.waiters: dict[int, asyncio.Future] = {}
        self.seq = 70000

    def on_los(self, m: dict):
        fut = self.waiters.pop(int(m.get("seq", 0)), None)
        if fut and not fut.done():
            fut.set_result(m)

    async def los(self, a: int, target: int, timeout: float = 1.5):
        """-> (sees, distance) from the plugin; None if the plugin can't answer."""
        caps = set((self.b.asi_info or {}).get("caps") or [])
        if "los" not in caps or not self.b.asi.up:
            return None
        self.seq += 1
        seq = self.seq
        fut = asyncio.get_running_loop().create_future()
        self.waiters[seq] = fut
        self.b.asi.send("los", seq, int(a), int(target))
        try:
            m = await asyncio.wait_for(fut, timeout)
        except asyncio.TimeoutError:
            return None
        finally:
            self.waiters.pop(seq, None)
        if not m.get("ok"):
            return None
        return bool(m.get("see")), float(m.get("d", -1))

    def where(self, h: int) -> dict:
        b = self.b
        p = b.game.ped(h) or {}
        if "x" in p:
            return p
        return next((x for x in b.game.near_peds or [] if int(x.get("h", 0)) == h), {}) or {}

    @staticmethod
    def dist(a: dict, b: dict) -> float:
        if not a or not b or "x" not in a or "x" not in b:
            return 999.0
        return math.dist((a["x"], a["y"], a.get("z", 0)), (b["x"], b["y"], b.get("z", 0)))

    def can_ask(self) -> bool:
        return "los" in set((self.b.asi_info or {}).get("caps") or []) and bool(self.b.asi.up)

    def _base(self, observer, victim, victim_pos, wpn):
        b = self.b
        me = self.where(observer)
        vp = dict(victim_pos or {}) or self.where(victim)
        d = self.dist(me, vp)
        if d >= 999:          # no positions: the scan's distance from the person you talk to ('de'), else from you
            d = float(vp.get("de", vp.get("d", me.get("d", 999))) or 999)
        pl = b.game.player or {}
        loud = weapon_is_loud(b, wpn if wpn is not None else pl.get("wpn"))
        return me, vp, d, pl, loud

    def _finish(self, observer, victim, saw, d, loud) -> dict:
        heard = ""
        if not saw:
            if loud and d < GUN_HEAR_M:
                heard = "shot"
            elif d < SCREAM_HEAR_M:
                heard = "scream"
        out = {"saw": bool(saw), "heard": heard, "d": round(d, 1), "loud": loud}
        log.info("[PERCEIVE] %d about %d's death: %s (%.0f m%s)", observer, victim,
                 "SAW IT" if saw else ("heard a " + heard) if heard else "knows nothing", d, ", gun" if loud else ", quiet")
        return out

    def death_guess(self, observer: int, victim: int, victim_pos: dict | None = None, wpn=None, engaged: bool = True) -> dict:
        """Without the plugin's line-of-sight answer: what the scans saw last. 'elos' on the victim = the line of sight
        from the person you talk to; 'los' = from YOU (you stand over the body, so close by that's a fair guess)."""
        me, vp, d, pl, loud = self._base(observer, victim, victim_pos, wpn)
        if "elos" in vp and engaged:
            saw = bool(vp.get("elos")) and d < SEE_M
        elif "los" in me:
            saw = bool(me.get("los")) and d < 18
        else:
            saw = d < 12
        return self._finish(observer, victim, saw, d, loud)

    async def death(self, observer: int, victim: int, victim_pos: dict | None = None, wpn=None, engaged: bool = True) -> dict:
        """What `observer` perceived of `victim` being killed just now -> {"saw", "heard": "shot"|"scream"|"", "d"}"""
        if not self.can_ask():
            return self.death_guess(observer, victim, victim_pos, wpn, engaged)
        me, vp, d, pl, loud = self._base(observer, victim, victim_pos, wpn)
        saw = False
        if d < SEE_M:
            r = await self.los(observer, victim)
            if r is not None and r[0]:
                saw = True
            elif d < 30:
                r2 = await self.los(observer, -1)                         # sees YOU standing over the body
                if r2 is not None:
                    saw = r2[0] and self.dist(vp, pl) < 6
                elif r is None:
                    return self.death_guess(observer, victim, victim_pos, wpn, engaged)
        return self._finish(observer, victim, saw, d, loud)
