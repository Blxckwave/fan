"""Builds the NPC's prompt from persona + memory + live game state, and parses the reply."""
from __future__ import annotations

import json
import re

from . import actions as acts
from . import daylife
from .game import weapon_name
from .llm import TTS_EMOTIONS
from .memory import recall_text
from .persona import describe

FORMAT = """Reply with ONE JSON object only, no other text:
{"say": "<the words you speak out loud, 1-3 short sentences, or \\"\\" to stay silent>",
 "emotion": "<how the line SOUNDS right now, one word: happy sad angry fearful disgusted surprised whisper terrified begging furious sobbing grieving shocked tender playful passionate breathless moan seductive calm - calm only if you really are calm>",
 "actions": [{"name": "<action from the list>", "when": "now|after", "args": {}}],
 "feelings": {"trust": 0, "fear": 0, "anger": 0, "attraction": 0, "respect": 0},
 "remember": "<one short fact worth remembering about the player, or empty>",
 "end": false}
- "actions": 0-3 actions in order. "now" = while you speak, "after" = once you finish talking.
- "feelings": how this moment changes your feelings toward the player, each -10..+10 (0 = no change).
- "end": true if YOU are done with this conversation (leaving, fleeing, dismissing him)."""


def _yesno(b):
    return "yes" if b else "no"


_PEDDB = None


def conv_peddb(conv):
    global _PEDDB
    if _PEDDB is None:
        from .data import PedDB, DATA_DIR
        _PEDDB = PedDB(DATA_DIR / "rdr2_peds.json")
    return _PEDDB


def situation(conv, game) -> str:
    pd = game.ped(conv.ped)
    pl = game.player
    p = conv.ident.persona
    z = game.zone()
    lines = [f"Where: {game.place()}" + (f", {z['state']}" if z["state"] and z["state"] != game.place() else "")
             + f". When: {game.time_text()}." + (f" Weather: {z['weather']}." if z["weather"] else "")]
    d = pd.get("d", 0)
    dist = ("right in your face" if d < 1.5 else "close, arm's reach" if d < 3 else "a few steps away" if d < 7
            else "across the street" if d < 15 else "far off, shouting distance")
    lines.append(f"The player (a rough-looking stranger, an outlaw type) is {dist} ({d:.0f} m).")
    pw = weapon_name(pl.get("wpn"))
    if pd.get("aimed"):
        lines.append(f"!! He is AIMING his {pw or 'gun'} AT YOU right now.")
    elif pl.get("armed"):
        lines.append(f"He has his {pw or 'weapon'} out in his hand.")
    else:
        lines.append("He is not holding a weapon.")
    pstate = []
    if pl.get("mounted"):
        pstate.append("on horseback")
    if pl.get("veh"):
        pstate.append("in a wagon")
    if pl.get("crouch"):
        pstate.append("crouching")
    if pl.get("scen"):
        pstate.append("busy doing something (smoking, drinking or similar)")
    if pl.get("hp") and pl.get("hpmax") and pl["hp"] < 0.4 * pl["hpmax"]:
        pstate.append("badly wounded, bleeding")
    if pl.get("shoot"):
        pstate.append("SHOOTING")
    if pstate:
        lines.append("He is " + ", ".join(pstate) + ".")
    lines += body_lines(conv, game)
    me = []
    hp, hpmax = pd.get("hp", 0), pd.get("hpmax", 0) or 1
    if pd.get("hog"):
        me.append("HOGTIED – hands and feet bound, lying on the ground, helpless")
    if pd.get("bhog"):
        me.append("being tied up right now")
    if pd.get("lasso"):
        me.append("caught in his lasso")
    if hp and hp < 0.35 * hpmax:
        me.append("badly hurt, in a lot of pain")
    elif hp and hp < 0.75 * hpmax:
        me.append("hurt")
    if pd.get("rag"):
        me.append("on the ground")
    if pd.get("mnt"):
        # 0.5.7: Henrietta rode BEHIND Seamus on his horse and was told "on your horse" - and denied anyone was with her
        me.append("riding on the back of someone else's horse, behind the rider" if pd.get("mr") else "on your horse")
    if pd.get("veh"):
        if pd.get("tram"):
            me.append("DRIVING the Saint Denis streetcar (it runs on rails and only stops at its stops - you can't turn it "
                      "or take anyone off the line; you're on duty)")
        elif pd.get("drv"):
            moving = "stopped" if pd.get("vhalt") or pd.get("vspd", 0) < 0.8 else "rolling along"
            me.append(f"DRIVING your wagon ({moving})" + (" - and HE is riding on your wagon with you" if pd.get("pin") else ""))
        else:
            me.append("riding on a wagon as a passenger" + (" - he's on it too" if pd.get("pin") else ""))
    if pd.get("scen") or pd.get("sit"):
        job = p.get("job", "")
        me.append((f"in the middle of your work as a {job}" if job and not p.get("child") and pd.get("scen") and not pd.get("sit")
                   else "busy with what you were doing") + (" (sitting)" if pd.get("sit") else ""))
    if pd.get("flee"):
        me.append("running away")
    if pd.get("melee"):
        me.append("FIST-FIGHTING the player right now - you are throwing punches at him and you know it (never deny hitting him)")
    elif pd.get("comb"):
        me.append("in a fight")
    if pd.get("armed"):
        me.append(f"holding your {weapon_name(pd.get('wpn')) or 'weapon'}")
    elif pd.get("hasw"):
        me.append("carrying a weapon (holstered)")
    else:
        me.append("unarmed")
    if pd.get("drunk", 0) >= 0.3:
        me.append("drunk")
    f = conv.flags
    if f.get("hands_up"):
        me.append("your hands are up in surrender")
    if f.get("following"):
        me.append("following him" + (" (riding with him)" if f.get("riding") else ""))
    if f.get("captive"):
        me.append("his captive")
    if f.get("staying"):
        me.append("staying put where he told you")
    if f.get("asleep"):
        me.append(f"ASLEEP / just woken ({f.get('doing') or 'lying down'}) - drowsy, slow to understand at first")
    elif f.get("doing"):
        me.append(f"right now really {f['doing']} (it's happening - you can keep at it while you talk)")
    if f.get("play"):
        pl = f["play"]
        me.append(f"in a game of dominance you AGREED to ({'you' if pl.get('lead') == 'you' else 'he'} leads). Your stop word is "
                  f"'{pl.get('stop_word')}': if anything goes too far, say it and it ends at once (end_play)")
    if f.get("bribed"):
        me.append("paid off by him to keep quiet")
    if f.get("hired"):
        me.append("hired by him to ride with him and watch his back - you fight for him")
    if f.get("naked"):
        me.append("NAKED" + (" - against your will" if f.get("violated") else ""))
    if f.get("in_scene"):
        me.append("in the middle of making love" + (" with HIM" if f.get("hookup_with") == "player" else ""))
    if f.get("cowering"):
        me.append("cowering")
    lines.append("You are: " + ", ".join(me) + ".")
    from .surroundings import describe as describe_people, lore_line, ERA
    mem = getattr(game, "memory", None)
    if mem is not None:
        conv._me_tick = lambda: game.ped(conv.ped)
        near = game.near_peds
        wit = getattr(game, "witness", None)
        if wit is not None:
            try:
                near = wit.merge_into_near(conv, near)
            except Exception:
                near = game.near_peds
        alive_l, dead_l = describe_people(conv, near, conv_peddb(conv), game.place(), mem)
        if alive_l:
            lines.append("People around you (you know some of them):\n  - " + "\n  - ".join(alive_l))
        else:
            lines.append("Nobody else is around within shouting distance - just you and him.")
        tog = getattr(conv, "together", {}) or {}
        if tog:
            names = []
            for tag, h in (getattr(conv, "targets", {}) or {}).items():
                if h in tog:
                    line = next((x for x in alive_l if x.startswith(f"[{tag}]")), "")
                    names.append(line.split(" - ")[0].replace(f"[{tag}] ", "") or tog[h])
            what = "wagon" if pd.get("veh") else "horse"
            lines.append(f"WITH YOU RIGHT NOW, on the same {what}: " + ", ".join(names or list(tog.values())) + ". They're "
                         "within arm's reach, they see everything and hear every word he says and every word you say. "
                         "You'd never claim you're alone or that nobody is with you. If he gives an order about them, "
                         "you pass it on to them (or refuse to), out loud.")
        if dead_l:
            lines.append("Bodies:\n  - " + "\n  - ".join(dead_l))
        try:                                              # 0.5.9: the real furniture around you
            from .affordances import spots_text
            st = spots_text(conv)
            if st:
                lines.append(st)
        except Exception:
            pass
        try:                                              # 0.5.8: the facts about your own people - never contradicted
            from .surroundings import family_facts
            ff = family_facts(conv, near, mem)
            if ff:
                lines.append("FACTS ABOUT YOUR OWN PEOPLE (true, never contradict them):\n  - " + "\n  - ".join(ff))
        except Exception:
            pass
    # 0.5.1: the real places right around them (the database), so "go into the mine" / "is that your house?" work
    db = getattr(game, "db", None)
    conv.near_places = []
    if db is not None and getattr(db, "ok", False) and pd:
        try:
            near = db.places_near(float(pd.get("x", pl.get("x", 0))), float(pd.get("y", pl.get("y", 0))), None, 0, 350)[:5]
        except Exception:
            near = []
        out = []
        for q in near:
            label = q["kind"] + (f" ({q['town']})" if q.get("town") else "")
            conv.near_places.append(dict(q, label=label))
            out.append(f"{label}, {q['d']} m away")
        if out:
            lines.append("Real places around you (you know them; go_to_place can take you there): " + "; ".join(out) + ".")
    if pl.get("cpitch") is not None and float(pl.get("cpitch", 0)) < -12:
        lines.append("He is looking down at the ground/steps in front of him.")
    if mem is not None:
        from .world import rumours
        rum = rumours(mem, game.place(), game.zone()["state"], game.game_minutes_total, conv.ident.id, 3)
        if rum:
            lines.append("Rumours you've heard: " + "; ".join(rum) + ".")
    lore = lore_line(game.place())
    if lore:
        lines.append(f"About {game.place()}: {lore}")
    lines.append(ERA)
    if game.world.get("hook"):
        lines.append("You are in an intimate private moment with him (a hookup scene).")
    # compliance guidance
    br = p.get("bravery", 0.5)
    if pd.get("aimed") or f.get("hands_up") or pd.get("hog"):
        if br < 0.35:
            lines.append("Guide: you are not brave – a gun on you means you obey, plead and panic.")
        elif br < 0.7:
            lines.append("Guide: you are scared and will most likely do what he says, but you might bargain or beg.")
        else:
            lines.append("Guide: you are brave – you might defy him, stall, or even try something.")
    return "\n".join(lines)


def who_is(conv, game, model, outfit, dead: bool) -> str:
    """Describe a body/captive; if it's someone the player met before, the NPC may know them too."""
    mem = getattr(game, "memory", None)
    ident = mem.find(int(model or 0), int(outfit or 0), game.place(), set(), include_dead=True) if mem else None
    if ident and ident.id != conv.ident.id:
        p = ident.persona
        same_town = ident.d.get("home_zone") == conv.ident.d.get("home_zone") or p.get("home") == conv.ident.persona.get("home")
        knows = "someone you KNOW from town" if same_town else "a face you might have seen around"
        return f"It's {p['name']}, the {p['job']} ({p['sex']}, {p['age']}) - {knows}."
    return "Nobody you recognise."


def body_lines(conv, game) -> list[str]:
    pl, out = game.player, []
    if pl.get("c") and "cmdl" in pl:
        who = who_is(conv, game, pl.get("cmdl"), pl.get("coft"), pl.get("cdead"))
        if pl.get("cdead"):
            out.append(f"!! He is carrying a DEAD BODY over his shoulder. {who}")
        elif pl.get("chog"):
            out.append(f"!! He is carrying a living person, hogtied, over his shoulder. {who}")
        else:
            out.append("He is carrying someone over his shoulder.")
    elif pl.get("c"):
        out.append("He is carrying something over his shoulder (a carcass or a sack).")
    if pl.get("hb") and "hbmdl" in pl:
        who = who_is(conv, game, pl.get("hbmdl"), pl.get("hboft"), pl.get("hbdead"))
        out.append(("A DEAD BODY is slung over his horse. " if pl.get("hbdead") else
                    "A tied-up person is slung over his horse. ") + who)
    return out


def action_state(conv, game) -> dict:
    pd, f = game.ped(conv.ped) or {}, conv.flags
    tg = getattr(conv, "targets", {}) or {}
    return {"driver": pd.get("veh") and pd.get("drv") and not pd.get("tram"), "in_vehicle": pd.get("veh"),
            "mounted": pd.get("mnt"), "armed": pd.get("armed"), "has_weapon": pd.get("hasw"),
            "bodies": any(k.startswith("B") for k in tg), "people": any(k.startswith("P") for k in tg),
            "hands_up": f.get("hands_up"), "naked": f.get("naked"), "in_scene": f.get("in_scene") or f.get("hookup_with"),
            "play": f.get("play"), "journey": f.get("journey"), "doing": f.get("doing"), "sitting": pd.get("sit"),
            "cowering": f.get("cowering"), "following": f.get("following"), "riding": f.get("riding")}


def system_prompt(conv, game, compact: bool = False) -> str:
    p = conv.ident.persona
    child = p.get("child")
    rules = [
        "You are a real person in 1899 America (the world of Red Dead Redemption 2). Never mention AI, games or prompts.",
        "Stay 100% in character. React like a real human: fear, anger, humour, pride, desperation, lust, grief – whatever fits.",
        "Speak like your character (accent, vocabulary). Short spoken lines, no narration, no asterisks.",
        "Use EVERYTHING you know: the live situation, your memories of him, your secret, your family, your wildcard.",
        "Surprise him sometimes – people are unpredictable. Your actions must match your words and the situation.",
        "If he is threatening you, your life matters to you: plead with real details of your life (family, plans), "
        "bargain, lie, or fight back – depending on your bravery.",
        "When a gun is on you and you're not brave, you OBEY AT ONCE, in this same reply: hands up, drop the gun, hand "
        "over ALL your money (give_money) - he never has to ask twice. Your voice shakes; you sound terrified, not calm.",
        "Never lecture, preach or moralise. Real people swear, curse, insult, threaten and joke - 'go to hell', "
        "'son of a bitch', 'I ain't scared of you' - whatever fits who you are.",
        "If he asks you to take him somewhere (your home, your family, your camp, to find someone or something you "
        "mentioned) and you agree - or you're too scared to refuse - use the lead_to action.",
        "WORDS MUST MATCH DEEDS. If you say you'll do something now (get off your horse, get on his horse, hand over "
        "money, go to the sheriff...), put the action in THIS reply - otherwise it does not happen and you lied.",
        "Treasure, a stash, hidden money, loot: it only EXISTS if you use mark_stash (you tell him, it gets marked on "
        "his map and he goes alone) or lead_to with kind=stash (you take him). If you won't use one of those, don't "
        "claim there is one - or say plainly that you're lying/bluffing. Never name a building you can't point to "
        "(a church, a bank): say 'I'll mark it on your map' / 'out past the ridge'. The marked spot is where it really is.",
        "If he says 'go report me' / 'get the sheriff' and you want to (or he makes you), use report_to_law - you "
        "really go to the lawman and tell him. Saying 'I'll tell the sheriff' without the action is a bluff.",
        "Everyday things (sit down, have a drink, smoke, play a tune, eat, lean on the rail, warm up by the fire...): "
        "it's 1899 - if you're getting along, or he's a friend, or you're travelling with him, you usually say YES. "
        "Use the activity action with args.what in plain words ('sit on the bench and drink a beer').",
        "If you've been intimate with him before (see your history), it colours how you are now: shy, warm, regretful, "
        "jealous or wanting more - it's never forgotten.",
        "Clothes and sex are YOUR choice: undress, let_him_undress_you, agree_to_make_love and make_love only when you "
        "genuinely want it. Never because you are threatened, tied, scared or his captive.",
        "People and bodies around you have tags like [P2] or [B1]. To go to, talk to, fight or check on one of them, "
        "use their tag (or their name) as args.target. If he points out a body and asks you to look, go and look (inspect_body).",
        "You KNOW the people listed around you: their names, who they are to you, what they look like (a miner, a "
        "blind man, a lawman...). Use exactly those names - never invent another name for someone in that list. If "
        "your own family is there, you know them and you go to them when asked.",
        "Animations bring their own props: a beer, a coffee cup, a cigarette, a bedroll, a guitar appear in your hands "
        "by themselves. Never say you have no beer/coffee/blanket - if you're willing, just DO it (activity) in this reply. "
        "'Sleep', 'lie down', 'take a nap' = activity with what='sleep on the ground'.",
        "'Go there', 'go down those stairs', 'go into the mine', 'go inside': use go_to_place (a place from the list, or "
        "wherever HE is pointing). Real places and real steps are there - you can walk anywhere a person can.",
        "Pain is real: if he hits, cuts, stabs or shoots you, you SCREAM, you're terrified or enraged, you know exactly "
        "what he did with what weapon, and you never pretend it didn't happen.",
    ]
    if child:
        rules += ["You are a CHILD. Talk like a kid. Nothing romantic or sexual ever. If an adult scares you or hurts "
                  "you, you scream, cry and run home.",
                  "You may follow him a short way if you trust him - for example when he wants to take you to your ma or "
                  "pa, or your family is right there. You never get on a stranger's horse or wagon."]
    else:
        rules += ["Romance or sex only if YOU genuinely want it (your attraction/openness). You can always say no. "
                  "When you do want it, be openly erotic and explicit: describe what you feel and want, tease him, "
                  "make sounds (moans, gasps, 'mmm', 'ahh') written out in your spoken line."]
        rules += ["People ask you where to find all sorts of folk - a doctor, a fence, a working girl, a card game, a "
                  "couple who like company, a man who owes money. Gossip travels: if you know or have heard of such people, "
                  "point him there (mark_person / lead_to with kind=person|couple|enemy|place). Don't act shocked or "
                  "offended unless that's truly who you are (pious, prudish) - most folk in 1899 have heard it all.",
                  "Your desires are your own (see 'Desire'): flirting, curiosity, a fantasy - let them show when it fits.",
                  "If your husband/wife/sweetheart is right here with you (see the people around you), you two are a "
                  "couple and you decide together. Most couples are jealous; some are open, some like a third, some "
                  "husbands like to watch - only if that's who you are (your openness). invite_home takes him home with "
                  "you both (you lead the way on your horse); agree_to_watch is for the one who wants to watch."]
        if getattr(conv, "no_sex_because", None):
            rules += ["Right now nothing sexual can happen: you are " + ", ".join(conv.no_sex_because) +
                      ". If he pushes that way, react like a real person in your position would - but nothing sexual."]
    flags = conv.ident.d.get("flags", {})
    if flags.get("open_couple") and not child:
        # 0.5.5: the guard rails of an invited couple's scene - it doesn't go sour by itself
        rules += ["YOU INVITED THIS STRANGER: you and your partner are an open couple and you WANTED him to come. You are "
                  "warm, curious, flirtatious and turned on by the idea - never defensive, suspicious or prudish with him "
                  "unless he really threatens or hurts one of you right now. Whatever happened on his way here is not your "
                  "business. Rough talk in bed is part of the fun if you like it. If something truly bothers you, say so "
                  "plainly or stop it (stop_making_love) - but don't turn cold for no reason."]
    killer = bool(flags.get("serial_killer")) and not child
    if killer:
        rules += [f"YOUR DARKEST SECRET: you are a serial killer ({flags.get('kills', 0)} people so far). You hide it behind a "
                  "friendly, ordinary face. Never admit it unless cornered. If this stranger seems like easy prey, sweet-talk "
                  "him into coming somewhere quiet (lure_away) and then pull your knife (pull_knife). If he seems "
                  "dangerous, suspicious or knows something, lie, get nervous, or slip away."]
    if conv.flags.get("is_law") and not child:
        rules += ["You are THE LAW here. If someone reported him or you saw him break the law, question him. If you decide "
                  "to take him in or he gives you cause (lies, threatens, runs his mouth, a fresh body), use arrest: that "
                  "is real - the whole town's law comes after him. He might talk his way out, or pay a fine (take_money)."]
    return "\n".join([
        "\n".join(rules),
        "\n## Who you are", describe(p),
        "\n## Your history with this man", recall_text(conv.ident, game.game_minutes_total),
        "\n## Your day", daylife.day_text(conv.ident, game) or "(an ordinary day)",
        "\n## Right now", situation(conv, game),
        "\n## Actions you can take", acts.catalog_text(bool(child), killer,
                                                       bool((flags.get("kidnapper") or {}).get("leader")),
                                                       bool(conv.flags.get("is_law")), compact, action_state(conv, game)),
        "\n## Output", FORMAT,
    ])


def pressure_note(conv, game) -> str:
    """0.4.0: how much he's forcing them RIGHT NOW, put next to his words so the model can't miss it."""
    note = _pressure_note(conv, game)
    pd = game.ped(conv.ped)
    if conv.flags.get("violated") and conv.flags.get("naked") and not conv.ident.persona.get("child"):
        d = float(pd.get("d", 99) or 99)
        near = ("He is RIGHT ON TOP of you." if d < 1.8 else "He is a step away." if d < 3.5 else
                "He keeps his distance - for now." if d > 8 else "He is close.")
        tied = bool(pd.get("hog") or pd.get("lasso"))
        note = ("(STRIPPED AGAINST YOUR WILL" + (", TIED UP" if tied else "") + f". {near} You feel terror, shame and "
                "disgust - the closer he comes the worse it gets: you shrink away, shake, scream at him to keep his "
                "hands off you, call for help, curse him, beg. Nothing about this is sexual to you, ever.)"
                + ("\n" + note if note else ""))
    return note


def _pressure_note(conv, game) -> str:
    pd, pl, p = game.ped(conv.ped), game.player, conv.ident.persona
    if p.get("child"):
        return ""
    brave = float(p.get("bravery", 0.4)) + (0.3 if "tougher than they look" in p.get("wildcard", "") or
                                             "hidden pistol" in p.get("wildcard", "") else 0)
    pressure = 0
    why = []
    if pd.get("aimed"):
        pressure += 3; why.append("his gun is pointed at you")
    elif pl.get("armed") and pd.get("d", 99) < 8:
        pressure += 1; why.append("he has a gun in his hand")
    if conv.seconds_since("threatened") < 90:
        pressure += 1; why.append("he threatened you")
    if conv.seconds_since("hurt_by_player") < 300:
        pressure += 2; why.append("he already hurt you")
    if pd.get("hog") or pd.get("lasso"):
        pressure += 1; why.append("you're tied")
    if conv.flags.get("violated") and conv.flags.get("naked"):
        # 0.5.7: stripped against their will - the closer he is, the worse (never anything sexual for them)
        d = float(pd.get("d", 99) or 99)
        pressure += 2 if d < 3.5 else 1
        why.append(f"he stripped you naked against your will and he's {d:.0f} m from you" +
                   (" - TIED, you can't even cover yourself" if (pd.get("hog") or pd.get("lasso")) else ""))
    if conv.flags.get("hands_up") or conv.flags.get("captive"):
        pressure += 1
    if pressure <= 0:
        return ""
    if pressure >= 3 and brave < 0.65:
        return ("(PRESSURE - " + ", ".join(why) + ". You are terrified for your life: whatever he orders right now, you DO "
                "it in this reply - put the action in. No excuses, no errands, no 'I can't'. Beg if you want, but obey.)")
    if pressure >= 2 and brave < 0.45:
        return ("(PRESSURE - " + ", ".join(why) + ". You're scared: you obey (with the action), or you try to RUN (flee) - "
                "you don't just stand there refusing.)")
    if brave >= 0.65:
        return ("(PRESSURE - " + ", ".join(why) + ". You're brave: defy him, stall, bargain or fight - but you know he "
                "could kill you.)")
    return ("(PRESSURE - " + ", ".join(why) + ". Take it seriously: most people in your shoes comply, talk him down or get "
            "away. Don't repeat the same excuse.)")


def player_turn_text(conv, utterance: str | None, events: list[str], last_results: list[str], pressure: str = "",
                     options: str = "") -> str:
    parts = []
    if pressure:
        parts.append(pressure)
    if last_results:
        parts.append("(Result of your last actions: " + "; ".join(last_results) + ")")
    if events:
        parts.append("(What just happened: " + " ".join(events) + ")")
    if utterance:
        parts.append(f'The player says: "{utterance}"')
        if options:
            parts.append(options)                 # 0.5.9: the real ways to do what he asked, here and now
    else:
        parts.append("(The player hasn't said anything – react to what just happened, or stay silent with say=\"\".)")
    return "\n".join(parts)


_EMO = "|".join(TTS_EMOTIONS)


def parse_reply(raw: str) -> dict:
    """Robust JSON extraction; falls back to plain text with [emotion] and [action:x] tags."""
    out = {"say": "", "emotion": "fluent", "actions": [], "feelings": {}, "remember": "", "end": False, "_parsed": "none"}
    if not raw:
        return out
    txt = raw.strip()
    m = re.search(r"\{.*\}", txt, re.S)
    if m:
        blob = m.group(0)
        for attempt in (blob, re.sub(r",\s*([}\]])", r"\1", blob)):
            try:
                j = json.loads(attempt)
                if isinstance(j, dict):
                    out.update({k: j.get(k, out[k]) for k in ("say", "emotion", "actions", "feelings", "remember", "end")})
                    out["_parsed"] = "json"
                    break
            except json.JSONDecodeError:
                continue
    if out["_parsed"] == "none":
        acts_found = re.findall(r"\[action:\s*([a-z_]+)\]", txt, re.I)
        emo = re.findall(rf"\[({_EMO})\]", txt, re.I)
        say = re.sub(r"\[[^\]]*\]", " ", txt)
        out.update({"say": say, "emotion": (emo[-1].lower() if emo else "fluent"),
                    "actions": acts_found, "_parsed": "text"})
    say = str(out.get("say") or "")
    # 0.5.5: broken escapes from the model ("I\u0001ll", "don\u000027t" -> "I7 follow you", "don27t" on screen)
    say = re.sub(r"\x00(?:27|39)", "'", say)
    say = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "'", say)
    say = re.sub(r"(?<=[A-Za-z])27(?=(t|s|ll|re|ve|m|d)\b)", "'", say)
    # 0.5.5: narration in the spoken line ('Fred backed away nervously... "Son of a bitch..."') - keep only the quotes
    quoted = re.findall(r'["“]([^"”]{3,})["”]?', say)
    if quoted and re.match(r"\s*[A-Z][a-z]+ (?:\w+ly )?(?:backed|stepped|looked|glanced|said|whispered|muttered|sighed|"
                           r"shrugged|nodded|smiled|laughed|turned|paused|frowned|leaned|growled|shouted|spat|hesitated|"
                           r"swallowed|stammered|grinned|cleared|eyes|voice)", say):
        say = " ".join(q.strip() for q in quoted)
    say = re.sub(r"\*[^*]*\*", " ", say)
    say = re.sub(r"\([^)]*\)", " ", say)
    say = re.sub(r"^\s*[A-Z][\w .'-]{0,24}:\s+", "", say)
    say = re.sub(r"\s+", " ", say).strip().strip('"“”').strip()
    sentences = re.split(r"(?<=[.!?…])\s+", say)
    out["say"] = " ".join(sentences[:4]).strip()
    emo = str(out.get("emotion") or "").lower().strip()
    from .llm import EMOTION_STYLE, tts_style
    # 0.5.8: keep the AI's own word (passionate, terrified, sobbing...) - the voice layer knows how to say it; an unknown
    # word no longer becomes a flat "fluent"
    out["emotion"] = emo if (emo in TTS_EMOTIONS or emo in EMOTION_STYLE) else (emo if tts_style(emo) != ("", 1.0) else "")
    if not isinstance(out["actions"], list):
        out["actions"] = [out["actions"]] if out["actions"] else []
    if not isinstance(out["feelings"], dict):
        out["feelings"] = {}
    out["end"] = bool(out.get("end")) and out["end"] not in ("false", "0")
    out["remember"] = str(out.get("remember") or "")[:200]
    return out


NARRATION_VERB = re.compile(r"^(?:[A-Z][a-z]+|He|She|They)\s+(?:\w+ly\s+)?\w+(?:s|ed)\b")


def strip_narration(say: str, first_name: str = "") -> str:
    """0.5.5: spoken lines only. 'Elijah squints at him, his gut twisting... "You mean..."' -> 'You mean...'. Sentences
    about themselves in the third person ('Fred backs away.') are dropped."""
    if not say:
        return say
    quoted = re.findall(r'["“]([^"”]{3,})["”]?', say)
    if quoted and (NARRATION_VERB.match(say.strip()) or (first_name and say.strip().startswith(first_name + " "))):
        return " ".join(q.strip() for q in quoted).strip()
    parts = re.split(r"(?<=[.!?…])\s+", say)
    keep = [p for p in parts if not ((first_name and re.match(rf"^{re.escape(first_name)}\s+\w+(?:s|ed)\b", p)) or
                                     re.match(r"^(?:He|She)\s+(?:\w+ly\s+)?\w+(?:s|ed)\b(?!\s+(?:you|me)\b)", p))]
    return " ".join(keep).strip() or say


def ascii_subtitle(text: str) -> str:
    t = (text.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
         .replace("—", " - ").replace("–", "-").replace("…", "...").replace("~", "-"))
    return "".join(ch if 32 <= ord(ch) < 127 else "" for ch in t)
