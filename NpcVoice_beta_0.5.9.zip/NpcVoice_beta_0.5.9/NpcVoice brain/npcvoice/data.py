"""Static game data: ped DB (by model hash), zones, weather, gestures, moods, emotes, scenarios."""
from __future__ import annotations

import json
import re
from pathlib import Path

from .hashing import joaat

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def _load(name, default):
    p = DATA_DIR / name
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return default


# ── ped classification ───────────────────────────────────────
# 0.5.1: ONLY real children. 0.5.0 also matched "son"/"daughter" in model names, so U_M_Y_CzPHomesteadSon_02 - a grown
# young man in the game - was treated as a child: invincible, couldn't be hurt or argued with, "the kid runs off".
# The game's homestead/ranch "son"/"daughter" models are young ADULTS (the ped list says age 'Young', like every 18-26
# model). Kids are the street kids, the newspaper boy, the starving shack kid and the story children.
CHILD_PED = re.compile(
    r"streetkid|starvingkid|mixedracekid|_kid_|kids_|newspaperboy|wapitiboy|the_boy|jackmarston|childr?e?n?\b|_child"
    r"|teens_|_teen\b|orphan|baby|infant|schoolgirl|schoolboy|littlegirl|littleboy", re.I)
STORY_PED = re.compile(r"^(cs_|player_|mp_u_|cs_mp_)", re.I)
NON_HUMAN = re.compile(r"saddle|_dogs?_|horse|^a_c_|animal_", re.I)
PLAYER_MODELS = {joaat("player_zero"), joaat("player_three")}

REGION_CODES = {
    "val": "Valentine", "rhd": "Rhodes", "blw": "Blackwater", "sd": "Saint Denis", "nbx": "Saint Denis",
    "str": "Strawberry", "asb": "Annesburg", "ann": "Annesburg", "vht": "Van Horn", "arm": "Armadillo",
    "tum": "Tumbleweed", "emr": "Emerald Ranch", "caj": "the bayou", "lag": "Lagras", "wap": "Wapiti",
    "bvn": "Big Valley", "grz": "the Grizzlies", "hrt": "Heartlands", "ros": "Roanoke", "scm": "Scarlett Meadows",
    "blu": "Bluewater Marsh", "bay": "Bayou Nwa", "gua": "Guarma", "cor": "Cornwall", "riv": "Riggs Station",
}
ROLE_HINTS = [
    (r"prostitute|whore", "prostitute", "works at the saloon upstairs; direct, businesslike, names a price"),
    (r"sheriff|deputy|police|lawrural|pinlaw|pinkerton|marshal|lawman|lawmen|_law_", "lawman",
     "law enforcement (police / deputy); suspicious, authoritative, carries a badge and a gun"),
    (r"guard", "guard", "an armed guard (bank, train, coach or prison); watchful, gruff"),
    (r"doctor|nurse", "doctor", "town doctor; practical, busy"),
    (r"bartender|barkeep", "bartender", "tends bar; has seen it all"),
    (r"shopkeep|storeowner|butcher|baker|fence|gunsmith|trapper|tailor|barber", "shopkeeper", "runs a business"),
    (r"priest|preacher|nun|_rev", "clergy", "a person of the cloth"),
    (r"odriscoll|lemoyneraider|murfree|skinner|delloboparty|laramie|_g_m_|_g_f_|gang|bandit|outlaw", "outlaw",
     "rides with a gang; dangerous, quick to threaten"),
    (r"army|soldier|exconfed", "soldier", "soldier or veteran; blunt, bitter"),
    (r"miner|lumberjack|railworker|dockworker|laborer|labourer|construct|cotton|worker", "labourer",
     "manual labourer; tired, rough"),
    (r"cowboy|rancher|cattle|wrangler|farmer|homestead|ranch", "rancher", "works the land"),
    (r"hillbilly|swamp|inbred|moonshine", "backwoods", "backwoods folk; hostile to outsiders"),
    (r"upperclass|fancy|gentleman|aristocrat|wealthy|rich", "gentry", "upper class; refined, condescending"),
    (r"traveller|traveler|tourist|drifter|vagrant|hobo|beggar|tramp", "drifter", "on the road; poor, wary"),
    (r"townfolk|resident|citizen|cityfolk|crowd|loafer", "townsfolk", "ordinary resident"),
    (r"corpse|dead", "corpse", "a dead body"),
]


# what the model name itself says about the person (job / look) - the brain uses it for their job and so others can
# describe them ("the miner", "the blind man") - 0.5.1
MODEL_JOBS = [
    (r"miner", "coal miner", "a miner in soot-black work clothes"),
    (r"lumberjack", "lumberjack", "a lumberjack"),
    (r"railworker|rail_?worker", "railroad worker", "a railroad worker"),
    (r"dockworker|dockforeman", "dock worker", "a dock worker"),
    (r"laborer|labourer|lnsworker|_worker|cghworker|bwmworker|bivworker|htlworker|mapworker|cktworker", "labourer",
     "a working man in rough clothes"),
    (r"foreman", "foreman", "a foreman"),
    (r"cowpoke|cowboy|wtccowboy", "cowhand", "a cowhand"),
    (r"rancher|farmhand|homestead|farmer|farmtravelers", "farmer", "a farm hand"),
    (r"bartender", "bartender", "a bartender"),
    (r"doctor", "doctor", "the doctor"),
    (r"undertaker", "undertaker", "the undertaker"),
    (r"gunsmith", "gunsmith", "the gunsmith"),
    (r"butcher", "butcher", "a butcher"),
    (r"barber", "barber", "the barber"),
    (r"tailor", "tailor", "the tailor"),
    (r"photographer", "photographer", "a photographer"),
    (r"genstoreowner|generalstoreowner", "general store owner", "the shopkeeper"),
    (r"hotelowner", "hotel owner", "the hotel owner"),
    (r"bankclerk", "bank clerk", "a bank clerk"),
    (r"trainstationworker|stationclerk|ticketseller|conductor", "railway clerk", "a railway clerk"),
    (r"preacher|priest", "preacher", "a preacher"),
    (r"prostitute|whore", "working girl", "a working girl"),
    (r"musician|fiddle|stringquartet", "musician", "a musician"),
    (r"marketvendor|customvendor|dealer", "street vendor", "a vendor"),
    (r"trapper", "trapper", "a trapper"),
    (r"huntertravelers|hunter", "hunter", "a hunter"),
    (r"sailor|boatcrew|skiffdriver|captain", "sailor", "a sailor"),
    (r"graverobber", "grave robber", "a shifty grave robber"),
    (r"bum|hobo|vagrant|beggar|islbum", "vagrant", "a ragged vagrant"),
    (r"skinnyoldguy|wiseoldman|oldcajun", "old-timer", "an old-timer"),
    (r"blind", "blind beggar", "a BLIND man (eyes clouded, feeling his way with a cane)"),
    (r"upperclass|highsociety|fancytravellers|fancytourist|wealthy", "", "a well-dressed, wealthy-looking person"),
    (r"roughtravellers|survivalist", "", "a rough-looking traveller"),
    (r"obesemen|obesewomen", "", "a heavy-set person"),
    (r"chinatown", "", "a Chinese immigrant from Chinatown"),
    (r"sheriff|deputy|police|lawrural|marshal", "", "a lawman with a badge"),
]


def model_job(model_name: str) -> tuple[str, str]:
    low = (model_name or "").lower()
    for pat, job, look in MODEL_JOBS:
        if re.search(pat, low):
            return job, look
    return "", ""


class PedDB:
    def __init__(self, path: Path):
        self.by_hash: dict[int, dict] = {}
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))["peds"]
        except Exception:
            raw = []
        for p in raw:
            n = (p.get("n") or "").split("=")[-1].strip()   # skip junk like 'Backup.PedWhistleModels = X'
            if n and " " not in n:
                self.by_hash[joaat(n)] = p
        self.count = len(self.by_hash)

    def classify(self, model_hash: int, is_male_native: bool | None) -> dict:
        """-> {name, known, story, child, nonhuman, sex, age_label, role, role_note, region}"""
        p = self.by_hash.get(model_hash & 0xFFFFFFFF)
        name = p["n"] if p else f"unknown_{model_hash & 0xFFFFFFFF:08X}"
        low = name.lower()
        sex = (p or {}).get("s")
        if not sex and is_male_native is not None:
            sex = "Male" if is_male_native else "Female"
        role, note = "", ""
        for pat, r, n in ROLE_HINTS:
            if re.search(pat, low):
                role, note = r, n
                break
        region = ""
        parts = low.split("_")
        if len(parts) >= 4:
            for code in sorted(REGION_CODES, key=len, reverse=True):
                if parts[3].startswith(code):
                    region = REGION_CODES[code]
                    break
        job, look = model_job(name)
        child = bool(CHILD_PED.search(low))
        if child and (p or {}).get("a") in ("Middle Age", "Old"):
            child = False             # the ped list knows better than a word in the name
        return {
            "model_job": job,
            "look": look,
            "model_name": name,
            "known": p is not None,
            "story": bool(STORY_PED.match(low)) or (model_hash & 0xFFFFFFFF) in PLAYER_MODELS,
            "child": child,
            "nonhuman": bool(NON_HUMAN.search(low)),
            "sex": (sex or "Female").lower(),
            "age_label": (p or {}).get("a") or "",
            "role": role,
            "role_note": note,
            "home_hint": region,
        }


class Zones:
    def __init__(self):
        self.by_hash = {int(k): v for k, v in _load("zones.json", {}).items()}

    def name(self, h) -> str:
        if not h:
            return ""
        z = self.by_hash.get(int(h) & 0xFFFFFFFF)
        if not z or z.get("type_name", "").startswith("TEXT_"):
            return ""
        n = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", z["name"]).replace("_", " ")
        return " ".join(w if w[:1].isupper() else w.capitalize() for w in n.split())


WEATHER = {joaat(w): w.lower() for w in _load("weather.json", [])}
GESTURES = _load("gestures.json", {})
MOODS = _load("facial_moods.json", {})
EMOTES = set(_load("emotes.json", []))
SCENARIOS = _load("scenarios.json", {})


def weather_name(h) -> str:
    return WEATHER.get(int(h or 0) & 0xFFFFFFFF, "")
