def joaat(s: str) -> int:
    """Rockstar's Jenkins one-at-a-time hash (lower-cased), as GET_HASH_KEY."""
    h = 0
    for ch in s.lower().encode("utf-8"):
        h = (h + ch) & 0xFFFFFFFF
        h = (h + (h << 10)) & 0xFFFFFFFF
        h ^= h >> 6
    h = (h + (h << 3)) & 0xFFFFFFFF
    h ^= h >> 11
    h = (h + (h << 15)) & 0xFFFFFFFF
    return h


def u32(v) -> int:
    return int(v) & 0xFFFFFFFF
