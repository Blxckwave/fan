"""The RDR2 game database (data/db, built by tools/build_db.py from community-extracted game data).

Loaded lazily: the big tables (20k objects, 26k animation dictionaries, 16k clothes) only when first used.
Every query returns real game names/hashes/coordinates - nothing here is generated.
"""
from __future__ import annotations

import gzip
import json
import math
import random
import re
from pathlib import Path

from .log import log


class GameDB:
    def __init__(self, folder: Path):
        self.dir = folder
        self._c: dict[str, object] = {}

    def _load(self, name: str, default):
        if name in self._c:
            return self._c[name]
        val = default
        for p in (self.dir / f"{name}.json", self.dir / f"{name}.json.gz"):
            if p.exists():
                try:
                    raw = gzip.decompress(p.read_bytes()) if p.suffix == ".gz" else p.read_bytes()
                    val = json.loads(raw)
                except Exception as e:
                    log.warning("[DB] %s unreadable: %s", p.name, e)
                break
        self._c[name] = val
        return val

    @property
    def ok(self) -> bool:
        return bool(self.places)

    # ── places ──
    @property
    def places(self) -> list[dict]:
        return self._load("places", [])

    @property
    def towns(self) -> dict:
        return self._load("towns", {})

    def town_at(self, x: float, y: float, within: float = 450) -> str:
        best, bd = "", within
        for t, c in self.towns.items():
            d = math.hypot(c["x"] - x, c["y"] - y)
            if d < bd:
                best, bd = t, d
        return best

    def places_near(self, x: float, y: float, kinds=None, rmin: float = 0, rmax: float = 3000, town: str = "",
                    lived_in: bool | None = None) -> list[dict]:
        out = []
        for p in self.places:
            if kinds and p["kind"] not in kinds:
                continue
            if town and p.get("town", "").lower() != town.lower():
                continue
            if lived_in is not None and bool(p.get("lived_in")) != lived_in:
                continue
            d = math.hypot(p["x"] - x, p["y"] - y)
            if rmin <= d <= rmax:
                out.append(dict(p, d=round(d)))
        return sorted(out, key=lambda p: p["d"])

    KIND_WORDS = {
        "saloon": "saloon", "bar": "saloon", "tavern": "saloon", "hotel": "hotel", "inn": "hotel", "brothel": "brothel",
        "cathouse": "brothel", "whorehouse": "brothel", "church": "church", "chapel": "church", "bank": "bank",
        "sheriff": "sheriff office", "jail": "jail", "store": "general store", "shop": "general store",
        "gunsmith": "gunsmith", "doctor": "doctor", "barber": "barber", "tailor": "tailor", "theater": "theater",
        "theatre": "theater", "station": "train station", "depot": "train station", "stable": "stable",
        "mansion": "mansion", "manor": "mansion", "plantation": "mansion", "farm": "farmhouse", "farmhouse": "farmhouse",
        "homestead": "farmhouse", "ranch": "ranch", "barn": "barn", "cabin": "cabin", "shack": "shack", "hut": "shack",
        "house": "house", "home": "house", "camp": "camp", "cave": "cave", "mine": "mine", "mill": "mill",
        "bridge": "bridge", "dock": "dock", "pier": "dock", "graveyard": "graveyard", "cemetery": "graveyard",
        "fort": "fort", "ruins": "ruins", "well": "well", "school": "school", "lighthouse": "lighthouse",
        "fence": "fence", "boathouse": "boathouse",
    }

    def kinds_in(self, text: str) -> list[str]:
        t = " " + re.sub(r"[^a-z ]", " ", (text or "").lower()) + " "
        return list(dict.fromkeys(v for k, v in self.KIND_WORDS.items() if f" {k} " in t or f" {k}s " in t))

    def town_in(self, text: str) -> str:
        t = (text or "").lower()
        for town in sorted(self.towns, key=len, reverse=True):
            if town.lower() in t:
                return town
        return ""

    def pick_destination(self, x: float, y: float, text: str, default_kinds, rmin: float, rmax: float,
                         rng: random.Random | None = None, only=None) -> dict | None:
        """A REAL place for a trip: the kind/town the person talked about if we know one, else a fitting place nearby.
        Returns None when nothing fits (the caller then uses open ground). only (0.5.8): the kinds it MAY be (a couple's
        home is a house, never the saloon they were talking about)."""
        rng = rng or random.Random()
        kinds, town = self.kinds_in(text), self.town_in(text)
        if only:
            kinds = [k for k in kinds if k in only]
        tries = []
        # 0.5.1: never "very far": a named town only counts if it's within ~2.5 km; and when nothing fits, ANY real
        # place nearby rather than a random point (Ruth's random point was out in the sea, off the map)
        if kinds or town:
            homes = {"house", "farmhouse", "cabin", "shack", "camp", "ranch"}
            far = 4000 if (town and kinds and not set(kinds) <= homes) else 2500     # "the saloon in Rhodes": that one
            tries.append(dict(kinds=kinds or (list(only) if only else None), town=town, rmin=0 if town else rmin * 0.3,
                              rmax=far if town else rmax * 1.5))
        tries.append(dict(kinds=list(default_kinds), town="", rmin=rmin, rmax=rmax))
        tries.append(dict(kinds=list(default_kinds), town="", rmin=rmin * 0.3, rmax=rmax * 2.0))
        if only:
            tries.append(dict(kinds=list(only), town="", rmin=60, rmax=5000))
        else:
            tries.append(dict(kinds=None, town="", rmin=min(rmin, 150), rmax=rmax * 2.0))
            tries.append(dict(kinds=None, town="", rmin=60, rmax=5000))
        for t in tries:
            found = self.places_near(x, y, t["kinds"], t["rmin"], t["rmax"], t["town"])
            if found:
                pick = rng.choice(found[:6])
                log.info("[DB] destination for %r: %s (%s, %s) %d m", text[:60], pick["name"], pick["kind"],
                         pick.get("town") or "wilderness", pick["d"])
                return pick
        return None

    # ── everything else, on demand ──
    @property
    def objects(self) -> dict:
        return self._load("objects", {})

    @property
    def vehicles(self) -> dict:
        return self._load("vehicles", {})

    @property
    def peds(self) -> dict:
        return self._load("peds", {})

    @property
    def anims(self) -> dict:
        return self._load("anims", {})

    @property
    def clothes(self) -> list:
        return self._load("clothes", [])

    @property
    def cloth_categories(self) -> dict:
        return self._load("cloth_categories", {})

    @property
    def furniture(self) -> dict:
        return self._load("furniture", {})

    def search_anims(self, words, limit: int = 20) -> list[tuple[str, str]]:
        """(dictionary, clip) pairs whose names contain ALL the words."""
        ws = [w.lower() for w in words if w]
        out = []
        for d, clips in self.anims.items():
            dl = d.lower()
            for c in clips:
                full = dl + "/" + c.lower()
                if all(w in full for w in ws):
                    out.append((d, c))
                    if len(out) >= limit:
                        return out
        return out

    def search_objects(self, pattern: str, limit: int = 30) -> list[str]:
        rx = re.compile(pattern, re.I)
        return [n for n in self.objects if rx.search(n)][:limit]
