"""Procedural, seeded NPC personalities: name, age, job, family, temperament, secrets, wildcards.

Every identity gets a stable seed, so the same person is generated the same way every time.
Randomness is deliberate: ~1 in 6 people carries a 'wildcard' that makes them behave unexpectedly.
"""
from __future__ import annotations

import random

M_FIRST = ("John William James George Charles Frank Joseph Henry Robert Thomas Edward Harry Walter Arthur Fred "
           "Albert Samuel Clarence Louis David Joe Charles Roy Earl Elmer Herbert Otis Silas Ezra Jedediah Amos "
           "Cyrus Abner Levi Virgil Wyatt Jesse Cole Luther Homer Clement Jasper Emmett Rufus Leroy Ike Seamus "
           "Patrick Declan Hans Otto Wilhelm Giuseppe Antonio Mateo Javier Esteban Ramon Pierre Etienne Jean "
           "Lucien Isaiah Moses Elijah Booker Augustus Cornelius Ambrose Barnabas Hiram Thaddeus Obadiah").split()
F_FIRST = ("Mary Anna Emma Elizabeth Margaret Minnie Ida Annie Bertha Alice Clara Sarah Ella Lillie Agnes Martha "
           "Florence Mabel Bessie Edna Pearl Hattie Nellie Etta Cora Ada Lula Eliza Josephine Rosa Viola Mae "
           "Beatrice Della Effie Myrtle Opal Iris Ruth Esther Hannah Abigail Constance Prudence Temperance "
           "Bridget Siobhan Greta Liesel Francesca Lucia Rosalind Carmen Lupe Inés Colette Odette Marguerite "
           "Delphine Celeste Henrietta Winifred Theodora Lavinia Philomena Eudora Ophelia").split()
SURNAMES = ("Smith Johnson Brown Miller Davis Wilson Moore Taylor Anderson Thomas Jackson White Harris Martin "
            "Thompson Clark Lewis Walker Hall Allen Young King Wright Hill Scott Green Baker Adams Nelson Carter "
            "Mitchell Roberts Turner Phillips Campbell Parker Evans Edwards Collins Stewart Morris Murphy Cook "
            "Rogers Morgan Cooper Peterson Reed Bailey Bell Kelly Howard Ward Cox Hayes Bishop Fletcher Pruitt "
            "Calloway Hollis Dobbs Tillman Whitaker Crenshaw McGee O'Malley Flanagan Gallagher Schreiber Vogel "
            "Hartmann Romano Bianchi Esposito Delgado Herrera Navarro Fontenot Thibodeaux Boudreaux LeBlanc "
            "Broussard Pettibone Swanson Lindqvist Haskins Pickett Bramble Kincaid Ashby Goodnight").split()

JOBS = {
    "townsfolk": ["general store clerk", "laundress", "seamstress", "schoolteacher", "blacksmith's helper",
                  "carpenter", "stable hand", "baker", "post office clerk", "widow living off a pension",
                  "boarding-house keeper", "cobbler", "telegraph operator", "undertaker's assistant",
                  "street sweeper", "barber's apprentice", "photographer's assistant", "church organist"],
    "rancher": ["cattle rancher", "ranch hand", "farmer", "farmer's wife", "horse breaker", "sheep herder",
                "homesteader", "dairy farmer"],
    "labourer": ["coal miner", "railroad worker", "lumberjack", "dock worker", "cotton picker", "brick layer",
                 "ditch digger"],
    "gentry": ["banker", "lawyer", "landowner", "society lady", "newspaper editor", "wealthy widow",
               "plantation heir", "investor from back east"],
    "drifter": ["drifter", "gambler", "snake-oil salesman", "out-of-work cowhand", "vagrant", "travelling preacher",
                "prospector", "bounty hunter down on his luck"],
    "outlaw": ["outlaw", "horse thief", "stagecoach robber", "gang lookout", "moonshine runner"],
    "lawman": ["deputy", "police officer", "police sergeant", "Pinkerton agent", "marshal", "sheriff's deputy"],
    "guard": ["bank guard", "train guard", "coach guard", "prison guard"],
    "backwoods": ["moonshiner", "trapper", "swamp dweller", "hermit"],
    "soldier": ["army private", "ex-Confederate veteran", "cavalry sergeant"],
    "bartender": ["bartender"], "doctor": ["doctor"], "clergy": ["preacher"], "shopkeeper": ["shopkeeper"],
    "prostitute": ["working girl"], "corpse": ["(dead)"], "": [],
}
TEMPERAMENTS = [
    ("friendly", 10), ("guarded", 14), ("grumpy", 10), ("nervous", 9), ("proud", 7), ("cheerful", 6),
    ("hot-headed", 7), ("melancholy", 6), ("sly", 6), ("pious", 5), ("crude", 6), ("timid", 6),
    ("curious", 6), ("bitter", 6), ("flirtatious", 4), ("paranoid", 4), ("stoic", 6), ("chatty", 6),
]
SPEECH = ["slow southern drawl", "clipped and blunt", "educated and wordy", "mumbles, trails off",
          "curses constantly", "few words", "talks a mile a minute", "stutters when nervous",
          "thick Irish brogue", "German accent, formal", "folksy sayings", "sarcastic", "very polite, old-fashioned",
          "loud and brash", "soft-spoken"]
QUIRKS = ["keeps checking a pocket watch", "chews tobacco and spits", "hums hymns", "never looks you in the eye",
          "laughs at the wrong moments", "quotes scripture", "obsessed with the weather",
          "complains about their back", "brags about a famous cousin", "suspicious of anyone with a hat like yours",
          "collects bird feathers", "is half deaf and asks you to repeat", "has a lucky coin they rub",
          "hates horses", "talks about their late dog", "always hungry", "reads newspapers religiously"]
FEARS = ["dying alone", "the law", "outlaws", "losing the farm", "God's judgement", "wolves", "being poor again",
         "their own temper", "doctors", "the dark", "being found out", "their husband/wife", "debt collectors"]
DESIRES = ["move to California", "save enough to buy land", "see their children grow up", "find a lost brother",
           "get revenge on a man who wronged them", "a quiet life", "be respected in town", "strike it rich",
           "find love", "get out of debt", "make it to the next town before dark", "a stiff drink"]
SECRETS = ["owes money to dangerous men", "once killed a man in Kansas", "is cheating on their spouse",
           "has stolen money hidden at home", "ran away from a family back east", "informs for the law",
           "drinks in secret", "is not who they say they are", "buried something valuable nearby",
           "deserted the army", "has a child no one knows about", "secretly admires outlaws",
           "is wanted under another name", "steals from their employer"]
WILDCARDS = [
    "has a hidden pistol and is far braver than they look",
    "is a compulsive liar who invents wild stories",
    "is a little unhinged and laughs at danger",
    "instantly takes a liking to the player and wants to tag along",
    "recognises the player from a wanted poster (or thinks so)",
    "is very drunk today",
    "is grieving someone who died this week and is fragile",
    "thinks the player is someone else they know",
    "is a religious zealot who wants to save the player's soul",
    "is desperate for money and will do almost anything for a few dollars",
    "is tougher than they look and does not scare easily",
    "is an aspiring outlaw who wants to impress the player",
    "is paranoid that the player is following them",
]
TODAY = ["heading to the general store", "on the way home after work", "waiting for someone who is late",
         "looking for a lost horse", "killing time", "on an errand for their employer", "trying to sell something",
         "avoiding someone", "out for fresh air", "on the way to church", "meeting a friend for a drink later",
         "heading out of town", "just arrived in the area", "looking for work", "visiting a sick relative",
         "collecting money someone owes them", "running late for work", "on the way to the doctor",
         "picking up a letter at the post office", "trying to forget a bad day", "fetching supplies for home"]
# 0.4.0: names that fit the face (a Chinatown model was 'Giuseppe Young')
CHINESE_M = "Wei Ming Jun Hao Li Chen Bo Feng Gang Hui Jian Kang Lei Long Qiang Shan Tao Yong Zhen".split()
CHINESE_F = "Mei Lan Hua Ying Xiu Fang Li Juan Ling Na Ping Qing Yan Yun Zhen".split()
CHINESE_S = "Chen Wong Li Zhang Liu Huang Lin Zhou Wu Ng Lee Chan Lau Yee Fong".split()
SPANISH_M = "José Juan Manuel Francisco Miguel Pedro Luis Antonio Ramón Esteban Mateo Javier Diego Santiago Rafael".split()
SPANISH_F = "María Guadalupe Rosa Carmen Josefa Lupe Elena Isabel Juana Teresa Dolores Inés".split()
SPANISH_S = "García Hernández López Martínez González Pérez Sánchez Ramírez Flores Rivera Torres Delgado Herrera Navarro".split()
CREOLE_M = "Jean Pierre Louis Étienne Lucien Antoine Baptiste Gaston Hippolyte Remy Thibault".split()
CREOLE_F = "Marie Colette Odette Marguerite Delphine Celeste Josette Amélie Félicité".split()
CREOLE_S = "Fontenot Thibodeaux Boudreaux LeBlanc Broussard Guidry Landry Hebert Arceneaux Robichaux".split()


def name_pool(model_name: str):
    m = (model_name or "").lower()
    if "chinatown" in m or "chinese" in m or "asian" in m:
        return CHINESE_M, CHINESE_F, CHINESE_S, 1.0
    if any(k in m for k in ("mex", "bandito", "nuevo", "chelonia", "_tum", "_arm", "_gua", "rhdcolored")):
        return SPANISH_M, SPANISH_F, SPANISH_S, 0.6 if "_tum" in m or "_arm" in m else 0.9
    if any(k in m for k in ("_caj", "_lag", "_bay", "_blu", "creole", "_sdslums")):
        return CREOLE_M, CREOLE_F, CREOLE_S, 0.5
    return None


def _weighted(rng, items):
    total = sum(w for _, w in items)
    r = rng.uniform(0, total)
    for v, w in items:
        r -= w
        if r <= 0:
            return v
    return items[-1][0]


def generate(seed: str, cls: dict, home: str) -> dict:
    """cls = PedDB.classify() output; home = zone name where first met."""
    rng = random.Random(seed)
    male = cls["sex"] == "male"
    child = cls["child"]
    label = cls["age_label"]
    if child:
        age = rng.randint(8, 14)
    elif label == "Young":
        age = rng.randint(18, 26)
    elif label == "Old":
        age = rng.randint(55, 76)
    else:
        age = rng.randint(27, 52)
    first = rng.choice(M_FIRST if male else F_FIRST)
    last = rng.choice(SURNAMES)
    pool = name_pool(cls.get("model_name", ""))
    if pool and rng.random() < pool[3]:
        first = rng.choice(pool[0] if male else pool[1])
        last = rng.choice(pool[2])
    role = cls["role"] or "townsfolk"
    jobs = JOBS.get(role) or JOBS["townsfolk"]
    job = "a child" if child else rng.choice(jobs)
    if not child and cls.get("model_job"):
        job = cls["model_job"]          # 0.5.1: a miner model is a miner (Barnabas in Annesburg said "lumberjack")
    temperament = _weighted(rng, TEMPERAMENTS)
    if child and temperament in ("flirtatious", "crude"):
        temperament = "curious"
    p = {
        "name": f"{first} {last}",
        "first_name": first,
        "sex": "male" if male else "female",
        "age": age,
        "child": child,
        "job": job,
        "role": role,
        "role_note": cls.get("role_note", ""),
        "look": cls.get("look", ""),
        "home": cls.get("home_hint") or home or "these parts",
        "temperament": temperament,
        "speech": rng.choice(SPEECH),
        "quirk": rng.choice(QUIRKS),
        "fear": rng.choice(FEARS),
        "desire": rng.choice(DESIRES),
        "today": rng.choice(TODAY),
        "bravery": round(rng.betavariate(2, 2.6) + (0.35 if role in ("lawman", "outlaw", "soldier", "guard") else 0), 2),
        "honesty": round(rng.random(), 2),
        "greed": round(rng.random(), 2),
        "secret": rng.choice(SECRETS) if (not child and rng.random() < 0.3) else "",
        "wildcard": rng.choice(WILDCARDS) if (not child and rng.random() < 0.17) else "",
    }
    if child:
        p["family"] = rng.choice(["lives with ma and pa", "lives with a grandmother", "an orphan sleeping rough",
                                  "the eldest of six siblings"])
        p["romance_openness"] = 0.0
    else:
        status = rng.choices(["married", "widowed", "single", "courting"], [45, 15, 30, 10])[0]
        kids = rng.choices([0, 1, 2, 3, 5], [30, 22, 24, 15, 9])[0] if age >= 21 else 0
        fam = status
        if kids:
            fam += f", {kids} child{'ren' if kids > 1 else ''} at home"
        p["family"] = fam
        p["romance_openness"] = round(min(1.0, rng.betavariate(1.6, 3.0)
                                          + (0.45 if role == "prostitute" else 0)
                                          + (0.2 if temperament == "flirtatious" else 0)
                                          - (0.25 if status == "married" else 0)
                                          - (0.2 if temperament == "pious" else 0)), 2)
        p["romance_openness"] = max(0.0, p["romance_openness"])
        # 0.5.1: people have desires of their own - all kinds, not only "my loyalty lies with my family"
        p["sexuality"] = sexuality(rng, male, status, p["romance_openness"])
        if p["sexuality"] and any(k in p["sexuality"] for k in ("watch", "third", "open", "swap")):
            p["romance_openness"] = round(min(1.0, p["romance_openness"] + 0.3), 2)
    p["bravery"] = max(0.0, min(1.0, p["bravery"]))
    lo, hi = {"drifter": (0, 3), "backwoods": (0, 4), "labourer": (1, 8), "rancher": (2, 15), "townsfolk": (1, 12),
              "shopkeeper": (8, 40), "bartender": (5, 25), "doctor": (10, 50), "gentry": (25, 150), "prostitute": (4, 25),
              "lawman": (4, 20), "guard": (3, 15), "outlaw": (5, 70), "soldier": (2, 10), "clergy": (0, 6)}.get(role, (1, 10))
    p["cash"] = 0.0 if child else round(rng.uniform(lo, hi) + rng.choice([0, 0, 0.25, 0.5, 0.75]), 2)
    return p


KINKS_ANY = ["likes being watched", "loves to talk dirty", "likes to take charge in bed", "likes to be told what to do",
             "has a wild past (a few years in a Saint Denis cathouse) and isn't shy about it", "is easily tempted by a stranger",
             "is curious about doing it somewhere they could get caught", "has fantasies about a third person in bed"]
KINKS_MARRIED_M = ["secretly wants to watch his wife with another man - it's his fantasy, and she knows",
                   "and his wife have an open arrangement: they invite a stranger home now and then",
                   "and his wife like to swap partners with another couple"]
KINKS_MARRIED_F = ["and her husband have an open arrangement - he likes to watch her with other men",
                   "is bored in her marriage and tempted by a strong stranger",
                   "and her husband sometimes invite a stranger home - they both enjoy it"]


def sexuality(rng, male: bool, status: str, openness: float) -> str:
    who = rng.choices(["", "likes both men and women", "prefers their own sex (kept quiet in 1899)"], [84, 11, 5])[0]
    kink = ""
    roll = rng.random()
    if status == "married" and roll < 0.14:
        kink = rng.choice(KINKS_MARRIED_M if male else KINKS_MARRIED_F)
    elif roll < 0.32 + openness * 0.3:
        kink = rng.choice(KINKS_ANY)
    return ", ".join(x for x in (who, kink) if x)


def describe(p: dict) -> str:
    lines = [
        f"Name: {p['name']} ({p['sex']}, {p['age']}{' – a CHILD' if p['child'] else ''}). Job: {p['job']}.",
        f"From: {p['home']}. Family: {p['family']}." + (f" You look like {p['look']}." if p.get("look") else ""),
        f"Temperament: {p['temperament']}. Speaks: {p['speech']}. Quirk: {p['quirk']}.",
        f"Fears {p['fear']}. Wants to {p['desire']}. Right now: {p['today']}.",
        f"Bravery {p['bravery']:.1f}/1, honesty {p['honesty']:.1f}/1, greed {p['greed']:.1f}/1. "
        f"Money on you: ${p.get('cash', 2.0):.2f}.",
    ]
    if p.get("role_note"):
        lines.append(f"Role: {p['role_note']}.")
    if p.get("sexuality") and not p.get("child"):
        lines.append(f"Desire (private - it colours how you react to flirting, never forced): {p['sexuality']}.")
    if p.get("secret"):
        lines.append(f"Secret (hide it unless pressured): {p['secret']}.")
    if p.get("wildcard"):
        lines.append(f"WILDCARD – this person {p['wildcard']}.")
    if p.get("backstory"):
        lines.append(f"Backstory: {p['backstory']}")
    return "\n".join(lines)
