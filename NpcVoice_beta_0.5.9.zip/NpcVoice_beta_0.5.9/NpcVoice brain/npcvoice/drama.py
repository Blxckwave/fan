"""Kin drama (0.5.1): the people who belong to each other act like it - without you having to ask.

Every second, for everyone you're dealing with, NpcVoice looks at who their kin are (husband/wife/sweetheart, kids,
parents, brother/sister - from a trip's family, a couple found together, or two people glued together on the street)
and whether something is happening to one of them in front of the other:

  TAKEN      - you ride off with her on your horse, or she follows you away (scared or willing): the husband begs,
               runs after your horse shouting her name, or - a brave armed man - draws on you. A kid cries and runs after.
  THREATENED - a gun on his wife, his wife's hands up: he pleads, steps in front of her, or goes for his gun.
  HURT/KILLED- you cut or shoot one of them: the other screams, attacks you (brave) or flees (scared) - and never forgets.
  HOME       - a guide who brought you home walks straight to his wife and kids; the wife comes to him.

Every reaction is a real voice line (from the AI, with the actual situation) + a real task in the game, and both
people remember it. The person the drama is about can be talked to as usual afterwards (they know what happened).
"""
from __future__ import annotations

import asyncio
import json
import math
import random
import re
import time
import traceback

from .log import log

KIN = {"your husband": "spouse", "your wife": "spouse", "your sweetheart": "spouse", "your son": "child",
       "your daughter": "child", "your own child": "child", "your pa": "parent", "your ma": "parent",
       "your mother": "parent", "your father": "parent", "your brother": "sibling", "your sister": "sibling",
       "your kin": "sibling", "family": "sibling", "your cousin": "cousin", "a friend of yours": "friend",
       "an old friend": "friend", "your friend from work": "friend", "your workmate": "workmate",
       "your neighbour": "neighbour", "your boss": "workmate", "someone you know by name": "acquaintance"}
# how much they care: the weight of the bond (a husband for his wife > a workmate > someone you know by name)
BOND = {"spouse": 1.0, "child": 1.0, "parent": 0.9, "sibling": 0.8, "cousin": 0.6, "friend": 0.55, "workmate": 0.4,
        "neighbour": 0.4, "acquaintance": 0.25}
# how bad it is that's happening to them
SEVERITY = {"words": 0.4, "threatened": 0.65, "taken": 0.8, "hurt": 0.9, "killed": 1.0, "heard_shot": 0.6,
            # 0.5.7: what else a man can do to someone in front of the people who love them
            "looted": 0.55, "tied": 0.75, "stripped": 0.95}
# 0.5.7: the kin who would feel it as their own honour (1899): a husband, father, brother, grown son - for a woman
HONOUR_KINDS = {"spouse", "parent", "sibling", "child"}
TEMPER = {"hot-headed": 0.18, "proud": 0.1, "grumpy": 0.05, "cheerful": 0.0, "timid": -0.18, "melancholy": -0.05,
          "nervous": -0.12, "pious": -0.05, "crude": 0.08, "sly": -0.05}


class Drama:
    def __init__(self, brain):
        self.b = brain
        self.last: dict[tuple, float] = {}
        self.greeted: set[int] = set()

    # ── who belongs to whom ──
    def handle_of(self, iid: str) -> int:
        return next((h for h, i in self.b.handle_ident.items() if i == iid), 0)

    def kin_of(self, conv) -> list[tuple[int, object, str]]:
        """-> [(ped handle, identity or None, 'spouse'|'child'|'parent'|'sibling')] who are around."""
        b, out, seen = self.b, [], set()
        rels = conv.ident.d.get("relations") or {}
        for k, r in rels.items():
            kind = KIN.get(str(r.get("rel", "")))
            if not kind:
                continue
            h, ident = 0, None
            if k.startswith("id:"):
                ident = b.memory.ids.get(k[3:])
                h = self.handle_of(k[3:])
            elif k == "guide":
                gid = next((i for i in b.memory.ids.values() if i.persona.get("name") == r.get("name")), None)
                if gid:
                    ident, h = gid, self.handle_of(gid.id)
            if h and h != conv.ped and h not in seen and not b.dead(h):
                seen.add(h)
                out.append((h, ident, kind))
        from .surroundings import PAIRS, key_of
        mykey = getattr(conv, "_key", None)
        for p in b.game.near_peds:
            h = int(p.get("h", 0))
            if h in seen or h == conv.ped or not p.get("alive", 1):
                continue
            rel = PAIRS.get((mykey, key_of(p))) if mykey else None
            kind = KIN.get(rel or "")
            if kind:
                seen.add(h)
                iid = b.handle_ident.get(h)
                ident = self.remember_bond(conv, h, b.memory.ids.get(iid) if iid else None, rel)
                out.append((h, ident, kind))
        return out

    def remember_bond(self, conv, h, ident, rel):
        """Two people seen together as husband and wife (same horse, arm in arm...) stay that, for both of them, for
        good - also once they're apart (she rides off with you: he's still her husband, and he knows it)."""
        ident = self.ident_for(h, ident)
        if ident is None:
            return None
        from .surroundings import MIRROR
        back = MIRROR.get(rel) or {"your son": None, "your daughter": None}.get(rel)
        if rel in ("your pa", "your ma"):
            back = "your own child"
        elif rel == "your own child":
            back = "your pa" if conv.ident.persona.get("sex") == "male" else "your ma"
        elif rel in ("your brother", "your sister"):
            back = "your brother" if conv.ident.persona.get("sex") == "male" else "your sister"
        mine = conv.ident.d.setdefault("relations", {})
        if mine.get(f"id:{ident.id}", {}).get("rel") != rel:
            mine[f"id:{ident.id}"] = {"rel": rel, "name": ident.persona.get("name")}
            conv.ident.dirty()
            if back:
                ident.d.setdefault("relations", {})[f"id:{conv.ident.id}"] = {"rel": back, "name": conv.ident.persona.get("name")}
                ident.dirty()
            log.info("[DRAMA] remembered: %s is %s's %s", ident.persona.get("name"), conv.name, rel.replace("your ", ""))
        return ident

    def pos(self, h) -> dict:
        p = self.b.game.ped(h)
        if p and time.time() - p.get("_t", 0) < 5:
            return p
        return next((x for x in self.b.game.near_peds if int(x.get("h", 0)) == h), {}) or {}

    def ident_for(self, h, ident):
        """Somebody's kin we never talked to still gets a real person (with the name everybody already uses)."""
        if ident is not None:
            return ident
        b = self.b
        p = self.pos(h)
        if not p:
            return None
        cls = b.peddb.classify(int(p.get("m", 0)), bool(p.get("male")))
        if cls["nonhuman"] or cls["story"]:
            return None
        ident = b.memory.create(int(p.get("m", 0)), int(p.get("o", 0)), cls, b.game.place(), b.game.game_minutes_total)
        from .surroundings import NAMES, key_of
        pre = NAMES.get(key_of(p))
        if pre:
            ident.persona["name"] = pre["name"]
            ident.persona["first_name"] = pre["name"].split()[0]
        b.handle_ident[h] = ident.id
        return ident

    # ── the loop ──
    async def tick(self):
        try:
            for conv in list(self.b.convs.values()):
                if conv.ended and not conv.companion:
                    continue
                if self.b.dead(conv.ped):
                    continue
                for h, ident, kind in self.kin_of(conv):
                    self.keep_near(conv, h, ident, kind)
                    await self.check_pair(conv, h, ident, kind)
            self.let_go()
        except Exception:
            log.error("[DRAMA] tick crashed:\n%s", traceback.format_exc())

    # ── kin don't just ride off while something's happening to their person ──
    def tense(self, conv) -> bool:
        f, me = conv.flags, self.b.game.ped(conv.ped) or {}
        return bool(me.get("aimed") or f.get("hands_up") or f.get("captive") or me.get("hog")
                    or conv.seconds_since("threatened") < 120 or conv.seconds_since("hurt_by_player") < 120
                    or ((f.get("riding") or f.get("following")) and conv.seconds_since("threatened") < 600))

    def keep_near(self, conv, h, ident, kind):
        """While their wife / brother / friend is being threatened, held or taken, the person stays (within reach),
        watches, and isn't sent off by the end of their own talk. A weak bond doesn't hold them for long."""
        b = self.b
        if not getattr(self, "kept", None):
            self.kept: dict[int, dict] = {}
        if not self.tense(conv) or BOND.get(kind, 0.3) < 0.35 or b.dead(h):
            return
        kp = self.pos(h)
        if not kp or kp.get("d", 99) > 70:
            return
        k = self.kept.get(h)
        now = time.time()
        if k and now < k["next"]:
            k["until"] = now + 60
            return
        own = b.convs.get(h)
        if own and not own.ended:
            return                                   # you're talking to him: his own talk drives him
        b.asi.send("actor", h, 1)
        far = kp.get("d", 99) > 18
        if kp.get("mnt") and far:
            b.asi.prim(h, "drama", ("dismount",))
        b.asi.prim(h, "drama", ("goto_player", 5.0, 7.0) if far else ("face", 8000, f"t={conv.ped}"))
        if not k:
            log.info("[DRAMA] %s stays close: something's happening to %s", (ident.persona.get("name") if ident else h),
                     conv.name)
        self.kept[h] = {"conv": conv.ped, "next": now + 6, "until": now + 60}

    def let_go(self):
        b = self.b
        for h, k in list((getattr(self, "kept", None) or {}).items()):
            if time.time() < k["until"]:
                continue
            self.kept.pop(h, None)
            if h not in b.convs or b.convs[h].ended:
                b.asi.send("actor", h, 0)

    def due(self, a, b, what, secs) -> bool:
        k = (a, b, what)
        if time.time() - self.last.get(k, 0) < secs:
            return False
        self.last[k] = time.time()
        return True

    async def check_pair(self, conv, h, ident, kind):
        b = self.b
        kp = self.pos(h)
        if not kp or kp.get("d", 99) > 60 or h in b.convs and b.convs[h].flags.get("following"):
            return
        me = b.game.ped(conv.ped) or {}
        f = conv.flags
        coerced = bool(f.get("captive") or f.get("hands_up") or conv.seconds_since("threatened") < 300)
        # TAKEN: riding with / following the stranger away from their kin
        rode_off = bool(f.get("riding")) and b.game.player.get("mounted") and kp.get("d", 0) > 15
        if (f.get("riding") or f.get("following")) and not f.get("journey") and kp.get("d", 0) > 6 \
                and (coerced or rode_off) and self.due(conv.ped, h, "taken", 75):
            await self.react(conv, h, ident, kind, "taken", coerced)
            return
        sees = bool(kp.get("elos", kp.get("los", 1))) or kp.get("de", kp.get("d", 99)) < 15
        # 0.5.7: STRIPPED against her will in front of him - and again every time you get close to her after that
        if sees and kp.get("d", 99) < 40 and conv.seconds_since("stripped") < 5 and self.due(conv.ped, h, "stripped", 120):
            await self.react(conv, h, ident, kind, "stripped", True)
            return
        if sees and f.get("violated") and f.get("naked") and me.get("d", 99) < 2.5 and kp.get("d", 99) < 40 \
                and self.due(conv.ped, h, "stripped_close", 45):
            await self.react(conv, h, ident, kind, "stripped", True)
            return
        # 0.5.7: LOOTED / TIED UP in front of them
        if sees and kp.get("d", 99) < 30 and conv.seconds_since("looted") < 5 and self.due(conv.ped, h, "looted", 90):
            await self.react(conv, h, ident, kind, "looted", True)
            return
        if sees and kp.get("d", 99) < 35 and conv.seconds_since("hogtied") < 5 and self.due(conv.ped, h, "tied", 120):
            await self.react(conv, h, ident, kind, "tied", True)
            return
        # THREATENED in front of them
        if (me.get("aimed") or f.get("hands_up")) and kp.get("d", 99) < 30 and self.due(conv.ped, h, "threat", 60):
            await self.react(conv, h, ident, kind, "threatened", True)
            return
        # HURT in front of them
        if conv.seconds_since("hurt_by_player") < 3 and kp.get("d", 99) < 35 and self.due(conv.ped, h, "hurt", 30):
            await self.react(conv, h, ident, kind, "hurt", True)
            return
        # THREATENED WITH WORDS ("I'll kill you and your husband"): they heard it, if they were close enough to hear
        if conv.seconds_since("threatened") < 6 and kp.get("d", 99) < 20 and self.due(conv.ped, h, "words", 45):
            await self.react(conv, h, ident, kind, "words", True)

    def on_kin_killed(self, conv, killer_is_player: bool):
        """Called when someone you were dealing with dies: their kin around react - to what they could perceive.
        0.5.8: her husband far away behind a wall talked about her death as if he'd watched it. Now: he SAW it (line
        of sight, close enough) -> 'killed in front of your eyes'; he only HEARD a shot -> he's alarmed and afraid for
        her, but doesn't know; neither -> nothing yet (he finds out when he sees her body)."""
        if not killer_is_player:
            return
        vp = dict(self.b.game.ped(conv.ped) or {})
        vp = {k: vp[k] for k in ("x", "y", "z") if k in vp} or None
        wpn = (self.b.game.player or {}).get("wpn")
        for h, ident, kind in self.kin_of(conv):
            if self.due(conv.ped, h, "killed", 600):
                asyncio.create_task(self._kin_killed(conv, h, ident, kind, vp, wpn))

    async def _kin_killed(self, conv, h, ident, kind, vp, wpn):
        try:
            # the kin is the observer: 'elos' in the scan is HIS line of sight to the one you talked to (= the victim)
            kp = self.pos(h)
            if vp is None and kp:
                vp = {"de": kp.get("de", kp.get("d", 99)), "elos": kp.get("elos", 0)} if "de" in kp else None
            elif vp is not None and kp and "elos" in kp:
                vp = dict(vp, elos=kp.get("elos"))
            pr = await self.b.perception.death(h, conv.ped, vp, wpn)
            if pr["saw"]:
                await self.react(conv, h, ident, kind, "killed", True)
            elif pr["heard"] == "shot":
                await self.react(conv, h, ident, kind, "heard_shot", True)
            else:
                log.info("[DRAMA] %s didn't see or hear %s die (%.0f m) - doesn't know yet", h, conv.name, pr["d"])
                ident = self.ident_for(h, ident)
                if ident is not None:
                    ident.d["unaware_of_death"] = {"who": conv.ident.persona.get("name", conv.name),
                                                   "rel": kind, "game_min": self.b.game.game_minutes_total}
                    ident.dirty()
        except Exception:
            log.error("[DRAMA] kin perception crashed:\n%s", traceback.format_exc())

    # ── what they do ──
    def weigh(self, kind, what, kp, ident, victim=None) -> tuple[float, float, bool]:
        """-> (how much this matters to them, their nerve, armed). Bond x how bad it is; nerve = their courage, a gun,
        their line of work - minus how scared of you they already are and how mean you look right now."""
        b = self.b
        p = ident.persona if ident else {}
        armed = bool(kp.get("hasw") or kp.get("armed")) or p.get("role") in ("lawman", "outlaw", "rancher", "guard", "soldier")
        stake = BOND.get(kind, 0.3) * SEVERITY.get(what, 0.6)
        nerve = float(p.get("bravery", 0.45)) + (0.2 if armed else 0) + (0.15 if p.get("role") in ("lawman", "outlaw", "soldier") else 0)
        if ident:
            st = ident.stats
            nerve -= 0.4 * st.get("fear", 10) / 100
            nerve += 0.2 * ident.d.get("nemesis", {}).get("grudge", 0) / 100     # an old grudge makes them bolder
            stake += 0.1 * st.get("anger", 5) / 100
        pl = b.game.player or {}
        if pl.get("armed") or pl.get("wpn") not in (None, 0, "", "WEAPON_UNARMED"):
            nerve -= 0.1
        # 0.5.7: who HE is (temper, age) and what this is to him (his honour: a man watching his wife / daughter /
        # sister stripped or robbed). Rage eats fear: the worse it is, the less the gun in your hand holds him back.
        nerve += TEMPER.get(str(p.get("temperament", "")), 0.0)
        age = int(p.get("age", 35) or 35)
        if age >= 60:
            nerve -= 0.15
        elif 18 <= age <= 40:
            nerve += 0.05
        if kp.get("aimed"):
            nerve -= 0.25                                # your gun is on HIM right now
        if kp.get("hog") or kp.get("lasso"):
            nerve = 0.0                                  # tied himself: he can only shout
        honour = bool(victim is not None and p.get("sex") == "male" and kind in HONOUR_KINDS and
                      victim.ident.persona.get("sex") == "female")
        if what in ("stripped", "looted", "tied") and honour:
            stake += {"stripped": 0.25, "tied": 0.12, "looted": 0.08}[what]
        if what == "stripped":
            nerve += 0.3 * stake + (0.12 if honour else 0)       # rage
        return min(1.0, stake), max(0.0, min(1.0, nerve)), armed

    def plan(self, kind, what, coerced, kp, ident, victim=None) -> list[tuple]:
        p = ident.persona if ident else {}
        brave = float(p.get("bravery", 0.45))
        child = bool(p.get("child"))
        stake, nerve, armed = self.weigh(kind, what, kp, ident, victim)
        if what in ("stripped", "looted", "tied"):
            return self.plan_violation(what, kind, stake, nerve, armed, child, p, kp)
        if not child and what in ("words", "threatened", "taken") and kind not in ("spouse", "child", "parent", "sibling"):
            # a friend / workmate / neighbour: speaks up, goes for help, or stays out of it
            if stake < 0.25:
                return [("face", 8000)]
            if nerve >= 0.6:
                return [("goto_player", 2.0, 3.0), ("face", 10000)]
            return [("clear",), ("flee", 60)] if what != "words" else [("face", 8000)]
        if not child and what == "words":
            if stake >= 0.35 and nerve >= 0.65 and armed:
                return [("goto_player", 1.6, 2.2), ("draw",), ("face", 15000)]       # steps in, hand on his gun
            if stake >= 0.35 and nerve >= 0.45:
                return [("goto_player", 1.6, 2.2), ("face", 15000)]                  # steps up between you
            return [("face", 10000)]
        brave = nerve
        if child:
            return [("emote", 0, "KIT_EMOTE_REACTION_SOB_1", 0), ("goto_player", 2.0, 3.0)] if what != "killed" \
                else [("emote", 0, "KIT_EMOTE_REACTION_SOB_1", 0), ("flee", 80)]
        if what == "heard_shot":                      # 0.5.8: a shot from where she was - he didn't see it
            return ([("clear",), ("goto_player", 4.0, 6.0), ("face", 12000)] if brave >= 0.45 else
                    [("clear",), ("cower", 12000)])
        if what == "killed":
            return ([("block", 0), ("draw",), ("combat",)] if brave >= 0.5 and armed else
                    [("emote", 0, "KIT_EMOTE_REACTION_SOB_1", 0), ("block", 0), ("flee", 150)])
        if what == "hurt":
            return ([("block", 0), ("draw",), ("combat",)] if brave >= 0.6 and armed else
                    [("block", 0), ("goto_player", 2.0, 3.0)] if brave >= 0.4 else [("block", 0), ("flee", 120)])
        if what == "threatened":
            return ([("draw",), ("face", 15000)] if brave >= 0.7 and armed else
                    [("clear",), ("emote", 0, "KIT_EMOTE_REACTION_BEGMERCY_1", 2)])
        # taken
        if kind == "spouse" and coerced and brave >= 0.7 and armed:
            return [("block", 0), ("draw",), ("combat",)]
        if kind in ("spouse", "parent", "sibling"):
            return [("clear",), ("goto_player", 2.5, 3.0)]          # runs after your horse
        return [("clear",), ("goto_player", 2.5, 3.0)]

    @staticmethod
    def plan_violation(what, kind, stake, nerve, armed, child, p, kp) -> list[tuple]:
        """0.5.7: stripped / robbed / tied in front of the people who love them. A man for his wife, daughter or
        sister: rage - he goes for his gun or comes at you with his fists; a scared one shouts, begs or runs for help.
        A woman: comes to cover her, screams for help, or flees to get the law. A child: cries, runs to them."""
        if kp.get("hog") or kp.get("lasso"):
            return [("face", 12000)]                                         # tied himself: only his voice
        if child:
            return [("emote", 0, "KIT_EMOTE_REACTION_SOB_1", 0), ("goto_player", 2.0, 3.0)]
        male = p.get("sex") == "male"
        if stake < 0.3:
            return [("face", 8000)]                                          # not his business - he watches
        if what == "stripped":
            if armed and nerve >= 0.45:
                return [("block", 0), ("draw",), ("combat",)]
            if male and nerve >= 0.35:
                return [("block", 0), ("combat",)]                           # comes at you with his fists
            if nerve >= 0.3:
                return [("clear",), ("goto_player", 1.4, 2.0), ("face", 15000)]   # steps in between, shouting
            return [("block", 0), ("flee", 120)]                             # runs - for help, for the law
        if what == "tied":
            if armed and nerve >= 0.65 and kind in HONOUR_KINDS:
                return [("block", 0), ("draw",), ("combat",)]
            if nerve >= 0.4:
                return [("clear",), ("goto_player", 1.8, 2.4), ("face", 15000)]
            return [("clear",), ("emote", 0, "KIT_EMOTE_REACTION_BEGMERCY_1", 2)]
        # looted
        if armed and nerve >= 0.7 and kind in HONOUR_KINDS:
            return [("draw",), ("goto_player", 2.0, 3.0), ("face", 15000)]
        if nerve >= 0.45:
            return [("clear",), ("goto_player", 2.0, 3.0), ("face", 12000)]
        return [("face", 10000)]

    async def react(self, conv, h, ident, kind, what, coerced):
        b = self.b
        if b.ptt_ped:
            return
        ident = self.ident_for(h, ident)
        if ident is None:
            return
        kp = self.pos(h)
        g = b.game
        male = conv.ident.persona.get("sex") == "male"
        rel = {"spouse": "husband" if male else "wife", "child": "child", "parent": "father" if male else "mother",
               "sibling": "brother" if male else "sister", "cousin": "cousin", "friend": "friend",
               "workmate": "workmate", "neighbour": "neighbour", "acquaintance": "acquaintance"}.get(kind, "friend")
        who = conv.ident.persona["first_name"]
        fem = conv.ident.persona.get("sex") != "male"
        obj, pos = ("her", "her") if fem else ("him", "his")
        tied_now = bool((g.ped(conv.ped) or {}).get("hog"))
        situ = {"stripped": f"the stranger just STRIPPED your {rel} {who} NAKED against {pos} will, right in front of you"
                            + (f" - {who} is tied up and helpless on the ground" if tied_now else "")
                            + f". It's an outrage, a disgrace to {obj} and to you",
                "looted": f"the stranger is going through your {rel} {who}'s pockets - robbing {obj} right in front of you"
                          + (" while they lie tied up" if tied_now else ""),
                "tied": f"the stranger just hogtied your {rel} {who} and dumped {obj} on the ground in front of you",
                "words": f"the stranger just THREATENED your {rel} {who} - you heard it",
                "taken": f"the stranger is taking your {rel} {who} away" + (" by force" if coerced else
                                                                             " - and they're going with him"),
                "threatened": f"the stranger has a gun on your {rel} {who}",
                "hurt": f"the stranger just hurt your {rel} {who} right in front of you",
                "killed": f"the stranger just KILLED your {rel} {who} in front of your eyes",
                "heard_shot": f"a GUNSHOT just rang out from where your {rel} {who} was. You did NOT see what happened "
                              f"and you don't know if {who} is hurt - you're afraid for {obj}: you call out for {obj}, "
                              f"ask what happened. Never say {who} is dead"}[what]
        prims = self.plan(kind, what, coerced, kp, ident, conv)
        stake, nerve, armed = self.weigh(kind, what, kp, ident, conv)
        log.info("[DRAMA] %s (%s of %s): %s -> %s (cares %.2f, nerve %.2f%s)", ident.persona["name"], rel, conv.name, what,
                 prims[-1][0], stake, nerve, ", armed" if armed else "")
        b.asi.send("actor", h, 1)
        for pr in prims:
            b.asi.prim(h, "drama", pr)
        ident.add_event(situ.replace("the stranger", "the stranger (HIM)"), g.game_minutes_total, g.place(), 3)
        ident.adjust({"anger": 40, "fear": 10, "trust": -40, "respect": -20} if what == "stripped" else
                     {"fear": 15} if what == "heard_shot" else
                     {"anger": 25, "fear": 15, "trust": -25}, what, cap=50 if what == "stripped" else 40)
        if prims[-1][0] == "combat":
            ident.d.setdefault("nemesis", {}).setdefault("grudge", 0)
            ident.d["nemesis"]["grudge"] = min(100, int(ident.d["nemesis"]["grudge"]) + 30)    # he won't forget
            ident.dirty()
        conv.ident.add_event(f"your {self.back_rel(kind, ident)} {ident.persona['first_name']} saw it: {what}",
                             g.game_minutes_total, g.place(), 2)
        conv.pending_events.append(("kin", f"Your {self.back_rel(kind, ident)} {ident.persona['first_name']} is right there "
                                           f"and reacting: {what}. You see and hear it.", 2))
        if prims[-1][0] == "face" and stake < 0.35:
            await asyncio.sleep(8)                       # just watches - it's not their business (but they remember)
            b.asi.send("actor", h, 0)
            return
        line = await self.line(ident, situ, prims[-1][0])
        if line:
            await b.say_line(h, ident, line, "angry" if prims[-1][0] in ("combat", "draw") else "fearful")
        if prims[-1][0] not in ("combat",):
            await asyncio.sleep(12)
        b.asi.send("actor", h, 0)

    @staticmethod
    def back_rel(kind, ident) -> str:
        male = ident.persona.get("sex") == "male"
        return {"spouse": "husband" if male else "wife", "child": "son" if male else "daughter",
                "parent": "pa" if male else "ma", "sibling": "brother" if male else "sister", "cousin": "cousin",
                "friend": "friend", "workmate": "workmate", "neighbour": "neighbour",
                "acquaintance": "acquaintance"}.get(kind, "friend")

    async def line(self, ident, situ, doing) -> str:
        b = self.b
        if b.cfg.fake_ai:
            return {"combat": "Get your hands off them, you son of a bitch!", "draw": "Let them go or I swear I'll shoot!",
                    "flee": "No! NO! God help us!"}.get(doing, "Please! Please, mister, bring them back!")
        p = ident.persona
        doing = {"combat": "you go for him - to defend them and your honour", "draw": "you draw your gun on him",
                 "flee": "you run - for help, for the law", "goto_player": "you step in between them and him",
                 "face": "you stand there shouting at him"}.get(doing, doing)
        user = (f"You are {p['name']} ({p['sex']}, {p['age']}, {p['temperament']}, bravery {p.get('bravery', 0.5):.1f}), "
                f"1899. Right now {situ}. What you do: {doing}. Say ONE short spoken line (shouted, pleading, cursing - "
                f"whatever you'd really say; use their name). JSON only: {{\"say\": \"\"}}")
        raw, _, _ = await asyncio.to_thread(b.ai.chat, [{"role": "system", "content": "You voice real people in a western "
                                                                                      "game. One raw spoken line, no narration."},
                                                        {"role": "user", "content": user}], False, 90, 0.95)
        try:
            return str(json.loads(re.search(r"\{.*\}", raw or "", re.S).group(0)).get("say", ""))[:200]
        except Exception:
            return (raw or "").strip().strip('"')[:200]

    # ── home: the guide goes to his people, they come to him ──
    def go_home_to_family(self, guide_conv, people: list[dict]):
        b = self.b
        if not guide_conv or guide_conv.ended or b.dead(guide_conv.ped) or guide_conv.ped in self.greeted:
            return
        self.greeted.add(guide_conv.ped)
        spouse = next((x for x in people if str(x["mem"].get("relation", "")).lower() in ("wife", "husband")), None)
        first = spouse or (people[0] if people else None)
        if not first:
            return
        b.asi.prim(guide_conv.ped, "home", ("clear",))
        b.asi.prim(guide_conv.ped, "home", ("goto_player", 1.2, 1.4, f"t={first['h']}"))
        b.asi.prim(first["h"], "home", ("clear",))
        b.asi.prim(first["h"], "home", ("goto_player", 1.2, 1.4, f"t={guide_conv.ped}"))
        for x in people:
            if x is not first and x.get("child"):
                b.asi.prim(x["h"], "home", ("clear",))
                b.asi.prim(x["h"], "home", ("goto_player", 1.6, 2.0, f"t={guide_conv.ped}"))
        guide_conv.flags["following"] = False
        log.info("[DRAMA] %s walks over to %s (home)", guide_conv.name, first["ident"].persona["name"])
