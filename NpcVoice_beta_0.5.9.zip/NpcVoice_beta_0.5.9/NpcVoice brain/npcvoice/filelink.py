"""File link to NpcVoice.asi: no sockets, no ports - works even when the game's networking is blocked.

Folder: %LOCALAPPDATA%\\NpcVoice\\link (or NPCVOICE_LINK_DIR). The game writes session.txt and
a2b_<sid>_<seg>.txt; the brain writes b2a_<sid>_<seg>.txt and brain_alive.txt ("<sid> <ms>").
Writers only append; readers delete a segment once the next one exists.
"""
from __future__ import annotations

import asyncio
import json
import os
import time
import traceback
from pathlib import Path

from .log import log

SEG_MAX = 1_000_000


def default_dir() -> Path:
    env = os.environ.get("NPCVOICE_LINK_DIR")
    if env:
        return Path(env)
    base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    return Path(base) / "NpcVoice" / "link"


class FileWriter:
    """Looks like an asyncio StreamWriter to Asi: write(bytes) / is_closing() / close()."""

    def __init__(self, folder: Path, sid: str):
        self.folder, self.sid, self.seg, self.closed = folder, sid, 0, False
        self.f = open(self._path(), "ab")

    def _path(self):
        return self.folder / f"b2a_{self.sid}_{self.seg}.txt"

    def write(self, data: bytes):
        if self.closed:
            return
        try:
            self.f.write(data)
            self.f.flush()
            if self.f.tell() > SEG_MAX:
                self.f.close()
                self.seg += 1
                self.f = open(self._path(), "ab")
        except OSError as e:
            log.warning("[LINK] write failed: %s", e)

    def is_closing(self):
        return self.closed

    def close(self):
        self.closed = True
        try:
            self.f.close()
        except OSError:
            pass

    def get_extra_info(self, _):
        return f"file link session {self.sid}"


class FileLink:
    def __init__(self, brain, folder: Path | None = None):
        self.brain = brain
        self.folder = folder or default_dir()
        self.sid = ""
        self.writer: FileWriter | None = None
        self.rseg, self.roff, self.rx = 0, 0, b""
        self.last_data = 0.0
        self.live = False

    async def run(self):
        self.folder.mkdir(parents=True, exist_ok=True)
        log.info("file link: watching %s (no networking needed)", self.folder)
        last_hb = 0.0
        while True:
            try:
                await self.step()
                now = time.time()
                if self.sid and now - last_hb > 0.5:
                    last_hb = now
                    self._heartbeat(now)
            except Exception:
                log.error("[LINK] crashed:\n%s", traceback.format_exc())
                await asyncio.sleep(1)
            await asyncio.sleep(0.015)

    def _heartbeat(self, now: float):
        """Overwrite in place with a fixed-length line: never replaced/renamed, so Windows file locks
        (the game reading it at the same moment) can't make it fail or look stale."""
        line = f"{int(self.sid):020d} {int(now * 1000):020d}\n".encode()
        p = self.folder / "brain_alive.txt"
        try:
            with open(p, "r+b" if p.exists() else "wb") as f:
                f.seek(0)
                f.write(line)
                f.truncate(len(line))
        except OSError as e:
            if now - getattr(self, "_hb_warn", 0) > 10:
                self._hb_warn = now
                log.warning("[LINK] heartbeat write failed (will retry): %s", e)

    def _read_sid(self) -> str:
        try:
            return (self.folder / "session.txt").read_text().strip()
        except OSError:
            return ""

    async def step(self):
        sid = self._read_sid()
        if sid and sid != self.sid:
            await self._new_session(sid)
        if not self.sid:
            return
        p = self.folder / f"a2b_{self.sid}_{self.rseg}.txt"
        data = b""
        try:
            with open(p, "rb") as f:
                f.seek(self.roff)
                data = f.read()
        except OSError:
            pass
        if data:
            self.roff += len(data)
            self.rx += data
            self.last_data = time.time()
            if not self.live:
                await self._attach()
            *lines, self.rx = self.rx.split(b"\n")
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line.decode("utf-8", "replace"))
                except json.JSONDecodeError:
                    log.warning("[LINK] bad line: %r", line[:200])
                    continue
                try:
                    await self.brain.on_msg(msg)
                except Exception:
                    log.error("handler crashed on %s:\n%s", msg.get("t"), traceback.format_exc())
        else:
            nxt = self.folder / f"a2b_{self.sid}_{self.rseg + 1}.txt"
            if nxt.exists():
                try:
                    p.unlink()
                except OSError:
                    pass
                self.rseg, self.roff = self.rseg + 1, 0
            # the game sends at least one tick per second while running
            if self.live and time.time() - self.last_data > 12:
                log.warning("[LINK] no data from the game for 12 s – treating as disconnected")
                self._detach()

    async def _new_session(self, sid: str):
        log.info("[LINK] game session %s started (previous: %s)", sid, self.sid or "none")
        self._detach()
        if self.writer:
            self.writer.close()
        for old in self.folder.glob("b2a_*.txt"):
            if not old.name.startswith(f"b2a_{sid}_"):
                try:
                    old.unlink()
                except OSError:
                    pass
        self.sid, self.rseg, self.roff, self.rx = sid, 0, 0, b""
        self.writer = FileWriter(self.folder, sid)
        self.last_data = time.time()

    async def _attach(self):
        if self.brain.asi.up and not isinstance(self.brain.asi.writer, FileWriter):
            log.warning("[LINK] a TCP game connection is also open – the file link takes over")
        self.brain.asi.writer = self.writer
        self.live = True
        log.info("game connected through the file link (%s)", self.folder)

    def _detach(self):
        if self.live:
            self.live = False
            if self.brain.asi.writer is self.writer:
                self.brain.asi.writer = None
            self.brain.on_game_lost()
            log.info("game disconnected (file link)")
