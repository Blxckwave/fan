"""Microphone capture (push-to-talk from the game) and positional NPC voice playback."""
from __future__ import annotations

import io
import math
import os
import threading
import wave

from .log import log

SAMPLE_RATE = 16000
# keep Ctrl+C / window-close working: SDL (pygame) would otherwise swallow the signals
os.environ.setdefault("SDL_NO_SIGNAL_HANDLERS", "1")
os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")


class Recorder:
    """The microphone stream is opened ONCE and stays open; push-to-talk only switches collecting on/off.
    (Opening/closing a stream on every X press could hang on some Windows audio drivers.)"""

    def __init__(self, device=None):
        self.device = device
        self._frames = []
        self._stream = None
        self._recording = False
        self._lock = threading.Lock()
        self.available = True
        self.error = ""
        try:
            import sounddevice  # noqa: F401
        except Exception as e:
            self.available = False
            self.error = str(e)
            log.error("[MIC] sounddevice unavailable: %s", e)

    def open(self) -> bool:
        if not self.available:
            return False
        if self._stream:
            return True
        import sounddevice as sd
        try:
            self._stream = sd.InputStream(samplerate=SAMPLE_RATE, channels=1, dtype="int16",
                                          device=self.device, callback=self._cb, blocksize=0)
            self._stream.start()
            try:
                name = sd.query_devices(self._stream.device)["name"]
            except Exception:
                name = str(self._stream.device)
            log.info("[MIC] microphone open (stays open): %s", name)
            return True
        except Exception as e:
            self.error = str(e)
            log.error("[MIC] cannot open microphone: %s", e)
            self._stream = None
            return False

    def _cb(self, indata, frames, t, status):
        if self._recording:
            self._frames.append(indata.copy())

    def start(self) -> bool:
        if not self.open():
            return False
        with self._lock:
            self._frames = []
            self._recording = True
        log.debug("[MIC] collecting")
        return True

    def stop(self) -> tuple[bytes | None, float, int]:
        """-> (wav bytes, seconds, peak level)"""
        with self._lock:
            self._recording = False
            frames, self._frames = self._frames, []
        if not frames:
            return None, 0.0, 0
        import numpy as np
        audio = np.concatenate(frames, axis=0)
        secs = len(audio) / SAMPLE_RATE
        peak = int(np.abs(audio).max()) if len(audio) else 0
        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(SAMPLE_RATE)
            wf.writeframes(audio.tobytes())
        log.debug("[MIC] captured %.2fs peak=%d", secs, peak)
        return buf.getvalue(), secs, peak


class Voice3D:
    """Plays one NPC line at a time; volume/pan follow the ped's position relative to the camera."""

    def __init__(self, near_m=3.0, far_m=35.0, master=1.0):
        self.near, self.far, self.master = near_m, far_m, master
        self.ok = False
        self._chan = None
        self._snd = None
        self._music_mode = False
        self._lock = threading.Lock()
        self.playing_ped = 0
        self._paused = False
        try:
            import pygame
            pygame.mixer.pre_init(frequency=32000, size=-16, channels=2)
            pygame.mixer.init()
            pygame.mixer.set_num_channels(4)
            self.ok = True
            log.info("[AUDIO] mixer ready %s", pygame.mixer.get_init())
        except Exception as e:
            log.error("[AUDIO] pygame mixer unavailable (%s) – NPC voices will be silent, subtitles still work", e)

    def length_of(self, mp3: bytes) -> float:
        if not self.ok:
            return max(1.5, len(mp3) / 16000.0)
        import pygame
        try:
            return pygame.mixer.Sound(file=io.BytesIO(mp3)).get_length()
        except Exception:
            return max(1.5, len(mp3) / 16000.0)   # 128 kbps ≈ 16 kB/s

    def play(self, mp3: bytes, ped: int) -> float:
        """Start playback, return duration (s)."""
        self.stop()
        if not self.ok:
            self.playing_ped = ped
            return self.length_of(mp3)
        import pygame
        with self._lock:
            try:
                self._snd = pygame.mixer.Sound(file=io.BytesIO(mp3))
                self._chan = self._snd.play()
                self._music_mode = False
                dur = self._snd.get_length()
            except Exception as e:
                log.warning("[AUDIO] Sound() cannot decode mp3 (%s) – using music stream without panning", e)
                pygame.mixer.music.load(io.BytesIO(mp3))
                pygame.mixer.music.play()
                self._music_mode = True
                dur = max(1.5, len(mp3) / 16000.0)
            self.playing_ped = ped
            return dur

    def busy(self) -> bool:
        if not self.ok:
            return False
        import pygame
        with self._lock:
            if self._music_mode:
                return pygame.mixer.music.get_busy()
            return bool(self._chan and self._chan.get_busy())

    def stop(self):
        with self._lock:
            self.playing_ped = 0
            if not self.ok:
                return
            import pygame
            try:
                if self._chan:
                    self._chan.stop()
                pygame.mixer.music.stop()
            except Exception:
                pass
            self._chan = None

    def set_paused(self, paused: bool):
        if not self.ok or paused == self._paused:
            return
        import pygame
        self._paused = paused
        (pygame.mixer.pause if paused else pygame.mixer.unpause)()
        (pygame.mixer.music.pause if paused else pygame.mixer.music.unpause)()

    def spatialize(self, player: dict, ped: dict):
        """Volume by distance from the camera, stereo pan by angle, muffled without line of sight."""
        if not self.ok or not ped:
            return
        try:
            cx, cy, cz = player.get("cx", player["x"]), player.get("cy", player["y"]), player.get("cz", player["z"])
            dx, dy, dz = ped["x"] - cx, ped["y"] - cy, ped["z"] + 0.6 - cz
        except KeyError:
            return
        d = math.sqrt(dx * dx + dy * dy + dz * dz)
        if d <= self.near:
            vol = 1.0
        elif d >= self.far:
            vol = 0.0
        else:
            x = (d - self.near) / (self.far - self.near)
            vol = (1 - x) ** 1.6
        if not ped.get("los", 1):
            vol *= 0.55
        vol *= self.master
        yaw = math.radians(player.get("cyaw", 0.0))
        # RDR2: heading 0 = +Y (north), positive yaw turns left (counter-clockwise)
        fx, fy = -math.sin(yaw), math.cos(yaw)
        rx, ry = fy, -fx
        horiz = math.hypot(dx, dy) or 1.0
        pan = (dx * rx + dy * ry) / horiz          # -1 left … +1 right
        left = vol * min(1.0, 1.0 - 0.75 * max(0.0, pan))
        right = vol * min(1.0, 1.0 + 0.75 * min(0.0, pan))
        import pygame
        with self._lock:
            if self._music_mode:
                pygame.mixer.music.set_volume(vol)
            elif self._chan:
                self._chan.set_volume(left, right)
        return vol, pan
