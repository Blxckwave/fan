"""Daily life (0.5.0): every person you've met has a home, a workplace and a day.

- HOME: a real lived-in place (house, shack, cabin, farmhouse, camp...) near where you first met them, from the game
  database - picked once and remembered. WORK: the real place their job is done (the saloon for a bartender, the
  general store for a clerk, the sheriff's office for a deputy, a farm for a farmer...).
- ROUTINE: wake, work, eat, work, evening (saloon / home / church on Sunday), sleep - seeded per person, so it's
  stable from day to day but different between people; night workers (bartenders, working girls) are the other way.
- JOURNAL: what they did today = the routine up to the current game hour + what REALLY happened to them (memory
  events from today: met you, made love, were robbed, saw a body...). Put in the prompt so they know their day.
- APPOINTMENTS: "meet me at the saloon tonight" is remembered, and next time they know if you came.
"""
from __future__ import annotations

import math
import random

WORK_KIND = [   # job words -> the kind of real place the work happens at
    (("bartender", "saloon", "working girl", "gambler"), ["saloon", "brothel", "hotel"]),
    (("store", "clerk", "shopkeeper", "butcher", "baker", "cobbler"), ["general store"]),
    (("gunsmith",), ["gunsmith"]), (("doctor", "nurse"), ["doctor"]), (("barber",), ["barber"]), (("tailor", "seamstress"), ["tailor"]),
    (("deputy", "sheriff", "marshal", "police", "lawman"), ["sheriff office", "police station", "jail"]),
    (("bank", "banker"), ["bank"]), (("photographer",), ["photo studio"]), (("telegraph", "post office", "station", "railroad"), ["train station", "station"]),
    (("stable", "horse"), ["stable"]), (("blacksmith",), ["blacksmith", "stable"]), (("preacher", "organist", "church"), ["church"]),
    (("teacher", "school"), ["school"]), (("miner", "coal"), ["mine"]), (("farmer", "rancher", "ranch hand", "homesteader", "dairy", "herder"),
                                                                       ["farmhouse", "farm", "ranch", "barn"]),
    (("lumberjack", "carpenter", "sawmill"), ["mill", "barn"]), (("dock", "fisher"), ["dock", "boathouse"]),
    (("hotel", "boarding-house"), ["hotel"]), (("undertaker",), ["building"]), (("teamster", "driver", "coachman", "carter", "delivery"),
                                                                                 ["stable", "general store", "station"]),
]
HOME_KINDS = ["house", "shack", "cabin", "farmhouse", "camp", "ranch", "farm", "mansion", "hotel"]
NIGHT = ("bartender", "working girl", "gambler")


def _rng(ident, salt=""):
    return random.Random(f"{ident.id}:{salt}")


def assign_places(ident, db, x: float, y: float):
    """Home + work, from real places near where you met them. Stored once in the identity."""
    d = ident.d
    if d.get("home_place") or db is None or not db.ok:
        return
    rng = _rng(ident, "home")
    job = (ident.persona.get("job") or "").lower()
    homes = db.places_near(x, y, HOME_KINDS, 0, 1600, lived_in=None)
    homes = [h for h in homes if h["kind"] in HOME_KINDS] or db.places_near(x, y, HOME_KINDS, 0, 4000)
    if homes:
        h = rng.choice(homes[:5])
        d["home_place"] = {k: h[k] for k in ("name", "kind", "town", "x", "y", "z")}
    kinds = next((k for words, k in WORK_KIND if any(w in job for w in words)), None)
    if kinds:
        work = db.places_near(x, y, kinds, 0, 2500)
        if work:
            w = rng.choice(work[:3])
            d["work_place"] = {k: w[k] for k in ("name", "kind", "town", "x", "y", "z")}
    ident.dirty()


def _label(p: dict | None, fallback: str) -> str:
    if not p:
        return fallback
    return f"the {p['kind']}" + (f" in {p['town']}" if p.get("town") else " out of town")


def routine(ident, weekday: int) -> list[tuple[float, str]]:
    """(start hour, what) for one day. weekday 0 = Sunday (game clock)."""
    if ident.d.get("household"):
        from .household import routine_for_ident
        return routine_for_ident(ident, weekday)
    rng = _rng(ident, f"day{weekday}")
    p = ident.persona
    job = (p.get("job") or "").lower()
    home = _label(ident.d.get("home_place"), "home")
    work = _label(ident.d.get("work_place"), "work")
    if p.get("child"):
        return [(6.5, f"woke up at {home}"), (8, "did chores at home"), (10, "played outside"), (13, "ate with the family"),
                (14, "ran an errand for ma"), (18, "had supper at home"), (20.5, "went to bed")]
    wake = rng.choice([5, 5.5, 6, 6.5, 7])
    if any(w in job for w in NIGHT):
        return [(10 + rng.random(), f"woke up late at {home}"), (12, "ate something"), (14, f"went to {work}"),
                (16, f"worked at {work}"), (21, f"busy night at {work}"), (2, f"went back to {home} to sleep")]
    if weekday == 0 and rng.random() < 0.6:
        return [(wake, f"woke up at {home}"), (9, "went to church"), (12, "Sunday dinner with family or friends"),
                (15, "rested, walked around town"), (19, rng.choice(["had a drink at the saloon", "stayed home"])), (21.5, f"went to bed at {home}")]
    evening = rng.choice(["had a drink at the saloon", "ate supper at home", "visited a friend", "played cards at the saloon",
                          "stayed home mending things"])
    return [(wake, f"woke up at {home}"), (wake + 0.5, "had breakfast"), (wake + 1.5, f"went to work at {work}"),
            (12, "ate lunch"), (13, f"back to work at {work}"), (18, "finished work"), (19, evening), (22, f"went to bed at {home}")]


def journal(ident, weekday: int, hour: float, minute: int, game_min_total: float) -> list[str]:
    """Today so far: the routine up to now, mixed with what really happened today."""
    out = []
    for h, what in routine(ident, weekday):
        if h <= hour + minute / 60:
            out.append((h, what))
    day_start = game_min_total - (hour * 60 + minute)
    for e in ident.d.get("events", [])[-30:]:
        gm = e.get("game_min")
        if gm is not None and gm >= day_start - 1:
            h = (gm - day_start) / 60.0
            out.append((h, e.get("what", "")))
    out.sort(key=lambda t: t[0])
    lines = []
    for h, what in out[-9:]:
        hh = int(h) % 24
        lines.append(f"{hh:02d}:{int((h % 1) * 60):02d} {what}")
    return lines


def now_should_be(ident, weekday: int, hour: float) -> str:
    cur = None
    for h, what in routine(ident, weekday):
        if h <= hour:
            cur = what
    return cur or "at home"


def day_text(ident, game) -> str:
    w = game.world
    hr, mn, dow = int(w.get("hr", 12)), int(w.get("mn", 0)), int(w.get("dow", 1))
    home, work = ident.d.get("home_place"), ident.d.get("work_place")
    lines = []
    if home:
        lines.append(f"You live at {_label(home, 'home')} ({home['name']}).")
    if work:
        lines.append(f"You work at {_label(work, 'work')}.")
    j = journal(ident, dow, hr, mn, game.game_minutes_total)
    if j:
        lines.append("Your day so far:\n  - " + "\n  - ".join(j))
    appts = [a for a in ident.d.get("appointments", []) if not a.get("done")]
    for a in appts[-2:]:
        lines.append(f"You promised to meet him at {a['where']} ({a['when']}).")
    return "\n".join(lines)


def add_appointment(ident, where: str, when: str, game_min: float):
    ident.d.setdefault("appointments", []).append({"where": where, "when": when, "made": game_min, "done": False})
    ident.d["appointments"] = ident.d["appointments"][-5:]
    ident.dirty()
