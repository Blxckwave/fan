"""0.5.7 - people who are RIGHT THERE know it, and what you do to someone is felt by them and by the people who love them.

From the 2026-11-14 00:02-00:51 logs:
  - Cole Bailey, wagon driver, two passengers on his seat: "I don't have any passengers. It's just me!" - the prompt said
    "nobody else is around" (in St Denis the plugin's 256-slot ped list ran out before reaching them). Now the people on
    the same horse / wagon come straight from the seats (tick `mates`), they are ALWAYS in the prompt as "with you right
    now", they hear every word, and an order to the driver about them ("tell your passengers to get off") reaches them:
    each one answers and acts for themselves (obeys, freezes, runs, fights) right after the driver.
  - Henrietta King behind Seamus on his horse: "I ain't got no one with me" - same fix (the rider is read from the horse).
  - Looting: going through the pockets of someone tied up / knocked down / held up is noticed (the game's own
    looting state), remembered, and reacted to - also by someone you weren't talking to.
  - Stripped against their will and tied: every step closer makes it worse (terror, disgust, shame - nothing sexual),
    stepping back is a small relief. Their kin who see it react through drama.py ("stripped", "looted", "tied").
"""
from __future__ import annotations

import random
import re
import time
import traceback

from .log import log

# words that make the people riding with the one you talk to answer as well (they heard it all anyway)
MATES_RE = re.compile(r"\b(passengers?|riders?|the others?|other ones?|your (wife|husband|missus|woman|man|friends?|family|"
                      r"folks|kids?|children|boys?|girls?|sons?|daughters?|brothers?|sisters?|companions?|partners?|"
                      r"people|friend there|pa|ma|mother|father)|him too|her too|them too|they|them|everyone|everybody|"
                      r"every one of you|all of you|both of you|you two|you both|the two of you|y'?all|whoever|nobody "
                      r"moves|get (off|down|out)|off the (wagon|horse|coach|cart)|hands up|surrender|on the ground)\b")
# player distance bands for someone stripped against their will (m): each step closer is a new, worse moment
BANDS = [(1.6, "right on top of you - close enough to touch you"), (3.2, "a step or two away"),
         (6.0, "coming toward you")]


def now() -> float:
    return time.time()


class Witness:
    def __init__(self, brain):
        self.b = brain
        self.nude_seen: dict[int, tuple[int, float]] = {}      # ped -> (nude 0/1, when) from the area scan
        self.looted_seen: dict[int, float] = {}

    # ── who is on the same horse / wagon ─────────────────────────────────────────────────────────────────────────
    def mates_of(self, conv) -> list[dict]:
        """People sharing this person's horse or wagon: from their own tick (seats, rider) - never from the area scan
        alone - plus anyone the scan saw on the same horse/wagon."""
        g = self.b.game
        me = g.ped(conv.ped) or {}
        out, seen = [], set()
        for m in me.get("mates") or []:
            h = int(m.get("h", 0) or 0)
            if h and h != conv.ped and h not in seen and m.get("alive", 1):
                seen.add(h)
                out.append(dict(m))
        myveh, mymount = int(me.get("vh", 0) or 0), int(me.get("mh", 0) or 0)
        for p in g.near_peds or []:
            h = int(p.get("h", 0) or 0)
            if not h or h == conv.ped or h in seen or not p.get("alive", 1):
                continue
            if (myveh and int(p.get("vh", 0) or 0) == myveh) or (mymount and int(p.get("mh", 0) or 0) == mymount):
                seen.add(h)
                how = ("driver" if p.get("drv") else "passenger") if myveh else \
                    ("rider" if int(me.get("mr", 0) or 0) == h else "behind")
                out.append({"h": h, "m": p.get("m"), "o": p.get("o"), "male": p.get("male"), "alive": 1, "how": how})
        return out

    def merge_into_near(self, conv, near: list[dict]) -> list[dict]:
        """The prompt's people list always holds the mates, whatever the area scan saw (St Denis: it saw nobody)."""
        mates = self.mates_of(conv)
        if not mates:
            return near
        have = {int(p.get("h", 0) or 0) for p in near}
        me = self.b.game.ped(conv.ped) or {}
        extra = []
        for m in mates:
            h = int(m["h"])
            if h in have:
                for p in near:
                    if int(p.get("h", 0) or 0) == h:
                        p.setdefault("how", m.get("how"))
                continue
            extra.append({"h": h, "m": m.get("m", 0), "o": m.get("o", 0), "male": m.get("male", 0), "alive": 1,
                          "d": me.get("d", 3), "de": 0.7, "los": 1, "elos": 1, "how": m.get("how"),
                          "vh": me.get("vh", 0) if m.get("how") in ("driver", "passenger") else 0,
                          "mh": me.get("mh", 0) if m.get("how") in ("rider", "behind") else 0,
                          "mnt": 1 if m.get("how") in ("rider", "behind") else 0})
        return list(near) + extra

    def mate_convs(self, conv) -> list:
        return [c for c in (self.b.convs.get(int(m["h"])) for m in self.mates_of(conv)) if c and not c.ended]

    def bring_in_mates(self, conv) -> list:
        """The people on the same seat are in this conversation too (they hear everything): each gets their own
        person, memory and voice - without sending the one you're talking to away."""
        out = []
        for m in self.mates_of(conv):
            h = int(m["h"])
            c = self.b.convs.get(h)
            if c and not c.ended:
                out.append(c)
                continue
            try:
                c = self.b.on_engage_req({"ped": h, "model": m.get("m", 0), "outfit": m.get("o", 0),
                                          "male": m.get("male", 0), "human": 1, "alive": 1}, reason="mate", side=True)
            except Exception:
                log.error("[MATES] bring_in crashed:\n%s", traceback.format_exc())
                c = None
            if c:
                c.flags["mate_of"] = conv.ped
                log.info("[MATES] %s rides with %s (%s) - hears everything", c.name, conv.name, m.get("how"))
                out.append(c)
        return out

    def mates_should_answer(self, utterance: str, conv=None) -> bool:
        low = (utterance or "").lower()
        if MATES_RE.search(low):
            return True
        if conv is not None:            # their names / what they are to the one you talk to
            for c in self.mate_convs(conv):
                first = (c.ident.persona.get("first_name") or "").lower()
                if first and re.search(r"\b" + re.escape(first) + r"\b", low):
                    return True
        return False

    def mate_followup_event(self, first, c) -> str:
        """What the passenger heard: the player's words AND what the driver said/did right next to them."""
        rel = (getattr(first, "together", {}) or {}).get(c.ped) or ""
        said = next((t.split(": ", 1)[1] for t in reversed(first.transcript) if not t.startswith("Player:") and ": " in t),
                    "")
        did = [a for a in (first.flags.get("_last_actions") or [])]
        who = first.ident.persona.get("first_name", "the driver")
        txt = (f"You are RIGHT THERE with {who}" + (f" ({rel.replace('your ', 'he/she is your ')})" if rel else "") +
               " - on the same " + ("wagon" if (self.b.game.ped(first.ped) or {}).get("veh") else "horse") +
               ". You heard every word the stranger said to " + who + ", and " + who + "'s answer")
        if said:
            txt += f": \"{said[:160]}\""
        if did:
            txt += f" ({who} " + ", ".join(did) + ")"
        txt += (". It's about YOU too. Decide for yourself, right now, with an action: do what he ordered, or what "
                f"{who} told you, or refuse, run or fight - whatever YOU would do. Never act as if you weren't there.")
        return txt

    # ── looting ──────────────────────────────────────────────────────────────────────────────────────────────────
    def on_looted(self, conv, cur: dict):
        b, g = self.b, self.b.game
        if conv.seconds_since("looted") < 20:
            return
        conv.mark("looted")
        conv.mark("threatened")
        how = ("tied up and helpless on the ground" if cur.get("hog") else "lying on the ground" if cur.get("rag")
               else "with your hands up" if conv.flags.get("hands_up") else "standing right there")
        conv.pending_events.append(("looted", f"!! The stranger is GOING THROUGH YOUR POCKETS right now - taking your money "
                                              f"and your things while you're {how}. You feel his hands on you. React as "
                                              f"a real person would.", 3))
        conv.ident.add_event("he robbed you - went through your pockets while you were " + how,
                             g.game_minutes_total, g.place(), 3)
        conv.ident.adjust({"anger": 18, "fear": 10, "trust": -20, "respect": -10}, "looted", cap=35)
        from . import world
        world.add_deed(b.memory, g.place(), g.zone()["state"], f"THE_STRANGER robbed {conv.name} (went through their "
                                                               f"pockets)", 2, g.game_minutes_total, g.near.get("people", 0))
        log.info("[LOOT] %s is being looted by the player (%s)", conv.name, how)
        if b.cfg.reactions:
            b.maybe_react(conv)

    # ── stripped against their will: closer is worse ─────────────────────────────────────────────────────────────
    def violation_tick(self, conv, cur: dict):
        f = conv.flags
        if not (f.get("violated") and f.get("naked")) or conv.ended:
            f.pop("_vband", None)
            return
        d = float(cur.get("d", 99) or 99)
        band = next((i for i, (lim, _) in enumerate(BANDS) if d <= lim), None)
        prev = f.get("_vband")
        tied = bool(cur.get("hog") or cur.get("lasso"))
        if band is not None and (prev is None or band < prev) and conv.seconds_since("violation_close") > 4:
            f["_vband"] = band
            conv.mark("violation_close")
            conv.mark("threatened")
            what = BANDS[band][1]
            helpless = (" You're TIED UP - you can't cover yourself, can't get away." if tied else "")
            conv.pending_events.append(("violation_close", f"!! He's coming closer to you - {what} ({d:.1f} m) - while "
                                        f"you're naked against your will.{helpless} You're terrified and disgusted: "
                                        f"scream at him to stay away, beg, call for help, curse him, try to get away - "
                                        f"nothing about this is sexual to you.", 3))
            conv.ident.adjust({"fear": 6 + 4 * (2 - band), "anger": 4, "trust": -6}, "violation_close", cap=25)
            log.info("[VIOLATION] %s: the player comes closer (%.1f m, band %d%s)", conv.name, d, band, ", tied" if tied else "")
            if not tied and band == 0 and not f.get("hands_up") and not cur.get("aimed") and \
                    float(conv.ident.persona.get("bravery", 0.4)) < 0.6:
                self.b.asi.prim(conv.ped, "violation", ("clear",))      # backs off from him
                self.b.asi.prim(conv.ped, "violation", ("flee", 12))
            if self.b.cfg.reactions:
                self.b.maybe_react(conv)
        elif prev is not None and d > 8 and conv.seconds_since("violation_close") > 6:
            f["_vband"] = None
            conv.pending_events.append(("violation_away", f"He stepped back ({d:.0f} m) - but you're still naked and "
                                        + ("tied up" if tied else "exposed") + ".", 1))

    # ── people you weren't talking to: looted / stripped right in front of you ────────────────────────────────────
    def on_nearby(self, peds: list[dict]):
        b = self.b
        if not b.asi.up or b.ptt_ped or b.frozen:
            return
        t = now()
        for p in peds:
            h = int(p.get("h", 0) or 0)
            if not h or not p.get("alive", 1):
                continue
            conv = b.convs.get(h)
            if conv and not conv.ended:
                continue                         # their own tick drives them
            if p.get("lt") and t - self.looted_seen.get(h, 0) > 30:
                self.looted_seen[h] = t
                c = self.engage_victim(p, "looted")
                if c:
                    self.on_looted(c, dict(p, hog=p.get("hog")))
                continue
            if "nude" in p:
                was = self.nude_seen.get(h)
                self.nude_seen[h] = (int(p.get("nude") or 0), t)
                if was is not None and was[0] == 0 and p.get("nude") and p.get("d", 99) < 4 and t - was[1] < 10:
                    c = self.engage_victim(p, "stripped")
                    if c:
                        c.flags["_had_clothes"] = True
                        b.on_undressed(c, dict(p, d=p.get("d", 2)))
                        if b.cfg.reactions:
                            b.maybe_react(c)
        if len(self.nude_seen) > 400:
            for h in [k for k, v in self.nude_seen.items() if t - v[1] > 60]:
                self.nude_seen.pop(h, None)

    def engage_victim(self, p: dict, why: str):
        b = self.b
        b.asi.send("engage", int(p["h"]))
        c = b.on_engage_req({"ped": int(p["h"]), "model": p.get("m", 0), "outfit": p.get("o", 0), "male": p.get("male", 0),
                             "human": 1, "alive": 1}, reason=why)
        if c:
            log.info("[WITNESS] %s noticed: %s (not in a conversation before)", c.name, why)
        return c

    def tick(self):
        """Every second: the violation distance bands for everyone stripped against their will."""
        try:
            for conv in list(self.b.convs.values()):
                if conv.ended or self.b.dead(conv.ped):
                    continue
                cur = self.b.game.ped(conv.ped)
                if cur:
                    self.violation_tick(conv, cur)
        except Exception:
            log.error("[WITNESS] tick crashed:\n%s", traceback.format_exc())
