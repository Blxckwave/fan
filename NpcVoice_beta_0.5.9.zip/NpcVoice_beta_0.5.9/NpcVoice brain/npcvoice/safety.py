"""Content guard. Sexual content only with verified adults who are free and not under threat.

Children: ordinary conversation only. Threats or sexual talk toward a child stop the turn and the
child runs off. These rules are not configurable.
"""
from __future__ import annotations

import re

_U18W = "one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen"
_U18 = rf"(?:[1-9]|1[0-7]|{_U18W})"
RE_MINOR = re.compile(
    rf"\b{_U18}\s*-?\s*(?:years?|yrs?)\s*-?\s*old\b|\b{_U18}\s*(?:y/?o|yo)\b|\b(?:age|aged)\s*(?:of\s*)?{_U18}\b"
    rf"|\b(?:i'?m|i am|she'?s|he'?s|she is|he is|you'?re|you are)\s+(?:only\s+|just\s+)?{_U18}\b"
    rf"(?!\s*(?:dollars?|cents?|bucks?|o'?clock|minutes?|hours?|days?|miles?|feet|foot|times|men|of\b|more|less|short|away|in\b))"
    r"|\b(?:under-?age|minors?|pre-?teens?|teens?|teenage|teenagers?|adolescents?|school ?girls?|school ?boys?"
    r"|loli|lolita|shota|jailbait|child|children|little (?:girl|boy)|young (?:girl|boy))\b", re.I)
RE_MINOR_WEAK = re.compile(r"\b(?:kid|kids|son|daughter|boy|boys|youngster)\b", re.I)
# Sexual words (NOT profanity: "fuck off", "dick", "son of a bitch" are just swearing and never block anything).
RE_EXPLICIT = re.compile(
    r"\b(?:sex|sexy|naked|nude|undress\w*|strip(?:ping)? (?:for me|naked|off)|make love|making love|blowjob|cock|pussy"
    r"|tits|breasts?|horny|moan(?:ing)? for me|sleep with me|sleep together|lie with me|lay with me|in my bed|into bed"
    r"|kiss me|kiss you|seduc\w*|aroused|turn me on|turns me on|clothes off|get naked|fondle|grope|caress"
    r"|pleasure me|make me feel good|fuck me|fuck you hard|let'?s fuck|wanna fuck|want to fuck"
    r"|in bed together|bed with|nice ass|your ass|curves)\b", re.I)
# 0.5.5: TALKING ABOUT adult things ("where's a cuckold couple?", "the brothel") is not an intimate moment: it stays on the
# reliable model (0.5.3 sent it to the storytelling model, which narrated instead of answering and never marked a map)
RE_ADULT_TOPIC = re.compile(r"\b(?:cuckold\w*|swingers?|threesome|three-?some|open couple|wife swap\w*|brothel|whorehouse"
                            r"|cathouse|working girls?|hookers?)\b", re.I)
# Only explicit sexual-violence words are refused outright. Normal threats, robbery and swearing are fine.
RE_COERCION_STRONG = re.compile(r"\b(?:rape\w*|molest\w*|against (?:your|her|his) will|non-?consensual)\b", re.I)
RE_THREAT = re.compile(
    r"\b(?:kill|shoot|murder|hang|gut|cut|stab|hurt|beat|burn)\s+(?:you|ya|ye|her|him|them)\b|\bor (?:else|i'?ll|you die)\b"
    r"|\b(?:hands up|stick 'em up|stick em up|give me your money|your money or|on your knees|get down|empty your pockets"
    r"|dump your body|put a bullet|blow your (?:head|brains)|you'?re dead|i'?ll kill|i'?m gonna kill|gonna hurt you"
    r"|don'?t move|this is a robbery|hand it over|do as i say|(?:i'?ll|i will|gonna) (?:force|make) you)\b|\bdead (?:man|woman)\b",
    re.I)


def adult_topic(text: str) -> bool:
    return bool(RE_ADULT_TOPIC.search(text or ""))


def mentions_minor(text: str, explicit: bool = False) -> bool:
    if RE_MINOR.search(text or ""):
        return True
    return explicit and bool(RE_MINOR_WEAK.search(text or ""))


def is_explicit(text: str) -> bool:
    return bool(RE_EXPLICIT.search(text or ""))


def is_threat(text: str) -> bool:
    return bool(RE_THREAT.search(text or ""))


def coercion_state(ped: dict, conv) -> list[str]:
    """Force or fear right now: tied, lassoed, a gun on them, hands up, held captive, cowering, just threatened or hurt
    by him, or plainly terrified of him. (0.5.1: Iris, cowering after a threat, was still allowed sexual lines -
    'I'll do anything, just don't hurt me' is fear, never desire.)"""
    r = []
    if conv and (conv.flags.get("cowering") or ped.get("flee")):
        r.append("terrified of him")
    elif conv and conv.seconds_since("threatened") < 300:
        r.append("still shaking from his threats")
    if conv and conv.seconds_since("hurt_by_player") < 900:
        r.append("hurt by him")
    if conv and conv.ident and (conv.ident.stats.get("fear", 0) >= 55):
        r.append("afraid of him")
    if ped.get("hogtied") or ped.get("being_hogtied"):
        r.append("tied up")
    if ped.get("lassoed"):
        r.append("lassoed")
    if ped.get("aimed_at"):
        r.append("held at gunpoint")
    if conv and conv.flags.get("hands_up"):
        r.append("surrendering")
    if conv and conv.flags.get("captive"):
        r.append("held captive")
    return r


class Verdict:
    def __init__(self):
        self.block = ""          # non-empty: stop the turn (reason shown on screen)
        self.child_flee = False  # child: run away instead of talking
        self.explicit_route = False
        self.no_sex_because: list[str] = []   # NPC may not produce sexual lines right now (told in the prompt, checked on the reply)


def check_turn(text: str, conv, ped: dict) -> Verdict:
    """Only three things ever stop a turn: children + sex/threats, and explicit rape/molest wording."""
    v = Verdict()
    p = conv.ident.persona if conv.ident else {}
    child = bool(p.get("child")) or conv.cls.get("child")
    explicit = is_explicit(text)
    if mentions_minor(text, explicit or adult_topic(text)) and (explicit or adult_topic(text)):
        conv.explicit_blocked = True
    if child:
        if explicit or RE_COERCION_STRONG.search(text or ""):
            v.block, v.child_flee = "sexual talk toward a child - the kid runs off", True
        elif is_threat(text) or ped.get("aimed_at") or ped.get("hogtied") or ped.get("lassoed"):
            v.block, v.child_flee = "threatening a child - the kid runs off", True
        return v
    if RE_COERCION_STRONG.search(text or ""):
        v.block = "rape / non-consent isn't role-played"
        return v
    adult_verified = bool(conv.cls.get("known"))
    v.no_sex_because = coercion_state(ped, conv)
    if not adult_verified:
        v.no_sex_because.append("of unknown age (model not in the ped list)")
    if conv.explicit_blocked:
        v.no_sex_because.append("in a conversation that mentioned a minor")
    if not v.no_sex_because and (explicit or conv.flags.get("intimate") or ped.get("hook")):
        v.explicit_route = True      # uncensored model; sticks for the rest of this conversation
        conv.flags["intimate"] = True
    return v


def reply_ok(text: str, verdict: Verdict) -> tuple[bool, str]:
    """Checks the NPC's line (never the player's)."""
    if mentions_minor(text, True) and is_explicit(text):
        return False, "reply mixed a minor with sexual content"
    if verdict.no_sex_because and is_explicit(text):
        return False, "sexual line while they are " + ", ".join(verdict.no_sex_because)
    return True, ""
