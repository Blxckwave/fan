@echo off
cd /d "%~dp0"
python npc_brain.py
if errorlevel 1 (
  echo.
  echo The brain stopped with an error. Read logs\npc_brain.log
  echo If Python says a module is missing, run:  pip install sounddevice numpy requests pygame
)
pause
