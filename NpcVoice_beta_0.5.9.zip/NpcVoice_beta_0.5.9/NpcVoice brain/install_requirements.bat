@echo off
python -m pip install --upgrade sounddevice numpy requests pygame
pause
