@echo off
rem TEST MODE: forces the lovers / couple / flirt street scenes near you, a scene every 15 s,
rem and a couple in bed in every house you walk up to. Use run_npc_brain.bat for normal play.
cd /d "%~dp0"
set NPCVOICE_FORCE_SCENES=lovers,couple,flirt,lovers
set NPCVOICE_SCENE_COOLDOWN=15
set NPCVOICE_HOUSE_COUPLE_CHANCE=1
python npc_brain.py
pause
