#!/usr/bin/env python3
"""NpcVoice brain. Start this (or run_npc_brain.bat) before or after starting RDR2.

    pip install sounddevice numpy requests pygame
"""
import asyncio
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from npcvoice import log as logmod  # noqa: E402
from npcvoice.config import Config  # noqa: E402


def main():
    cfg = Config(ROOT / "NpcVoice_brain.ini")
    logmod.setup(ROOT / "logs", debug=cfg.debug or "--debug" in sys.argv)
    from npcvoice.brain import Brain
    b = Brain(ROOT)
    if "--fake-ai" in sys.argv:
        b.cfg.fake_ai = True
    try:
        asyncio.run(b.run())
    except KeyboardInterrupt:
        logmod.log.info("bye")
    except OSError as e:
        if getattr(e, "errno", None) in (98, 10048):
            logmod.log.error("Port %d is already in use - another npc_brain is probably still running. "
                             "Close it (or change port in NpcVoice_brain.ini AND NpcVoice.ini).", b.cfg.port)
        else:
            logmod.log.exception("brain stopped")
        sys.exit(1)


if __name__ == "__main__":
    main()
