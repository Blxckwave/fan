"""0.5.7 - from the 2026-11-14 00:02-00:51 logs:
  Cole Bailey (wagon, two passengers): "I don't have any passengers" -> the passengers come from the seats, are in the
  prompt, hear the order and each answers/acts.  Henrietta King behind Seamus on his horse: "I ain't got no one with
  me" -> she rides BEHIND the rider and knows it.  Looting is felt.  Stripped + tied: every step closer is worse.
  A husband/father/brother who sees it reacts by his bond, honour, nerve, gun, temper and age."""
import asyncio, os, sys, tempfile, time
from pathlib import Path
from urllib.parse import unquote
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod, context, surroundings
from npcvoice.brain import Brain
from npcvoice.hashing import joaat
from npcvoice.memory import MemoryStore
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0


def check(c, w):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + w); ok += c; bad += (not c)


class W:
    def __init__(self): self.lines = []
    def is_closing(self): return False
    def write(self, b): self.lines.append(unquote(b.decode()))


ROOT = Path(__file__).resolve().parents[1]
_sleep = asyncio.sleep
async def nosleep(t=0, *a): await _sleep(0)


async def main():
    b = Brain(ROOT); b.cfg.fake_ai = True; b.cfg.households = False
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory; w = W(); b.asi.writer = w
    X, Y = 2600.0, -1200.0
    b.game.player = {"x": X, "y": Y, "z": 40, "cash": 500, "armed": 1, "wpn": joaat("WEAPON_MELEE_MACHETE")}
    b.game.world = {"hr": 13, "mn": 10, "dow": 1}
    said = []

    async def fake_say(ped, ident, text, emo, gesture=True):
        said.append((ped, text)); return 0.0
    b.say_line = fake_say

    async def fake_speak(conv, text, emo, gesture=True, gen=None):
        said.append((conv.ped, text)); b.run_after_actions(conv)
    b.speak = fake_speak
    surroundings.NAMES.clear(); surroundings.PAIRS.clear()

    def tick(h, **st):
        d = dict({"h": h, "d": 4, "alive": 1, "_t": time.time(), "x": X + 2, "y": Y, "z": 40}, **st)
        b.game.peds[h] = d
        return d

    def person(ped, model, **st):
        tick(ped, **st)
        c = b.on_engage_req({"ped": ped, "model": joaat(model), "outfit": 0, "male": int("_M_" in model.upper()),
                             "human": 1, "alive": 1})
        b.after_tick()
        return c

    # ───────────── 1. Cole Bailey's wagon in St Denis: the area scan saw NOBODY ─────────────
    P1, P2 = 400001, 400002
    mates = [{"h": P1, "m": joaat("A_F_M_MiddleSDTownfolk_01"), "o": 0, "male": 0, "alive": 1, "how": "passenger"},
             {"h": P2, "m": joaat("A_M_M_MiddleSDTownfolk_01"), "o": 0, "male": 1, "alive": 1, "how": "passenger"}]
    b.game.near_peds = []                                          # what 0.5.6 got in St Denis
    cole = person(224324, "A_M_M_MiddleSDTownfolk_03", veh=1, vh=302925, drv=1, vspd=0, mates=mates, d=5)
    sp = context.system_prompt(cole, b.game)
    check("Nobody else is around" not in sp, "the driver is no longer told 'nobody else is around'")
    check(sp.count("sitting right next to you on YOUR wagon") == 2, "both passengers are in his prompt, on his wagon")
    check("WITH YOU RIGHT NOW, on the same wagon" in sp and "hear every word" in sp,
          "...with the hard line: they're right here and hear every word")
    check(len(cole.together) == 2, "...and count as 'together' (leave_vehicle takes them down too)")

    # the order: "tell your passengers to get off the wagon right now and surrender"
    for h in (P1, P2):
        tick(h, veh=1, vh=302925, drv=0, d=5.5, mates=[{"h": 224324, "m": joaat("A_M_M_MiddleSDTownfolk_03"), "o": 0,
                                                         "male": 1, "alive": 1, "how": "driver"}])
    turns = []
    real_run = b.run_turn

    async def spy_turn(conv, wav=None, text=None, reaction=False):
        turns.append((conv.ped, text, list(conv.pending_events)))
        return await real_run(conv, wav, text, reaction)
    b.run_turn = spy_turn
    asyncio.sleep = nosleep
    try:
        await real_run(cole, text="tell your passengers to get off the wagon right now and surrender")
        for _ in range(60):
            await _sleep(0)
    finally:
        asyncio.sleep = _sleep
    check(P1 in b.convs and P2 in b.convs and not b.convs[P1].ended and not b.convs[P2].ended,
          "both passengers were pulled into the talk (their own person, memory, voice)")
    check(not cole.ended, "...without sending the driver away")
    check(any(l.startswith(f"actor {P1} 1") for l in w.lines), "...the plugin looks after them (actor)")
    mate_turns = [t for t in turns if t[0] in (P1, P2)]
    check(len(mate_turns) == 2, f"each passenger answers the order themselves ({len(mate_turns)} turns)")
    check(all(any(e[0] == "mates" and "heard every word" in e[1] for e in t[2]) for t in mate_turns),
          "...knowing they heard it all, right beside the driver, and what he answered")
    check(any("tell your passengers" in (t[1] or "") for t in mate_turns), "...with the player's own words")

    # an order that isn't about them: they only overhear it (no extra voices)
    turns.clear()
    asyncio.sleep = nosleep
    try:
        await real_run(cole, text="what's your name")
        for _ in range(30):
            await _sleep(0)
    finally:
        asyncio.sleep = _sleep
    b.run_turn = real_run
    check(not [t for t in turns if t[0] in (P1, P2)], "a question just for the driver: the passengers don't all answer")
    check(any(e[0] == "overheard" for e in b.convs[P1].pending_events), "...but they heard it (next time they know)")
    for c in list(b.convs.values()):
        b.end(c, "test")

    # ───────────── 2. Henrietta behind Seamus on HIS horse ─────────────
    surroundings.PAIRS.clear()
    SEAMUS = 129821
    henrietta = person(358935, "A_F_M_LagTownfolk_01", mnt=1, mh=777, mr=SEAMUS, d=40, flee=1,
                       mates=[{"h": SEAMUS, "m": joaat("A_M_M_BynRoughTravellers_01"), "o": 0, "male": 1, "alive": 1,
                               "how": "rider"}])
    b.game.near_peds = []
    sp = context.system_prompt(henrietta, b.game)
    check("riding on the back of someone else's horse" in sp, "she's told she rides BEHIND the rider (not 'your horse')")
    check("holding the reins of the horse you're both on" in sp and "WITH YOU RIGHT NOW, on the same horse" in sp,
          "...and who holds the reins, right there with her")
    rel = next(iter(henrietta.together.values()), "")
    check(rel in ("your husband", "your sweetheart", "your brother"), f"a man and a woman on one horse: {rel}")
    b.end(henrietta, "test")

    # ───────────── 3. looting ─────────────
    clara = person(500001, "A_F_M_LagTownfolk_01", hog=1, d=1.5)
    b.after_tick()
    tick(500001, hog=1, d=1.2, lt=1)
    b.after_tick()
    check(any(e[0] == "looted" and "GOING THROUGH YOUR POCKETS" in e[1] for e in clara.pending_events),
          "looting someone tied up: she feels it ('going through your pockets')")
    check(any("robbed you" in e["what"] for e in clara.ident.d["events"]), "...and remembers it")
    tick(500001, hog=1, d=1.2, lt=1); b.after_tick()
    check(sum(1 for e in clara.pending_events if e[0] == "looted") == 1, "...once, not every tick")

    # ───────────── 4. stripped against her will, tied: closer is worse ─────────────
    clara.pending_events.clear()
    tick(500001, hog=1, d=9, cu=0, cl=0, nude=1, lt=0); clara.flags["_had_clothes"] = True
    b.after_tick()
    # the plugin's undress far away is not 'him' (d=9): make it him
    clara.flags.pop("naked", None)
    tick(500001, hog=1, d=2.5, cu=3, cl=2, nude=0); b.after_tick()
    tick(500001, hog=1, d=2.5, cu=0, cl=0, nude=1); b.after_tick()
    check(clara.flags.get("violated") and clara.flags.get("naked"), "stripped by him, without agreeing -> violated")
    note = context.pressure_note(clara, b.game)
    check("STRIPPED AGAINST YOUR WILL, TIED UP" in note and "Nothing about this is sexual" in note,
          "her turn is framed as terror/shame/disgust - never sexual")
    check(any(e[0] == "violation_close" for e in clara.pending_events), "stripped by him at arm's length: that's already close")
    clara.marks["violation_close"] = time.time() - 10
    tick(500001, hog=1, d=12, cu=0, cl=0, nude=1); b.after_tick()          # he steps away...
    clara.pending_events.clear(); clara.marks.pop("violation_close", None)
    tick(500001, hog=1, d=5, cu=0, cl=0, nude=1); b.after_tick()           # ...and comes back
    e1 = [e for e in clara.pending_events if e[0] == "violation_close"]
    clara.marks["violation_close"] = time.time() - 10
    tick(500001, hog=1, d=1.2, cu=0, cl=0, nude=1); b.after_tick()
    e2 = [e for e in clara.pending_events if e[0] == "violation_close"]
    check(e1 and len(e2) == 2 and "right on top of you" in e2[-1][1] and "TIED UP" in e2[-1][1],
          "every step closer is a new, worse moment (coming toward you -> right on top of you)")
    f0 = clara.ident.stats["fear"]
    tick(500001, hog=1, d=1.0, cu=0, cl=0, nude=1); b.after_tick()
    check(len([e for e in clara.pending_events if e[0] == "violation_close"]) == 2, "...standing there doesn't repeat it")
    clara.marks["violation_close"] = time.time() - 10
    tick(500001, hog=1, d=12, cu=0, cl=0, nude=1); b.after_tick()
    check(any(e[0] == "violation_away" for e in clara.pending_events), "stepping back: a small relief (but still naked)")

    # ───────────── 5. her husband sees it ─────────────
    LEROY = 500002
    leroy_p = {"h": LEROY, "m": joaat("A_M_M_LagTownfolk_01"), "o": 0, "male": 1, "alive": 1, "d": 8, "de": 7,
               "elos": 1, "los": 1, "x": X + 8, "y": Y, "z": 40, "hasw": 1, "_t": time.time()}
    b.game.near_peds = [leroy_p]; b.game.peds[LEROY] = dict(leroy_p)
    surroundings.PAIRS[(clara._key, surroundings.key_of(leroy_p))] = "your husband"
    surroundings.PAIRS[(surroundings.key_of(leroy_p), clara._key)] = "your wife"
    kin = b.drama.kin_of(clara)
    check(kin and kin[0][2] == "spouse", "her husband is right there")
    ident = b.memory.ids[b.handle_ident[LEROY]]
    ident.persona.update(bravery=0.55, temperament="proud", age=34, sex="male")
    ident.stats["fear"] = 10
    w.lines.clear(); said.clear(); b.drama.last.clear()
    clara.mark("stripped")
    asyncio.sleep = nosleep
    try:
        await b.drama.tick()
    finally:
        asyncio.sleep = _sleep
    mine = [l for l in w.lines if f" {LEROY} " in l and l.startswith("task ")]
    check(any(" combat" in l for l in mine) and any(" draw" in l for l in mine),
          f"stripped in front of her armed husband: he draws and comes for you ({[l.split()[3] for l in mine]})")
    check(said and said[0][0] == LEROY, f"...shouting ({said[:1]})")
    check(ident.d["nemesis"]["grudge"] >= 30 and any("STRIPPED your wife" in e["what"] for e in ident.d["events"]),
          "...and he never forgets it (grudge, memory)")
    check(any(e[0] == "kin" and "stripped" in e[1] for e in clara.pending_events), "she sees him react")

    # unarmed but proud: his fists
    b.game.near_peds[0]["hasw"] = 0; b.game.peds[LEROY]["hasw"] = 0
    ident.persona.update(role="townsfolk")
    plan = b.drama.plan("spouse", "stripped", True, b.drama.pos(LEROY), ident, clara)
    check(plan[-1][0] == "combat" and not any(p[0] == "draw" for p in plan), f"unarmed: he comes at you with his fists ({plan})")
    # an old, timid man with your gun on him: no
    ident.persona.update(bravery=0.15, temperament="timid", age=66)
    b.game.peds[LEROY]["aimed"] = 1
    plan = b.drama.plan("spouse", "stripped", True, b.drama.pos(LEROY), ident, clara)
    check(plan[-1][0] in ("flee", "face"), f"old, timid, your gun on him: he runs for help instead ({plan[-1][0]})")
    b.game.peds[LEROY]["aimed"] = 0
    # a mere acquaintance: watches
    plan = b.drama.plan("acquaintance", "stripped", True, b.drama.pos(LEROY), ident, clara)
    check(plan[-1][0] == "face", f"someone who only knows her by name: watches ({plan[-1][0]})")
    # looted is less than stripped
    ident.persona.update(bravery=0.55, temperament="proud", age=34)
    s1, n1, _ = b.drama.weigh("spouse", "looted", b.drama.pos(LEROY), ident, clara)
    s2, n2, _ = b.drama.weigh("spouse", "stripped", b.drama.pos(LEROY), ident, clara)
    check(s2 > s1 and n2 > n1, f"stripping her is worse than robbing her (stake {s1:.2f}->{s2:.2f}, rage {n1:.2f}->{n2:.2f})")

    # ───────────── 6. someone you were NOT talking to ─────────────
    for c in list(b.convs.values()):
        b.end(c, "test")
    V = 600001
    vp = {"h": V, "m": joaat("A_M_M_LagTownfolk_01"), "o": 0, "male": 1, "alive": 1, "d": 1.4, "hog": 1, "lt": 1}
    tick(V, hog=1, d=1.4)
    b.witness.on_nearby([vp])
    vc = b.convs.get(V)
    check(vc and not vc.ended and any(e[0] == "looted" for e in vc.pending_events),
          "looting someone you never talked to: they notice and react")
    W2 = 600002
    tick(W2, d=1.5)
    b.witness.on_nearby([{"h": W2, "m": joaat("A_F_M_LagTownfolk_01"), "o": 0, "male": 0, "alive": 1, "d": 1.5, "nude": 0}])
    b.witness.on_nearby([{"h": W2, "m": joaat("A_F_M_LagTownfolk_01"), "o": 0, "male": 0, "alive": 1, "d": 1.5, "nude": 1}])
    wc = b.convs.get(W2)
    check(wc and wc.flags.get("violated") and any(e[0] == "stripped" for e in wc.pending_events),
          "stripped by another mod while you weren't talking to her: she reacts, it counts")


asyncio.run(main())
print(f"\n{ok} passed, {bad} failed")
sys.exit(1 if bad else 0)
