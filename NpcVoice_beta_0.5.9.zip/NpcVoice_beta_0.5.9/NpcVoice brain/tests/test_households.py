"""Households: every home has its own couple and a whole day - chores on their real furniture, meals together, the
porch, and from dark to dawn the night in their bed with position changes, rests and talk. Driven against a scripted
plugin (spawns, beds and the house's scenario points answered like the game would)."""
import asyncio, json, os, re, sys, tempfile, time, types
from pathlib import Path
from urllib.parse import unquote
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod, daylife
import npcvoice.household as H
from npcvoice.brain import Brain
from npcvoice.hashing import joaat
from npcvoice.memory import MemoryStore
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0
def check(c, w):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + w); ok += c; bad += (not c)
ROOT = Path(__file__).resolve().parents[1]
_sleep = asyncio.sleep
async def nosleep(t=0, *a): await _sleep(0)
H.asyncio = types.SimpleNamespace(**{k: getattr(asyncio, k) for k in dir(asyncio) if not k.startswith("__")})
H.asyncio.sleep = nosleep

HOUSE = "lak_loveshack_int"          # Lakay, Bayou Nwa


class Plugin:
    """Answers like NpcVoice.asi: spawns get handles, find_bed a bed, home_scan the house's scenario points."""
    def __init__(self, b, place, caps=True):
        self.b, self.place, self.lines, self.h = b, place, [], 5000
        x, y, z = place["x"], place["y"], place["z"]
        P = lambda n, dx, dy, h=0: [joaat(n), x + dx, y + dy, z, h]
        self.points = [P("PROP_HUMAN_SLEEP_BED_PILLOW_LEFT", 2, 3), P("PROP_HUMAN_SLEEP_BED_PILLOW_RIGHT", 2.8, 3),
                       P("PROP_HUMAN_SEAT_CHAIR_TABLE_EATING_KNIFE_FORK", -1, 0), P("PROP_HUMAN_SEAT_CHAIR_TABLE_EATING_KNIFE_FORK", -1, 1.2),
                       P("WORLD_HUMAN_CAULDRON_STIR_NO_POT", -2, -1), P("WORLD_HUMAN_FEED_CHICKEN", 9, 2),
                       P("PROP_HUMAN_SEAT_CHAIR_PORCH", 4, -3), P("PROP_HUMAN_SEAT_BENCH_PORCH", 4.5, -3.5),
                       P("PROP_HUMAN_WOOD_CHOP", 8, -6), P("WORLD_HUMAN_BROOM_WORKING", 0.5, 0.5)]
        b.asi_info = {"caps": ["home_scan", "use_point", "couple_pose", "nh_pos", "undress_wait"]} if caps else {}

    def is_closing(self): return False

    def write(self, raw):
        line = unquote(raw.decode().strip())
        self.lines.append(line)
        tok = line.split(" ")
        loop = asyncio.get_running_loop()
        if tok[0] == "spawn":
            self.h += 1
            h = self.h
            loop.call_soon(self.b.couples.on_spawned, {"seq": int(tok[1]), "h": h})
            x, y, z = float(tok[4]), float(tok[5]), float(tok[6])
            self.b.game.peds[h] = {"h": h, "alive": 1, "x": x, "y": y, "z": z, "d": 30.0, "los": 0, "_t": time.time()}
        elif tok[0] == "find_bed":
            loop.call_soon(self.b.couples.on_bed, {"seq": int(tok[1]), "ok": 1, "x": self.place["x"] + 2.4,
                                                   "y": self.place["y"] + 3, "z": self.place["z"], "hd": 90, "src": "object", "model": "p_bed05x"})
        elif tok[0] == "home_scan":
            loop.call_soon(self.b.households.on_home, {"seq": int(tok[1]), "pts": self.points})

    def sent(self, word, since=0):
        return [l for l in self.lines[since:] if l.split(" ")[0] == word or f" {word} " in l]


async def main():
    b = Brain(ROOT); b.cfg.fake_ai = True
    tmp = Path(tempfile.mkdtemp())
    b.memory = MemoryStore(tmp / "npc_memory"); b.game.memory = b.memory
    b.households.path = tmp / "households.json"; b.households.data = {"version": 1, "homes": {}}
    b.cfg.households = True; b.cfg.pose_seconds = 0.05
    place = next(p for p in b.db.places if p["name"] == HOUSE)
    plug = Plugin(b, place); b.asi.writer = plug
    hh = b.households

    def at(hr, mn=0, dow=3, dist=40.0):
        b.game.world = {"hr": hr, "mn": mn, "dow": dow}
        b.game.player = {"x": place["x"] + dist, "y": place["y"], "z": place["z"], "crouch": 0}
        for p in b.game.peds.values():
            p["d"] = dist

    async def tick(n=1):
        for _ in range(n):
            await hh.tick()
            for _ in range(5):
                await _sleep(0)

    # ── a weekday morning: they're there, at their chores, on their own furniture ──
    at(10, 0)
    await tick(2)
    lv = hh.live.get(HOUSE)
    check(lv is not None, "walk up to a Lakay shack at 10:00: its household comes alive")
    rec = hh.data["homes"][HOUSE]
    ia, ib = b.memory.ids[rec["a"]], b.memory.ids[rec["b"]]
    check(all("LAG" in m.upper() for m in (rec["ma"], rec["mb"])), f"Lakay folk: {rec['ma']}, {rec['mb']}")
    check(all(i.persona["age"] >= 21 and not i.persona.get("child") for i in (ia, ib)), "two adults")
    scans = [l for l in plug.sent("home_scan") if f"{place['x']:.2f}" in l]
    mine = [l for l in plug.sent("spawn") if l.split(" ")[3] in (rec["ma"], rec["mb"])
            and ((float(l.split(" ")[4]) - place["x"]) ** 2 + (float(l.split(" ")[5]) - place["y"]) ** 2) ** 0.5 < 12]
    check(len(mine) == 2 and len(scans) == 1, "two people spawned, the house scanned once")
    check("like=" in mine[1] and f"like={lv['a']['h']}" in mine[1], "the second partner is given the first one's skin tone")
    check(len(hh.live) == 2 and "lak_houseruined_int" in hh.live, "the ruined house next door has its own couple too (2 homes live)")
    check(all(b.handle_ident.get(lv[r]["h"]) == rec[r] for r in "ab"), "the game handles are these two people")
    check(len(rec["points"]) == 10 and rec["points"][0][0] == "PROP_HUMAN_SLEEP_BED_PILLOW_LEFT", "scan kept by name")
    acts = (lv["a"]["act"], lv["b"]["act"])
    check(all(a not in ("love", "sleep", "cozy") for a in acts), f"at 10:00 they're doing chores: {acts}")
    check(plug.sent("use_point") or plug.sent("scen"), "each started a chore (furniture spot or in place)")
    check(ia.persona["family"].startswith(("married to", "courting")) and ib.persona["name"] in ia.persona["family"],
          f"{ia.persona['name']}: {ia.persona['family']}")
    dt = daylife.day_text(ia, b.game)
    check("ate with" in dt and ib.persona["first_name"] in dt, "their journal is their real day")

    # ── lunch: both at their own table, on two different chairs ──
    n0 = len(plug.lines)
    at(12, 30)
    await tick(2)
    check(lv["a"]["act"] == "eat" and lv["b"]["act"] == "eat", "12:30: lunch together")
    up = [l for l in plug.lines[n0:] if " use_point " in l]
    chairs = {tuple(l.split(" ")[4:6]) for l in up}
    check(len(up) >= 2 and len(chairs) == 2, f"two different chairs at their table ({len(chairs)})")
    check(not any(" use_point " in l and " 1 -1" in l for l in plug.lines[n0:]), "they walk there (no warp mid-day)")

    # ── they talk while near you ──
    b.speaking = {}
    at(12, 35, dist=8.0)
    for r in "ab":
        b.game.peds[lv[r]["h"]].update(x=place["x"] - 1, y=place["y"] + (0.6 if r == "a" else -0.6))
    lv["next_chat"] = 0
    n0 = len(plug.lines)
    await tick(1)
    says = [l for l in plug.lines[n0:] if l.startswith("say ")]
    check(len(says) >= 2, f"they chat over lunch ({len(says)} lines, each in their own voice)")

    # ── evening: porch, then close as it gets dark ──
    b.speaking = {}
    at(19, 45)
    await tick(2)
    check(lv["a"]["act"] == "porch" and lv["b"]["act"] == "porch", "evening on the porch together")
    start, end = H.love_window(rec["seed"], 3)
    ch, cm = int(start - 0.5), int(round(((start - 0.5) % 1) * 60))
    n0 = len(plug.lines)
    at(ch, cm)
    await tick(2)
    check(lv["a"]["act"] == "cozy", f"{H.hours_label(start - 0.5)}: getting close")
    check(any(" face " in l and "t=" in l for l in plug.lines[n0:]), "they turn to each other")

    # ── the night ──
    n0 = len(plug.lines)
    sh, sm = int(start), int(round((start % 1) * 60))
    at(sh, sm + 5)
    await tick(2)
    L = lv["love"]
    check(L.get("on"), f"{H.hours_label(start)}: the night together starts")
    check(len([l for l in plug.lines[n0:] if " undress" in l]) == 2, "both undress")
    cpl = [l for l in plug.lines[n0:] if l.startswith("couple ")]
    mycpl = [l for l in cpl if l.split(" ")[2] == str(lv["a"]["h"])]
    check(mycpl and abs(float(mycpl[0].split(" ")[4]) - (place["x"] + 2.4)) < 0.05, "on THEIR bed")
    poses_seen = set()
    for l in cpl:
        poses_seen.add(" ".join(t for t in l.split(" ") if "=" in t))
    n0 = len(plug.lines)
    for _ in range(12):
        await _sleep(0.06)
        await tick(1)
    changes = [l for l in plug.lines[n0:] if l.startswith("couple_pose ")]
    check(len(changes) >= 2, f"they change position ({len(changes)} changes)")
    for l in changes:
        poses_seen.add(" ".join(t for t in l.split(" ") if "=" in t))
    check(len(poses_seen) >= 3, f"different positions: {sorted(poses_seen)}")
    rest_seen = any(l.startswith("couple_stop ") for l in plug.lines[n0:]) or L["phase"] == "rest"
    check(rest_seen, "after a few positions they stop to catch their breath")
    L["until"] = 0
    if L["phase"] == "rest":
        n1 = len(plug.lines)
        await tick(1)
        check(any(l.startswith("couple ") for l in plug.lines[n1:]) and L["session"] >= 2, "...and start again (session 2)")
    else:
        check(True, "...(still going)")
    b.speaking = {}
    at(23, 10, dist=6.0)
    L["next_talk"] = 0
    n0 = len(plug.lines)
    await tick(1)
    check(len([l for l in plug.lines[n0:] if l.startswith("say ")]) >= 1, "they talk to each other through the night")
    check(lv["a"]["act"] == "love", "23:10 - still their night")
    at(2, 30, dow=4, dist=40.0)
    await tick(1)
    check(lv["a"]["act"] == "love", "02:30 - still going (from dark to dawn)")

    # ── a gun on him: it stops at once, and not again tonight ──
    b.game.peds[lv["a"]["h"]]["aimed"] = 1
    n0 = len(plug.lines)
    await tick(1)
    check(not L.get("on") and any(l.startswith("couple_stop ") for l in plug.lines[n0:]), "a gun on them: it stops at once")
    check(len([l for l in plug.lines[n0:] if " dress" in l and "undress" not in l]) == 2, "they get dressed")
    b.game.peds[lv["a"]["h"]]["aimed"] = 0
    n0 = len(plug.lines)
    await tick(2)
    check(not lv["love"].get("on") and not [l for l in plug.lines[n0:] if l.startswith("couple ")], "...and it doesn't start again tonight")

    # ── dawn: they sleep in their bed, on the two pillow spots ──
    rec["disturbed_until"] = -1
    n0 = len(plug.lines)
    at(int(end) + 0, int(round((end % 1) * 60)) + 10, dow=4)
    await tick(2)
    check(lv["a"]["act"] == "sleep" and lv["b"]["act"] == "sleep", f"{H.hours_label(end)}: they fall asleep")
    beds = {tuple(l.split(" ")[4:6]) for l in plug.lines[n0:] if " use_point " in l}
    check(len(beds) == 2, f"each on their own pillow spot ({len(beds)})")

    # ── walking in on them (a new night) ──
    b.game.world = {"hr": 23, "mn": 0, "dow": 4}
    rec["disturbed_until"] = -1
    for r in "ab":
        lv[r]["block"] = None
    at(23, 0, dow=4)
    await tick(2)
    check(lv["love"].get("on"), "the next night")
    caught = []
    orig = b.couples.caught
    async def fake_caught(hc): caught.append(hc)
    b.couples.caught = fake_caught
    b.game.player["crouch"] = 1
    for r in "ab":
        b.game.peds[lv[r]["h"]].update(d=4.0, los=0)
    await tick(1)
    check(not caught and lv["love"].get("on"), "crouched and out of sight: they don't notice you")
    b.game.player["crouch"] = 0
    b.game.peds[lv["b"]["h"]].update(d=3.0, los=1)
    await tick(1)
    check(caught and not lv["love"].get("on"), "stand in the doorway in plain sight: they've seen you")
    check(rec["disturbed_until"] > b.game.game_minutes_total, "and they're not in the mood again for a while")
    b.couples.caught = orig

    # ── you ride off: they're taken away; the same couple next time ──
    n0 = len(plug.lines)
    at(10, 0, dow=5, dist=300.0)
    await tick(1)
    gone = {l.split(" ")[1] for l in plug.lines[n0:] if l.startswith("despawn ")}
    check(HOUSE not in hh.live and {str(lv["a"]["h"]), str(lv["b"]["h"])} <= gone and not hh.live, "ride off: they're taken away (both homes)")
    ids = (rec["a"], rec["b"])
    hh2 = H.Households(b)
    hh2.path = hh.path; hh2._load()
    check(hh2.household_for(place)["a"] == ids[0] and hh2.data["homes"][HOUSE]["b"] == ids[1], "come back: the same two people")
    on_disk = json.loads(hh.path.read_text())
    check(HOUSE in on_disk["homes"] and on_disk["homes"][HOUSE]["profile"]["style"], "households.json keeps them")

    # ── an old NpcVoice.asi: no scan, chores in place, one position all night ──
    b2 = Brain(ROOT); b2.cfg.fake_ai = True; b2.cfg.households = True; b2.cfg.pose_seconds = 0.05
    b2.memory = MemoryStore(Path(tempfile.mkdtemp())); b2.game.memory = b2.memory
    b2.households.path = Path(tempfile.mkdtemp()) / "households.json"; b2.households.data = {"version": 1, "homes": {}}
    old = Plugin(b2, place, caps=False); b2.asi.writer = old
    b, hh, plug = b2, b2.households, old
    at(10, 0)
    await tick(2)
    check(HOUSE in hh.live and not old.sent("home_scan") and not old.sent("use_point"), "old plugin: no scan, no furniture")
    check(old.sent("scen"), "...chores played in place instead")
    sh, sm = int(start), int(round((start % 1) * 60))
    at(sh, sm + 5)
    await tick(2)
    for _ in range(6):
        await _sleep(0.06)
        await tick(1)
    cp = [l for l in old.lines if l.startswith("couple ")]
    check(cp and not any("=" in l for l in cp) and not old.sent("couple_pose"), "...the night in the one built-in position")

    # ── the old random couples are off ──
    check(b.cfg.house_couples and getattr(b.cfg, "households"), "households replace the random house couples")


async def more_homes():
    """Canebreak Manor (a mansion) has its couple; homes the database doesn't know are found by their beds; places the
    game itself populates (a gang camp, a story family) are left to the game."""
    def fresh():
        b = Brain(ROOT); b.cfg.fake_ai = True; b.cfg.households = True
        b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory
        b.households.path = Path(tempfile.mkdtemp()) / "households.json"; b.households.data = {"version": 1, "homes": {}}
        return b
    async def tick(b, n=2):
        for _ in range(n):
            await b.households.tick()
            for _ in range(5):
                await _sleep(0)
    # Canebreak Manor
    b = fresh()
    cane = next(p for p in b.db.places if p["name"] == "can_manor_int")
    check(cane["kind"] == "mansion" and cane["town"] == "Canebreak Manor", f"Canebreak Manor is in the database ({cane['town']})")
    pl = Plugin(b, cane); b.asi.writer = pl
    b.game.world = {"hr": 11, "mn": 0, "dow": 2}
    b.game.player = {"x": cane["x"] + 30, "y": cane["y"], "z": cane["z"]}
    await tick(b)
    check("can_manor_int" in b.households.live, "walk up to Canebreak Manor: its couple is home")
    # a home the database doesn't know: found by its bed
    b = fresh()
    wx, wy, wz = -1650.0, 1240.0, 260.0
    check(not b.db.places_near(wx, wy, None, 0, 60), "(a spot in the wilds: nothing in the database within 60 m)")
    pl = Plugin(b, {"x": wx, "y": wy, "z": wz}); b.asi.writer = pl
    pl.points = [[joaat("PROP_HUMAN_SLEEP_BED_PILLOW"), wx + 6, wy + 4, wz, 0], [joaat("PROP_HUMAN_SEAT_CHAIR"), wx + 4, wy + 2, wz, 0]]
    saloon = next(p for p in b.db.places if p["kind"] == "saloon")
    pl.points.append([joaat("PROP_HUMAN_SLEEP_BED_PILLOW"), saloon["x"] + 5, saloon["y"], saloon["z"], 0])
    b.game.world = {"hr": 11, "mn": 0, "dow": 2}
    b.game.player = {"x": wx, "y": wy, "z": wz}
    await tick(b)
    found = b.households.data.get("found", {})
    check(len(found) == 1 and abs(next(iter(found.values()))["x"] - (wx + 6)) < 0.1, f"a house nobody listed is found by its bed ({list(found)})")
    check(not any(abs(f["x"] - saloon["x"]) < 40 for f in found.values()), "...a bed upstairs at a saloon isn't a home")
    check(any(k.startswith("home_") for k in b.households.live), "...and its couple is home")
    on_disk = json.loads(b.households.path.read_text())
    check(on_disk.get("found"), "...remembered for good (households.json)")
    # a place the game populates itself
    b = fresh()
    sha = next(p for p in b.db.places if p["name"] == "sha_mansion_int")
    pl = Plugin(b, sha); b.asi.writer = pl
    b.game.world = {"hr": 11, "mn": 0, "dow": 2}
    b.game.player = {"x": sha["x"] + 30, "y": sha["y"], "z": sha["z"]}
    gang = [n for n in (p2.get("n") for p2 in b.peddb.by_hash.values()) if n and n.upper().startswith("G_M_")][:2]
    b.game.near_peds = [{"h": 900 + i, "m": joaat(n), "x": sha["x"] + i, "y": sha["y"], "alive": 1} for i, n in enumerate(gang)]
    await tick(b)
    check("sha_mansion_int" not in b.households.live, "Shady Belle full of gang members: left to the game")
    b.game.near_peds = []
    b.households._occupied.clear()
    await tick(b)
    check("sha_mansion_int" in b.households.live, "...and once they're gone, a couple lives there")


def plan_checks():
    seeds = [joaat(p) for p in ("lak_loveshack_int", "ora_house_01_int", "shack_sw_int", "abe_farmhouse_int")] + list(range(200))
    lens, nights = [], []
    for s in seeds:
        for role in "ab":
            for d in range(7):
                p = H.day_plan(s, role, d, away=(s % 4 == 0 and role == "a"))
                lens.append(len(p))
                st, en = H.love_window(s, d)
                nights.append(H.block_at(p, st + 0.1)[1] == "love" and H.block_at(p, 23.9)[1] == "love")
                assert all(t2 > t1 for (t1, _), (t2, _) in zip(p, p[1:])), (s, role, d, p)
                assert all(a in H.ACTS or a == "porch" for _, a in p), p
    check(min(lens) >= 18 and sorted(lens)[len(lens) // 2] >= 28, f"a full day: {min(lens)}-{max(lens)} things, median {sorted(lens)[len(lens)//2]}")
    check(all(nights), "every couple, every night: together in bed from dark to midnight and on")
    a, b = H.day_plan(seeds[0], "a", 3), H.day_plan(seeds[1], "a", 3)
    check(a != b and H.day_plan(seeds[0], "a", 3) != H.day_plan(seeds[0], "a", 4), "no two houses / days alike")
    check(H.day_plan(seeds[0], "a", 3) == H.day_plan(seeds[0], "a", 3), "but the same day is always the same day")
    sched = H.day_plan(seeds[0], "a", 3) + H.day_plan(seeds[0], "b", 3)
    eat_a = [t for t, x in H.day_plan(seeds[0], "a", 3) if x == "eat"]
    eat_b = [t for t, x in H.day_plan(seeds[0], "b", 3) if x == "eat"]
    check(eat_a == eat_b and len(eat_a) == 3, "breakfast, lunch and supper together")
    for n, (_, _, pat, _) in H.ACTS.items():
        if pat:
            re.compile(pat)
    scen = set(json.loads((ROOT / "data" / "scenarios.json").read_text()))
    missing = [s for _, _, _, sc in H.ACTS.values() for s in sc if s not in scen]
    check(not missing, f"every in-place scenario exists in the game ({missing})")
    poses = json.loads((ROOT / "data" / "love_poses.json").read_text())["poses"]
    # 0.5.8: NpcHookups' own three positions (pos 1-3, attached the way it does it), each one distinct
    check(len(poses) >= 3 and len({(p.get('pos', 0), p.get('swap', 0), p.get('turn', 0), str(p.get('anim', ''))) for p in poses})
          == len(poses) and all(p.get("pos") in (1, 2, 3) or p.get("anim") for p in poses), f"{len(poses)} distinct positions")


plan_checks()
asyncio.run(main())
asyncio.run(more_homes())
print(f"\n{ok} passed, {bad} failed")
sys.exit(1 if bad else 0)
