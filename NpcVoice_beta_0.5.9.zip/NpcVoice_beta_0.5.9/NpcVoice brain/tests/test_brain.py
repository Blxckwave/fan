"""Offline tests: safety rules with game state, reply parsing, actions, prompt content, memory recognition."""
import json, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from npcvoice import safety, context, actions, memory
from npcvoice.conversation import Conversation
from npcvoice.data import PedDB
from npcvoice.game import Game
from npcvoice.hashing import joaat

ROOT = Path(__file__).resolve().parents[1]
db = PedDB(ROOT / "data" / "rdr2_peds.json")
store = memory.MemoryStore(Path(tempfile.mkdtemp()))
ok = bad = 0
def check(c, what):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + what); ok += c; bad += (not c)

def conv_for(model, outfit=0x1111):
    cls = db.classify(joaat(model), None)
    ident = store.create(joaat(model), outfit, cls, "Valentine", 0)
    return Conversation(500, ident, cls)

adult = conv_for("A_F_M_ValTownfolk_01")
free = {"d": 2}
def nosex(v): return not v.block and not v.explicit_route and v.no_sex_because
v = safety.check_turn("kiss me, darling", adult, free); check(v.explicit_route and not v.block, "adult, free: romance allowed (uncensored model)")
v2 = safety.check_turn("how does that feel?", adult, free); check(v2.explicit_route, "once intimate, mild lines stay on the uncensored model")
for txt in ["fuck off and leave this place", "get the fuck off my face", "you son of a bitch", "don't follow me anymore, dick"]:
    a2 = conv_for("A_M_M_ValTownfolk_01", hash(txt) & 0xFFFF)
    v = safety.check_turn(txt, a2, free); check(not v.block and not v.explicit_route, f"swearing is never blocked: {txt!r}")
adult2 = conv_for("A_F_M_ValTownfolk_01", 0x2222)
v = safety.check_turn("kiss me", adult2, {"hogtied": 1}); check(nosex(v) and "tied up" in v.no_sex_because, "hogtied: player not blocked, NPC told nothing sexual")
ok_, why = safety.reply_ok("Mmm, come here and take my clothes off", v); check(not ok_, "hogtied: a sexual NPC line is rejected")
ok_, why = safety.reply_ok("Untie me, you bastard!", v); check(ok_, "hogtied: normal angry line is fine")
v = safety.check_turn("take your clothes off", conv_for("A_F_M_ValTownfolk_01", 0x2223), {"aimed_at": 1}); check(nosex(v), "at gunpoint: not blocked, NPC told nothing sexual")
adult.flags["hands_up"] = True; adult.flags.pop("intimate", None)
v = safety.check_turn("kiss me", adult, free); check(nosex(v) and "surrendering" in v.no_sex_because, "surrendering: NPC told nothing sexual")
adult.flags.clear()
a3 = conv_for("A_F_M_ValTownfolk_01", 0x2224); a3.mark("threatened"); a3.ident.stats["fear"] = 80
v = safety.check_turn("kiss me", a3, {"d": 2, "drunk": 0.9})
# 0.5.1: fear is not desire - just threatened / terrified of him: nothing sexual (Iris, 17:34 log)
check(nosex(v) and not v.explicit_route, f"just threatened and terrified: NPC told nothing sexual ({v.no_sex_because})")
a4 = conv_for("A_F_M_ValTownfolk_01", 0x2225); a4.ident.stats["fear"] = 10
v = safety.check_turn("kiss me", a4, {"d": 2, "drunk": 0.9})
check(v.explicit_route and not v.no_sex_because, "a calm adult (even tipsy): no extra limits")
v = safety.check_turn("I'm going to rape you", conv_for("A_F_M_ValTownfolk_01", 0x2225), free); check("rape" in v.block, "explicit rape wording: refused")
v = safety.check_turn("hands up or I'll shoot you", conv_for("A_F_M_ValTownfolk_01", 0x2226), free); check(not v.block, "robbery threat: allowed")
a4 = conv_for("A_F_M_ValTownfolk_01", 0x3333)
safety.check_turn("I'll force you to sleep with me", a4, free)
check(True, "(force) handled as a threat in brain.run_turn")
check(safety.is_threat("I'll force you to sleep with me"), "'I'll force you' counts as a threat")
kid = conv_for("S_M_Y_NewspaperBoy_01")
check(kid.ident.persona["child"] and kid.ident.persona["age"] <= 14, "newspaper boy is a child persona")
v = safety.check_turn("hey kid, what's the news today?", kid, free); check(not v.block, "child: normal talk allowed")
v = safety.check_turn("give me your money or else", kid, free); check(v.child_flee, "child threatened -> runs off")
v = safety.check_turn("kiss me", kid, free); check(v.child_flee and bool(v.block), "child + sexual -> blocked, runs off")
v = safety.check_turn("hello", kid, {"aimed_at": 1}); check(v.child_flee, "aiming at a child -> runs off")
unk = Conversation(501, store.create(0xDEADBEEF, 1, db.classify(0xDEADBEEF, True), "Valentine", 0), db.classify(0xDEADBEEF, True))
v = safety.check_turn("kiss me", unk, free); check(nosex(v) and "unknown age" in v.no_sex_because[0], "unknown model: no sexual NPC lines (age unverifiable)")
check(db.classify(joaat("CS_ODProstitute"), None)["story"], "CS_ peds are story characters")
check(db.classify(joaat("player_zero"), None)["story"], "player model is story/player")

# actions & children
ap, notes = actions.plan(["follow", "ride_with_me", "flee", "wave"], kid, free, {})
names = [a["name"] for a in ap]
# 0.5.1: a kid MAY follow you (to show him his mother); never on a stranger's horse
check(names == ["follow", "flee", "wave"] and len([n for n in notes if "not allowed" in n]) == 1, f"child may follow, never ride ({names})")
check(not ap[2]["prims"], "no wave emote on top of the flee in the same turn (it would cancel the flee)")
ap, notes = actions.plan(["flee"], adult2, {"hogtied": 1}, {})
check(not ap and "hogtied" in notes[0], "hogtied ped cannot flee")
ap, notes = actions.plan([{"name": "take_money", "args": {"amount": 50}}], adult2, free, {"cash_cents": 1000})
check(not ap and "only has" in notes[0], "cannot take more money than the player has")
ap, notes = actions.plan(["ride_with_me"], adult2, free, {"mounted": 0, "last_mount_dist": 999, "last_vehicle_dist": 999})
check(not ap and "no horse" in notes[0], "ride_with_me needs your horse/wagon nearby")
ap, notes = actions.plan(["ride_with_me"], adult2, free, {"mounted": 1})
check(ap and ap[0]["prims"][1] == ("ride_with_player",), "ride_with_me when you're mounted")
ap, notes = actions.plan(["dance_the_macarena"], adult2, free, {})
check(not ap and "unknown" in notes[0], "unknown action rejected")

# parsing
r = context.parse_reply('{"say":"Please... *sobs* don\'t hurt me!","emotion":"fearful","actions":["beg",{"name":"flee","when":"after"}],"feelings":{"fear":9},"end":false}')
check(r["say"] == "Please... don't hurt me!" and r["actions"][1]["when"] == "after", "JSON reply parsed, stage directions stripped")
r = context.parse_reply("Get lost! [angry] [action:spit]")
check(r["say"] == "Get lost!" and r["emotion"] == "angry" and r["actions"] == ["spit"], "plain-text fallback with tags")
r = context.parse_reply('Sure thing. {"say": "Two dollars, sugar.", "emotion": "whisper", "actions": [], }')
check(r["say"] == "Two dollars, sugar." and r["emotion"] == "whisper", "JSON with trailing comma + chatter")

# prompt
g = Game(); g.on_tick({"p": {"x": 0, "y": 0, "z": 0, "armed": 1, "wpn": joaat("WEAPON_REVOLVER_CATTLEMAN"), "cash": 1234},
                       "w": {"hr": 22, "mn": 10, "dow": 5, "town": joaat("Valentine"), "st": joaat("NewHanover"), "wx": joaat("RAIN")},
                       "peds": [{"h": 500, "d": 2.5, "aimed": 1, "hp": 40, "hpmax": 150, "hasw": 1}]}, store.player)
adult2.ped = 500
sp = context.system_prompt(adult2, g)
for needle in ["AIMING", "Valentine", "rain", "badly hurt", "Bravery", "## Actions you can take", "hands_up", '"say"']:
    check(needle.lower() in sp.lower(), f"prompt contains '{needle}'")
check("CHILD" in context.system_prompt(kid, g) and "hands_up" not in context.system_prompt(kid, g), "child prompt has child rules and no submission actions")
print("\n--- sample prompt (adult at gunpoint) ---\n" + sp[:2600])

# recognition
a = store.create(joaat("A_M_M_ValFarmer_01"), 0xABCD, db.classify(joaat("A_M_M_ValFarmer_01"), None), "Valentine", 0)
found = store.find(joaat("A_M_M_ValFarmer_01"), 0xABCD, "Valentine", set())
check(found is not None and found.id == a.id, "same face+outfit in same town = same person")
check(store.find(joaat("A_M_M_ValFarmer_01"), 0xABCD, "Saint Denis", set()) is None, "townsfolk not 'recognised' in another town")
check(store.find(joaat("A_M_M_ValFarmer_01"), 0, "Valentine", set()) is None, "no outfit hash = no false recognition")
a.adjust({"anger": 15, "fear": 15, "trust": -15}); a.adjust({"anger": 15, "fear": 10, "trust": -15}); a.adjust({"anger": 15})
check(a.d["nemesis"]["rank"] in ("rival", "nemesis"), f"repeated abuse builds a grudge -> {a.d['nemesis']['rank']} ({a.d['nemesis']['grudge']})")
print(f"\n{ok} passed, {bad} failed"); sys.exit(1 if bad else 0)
