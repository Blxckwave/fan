"""Recorder with a stand-in sounddevice: stream opened once, X just toggles collecting."""
import sys, threading, time, types, io, wave, tempfile
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
opens = []
class FakeStream:
    def __init__(self, samplerate, channels, dtype, device, callback, blocksize=0):
        opens.append(1); self.cb = callback; self.run = False; self.device = 0
    def start(self):
        self.run = True
        def feed():
            t = 0
            while self.run:
                x = (np.sin(np.arange(160) / 5 + t) * 8000).astype("int16").reshape(-1, 1); t += 1
                self.cb(x, 160, None, None); time.sleep(0.01)
        threading.Thread(target=feed, daemon=True).start()
    def stop(self): self.run = False
    def close(self): pass
fake = types.ModuleType("sounddevice"); fake.InputStream = FakeStream; fake.query_devices = lambda d: {"name": "Fake mic"}
sys.modules["sounddevice"] = fake
from npcvoice import log as logmod; logmod.setup(Path(tempfile.mkdtemp()))
from npcvoice.audio import Recorder
r = Recorder(); ok = r.open(); time.sleep(0.2)
res = []
for i in range(3):
    r.start(); time.sleep(0.5); wav, secs, peak = r.stop(); res.append((secs, peak))
    time.sleep(0.2)
w = wave.open(io.BytesIO(wav))
checks = [(ok, "microphone opened"), (len(opens) == 1, f"stream opened once for 3 presses ({len(opens)})"),
          (all(0.35 < s < 0.7 and p > 5000 for s, p in res), f"each press captures ~0.5 s of sound {res}"),
          (w.getframerate() == 16000 and w.getnchannels() == 1, "valid 16 kHz mono WAV")]
r.stop(); time.sleep(0.2); w2 = r.stop()
checks.append((w2[0] is None, "nothing is collected between presses"))
for c, t in checks: print(("PASS " if c else "FAIL ") + t)
sys.exit(0 if all(c for c, _ in checks) else 1)
