"""People who belong together stay together (your 00:04-00:12 log: Ophelia and Rufus on one horse): the bond is
remembered for good, the husband doesn't ride off while you threaten / take his wife, words count as a threat, the
reaction is weighed (bond x how bad x nerve / fear / a gun), a mere acquaintance only watches - and 'where is the bed?'
is about THIS house, never a yellow line to a family 600 m away."""
import asyncio, os, sys, tempfile, time
from pathlib import Path
from urllib.parse import unquote
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod, actions, context, surroundings
from npcvoice.brain import Brain
from npcvoice.hashing import joaat
from npcvoice.memory import MemoryStore
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0
def check(c, w):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + w); ok += c; bad += (not c)
class W:
    def __init__(self): self.lines = []
    def is_closing(self): return False
    def write(self, b): self.lines.append(unquote(b.decode()))
ROOT = Path(__file__).resolve().parents[1]
_sleep = asyncio.sleep
async def nosleep(t=0, *a): await _sleep(0)


async def main():
    b = Brain(ROOT); b.cfg.fake_ai = True; b.cfg.households = False
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory; w = W(); b.asi.writer = w
    cane = next(p for p in b.db.places if p["name"] == "can_manor_int")
    X, Y = cane["x"] + 20, cane["y"]
    b.game.player = {"x": X, "y": Y, "z": cane["z"], "cash": 500}
    b.game.world = {"hr": 23, "mn": 50, "dow": 3}
    said = []
    async def fake_say(ped, ident, text, emo, gesture=True):
        said.append((ped, text)); return 0.0
    b.say_line = fake_say
    surroundings.NAMES.clear(); surroundings.PAIRS.clear()

    def person(ped, model, outfit, **st):
        c = b.on_engage_req({"ped": ped, "model": joaat(model), "outfit": outfit, "male": int("_M_" in model.upper()),
                             "human": 1, "alive": 1})
        b.game.peds[ped] = dict({"h": ped, "d": 3, "alive": 1, "_t": time.time(), "x": X + 2, "y": Y, "z": 0}, **st)
        b.after_tick()
        return c

    async def drama(n=1):
        asyncio.sleep = nosleep
        try:
            for _ in range(n):
                await b.drama.tick()
        finally:
            asyncio.sleep = _sleep

    # Ophelia behind Rufus on his horse
    ophelia = person(292611, "A_F_M_LagTownfolk_01", 0, mnt=1)
    ophelia.ident.persona["family"] = "married"      # 0.5.8: a widow's companion is never her husband - this one isn't one
    rufus = {"h": 291587, "m": joaat("A_M_M_BynRoughTravellers_01"), "o": 0, "male": 1, "alive": 1, "d": 3, "de": 0.5,
             "los": 1, "mnt": 1, "x": X + 2.5, "y": Y, "z": 0, "_t": time.time()}
    b.game.near_peds = [rufus]
    b.game.peds[291587] = dict(rufus)
    context.system_prompt(ophelia, b.game)
    rel = surroundings.PAIRS.get((ophelia._key, surroundings.key_of(rufus)))
    kin = b.drama.kin_of(ophelia)
    check(rel and kin and kin[0][0] == 291587, f"Ophelia knows the man on her horse is kin ({rel})")
    rid = b.handle_ident.get(291587)
    check(rid and ophelia.ident.d["relations"].get(f"id:{rid}", {}).get("rel") == rel, "...remembered in HER memory")
    back = b.memory.ids[rid].d.get("relations", {}).get(f"id:{ophelia.ident.id}", {}).get("rel")
    check(back in ("your wife", "your husband", "your sweetheart", "your sister", "your brother"), f"...and in HIS ({back})")

    # he gets off and walks away a bit; the street pairing is gone - the bond isn't
    surroundings.PAIRS.clear()
    rufus.update(d=14, mnt=0); b.game.peds[291587].update(d=14, mnt=0, _t=time.time())
    kin = b.drama.kin_of(ophelia)
    check(kin and kin[0][0] == 291587, "they're apart now: still kin (not 'just someone I know')")

    # you threaten her with WORDS while he's within earshot
    rid_ident = b.memory.ids[rid]
    rid_ident.persona["bravery"] = 0.9
    rufus.update(d=8, hasw=1); b.game.peds[291587].update(d=8, hasw=1)
    w.lines.clear(); said.clear()
    ophelia.mark("threatened")
    await drama()
    mine = [l for l in w.lines if " 291587 " in l and l.startswith("task ")]
    check(any("goto_player" in l for l in mine) and any(" draw" in l for l in mine),
          f"'I'll kill you and your husband': a brave armed husband steps in, hand on his gun ({[l.split()[3] for l in mine]})")
    check(said and said[0][0] == 291587, f"...and says something ({said[:1]})")
    check(any("THREATENED your" in e["what"] for e in rid_ident.d["events"]), "...and remembers what he heard")

    # a timid husband: he can't stop you, but he doesn't ride off either
    rid_ident.persona["bravery"] = 0.15
    rid_ident.stats["fear"] = 70
    b.drama.last.clear()
    w.lines.clear(); said.clear()
    ophelia.mark("threatened")
    await drama()
    mine = [l for l in w.lines if " 291587 " in l and l.startswith("task ")]
    check(not any(" draw" in l or "combat" in l for l in mine), "a scared husband doesn't draw on you")
    # his talk with you ends ('you ignored them') - he'd normally be released and ride off
    rufus.update(d=35, mnt=1); b.game.peds[291587].update(d=35, mnt=1, _t=time.time())
    b.drama.kept = {}
    w.lines.clear()
    await drama()
    mine = [l for l in w.lines if " 291587" in l]
    check(any(l.startswith("actor 291587 1") for l in mine) and any("dismount" in l for l in mine)
          and any("goto_player" in l for l in mine),
          f"while his wife is held, he stays: gets off his horse and comes back ({[l.split()[0:4] for l in mine][:4]})")
    # it's over: let go after a while
    b.drama.kept[291587]["until"] = 0
    ophelia.events_t = {}
    ophelia.flags.update(hands_up=False, riding=False, following=False)
    ophelia._marks = {}
    if hasattr(ophelia, "marks"):
        ophelia.marks.clear()
    w.lines.clear()
    b.drama.let_go()
    check(any(l.startswith("actor 291587 0") for l in w.lines), "...and is let go once it's over")

    # someone she only knows by name: just watches, says nothing, remembers
    bystander = {"h": 300001, "m": joaat("A_M_M_LagTownfolk_01"), "o": 0, "male": 1, "alive": 1, "d": 6, "x": X + 5, "y": Y,
                 "z": 0, "_t": time.time()}
    b.game.near_peds = [bystander]
    b.game.peds[300001] = dict(bystander)
    surroundings.PAIRS[(ophelia._key, surroundings.key_of(bystander))] = "someone you know by name"
    surroundings.PAIRS[(surroundings.key_of(bystander), ophelia._key)] = "someone you know by name"
    said.clear(); w.lines.clear(); b.drama.last.clear()
    ophelia.mark("threatened")
    await drama()
    by_tasks = [l for l in w.lines if " 300001 " in l and l.startswith("task ")]
    check(not said and not any("combat" in l or "draw" in l for l in by_tasks),
          f"an acquaintance only watches - no line, no gun ({[l.split()[3] for l in by_tasks]})")

    # ── 'where is the bed?' ──
    ap, _ = actions.plan([{"name": "mark_person", "args": {"kind": "person", "who": "the people he told you about",
                                                            "where": "over there in the corner"}}],
                         ophelia, b.game.ped(292611), b.player_view())
    kept = b.local_guard(ophelia, "where is the bed , can u know where it is in this house ?", ap)
    check(ap and not kept, "'where is the bed in this house?' -> no yellow line on the map")
    extra = b.implied_mark(ophelia, "where is the bed , can u know where it is in this house ?",
                           {"say": "I-I think it's over there in the corner. Please don't get any closer!"}, [],
                           b.game.ped(292611), b.player_view())
    check(not extra, "...and 'it's over there in the corner' isn't read as a place on the map")
    extra = b.implied_mark(ophelia, "where can I find a couple that likes company?",
                           {"say": "Folks say the Hendersons over at Sweetwater like that sort of thing."}, [],
                           b.game.ped(292611), b.player_view())
    check(extra and extra[0]["name"] == "mark_person", "a real 'where do I find...' -> 'over at Sweetwater' is still marked")
    b.game.peds[292611].update(mnt=0, mounted=0, veh=0, hands=0)
    ap, _ = actions.plan([{"name": "go_to_place", "args": {"x": X + 1, "y": Y, "z": 0}}], ophelia, b.game.ped(292611), b.player_view())
    out = b.implied_activity(ophelia, "go sleep on that bed", {"say": "Alright, I'll go sleep."}, ap,
                             b.game.ped(292611), b.player_view())
    check(not any(a["name"] == "go_to_place" for a in out) and any(a["name"] == "activity" for a in out),
          f"'go sleep on that bed' + 'I'll sleep': she lies down on it, not just walks over ({[a['name'] for a in out]})")


asyncio.run(main())
print(f"\n{ok} passed, {bad} failed")
sys.exit(1 if bad else 0)
