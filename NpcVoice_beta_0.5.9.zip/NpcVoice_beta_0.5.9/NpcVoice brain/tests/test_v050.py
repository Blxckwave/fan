"""0.5.0: undress/dress + awareness (consent decides the reaction), love scenes via NpcHookups (both must say yes),
daily life (home/work/journal/appointments), play with a stop word, bribes, hired guns, coffee carry-over."""
import asyncio, os, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod, actions, context, daylife
from npcvoice.brain import Brain
from npcvoice.hashing import joaat
from npcvoice.memory import MemoryStore
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0
def check(c, w):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + w); ok += c; bad += (not c)
class W:
    def __init__(self): self.lines = []
    def is_closing(self): return False
    def write(self, b): self.lines.append(b.decode())
ROOT = Path(__file__).resolve().parents[1]


async def main():
    b = Brain(ROOT); b.cfg.fake_ai = True
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory; w = W(); b.asi.writer = w
    rho = b.db.towns["Rhodes"]
    b.game.player = {"x": rho["x"], "y": rho["y"], "z": 0, "cash": 5000}
    b.game.world = {"hr": 15, "mn": 30, "dow": 3}

    def person(ped, model, outfit, **st):
        c = b.on_engage_req({"ped": ped, "model": joaat(model), "outfit": outfit, "male": int("_M_" in model), "human": 1, "alive": 1})
        b.game.peds[ped] = dict({"h": ped, "d": 2, "alive": 1, "_t": time.time(), "x": rho["x"] + 2, "y": rho["y"]}, **st)
        b.after_tick()
        return c

    # ── daily life ──
    clerk = person(80, "A_M_M_RhdTownfolk_01", 1)
    clerk.ident.persona["job"] = "general store clerk"; clerk.ident.d.pop("home_place", None)
    daylife.assign_places(clerk.ident, b.db, rho["x"], rho["y"])
    hp, wp = clerk.ident.d.get("home_place"), clerk.ident.d.get("work_place")
    check(hp and hp["kind"] in daylife.HOME_KINDS, f"a real home near where you met ({hp and (hp['name'], hp['kind'], hp.get('town'))})")
    check(wp and wp["kind"] == "general store", f"a clerk works at a real general store ({wp and (wp['name'], wp.get('town'))})")
    j = daylife.journal(clerk.ident, 3, 15, 30, b.game.game_minutes_total)
    check(any("work" in x for x in j) and not any(x.startswith("22:") for x in j), f"journal: the day so far, nothing from tonight ({j})")
    clerk.ident.add_event("he bought tobacco from you", b.game.game_minutes_total, b.game.place(), 1)
    j = daylife.journal(clerk.ident, 3, 15, 30, b.game.game_minutes_total)
    check(any("tobacco" in x for x in j), "...and what really happened today is in it")
    check("Your day so far" in context.system_prompt(clerk, b.game), "the NPC knows its day")
    check(daylife.routine(clerk.ident, 3) == daylife.routine(clerk.ident, 3), "the routine is stable for that person")
    ap, _ = actions.plan([{"name": "meet_later", "args": {"where": "the Rhodes saloon", "when": "tonight"}}], clerk, b.game.ped(80), b.player_view())
    b.execute(clerk, ap[0])
    check(clerk.ident.d["appointments"][-1]["where"] == "the Rhodes saloon", "appointments are remembered")
    b.end(clerk, "test")
    again = person(80, "A_M_M_RhdTownfolk_01", 1)
    check(any(e[0] == "appointment" for e in again.pending_events), "meeting again: they remember the appointment")

    # ── undress / dress and awareness ──
    woman = person(81, "A_F_M_RhdTownfolk_01", 2, cu=3, cl=2, nude=0)
    woman.ident.persona["age"] = 30
    w.lines.clear()
    ap, notes = actions.plan(["undress"], woman, b.game.ped(81), b.player_view())
    b.execute(woman, ap[0])
    check(any(l.startswith("task ") and " undress" in l for l in w.lines), f"she undresses herself (her choice) ({notes})")
    b.game.peds[81].update(cu=0, cl=0, nude=1, _t=time.time()); b.after_tick()
    check(woman.flags.get("naked") and not woman.flags.get("violated"), "naked by her own choice: no outrage")
    ap, _ = actions.plan(["dress"], woman, b.game.ped(81), b.player_view())
    w.lines.clear(); b.execute(woman, ap[0])
    check(any(" dress" in l for l in w.lines if l.startswith("task ")), "she dresses again")
    b.game.peds[81].update(cu=3, cl=2, nude=0, _t=time.time()); b.after_tick()
    check(not woman.flags.get("naked"), "...and is dressed")
    # threatened -> she can't be made to undress
    woman.no_sex_because = ["held at gunpoint"]
    ap, notes = actions.plan(["undress"], woman, b.game.ped(81), b.player_view())
    check(not ap and "gunpoint" in notes[0], "at gunpoint: undress is impossible (no coercion)")
    woman.no_sex_because = []
    # stripped by the player with the Unstrip mod, without agreeing
    other = person(82, "A_F_M_RhdTownfolk_01", 3, cu=4, cl=2, nude=0, d=1.5)
    b.game.peds[82].update(cu=0, cl=0, nude=1, d=1.5, _t=time.time()); b.after_tick()
    check(other.flags.get("violated") and any(e[0] == "stripped" for e in other.pending_events),
          "stripped by you without agreeing -> she knows, outrage, never sexual")
    check(other.ident.stats["anger"] >= 30, "...and she's angry with you (memory)")
    from npcvoice import world
    check(any("stripped" in d["what"] for d in b.memory.player.get("deeds", [])), "...and the town will hear of it")
    # with consent
    third = person(83, "A_F_M_RhdTownfolk_01", 4, cu=4, cl=2, nude=0, d=1.5)
    ap, _ = actions.plan(["let_him_undress_you"], third, b.game.ped(83), b.player_view()); b.execute(third, ap[0])
    b.game.peds[83].update(cu=0, cl=0, nude=1, d=1.5, _t=time.time()); b.after_tick()
    check(third.flags.get("naked") and not third.flags.get("violated"), "she agreed -> no outrage")

    # ── love scenes through NpcHookups: both must say yes ──
    w.lines.clear()
    ap, _ = actions.plan([{"name": "make_love", "args": {"with": "me"}}], third, b.game.ped(83), b.player_view())
    b.execute(third, ap[0])
    check(any(l.startswith("hk_start ") and l.split()[2] == "83" and l.split()[3].strip() == "0" for l in w.lines),
          f"'with me' -> NpcHookups scene with the player ({[l for l in w.lines if l.startswith('hk')]})")
    b.game.near_peds = [{"h": 84, "m": joaat("A_M_M_RhdTownfolk_01"), "male": 1, "alive": 1, "d": 3, "x": rho["x"] + 3, "y": rho["y"]}]
    husband = person(84, "A_M_M_RhdTownfolk_01", 5)
    context.system_prompt(third, b.game)              # tags [P1]...
    tag = next((t for t, h in third.targets.items() if h == 84), None)
    w.lines.clear()
    ap, _ = actions.plan([{"name": "make_love", "args": {"with": tag}}], third, b.game.ped(83), b.player_view())
    if ap: b.execute(third, ap[0])
    check(tag and not any(l.startswith("hk_start") for l in w.lines), "with someone who hasn't said yes -> nothing starts")
    ap, _ = actions.plan(["agree_to_make_love"], husband, b.game.ped(84), b.player_view()); b.execute(husband, ap[0])
    w.lines.clear()
    ap, _ = actions.plan([{"name": "make_love", "args": {"with": tag}}], third, b.game.ped(83), b.player_view()); b.execute(third, ap[0])
    check(any(l.startswith("hk_start ") and l.split()[3].strip() == "84" for l in w.lines), "both said yes -> the scene starts")
    b.game.peds[83].update(hk=2, _t=time.time()); b.after_tick()
    b.game.peds[83].update(hk=0, _t=time.time()); b.after_tick()
    check(any("made love" in e["what"] for e in third.ident.d["events"]), "afterwards she remembers it")
    child = person(85, "S_M_Y_NewspaperBoy_01", 6)
    ap, notes = actions.plan(["undress", "make_love"], child, b.game.ped(85), b.player_view())
    check(not ap, "children: never")

    # ── play with a stop word, bribes, hired gun ──
    play = person(86, "A_F_M_RhdTownfolk_01", 7)
    ap, _ = actions.plan([{"name": "start_play", "args": {"stop_word": "bluebonnet", "who_leads": "you"}}], play, b.game.ped(86), b.player_view())
    b.execute(play, ap[0])
    check("bluebonnet" in context.system_prompt(play, b.game), "play: she knows her stop word")
    await b.run_turn(play, text="okay... bluebonnet")
    check(play.flags.get("play") is None, "saying the stop word ends it at once")
    law = person(87, "S_M_M_ValDeputy_01", 8)
    if law.flags.get("is_law"):
        ap, _ = actions.plan([{"name": "take_bribe", "args": {"amount": 10}}], law, b.game.ped(87), b.player_view()); b.execute(law, ap[0])
        ap, notes = actions.plan([{"name": "arrest", "args": {"crime": "robbery"}}], law, b.game.ped(87), b.player_view())
        check(not ap and "money" in notes[0], "a bribed lawman doesn't arrest you")
    gun = person(88, "A_M_M_RhdTownfolk_01", 9)
    ap, _ = actions.plan([{"name": "work_for_him", "args": {"amount": 5}}], gun, b.game.ped(88), b.player_view())
    w.lines.clear(); b.execute(gun, ap[0])
    check(gun.flags.get("hired") and gun.companion and any(l.startswith("money ") for l in w.lines), "hired gun: paid, follows you")

    # ── coffee carry-over (the 15:59 log) ──
    hat = person(89, "A_F_M_RhdTownfolk_01", 10)
    hat.transcript.append("Player: sit down here and finish your coffee")
    seen = []
    async def fake_try(ped, prim, timeout):
        seen.append(prim); return {"ok": True}
    b.scen_try = fake_try
    await b.run_activity(hat, "sit down")
    check(seen and "COFFEE" in str(seen[0]), f"the AI wrote 'sit', the player said coffee -> sits WITH coffee ({seen[:1]})")
    # a finished conversation never speaks again by itself
    b.end(hat, "test"); n = len(w.lines)
    await b.run_turn(hat, reaction=True)
    check(not any(l.startswith("say ") for l in w.lines[n:]), "an ended conversation stays silent")


asyncio.run(main())
print(f"\n{ok} passed, {bad} failed")
sys.exit(1 if bad else 0)
