"""0.5.2: kin drama (the husband who runs after your horse), trips to a couple / an enemy / a real place, lovers who
sneak off, desires in the persona."""
import asyncio, math, os, sys, tempfile, time
from pathlib import Path
from urllib.parse import unquote
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod, actions, context, surroundings, persona
from npcvoice.brain import Brain
from npcvoice.hashing import joaat
from npcvoice.memory import MemoryStore
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0
def check(c, w):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + w); ok += c; bad += (not c)
class W:
    def __init__(self): self.lines = []
    def is_closing(self): return False
    def write(self, b): self.lines.append(unquote(b.decode()))
ROOT = Path(__file__).resolve().parents[1]
_sleep = asyncio.sleep
async def nosleep(t): await _sleep(0)


async def main():
    b = Brain(ROOT); b.cfg.fake_ai = True
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory; w = W(); b.asi.writer = w
    rho = b.db.towns["Rhodes"]
    b.game.player = {"x": rho["x"], "y": rho["y"], "z": 0, "cash": 5000}
    b.game.world = {"hr": 21, "mn": 0, "dow": 3}
    said = []
    async def fake_say(ped, ident, text, emo, gesture=True):
        said.append((ped, text)); return 0.0
    b.say_line = fake_say

    def person(ped, model, outfit, **st):
        c = b.on_engage_req({"ped": ped, "model": joaat(model), "outfit": outfit, "male": int("_M_" in model.upper()),
                             "human": 1, "alive": 1})
        b.game.peds[ped] = dict({"h": ped, "d": 2, "alive": 1, "_t": time.time(), "x": rho["x"] + 2, "y": rho["y"], "z": 0}, **st)
        b.after_tick()
        return c

    # ── desires ──
    seen = [persona.generate(str(i), {"sex": "male" if i % 2 else "female", "child": False, "age_label": "", "role": "townsfolk",
                                      "model_name": "A_M_M_X"}, "Rhodes") for i in range(300)]
    check(sum(1 for p in seen if p.get("sexuality")) > 60, "plenty of people have desires of their own")
    check(any("watch" in p.get("sexuality", "") for p in seen), "...some husbands like to watch, some couples are open")
    p0 = next(p for p in seen if p.get("sexuality"))
    check("Desire" in persona.describe(p0), "the NPC is told their desire")

    # ── kin drama: you ride off with his wife ──
    surroundings.NAMES.clear(); surroundings.PAIRS.clear()
    wife = person(10, "A_F_M_RhdTownfolk_01", 1)
    wife.ident.persona["age"] = 30
    husband_near = {"h": 11, "m": joaat("A_M_M_RhdTownfolk_01"), "o": 2, "male": 1, "alive": 1, "d": 3, "de": 1.0, "los": 1,
                    "x": rho["x"] + 3, "y": rho["y"], "z": 0}
    b.game.near_peds = [husband_near]
    context.system_prompt(wife, b.game)
    r = surroundings.PAIRS.get((wife._key, surroundings.key_of(husband_near)))
    kin = b.drama.kin_of(wife)
    check(r in ("your husband", "your sweetheart", "your brother") and kin and kin[0][0] == 11, f"she knows the man glued to her is kin ({r})")
    ap, _ = actions.plan(["ride_with_me"], wife, b.game.ped(10), dict(b.player_view(), mounted=1))
    if ap: b.execute(wife, ap[0])
    wife.mark("threatened")
    husband_near["d"] = 12
    w.lines.clear(); said.clear()
    asyncio.sleep = nosleep
    try:
        await b.drama.tick()
    finally:
        asyncio.sleep = _sleep
    tasks = [l for l in w.lines if l.startswith("task ") and " 11 " in l]
    check(any("goto_player" in l or "combat" in l or "emote" in l for l in w.lines if " 11 " in l),
          f"you take his wife: he runs after you / draws / begs ({[l.split()[3] for l in tasks]})")
    check(said and said[0][0] == 11, f"...shouting a real line ({said[:1]})")
    hid = b.handle_ident.get(11)
    check(hid and any("taking your" in e["what"] for e in b.memory.ids[hid].d["events"]), "...and he remembers it")
    check(any(e[0] == "kin" for e in wife.pending_events), "she sees and hears him")

    # ── trips: a couple, an enemy, a real place ──
    guide = person(20, "A_M_M_RhdTownfolk_01", 5)
    b.journeys.active = None

    async def answer_plugin(rounds=300):
        done = set()
        for _ in range(rounds):
            await _sleep(0.005)
            for l in list(w.lines):
                p = l.split()
                key = (p[0], p[1]) if len(p) > 1 else None
                if not key or key in done:
                    continue
                if p[0] == "find_bed":
                    done.add(key)
                    b.couples.on_bed({"seq": int(p[1]), "ok": 1, "x": float(p[2]) + 2, "y": float(p[3]), "z": float(p[4]),
                                      "hd": 30.0, "model": "PROP_HUMAN_SLEEP_BED_PILLOW", "src": "scenario"})
                elif p[0] == "spawn":
                    done.add(key)
                    if b.couples.owns(int(p[1])):
                        b.couples.on_spawned({"seq": int(p[1]), "h": 700 + int(p[1]) % 100})
                    else:
                        b.journeys.on_spawned({"seq": int(p[1]), "h": 600 + int(p[1]) % 100})
    # exactly your 18:13 case: he MARKS the couple on your map (he doesn't come along)
    w.lines.clear()
    ap, notes = actions.plan([{"name": "mark_person", "args": {"kind": "couple", "who": "a couple named Ida and Benny, they're known for wild nights"}}],
                             guide, b.game.ped(20), b.player_view())
    b.execute(guide, ap[0])
    j = b.journeys.active
    check(j and j.kind == "couple" and not j.guided and not any("stash" in l for l in w.lines),
          f"'a couple named Ida and Benny' marked on the map is a COUPLE, not a stash (0.5.2 crashed: 'dollars') ({j and j.kind})")
    await _sleep(0.05)
    check(j.plan.get("members") and len(j.plan["members"]) == 2, "...the couple is planned")
    b.game.player.update(x=j.dest[0] + 100, y=j.dest[1])
    j.state = "spawning"; w.lines.clear()
    task = asyncio.create_task(answer_plugin())
    b.journeys.spawn_all(j)
    await task
    pair = [x for x in j.spawned if x.get("ident")]
    check(any(l.startswith("find_bed") for l in w.lines), "they're placed by finding their bed first")
    check(len(pair) == 2 and j.state == "spawned", "two of them, inside")
    check(pair and j.bed and all(math.hypot(x["x"] - j.bed["x"], x["y"] - j.bed["y"]) < 2.5 for x in pair),
          "...right by the bed, not at the door")
    check(all("couple" in x["ident"].persona["role_note"] for x in pair), "they know they're that couple")
    a1, a2 = pair[0]["ident"], pair[1]["ident"] if len(pair) > 1 else pair[0]["ident"]
    check(a1.persona["name"].split()[-1] == a2.persona["name"].split()[-1] and f"id:{a2.id}" in a1.d.get("relations", {}),
          "...married: one name, they know each other")
    check(all(x["ident"].persona["romance_openness"] >= 0.75 for x in pair), "...and they want it (open)")
    check(all(x["ident"].d.get("bed") for x in pair), "...and they know where their bed is")
    # you arrive: they greet you, one of them talks first
    asyncio.sleep = nosleep
    try:
        b.game.player.update(x=j.dest[0], y=j.dest[1])
        for x in pair:
            b.game.peds[x["h"]] = {"h": x["h"], "d": 3, "alive": 1, "_t": time.time()}
        j.state = "arrived"
        await b.journeys.arrival(j)
    finally:
        asyncio.sleep = _sleep
    host = b.convs.get(pair[0]["h"])
    check(host and host.flags.get("bed"), "you arrive: the host talks to you first, and the bed is theirs")
    # she says yes to his clear question -> it happens on their bed
    if host:
        host.no_sex_because = []
        reply = {"say": "Oh yes, come here, honey. Benny wants to watch.", "actions": []}
        ap = b.implied_love(host, "let's go to bed, I want to make love to you", reply, [], b.game.ped(host.ped), b.player_view())
        check(ap and ap[-1]["name"] == "make_love", "she says yes in her own words -> make_love (not just talk)")
        w.lines.clear(); b.execute(host, ap[-1])
        check(any(l.startswith("couple ") for l in w.lines), "...on their own bed (NpcVoice's scene)")
        ap = b.implied_love(host, "let's go to bed", {"say": "No, not tonight."}, [], b.game.ped(host.ped), b.player_view())
        check(not ap, "she says no -> nothing")
    b.end(guide, "test")
    g2 = person(21, "A_M_M_RhdTownfolk_01", 6)
    b.journeys.active = None
    b.journeys.start(g2, {"kind": "enemy", "who": "Silas Crane, the man who owes me forty dollars"})
    j = b.journeys.active
    check(j and j.kind == "person" and getattr(j, "hostile", False), "'the man who owes me' -> a trip to an enemy")
    await b.journeys.make_plan(j); j.state = "spawning"; w.lines.clear()
    b.journeys.spawn_all(j)
    check(any("weapon=" in l for l in w.lines if l.startswith("spawn ")), "...he's armed and waiting")
    b.end(g2, "test")
    g3 = person(22, "A_F_M_RhdTownfolk_01", 7)
    b.journeys.active = None
    b.journeys.start(g3, {"kind": "place", "where": "saloon", "who": "the saloon"})
    j = b.journeys.active
    check(j and j.kind == "place" and j.place and j.place["kind"] == "saloon", f"'take me to the saloon' -> the real saloon ({j and j.place and j.place['name']})")
    j.state = "spawning"; b.journeys.spawn_all(j)
    check(j.state == "spawned", "...nothing to build: it's already there")

    # ── lovers sneak off (director) ──
    from npcvoice.director import TPL
    check("lovers" in TPL and "sneak_off_love" in TPL["lovers"].outcomes, "a 'lovers' scene exists in the living world")
    ia = b.memory.create(joaat("A_M_M_RhdTownfolk_01"), 9, b.peddb.classify(joaat("A_M_M_RhdTownfolk_01"), True), "Rhodes", 0)
    ib = b.memory.create(joaat("A_F_M_RhdTownfolk_01"), 9, b.peddb.classify(joaat("A_F_M_RhdTownfolk_01"), False), "Rhodes", 0)
    w.lines.clear()
    asyncio.sleep = nosleep
    try:
        await b.couples.outdoor(30, 31, ia, ib, rho["x"] + 20, rho["y"], 0)
    finally:
        asyncio.sleep = _sleep
    check(any(l.startswith("couple ") for l in w.lines) and sum(" undress" in l for l in w.lines) == 2,
          "they sneak off and do it (undressed, the couple scene)")
    check(b.couples.house and b.couples.house[-1]["a"] == 30, "...and you can walk in on them")

    # ── the wagon: he knows who sits next to him, and they both get down ──
    surroundings.NAMES.clear(); surroundings.PAIRS.clear()
    drv = person(40, "A_M_M_RhdTownfolk_01", 40, vh=900, drv=1, veh=1)
    b.game.near_peds = [{"h": 41, "m": joaat("A_F_M_RhdTownfolk_01"), "o": 41, "male": 0, "alive": 1, "d": 3, "de": 1.4,
                         "los": 1, "vh": 900}]
    sp = context.system_prompt(drv, b.game)
    check("next to you on YOUR wagon" in sp, "the driver knows a woman sits right next to him on his wagon")
    check(41 in drv.together and drv.together[41] in ("your wife", "your sweetheart", "your sister", "a friend of yours"),
          f"...and who she is to him ({drv.together.get(41)})")
    ap, notes = actions.plan(["leave_vehicle"], drv, b.game.ped(40), b.player_view())
    check(ap and ("leave_vehicle",) in ap[0]["prims"] and ("on", 41, "leave_vehicle") in ap[0]["prims"],
          f"'get off the wagon' -> he climbs down and she does too ({ap and ap[0]['prims']})")

    # ── fear is not desire ──
    from npcvoice import safety
    iris = person(50, "A_F_M_RhdTownfolk_01", 50)
    iris.flags["cowering"] = True; iris.mark("threatened")
    v = safety.check_turn("tell me about your ass", iris, b.game.ped(50))
    okr, why = safety.reply_ok("I have a nice ass! Please, just let me go!", v)
    check(v.no_sex_because and not okr, f"cowering after a threat: her sexual line is refused ({why})")


asyncio.run(main())
print(f"\n{ok} passed, {bad} failed")
sys.exit(1 if bad else 0)
