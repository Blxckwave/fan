"""Several MiniMax keys: speech takes turns across the keys, a key that's out of credit / refused is skipped and
reported on screen and in the logs, and a key whose account lacks a voice passes the line on.
(0.5.8: voice cloning was removed - the clone checks went with it.)"""
import json, os, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod
from npcvoice.llm import KeyManager, Providers, account_problem
LOGDIR = Path(tempfile.mkdtemp())
logmod.setup(LOGDIR)
ok = bad = 0
def check(c, w):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + w); ok += c; bad += (not c)


class Resp:
    def __init__(self, j, code=200): self.status_code, self._j, self.text = code, j, json.dumps(j)
    def json(self): return self._j


class Server:
    """A fake MiniMax: three accounts; 'broke' ones answer 1008 insufficient balance."""
    def __init__(self):
        self.calls, self.broke, self.voices = [], set(), {}

    def post(self, url, headers=None, json=None, files=None, data=None, timeout=None):
        key = headers["Authorization"].split()[-1]
        path = url.split("/v1")[-1]
        self.calls.append((key, path))
        if key in self.broke:
            return Resp({"base_resp": {"status_code": 1008, "status_msg": "insufficient balance"}})
        if path == "/t2a_v2":
            return Resp({"data": {"audio": b"ID3".hex()}, "base_resp": {"status_code": 0}})
        return Resp({}, 404)


kf = Path(tempfile.mkdtemp()) / "keys.json"
kf.write_text(json.dumps({"minimax": ["key-AAAA", "key-BBBB", "key-CCCC"]}))
km = KeyManager(kf)
problems = []
km.on_problem = lambda svc, tail, why, secs: problems.append((svc, tail, why))
ai = Providers(km)
srv = Server()
ai.http = srv

# normal speech: takes turns
for _ in range(3):
    ai.tts("hello", "English_Trustworth_Man", "calm")
used = [k for k, p in srv.calls if p == "/t2a_v2"]
check(sorted(used) == ["key-AAAA", "key-BBBB", "key-CCCC"], f"normal speech takes turns over the 3 keys ({used})")

# a key out of credit: reported, and speech goes around it
srv.broke.add("key-BBBB")
srv.calls.clear()
for _ in range(3):
    ai.tts("hello", "English_Trustworth_Man", "calm")
check(any(t == "…BBBB" and "insufficient" in w for _, t, w in problems), f"a key out of credit is reported ({problems[-1:]})")
check(account_problem("minimax …BBBB: error 1008 insufficient balance"), "...as an ACCOUNT problem")
check(not account_problem("minimax …AAAA: error 2054 voice id not exist"), "...unlike a voice that's really gone")
srv.calls.clear()
for _ in range(4):
    ai.tts("hello", "English_Trustworth_Man", "calm")
check("key-BBBB" not in [k for k, p in srv.calls], "normal speech goes around the broke key")

# a key whose account doesn't have a stock voice (the China platform): the line goes to the next key, every time
srv.broke.clear()
real_post = srv.post
def china_post(url, headers=None, json=None, **kw):
    key = headers["Authorization"].split()[-1]
    if key == "key-AAAA" and url.endswith("/t2a_v2"):
        srv.calls.append((key, "/t2a_v2"))
        return Resp({"base_resp": {"status_code": 2054, "status_msg": "voice id not exist"}})
    return real_post(url, headers=headers, json=json, **kw)
srv.post = china_post
km._bad_until.clear()
srv.calls.clear()
res = [ai.tts("hello", "English_Graceful_Lady", "calm") for _ in range(6)]
check(all(m for m, _ in res), "every normal line is spoken even though one account lacks that voice")
check([k for k, p in srv.calls].count("key-AAAA") == 1, "...that key was asked once, then left out for that voice")
srv.post = real_post

# the brain: on screen + in the log, not spammed
from npcvoice.brain import Brain
import asyncio


class W:
    def __init__(self): self.lines = []
    def is_closing(self): return False
    def write(self, raw): self.lines.append(raw.decode())


async def brain_part():
    ROOT = Path(__file__).resolve().parents[1]
    b = Brain(ROOT)
    b.loop = asyncio.get_running_loop()
    b.asi.writer = W()
    b.key_problem("minimax", "…BBBB", "insufficient balance", 120)
    b.key_problem("minimax", "…BBBB", "insufficient balance", 120)
    await asyncio.sleep(0)
    toasts = [l for l in b.asi.writer.lines if l.startswith("toast")]
    check(len(toasts) == 1 and "BBBB" in toasts[0], f"shown in the game once, not spammed ({len(toasts)})")
    logtxt = "".join(p.read_text(errors="replace") for p in LOGDIR.glob("*.log"))
    check("[KEYS] MiniMax (voices) key …BBBB: insufficient balance" in logtxt, "logged as an error in npc_brain.log")

asyncio.run(brain_part())
print(f"\n{ok} passed, {bad} failed")
sys.exit(1 if bad else 0)
