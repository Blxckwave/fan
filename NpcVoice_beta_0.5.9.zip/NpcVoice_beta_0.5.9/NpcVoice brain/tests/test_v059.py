"""0.5.9 - "when I tell someone to sleep he never does": the activity catalog, meaning-based options the AI picks from,
the real spots around the person, the fallback chain (spot -> scenario in their own version -> its own loop -> next
option -> gesture), learning kept in your own folder, asleep that lasts and wakes on danger, and calibration."""
import asyncio, json, os, sys, tempfile, time
from pathlib import Path
from urllib.parse import unquote
os.environ["NPCVOICE_USER_DIR"] = tempfile.mkdtemp()
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod, actions, context
from npcvoice.activities import Activities, concepts_of, user_dir
from npcvoice.brain import Brain
from npcvoice.hashing import joaat
from npcvoice.memory import MemoryStore
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0


def check(c, w):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + w); ok += c; bad += (not c)


ROOT = Path(__file__).resolve().parents[1]


class Plugin:
    """Answers like NpcVoice.asi 0.5.9: spots around a person, scenario checks (scenarios can be told to fail), clips."""
    def __init__(self, b, fail_scen=()):
        self.b, self.lines, self.fail = b, [], set(fail_scen)
        self.spots = []
        b.asi_info = {"caps": ["home_scan", "use_point", "couple_pose", "nh_pos", "undress_wait", "los", "scen_variant",
                               "anim_try", "spots"]}

    def is_closing(self): return False

    def write(self, raw):
        line = unquote(raw.decode().strip()); self.lines.append(line); tok = line.split(" ")
        loop = asyncio.get_running_loop()
        if tok[0] == "spots":
            loop.call_soon(self.b.affordances.on_spots, {"seq": int(tok[1]), "ped": int(tok[2]), "pts": self.spots})
        elif tok[0] == "scen":
            loop.call_soon(lambda: asyncio.ensure_future(self.b.on_msg(
                {"t": "scen_check", "ped": int(tok[2]), "ok": tok[3] not in self.fail, "name": tok[3]})))
        elif tok[0] == "anim_try":
            loop.call_soon(lambda: asyncio.ensure_future(self.b.on_msg(
                {"t": "scen_check", "ped": int(tok[2]), "ok": True, "name": tok[4]})))
        elif tok[0] == "task" and len(tok) > 3 and tok[3] == "use_point":
            loop.call_soon(lambda: asyncio.ensure_future(self.b.on_msg(
                {"t": "scen_check", "ped": int(tok[2]), "ok": True, "name": "home spot"})))


async def main():
    # ── words -> meaning ──
    for q in ("go to sleep", "get some shut-eye", "hit the hay", "go to bed", "pass out for a while", "take a nap",
              "turn in for the night", "lie down and rest"):
        check("sleep" in concepts_of(q), f"'{q}' means sleep")
    check(not concepts_of("don't lie to me") and not concepts_of("the wagon crashed"), "'don't lie to me' is not sleep")
    check(not Brain.LOVE_ASK.search("go to bed, you look tired"), "'go to bed' is sleep, not a love request")
    check(Brain.LOVE_ASK.search("come to bed with me"), "...'come to bed with me' still is one")

    A = Activities([], Path(tempfile.mkdtemp()) / "learned.json")
    check(len(A.entries) > 400 and len(A.all) > 300, f"the catalog: {len(A.entries)} things to do ({len(A.all)} scenarios)")
    o, cons = A.options("go to sleep", False)
    check(o and o[0]["kind"] == "scenario" and "SLEEP" in o[0]["id"], f"a woman told to sleep -> {o[0]['id'] if o else '-'}")
    male_only = [e["id"] for e in A.entries if e["kind"] == "scenario" and e["sexes"] == ["m"]]
    check(len(male_only) > 100, f"{len(male_only)} activities only exist in male versions")
    o, _ = A.options("whittle a stick", False)
    check(not any(x["id"] in male_only for x in o), "...a woman is never offered one of them")
    o, _ = A.options("play us a tune on the banjo", True)
    check(o and "GUITAR" in o[0]["id"], f"no banjo in place -> the closest thing, a guitar ({o[0]['id'] if o else '-'})")
    o, _ = A.options("warm up by the fire", False)
    check(o and "FIRE" in o[0]["id"], f"'warm up by the fire' works for a woman ({o[0]['id'] if o else '-'})")
    v = A.variant_for("WORLD_HUMAN_SLEEP_GROUND_ARM", False)
    check("FEMALE" in v, f"her own version of it is passed to the game ({v})")
    clip = A.clip_for("WORLD_HUMAN_SLEEP_GROUND_ARM", v, False)
    check(clip and clip[0].startswith("amb_rest@world_human_sleep_ground@arm@female"), f"...and its own loop as a fallback ({clip})")
    spots = [{"tag": "F1", "id": "PROP_HUMAN_SLEEP_BED_PILLOW", "needs": "bed", "d": 4.0, "x": 1, "y": 2, "z": 3},
             {"tag": "F2", "id": "PROP_HUMAN_SEAT_CHAIR", "needs": "chair", "d": 2.0, "x": 0, "y": 1, "z": 3}]
    o, _ = A.options("go to sleep", True, spots=spots)
    check(o and o[0]["kind"] == "spot" and o[0]["spot"]["tag"] == "F1", f"a real bed 4 m away comes first ({o[0]['label'] if o else '-'})")
    check(sum(1 for x in o if x["kind"] == "spot") == 1, "...once (not once per pillow point)")
    # learning: in YOUR folder, kept across versions; the old file in the brain folder is taken over
    check(str(user_dir()) == os.environ["NPCVOICE_USER_DIR"], "what's learned lives in your own NpcVoice folder")
    A.learn("WORLD_HUMAN_SLEEP_GROUND_ARM", False, False, "A_F_M_VALTOWNFOLK_01")
    A.learn("WORLD_HUMAN_SLEEP_GROUND_ARM", False, False, "A_F_M_VALTOWNFOLK_01")
    A2 = Activities([], A.path)
    o2, _ = A2.options("go to sleep", False, "A_F_M_VALTOWNFOLK_01")
    check(o2[0]["id"] != "WORLD_HUMAN_SLEEP_GROUND_ARM", f"what didn't play for her model isn't first next time ({o2[0]['id']})")
    check(any(x["status"] == "didn't play last time" for x in o2), "...and the AI is told it didn't play")

    # ── a turn: the options are in the prompt, the AI picks one, the chain runs ──
    b = Brain(ROOT); b.cfg.fake_ai = True; b.cfg.households = False
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory
    b.activities = Activities([], Path(tempfile.mkdtemp()) / "l.json")
    b.affordances._names = None
    plug = Plugin(b, fail_scen={"WORLD_HUMAN_SLEEP_GROUND_ARM"}); b.asi.writer = plug
    b.game.player = {"x": 0, "y": 0, "z": 0, "cash": 50}
    b.game.peds[90] = {"h": 90, "d": 3, "alive": 1, "_t": time.time(), "x": 2, "y": 0, "z": 0, "hp": 150}
    conv = b.on_engage_req({"ped": 90, "model": joaat("A_F_M_ValTownfolk_01"), "outfit": 3, "male": 0, "human": 1, "alive": 1})
    plug.spots = [[joaat("PROP_HUMAN_SEAT_CHAIR_TABLE_EATING_KNIFE_FORK") & 0xFFFFFFFF, 3.0, 1.0, 0.0, 90, 1]]
    await b.affordances.prepare(conv, "you look tired, go to sleep")
    check(conv.options and all(o["kind"] != "spot" for o in conv.options[:1]), "no bed here: ground options first")
    txt = context.player_turn_text(conv, "you look tired, go to sleep", [], [], "", __import__("npcvoice.affordances", fromlist=["x"]).options_text(conv))
    check("WHAT YOU CAN REALLY DO" in txt and "[A1]" in txt and '"option": "A1"' in txt, "the options are in the turn, tagged")
    sp = context.system_prompt(conv, b.game)
    check("Real spots around you" in sp and "[F1]" in sp, "the real furniture around her is in her prompt")
    ap, notes = actions.plan([{"name": "activity", "args": {"option": "A1"}}], conv, b.game.ped(90), b.player_view())
    check(ap and ap[0]["prims"][0][2] == "A1", f"the AI answers with option A1 ({notes})")
    plug.lines.clear()
    b.execute(conv, ap[0])
    for _ in range(40):
        await asyncio.sleep(0.05)
        if conv.flags.get("doing"):
            break
    scen = [l for l in plug.lines if l.startswith("scen ")]
    check(scen and "FEMALE" in scen[0], f"started in HER version: {scen[0] if scen else '-'}")
    check(any(l.startswith("anim_try ") for l in plug.lines), "the scenario refused -> its own loop is played")
    check(conv.flags.get("asleep") and "sleep" in conv.flags.get("doing", ""), f"she's asleep for real ({conv.flags.get('doing')})")
    check(any("for real" in r for r in conv.last_results), "the AI is told it really happened")
    check("ASLEEP" in context.system_prompt(conv, b.game), "...and her prompt knows she's asleep")

    # ── a real bed next to her: she walks over and lies down on it ──
    b.game.peds[91] = {"h": 91, "d": 3, "alive": 1, "_t": time.time(), "x": 2, "y": 2, "z": 0, "hp": 150}
    n_before = len(plug.lines)
    c2 = b.on_engage_req({"ped": 91, "model": joaat("A_M_M_ValFarmer_01"), "outfit": 4, "male": 1, "human": 1, "alive": 1})
    check(conv.ended and 90 in b.lasting.held and "actor 90 1" in plug.lines[n_before:],
          "you turn to someone else: she stays asleep where she lies (kept as she is)")
    plug.spots = [[joaat("PROP_HUMAN_SLEEP_BED_PILLOW") & 0xFFFFFFFF, 5.0, 2.0, 0.5, 0, 1]]
    await b.affordances.prepare(c2, "go to bed")
    check(c2.options and c2.options[0]["kind"] == "spot", f"'go to bed' with a bed in the room -> that bed ({c2.options[0]['label'] if c2.options else '-'})")
    plug.lines.clear()
    b.start_activity(c2, "go to bed", option="A1")
    for _ in range(40):
        await asyncio.sleep(0.05)
        if c2.flags.get("doing"):
            break
    check(any(" use_point " in f" {l} " for l in plug.lines) and c2.flags.get("asleep"), "he walks to the bed and sleeps in it")

    # ── asleep after the talk; a gunshot wakes her ──
    turns = []
    async def fake_turn(c, reaction=False, **k):
        turns.append(c)
    b.run_turn = fake_turn
    b.end(conv, "you walked away")
    b.game.player["shoot"] = 1
    b.after_tick()
    await asyncio.sleep(0)
    nc = b.convs.get(90)
    ev = [e for e in (nc.pending_events if nc else []) if e[0] == "woken"]
    check(90 not in b.lasting.held and ev and "GUNSHOT" in ev[0][1], "a gunshot right by her wakes her - she reacts to it")
    check(turns and turns[-1] is nc, "...right away")

    # ── calibration ──
    plug.lines.clear()
    cal = b.calibrator
    todo = cal.entries("sleep")
    check(todo and all("sleep" in e["concepts"] or "rest" in e["concepts"] or "sleep" in e["label"] for e in todo),
          f"'calibrate sleep' -> {len(todo)} sleep activities")
    async def spawned(fut, timeout=10.0):
        return 7000 + len([l for l in plug.lines if l.startswith("spawn ")])
    b.couples.spawned = spawned
    import npcvoice.calibrate as cmod
    real_sleep = asyncio.sleep
    async def quick(t=0, *a):
        await real_sleep(0)
    cmod.asyncio.sleep = quick
    try:
        await cal.run("sleep")
    finally:
        cmod.asyncio.sleep = real_sleep
    rep = user_dir() / "calibration_report.txt"
    rtxt = rep.read_text() if rep.exists() else ""
    check("WORLD_HUMAN_SLEEP_GROUND_ARM" in rtxt and " m  " in rtxt and " f  " in rtxt,
          "calibration tried them on a man and a woman and wrote the report")
    check(any(k.startswith("WORLD_HUMAN_SLEEP_GROUND_PILLOW|f|") for k in b.activities.learned), "...and learned per sex and model")
    print(f"\n{ok} passed, {bad} failed")
    sys.exit(1 if bad else 0)

asyncio.run(main())
