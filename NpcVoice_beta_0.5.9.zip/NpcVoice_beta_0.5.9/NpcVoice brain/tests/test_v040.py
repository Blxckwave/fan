"""0.4.0: activities that search + learn, wagon driving, targets, group talk, pressure, scared run off, names/jobs."""
import asyncio, json, os, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod, actions, context
from npcvoice.activities import Activities, concepts_of
from npcvoice.brain import Brain
from npcvoice.hashing import joaat
from npcvoice.memory import MemoryStore
from npcvoice import persona
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0
def check(c, w):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + w); ok += c; bad += (not c)
class W:
    def __init__(self): self.lines = []
    def is_closing(self): return False
    def write(self, b): self.lines.append(b.decode())

ROOT = Path(__file__).resolve().parents[1]
scen = list(json.loads((ROOT / "data" / "scenarios.json").read_text()))

# ── the activity search ──
A = Activities(scen, Path(tempfile.mkdtemp()) / "learned.json")
c, cons = A.candidates("sit down and have a beer", True)
check(c and c[0] == "WORLD_HUMAN_SIT_DRINK", f"'sit down and have a beer' -> sit + drink ({c[:2]})")
c, _ = A.candidates("light a cigar", True)
check(c and "CIGAR" in c[0], f"cigar -> a cigar scenario ({c[:1]})")
c, _ = A.candidates("play us a tune on the guitar", True)
check(c and "GUITAR" in c[0], f"guitar ({c[:1]})")
c, _ = A.candidates("pray for her", False)
check(c and "MOURNING" in c[0], f"pray ({c[:1]})")
c, _ = A.candidates("sweep the porch", False)
check(c and "BROOM" in c[0], f"sweep ({c[:1]})")
check(concepts_of("blah blah nothing") == [], "no activity words -> nothing")
# learning: a broken one drops, the next one comes first
c0, _ = A.candidates("have a drink", True)
A.learn(c0[0], True, False); A.learn(c0[0], True, False)
c1, _ = A.candidates("have a drink", True)
check(c1[0] != c0[0], f"broken scenario is not tried first any more ({c0[0]} -> {c1[0]})")
A.learn(c1[0], True, True)
A2 = Activities(scen, A.path)
c2, _ = A2.candidates("have a drink", True)
check(c2[0] == c1[0], "what was learned is remembered after a restart")
check(A.emote_for(["drink"])[1] == "KIT_EMOTE_ACTION_WET_YOUR_WHISTLE_1", "nothing works -> 'wet your whistle' emote")

# ── names that fit the face ──
p = persona.generate("x1", {"sex": "male", "child": False, "age_label": "Middle Age", "role": "townsfolk",
                           "model_name": "A_M_M_SDChinatown_01"}, "Saint Denis")
check(p["last_name"] if "last_name" in p else p["name"].split()[-1] in persona.CHINESE_S, f"Chinatown model -> Chinese name ({p['name']})")


async def main():
    b = Brain(ROOT); b.cfg.fake_ai = True
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory; w = W(); b.asi.writer = w
    b.activities = Activities(scen, Path(tempfile.mkdtemp()) / "l.json")
    b.game.player = {"x": 0, "y": 0, "z": 0, "cash": 5000}

    # tram driver: job fits, can't be stopped; wagon driver: real stop / drive / waypoint / turn
    tram = {"ped": 60, "model": joaat("A_M_M_SDChinatown_01"), "outfit": 6, "male": 1, "human": 1, "alive": 1, "veh": 1, "drv": 1, "tram": 1}
    b.game.peds[60] = {"h": 60, "d": 4, "alive": 1, "_t": time.time(), "veh": 1, "drv": 1, "tram": 1}
    tc = b.on_engage_req(tram); b.after_tick()
    check("streetcar" in tc.ident.persona["job"], f"tram driver is a streetcar driver ({tc.ident.persona['job']})")
    ap, notes = actions.plan(["stop_wagon"], tc, b.game.ped(60), b.player_view())
    check(not ap and "rails" in notes[0], "a streetcar can't be pulled over")
    wag = {"ped": 61, "model": joaat("A_M_M_ValFarmer_01"), "outfit": 7, "male": 1, "human": 1, "alive": 1, "veh": 1, "drv": 1}
    b.game.peds[61] = {"h": 61, "d": 4, "alive": 1, "_t": time.time(), "veh": 1, "drv": 1}
    wc = b.on_engage_req(wag); b.after_tick()
    for name, prim in (("stop_wagon", "veh_stop"), ("give_ride", "veh_stop"), ("drive_on", "veh_go"),
                       ("drive_to_marker", "veh_waypoint")):
        ap, notes = actions.plan([name], wc, b.game.ped(61), b.player_view())
        check(ap and ap[0]["prims"][0][0] == prim, f"{name} -> {prim} ({notes})")
    ap, _ = actions.plan([{"name": "turn_wagon", "args": {"dir": "right"}}], wc, b.game.ped(61), b.player_view())
    check(ap and ap[0]["prims"][0][:2] == ("veh_turn", "right"), "turn right")
    ap, notes = actions.plan(["ride_with_me"], wc, b.game.ped(61), b.player_view())
    check(not ap and "give_ride" in notes[0], "the driver isn't sent to YOUR horse when you ask for a ride")
    ap, _ = actions.plan(["stop_following"], wc, b.game.ped(61), b.player_view())
    check(("leave_vehicle",) not in ap[0]["prims"], "'stop' never throws the driver off his own wagon")
    b.game.peds[61]["pin"] = 1; b.after_tick()
    check(wc.flags.get("player_aboard") and wc.companion, "you climb aboard -> the talk keeps going while you ride")
    check(any(e[0] == "aboard" for e in wc.pending_events), "...and he notices you got on")

    # targets: [P1]/[B1] tags, fight / inspect a body
    man = {"ped": 62, "model": joaat("A_M_M_ValTownfolk_01"), "outfit": 8, "male": 1, "human": 1, "alive": 1}
    b.game.peds[62] = {"h": 62, "d": 3, "alive": 1, "_t": time.time()}
    mc = b.on_engage_req(man); b.after_tick()
    b.game.near_peds = [{"h": 70, "m": joaat("A_M_M_ValFarmer_01"), "male": 1, "alive": 1, "d": 9, "x": 9, "y": 0},
                        {"h": 71, "m": joaat("A_F_M_ValTownfolk_01"), "male": 0, "alive": 0, "d": 55, "x": 55, "y": 0, "kp": 1}]
    prompt = context.system_prompt(mc, b.game)
    check("[P1]" in prompt and "[B1]" in prompt, "people and bodies get tags in the prompt")
    check("55 m" in prompt, "a body 55 m away is still known (0.3.1 cut at 40 m / 24 people)")
    ap, notes = actions.plan([{"name": "attack_person", "args": {"target": "P1"}}], mc, b.game.ped(62), b.player_view())
    check(ap and ("combat", "t=70") in ap[0]["prims"] and ("holster",) in ap[0]["prims"], f"'go punch him' -> fist fight with P1 ({notes})")
    ap, _ = actions.plan([{"name": "inspect_body", "args": {"target": "B1"}}], mc, b.game.ped(62), b.player_view())
    check(ap and ("goto_player", 1.2, 1.3, "t=71") in ap[0]["prims"], "'go look at her' -> walks to the body")
    ap, notes = actions.plan([{"name": "attack_person", "args": {"target": "P9"}}], mc, b.game.ped(62), b.player_view())
    check(not ap and "tag" in notes[0], "unknown tag is refused with a hint")

    # activity runner: first candidate broken -> second one, learned
    w.lines.clear()
    async def fake_asi():
        n = 0
        while True:
            await asyncio.sleep(0.05)
            for ln in list(w.lines):
                if ln.startswith("scen "):
                    w.lines.remove(ln); n += 1
                    parts = ln.split()
                    await b.on_msg({"t": "scen_check", "ped": int(parts[2]), "ok": n >= 2, "name": parts[3]})
    sim = asyncio.create_task(fake_asi())
    ap, _ = actions.plan([{"name": "drink", "args": {"what": "have a drink"}}], mc, b.game.ped(62), b.player_view())
    b.execute(mc, ap[0])
    await asyncio.sleep(1.0)
    sim.cancel()
    check(mc.flags.get("doing"), f"broken scenario -> next one tried -> doing it ({mc.flags.get('doing')})")
    lrn = b.activities.learned
    check(any(v.get("fail") for v in lrn.values()) and any(v.get("ok") for v in lrn.values()), "both results learned")

    # pressure: gun on a timid woman -> the turn says OBEY
    woman = {"ped": 63, "model": joaat("A_F_M_ValTownfolk_01"), "outfit": 9, "male": 0, "human": 1, "alive": 1}
    b.game.peds[63] = {"h": 63, "d": 3, "alive": 1, "aimed": 1, "_t": time.time()}
    wo = b.on_engage_req(woman); wo.ident.persona["bravery"] = 0.2
    note = context.pressure_note(wo, b.game)
    check("DO it" in note, f"gun on a timid woman -> she obeys ({note[:60]})")
    b.game.peds[63]["aimed"] = 0
    check(context.pressure_note(wo, b.game) == "", "no gun, no threat -> no pressure")

    # scared people run when you leave them
    wo.flags["hands_up"] = True
    w.lines.clear()
    b.end(wo, "you turned to someone else")
    check(any(l.startswith("task ") and " flee " in l for l in w.lines), "hands-up person runs off when you turn away")

    # group talk: two companions hear 'you two'
    b.end(wc, "test", release_tasks=True)
    f1 = b.on_engage_req({"ped": 64, "model": joaat("A_M_M_ValTownfolk_01"), "outfit": 10, "male": 1, "human": 1, "alive": 1})
    f1.flags["following"] = True
    f2 = b.on_engage_req({"ped": 65, "model": joaat("A_M_M_ValFarmer_01"), "outfit": 11, "male": 1, "human": 1, "alive": 1})
    f2.flags["following"] = True
    for c, h in ((f1, 64), (f2, 65)):
        b.game.peds[h] = {"h": h, "d": 4, "alive": 1, "_t": time.time()}
    check(f1 in b.listeners(f2) and f2 in b.listeners(f1), "two followers hear you together")
    called = []
    async def fake_turn(c, text=None, **kw):
        called.append((c.ped, text))
    b.run_turn = fake_turn
    r = b.route_group(f1, "you two, go have a drink")
    await asyncio.sleep(1.2)
    check(r is f1 and (65, "you two, go have a drink") in called, f"'you two' -> the second one answers too ({called})")
    called.clear()
    r = b.route_group(f1, f"{f2.ident.persona['first_name']}, go home")
    await asyncio.sleep(0.2)
    check(r is f2 and called and called[0][0] == 65, "saying the other one's name -> it goes to them")


    # a trip to ANY person he talks about: marked on the map, built from what he said; going your own way cancels it
    b.journeys.active = None
    g = b.on_engage_req({"ped": 66, "model": joaat("A_F_M_ValTownfolk_01"), "outfit": 12, "male": 0, "human": 1, "alive": 1})
    b.game.peds[66] = {"h": 66, "d": 3, "alive": 1, "_t": time.time()}
    b.game.player.update({"x": 0, "y": 0})
    w.lines.clear()
    ap, notes = actions.plan([{"name": "mark_person", "args": {"who": "my friend Rose at the old mill", "story": "she owes me"}}],
                             g, b.game.ped(66), b.player_view())
    b.execute(g, ap[0])
    await asyncio.sleep(0.3)
    j = b.journeys.active
    check(j and j.kind == "person" and not j.guided and any(l.startswith("route ") for l in w.lines), "mark_person -> a person trip on your map")
    check(j and j.plan.get("members"), f"...and who's waiting there is planned ({j and j.plan.get('members')})")
    b.game.player.update({"x": j.dest[0] + 4000, "y": j.dest[1]})
    w.lines.clear()
    await b.journeys.tick()
    check(j.state == "failed" and any(l.startswith("route_clear") for l in w.lines), "you ride off the other way -> the trip is called off")


    # 0.4.1: trips go to REAL places from the game database
    db = b.db
    check(db.ok and len(db.places) > 300 and "Rhodes" in db.towns, f"game database loaded ({len(db.places)} places, {len(db.towns)} towns)")
    val = db.towns["Valentine"]
    b.journeys.active = None
    h = b.on_engage_req({"ped": 67, "model": joaat("A_M_M_ValFarmer_01"), "outfit": 13, "male": 1, "human": 1, "alive": 1})
    b.game.peds[67] = {"h": 67, "d": 3, "alive": 1, "_t": time.time()}
    b.game.player.update({"x": val["x"], "y": val["y"], "z": 110})
    w.lines.clear()
    b.journeys.start(h, {"kind": "family", "who": "my wife and kids"})
    j = b.journeys.active
    check(j and j.place and j.place["kind"] in ("farmhouse", "house", "cabin", "shack", "camp", "ranch", "farm"),
          f"family trip from Valentine -> a real lived-in place ({j and j.place and (j.place['name'], j.place['kind'], j.place.get('town'))})")
    check(any(l.startswith("route ") for l in w.lines), "...with the yellow line to it")
    b.journeys.cancel(j, "test"); b.journeys.active = None
    p2 = b.on_engage_req({"ped": 68, "model": joaat("A_F_M_ValTownfolk_01"), "outfit": 14, "male": 0, "human": 1, "alive": 1})
    b.game.peds[68] = {"h": 68, "d": 3, "alive": 1, "_t": time.time()}
    b.journeys.start(p2, {"kind": "person", "who": "my friend Lottie, she works at the saloon in Rhodes"}, guided=False)
    j = b.journeys.active
    rho = [x for x in db.places if x["kind"] == "saloon" and x.get("town") == "Rhodes"]
    check(j and j.place and j.place["kind"] == "saloon" and j.place.get("town") == "Rhodes",
          f"'the saloon in Rhodes' -> the Rhodes saloon ({j and j.place and j.place['name']})")
    near_door = any(abs(d["x"] - j.dest[0]) < 0.2 and abs(d["y"] - j.dest[1]) < 0.2 for d in db._load("doors", []))
    check(near_door, "...anchored at its real front door, not inside the walls")
    check(any("real saloon in Rhodes" in r for r in p2.last_results), "the NPC is told the real place to talk about it")


asyncio.run(main())
print(f"\n{ok} passed, {bad} failed")
sys.exit(1 if bad else 0)
