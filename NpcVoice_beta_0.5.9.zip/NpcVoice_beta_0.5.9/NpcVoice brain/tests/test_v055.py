"""0.5.5: your 18:28-18:35 log - Hans (a black worker) taken home at gunpoint to his shack in Lakay: a white family on
the ROOF, introductions while hogtied, kids who 'recognised' you, Maggie running while saying 'I'll come with you'."""
import asyncio, json, os, sys, tempfile, time
from pathlib import Path
from urllib.parse import unquote
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod, actions, context, surroundings
from npcvoice.brain import Brain
from npcvoice.game import hurt_text
from npcvoice.hashing import joaat
from npcvoice.llm import clean_transcript
from npcvoice.memory import MemoryStore
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0
def check(c, w):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + w); ok += c; bad += (not c)
class W:
    def __init__(self): self.lines = []
    def is_closing(self): return False
    def write(self, b): self.lines.append(unquote(b.decode()))
ROOT = Path(__file__).resolve().parents[1]
_sleep = asyncio.sleep
async def nosleep(t): await _sleep(0)


async def main():
    b = Brain(ROOT); b.cfg.fake_ai = True
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory; w = W(); b.asi.writer = w
    shack = next(p for p in b.db.places if p["kind"] == "shack")
    b.game.player = {"x": shack["x"] + 200, "y": shack["y"], "z": shack["z"], "cash": 5000}
    b.game.world = {"hr": 18, "mn": 30, "dow": 3}

    def person(ped, model, outfit, **st):
        c = b.on_engage_req({"ped": ped, "model": joaat(model), "outfit": outfit, "male": int("_M_" in model.upper()),
                             "human": 1, "alive": 1})
        b.game.peds[ped] = dict({"h": ped, "d": 2, "alive": 1, "_t": time.time(), "x": b.game.player["x"] + 2,
                                 "y": b.game.player["y"], "z": shack["z"]}, **st)
        b.after_tick()
        return c

    hans = person(229890, "A_M_M_AsbTownfolk_01", 5)
    hans.mark("threatened"); hans.flags["captive"] = True
    from npcvoice.journey import Journey
    j = Journey(hans, "family", "my family", "")
    j.place = dict(shack); j.dest = [shack["x"], shack["y"], shack["z"]]
    j.plan = {"place": "a shack", "members": [{"name": "Eliza", "sex": "female", "age": 34, "relation": "wife", "doing": "cooking"},
                                              {"name": "Samuel", "sex": "male", "age": 10, "relation": "son"},
                                              {"name": "Maggie", "sex": "female", "age": 17, "relation": "daughter"}]}
    j.state = "route"; b.journeys.active = j
    b.game.player.update(x=shack["x"] + 100)
    w.lines.clear()
    await b.journeys.tick()
    check(not any(l.startswith("probe ") for l in w.lines), "a real shack: no ground probe from 300 m up (it hit the roof)")
    spawns = [l for l in w.lines if l.startswith("spawn ") and " ped A_" in l or " ped U_" in l]
    check(spawns and all(",like=229890" in l and l.split()[-1].startswith("floor") for l in spawns),
          f"everyone at the shack: the ground under the door (never the roof) + the guide's skin ({[l.split()[-1][:30] for l in spawns]})")
    for seq in list(j.pending):
        b.journeys.on_spawned({"seq": seq, "h": 700 + seq % 100})
    wife = next(x for x in j.spawned if x.get("ident") and x["mem"]["relation"] == "wife")
    old_model, old_h, ident = wife["model"], wife["h"], wife["ident"]
    w.lines.clear()
    b.journeys.on_tone({"t": "tone", "ped": old_h, "ok": 0, "want": 5, "got": 3, "how": "no match"})
    check(any(l.startswith(f"despawn {old_h} delete") for l in w.lines) and any(l.startswith("spawn ") and old_model not in l for l in w.lines),
          "her model can't get his skin tone -> another model is tried (the family is rebuilt until it fits)")
    seq = next(iter(j.pending))
    b.journeys.on_spawned({"seq": seq, "h": 999})
    again = next(x for x in j.spawned if x.get("h") == 999)
    check(again["ident"] is ident and b.handle_ident.get(999) == ident.id, "...the same Eliza (name, memory), a new look")
    check(len([x for x in j.spawned if x.get("role") == "person"]) == 3, "...and no extra person")
    # arrival while he's a captive
    sit = b.journeys.situation(j)
    check("BY FORCE" in sit, f"arriving with him at gunpoint is not 'they seem to get along' ({sit[:60]})")
    # the kids never met you
    kid = next(x for x in j.spawned if x.get("child"))
    b.game.peds[kid["h"]] = {"h": kid["h"], "d": 3, "alive": 1, "_t": time.time()}
    kc = b.on_engage_req({"ped": kid["h"], "model": joaat(kid["model"]), "outfit": 0, "male": 1, "human": 1, "alive": 1})
    check(kc and not any(e[0] == "recognised" for e in kc.pending_events), "his son doesn't 'recognise' a man he never met")
    # the home event: no introductions under a gun
    b.end(kc, "test")
    hans = b.on_engage_req({"ped": 229890, "model": joaat("A_M_M_AsbTownfolk_01"), "outfit": 5, "male": 1, "human": 1, "alive": 1})
    hans.flags["captive"] = True; hans.mark("threatened"); j.conv = hans
    people = [x for x in j.spawned if x.get("ident")]
    said = []
    async def fake_say(ped, ident, text, emo, gesture=True):
        said.append((ped, text)); return 0.0
    b.say_line = fake_say
    async def no_turn(*a, **k): return None
    b.run_turn = no_turn
    asyncio.sleep = nosleep
    try:
        await b.journeys.play(j, people, {"lines": [], "reactions": {}})
    finally:
        asyncio.sleep = _sleep
    ev = next((e[1] for e in hans.pending_events if e[0] == "home"), "")
    check(ev and "BY FORCE" in ev and "Introduce" not in ev, f"dragged home: he fears for them, no introductions ({ev[:50]})")

    # Maggie: "I'll come with you" -> she comes (0.5.4 made her run)
    mag = person(517, "U_F_Y_CzPHomesteadDaughter_01", 9)
    mag.mark("threatened")
    reply = {"say": "Please, don't hurt my family! I-I'll come with you, just don't hurt them!", "end": True}
    ap, _ = actions.plan(["flee"], mag, b.game.ped(517), b.player_view())
    out = b.implied_follow(mag, "you're coming with me as my hostage", reply, ap, b.game.ped(517), b.player_view())
    check([a["name"] for a in out] == ["follow"] and not reply["end"], f"'I'll come with you' -> she follows, doesn't run ({[a['name'] for a in out]})")

    # the little things from the same log
    check(clean_transcript("MBC 뉴스 이덕영입니다. ... Stop right now! Hold it right there!") == "Stop right now! Hold it right there!",
          "a phantom Korean TV phrase from the mic is dropped")
    say = context.parse_reply(json.dumps({"say": "O-okay, I-I\u0001ll follow you. Please d-don\u000027t hurt me!"}))["say"]
    check("I'll" in say and "don't" in say, f"broken apostrophes repaired ({say})")
    check("lasso" in hurt_text({"hp": 150, "hpmax": 200}, {"armed": 1, "wpn": joaat("WEAPON_LASSO")}, {"hp": 160}) and
          "SHOT" not in hurt_text({"hp": 150, "hpmax": 200}, {"armed": 1, "wpn": joaat("WEAPON_LASSO")}, {"hp": 160}),
          "a lasso isn't 'SHOT you with his lasso'")
    g = person(600, "A_M_M_RhdTownfolk_01", 11)
    ap, notes = actions.plan(["lead_to", {"kind": "couple", "who": "my wife Martha"}], g, b.game.ped(600), b.player_view())
    check(ap and ap[0]["name"] == "lead_to" and ap[0]["args"].get("kind") == "couple" and not notes,
          "['lead_to', {args}] -> the args belong to lead_to (the couple trip was lost)")
    calm = person(601, "A_F_M_RhdTownfolk_01", 12)
    out = b.implied_love(calm, "come to bed with me", {"say": "I'll call the sheriff if you say that again!"}, [],
                         b.game.ped(601), b.player_view())
    check(not out, "'I'll call the sheriff' is not a yes")

    # Fred (18:39): narration in his line, and the place he named never got a line on your map
    fred_raw = json.dumps({"say": "Fred backed away nervously, his eyes darting around. \"Son of a bitch... Ain't you heard? "
                                  "The wife-swappers are over at Sweetwater, at the manor by the pond.\"", "actions": []})
    r = context.parse_reply(fred_raw)
    check(r["say"].startswith("Son of a bitch") and "backed away" not in r["say"], f"no narration read out loud ({r['say'][:40]})")
    b.journeys.active = None
    fred = person(318730, "A_M_M_RhdTownfolk_01", 13)
    fred.transcript.append("Player: I'm looking for a cuckold couple, where can I find one?")
    out = b.implied_mark(fred, "I'm looking for a cuckold couple, where can I find one?", r, [], b.game.ped(318730), b.player_view())
    check(out and out[-1]["name"] == "mark_person" and out[-1]["args"]["kind"] == "couple",
          "he names the place -> it's marked on your map, as a COUPLE")
    w.lines.clear(); b.execute(fred, out[-1])
    check(any(l.startswith("route ") for l in w.lines) and b.journeys.active and b.journeys.active.kind == "couple",
          "...the yellow line is there and the couple will be waiting")
    out = b.implied_mark(fred, "where's the saloon?", {"say": "I ain't telling you nothing."}, [], b.game.ped(318730), b.player_view())
    check(not out, "no place named -> nothing marked")

    # why Fred/Elijah narrated: "cuckold" sent the question to the storytelling model (MythoMax, 4k context)
    from npcvoice import safety
    el = person(335372, "A_M_M_RhdTownfolk_01", 14)
    v = safety.check_turn("I'm looking for a cuckold couple, do you know one?", el, b.game.ped(335372))
    check(not v.explicit_route, "asking WHERE a cuckold couple lives stays on the reliable model (answers + marks the map)")
    v = safety.check_turn("take your clothes off and come to bed with me", el, b.game.ped(335372))
    check(v.explicit_route, "an intimate moment still goes to the uncensored model")
    full = context.system_prompt(el, b.game)
    small = context.system_prompt(el, b.game, compact=True)
    check(len(small) < len(full) - 1500 and "make_love" in small, f"...with a short prompt it can follow ({len(full)} -> {len(small)} chars)")
    from npcvoice.llm import EXPLICIT_LLM_PRIORITY
    check(EXPLICIT_LLM_PRIORITY[0]["model"] != "gryphe/mythomax-l2-13b", "MythoMax is no longer the first choice")
    check(context.strip_narration('Elijah squints at him, his gut twisting. "You mean a husband and wife? Ain\'t no such thing here.', "Elijah")
          == "You mean a husband and wife? Ain't no such thing here.", "his narration about himself is cut, his words stay")

    # Henry and Clara (18:49): "Clara, come on over here" -> she comes; talking to her doesn't send him away
    hen = person(310033, "A_M_M_RhdTownfolk_01", 20)
    clara_near = {"h": 66064, "m": joaat("A_F_M_RhdTownfolk_01"), "o": 21, "male": 0, "alive": 1, "d": 4, "de": 3, "los": 1}
    b.game.near_peds = [clara_near]
    context.system_prompt(hen, b.game)
    cname = surroundings.relation(hen, clara_near, b.peddb.classify(clara_near["m"], False), b.game.place(), b.memory)["name"].split()[0]
    out = b.implied_call(hen, {"say": f"{cname}, come on over here."}, [], b.game.ped(310033), b.player_view())
    check(out and out[0]["name"] == "call_over" and ("on", 66064, "goto_player", 1.2, 1.4, "t=310033") in out[0]["prims"],
          "'Clara, come on over here' -> Clara walks over to him")
    clara = person(66064, "A_F_M_RhdTownfolk_01", 21)
    clara.ident.d.setdefault("relations", {})[f"id:{hen.ident.id}"] = {"rel": "your husband"}
    b.convs.pop(310033, None); hen.ended = False; b.convs[310033] = hen
    b.on_engage_req({"ped": 66064, "model": joaat("A_F_M_RhdTownfolk_01"), "outfit": 21, "male": 0, "human": 1, "alive": 1})
    check(not hen.ended, "talking to his wife doesn't end his conversation (he doesn't walk off)")
    lone = person(777, "A_F_M_RhdTownfolk_01", 22)
    check(hen.ended, "...but turning to a stranger does")
    # she was told why you came
    i2 = b.memory.create(joaat("A_F_M_RhdTownfolk_01"), 23, b.peddb.classify(joaat("A_F_M_RhdTownfolk_01"), False), "x", 0)
    i2.d["on_meet"] = ["The stranger Fred told you about is HERE."]
    b.handle_ident[888] = i2.id
    b.game.peds[888] = {"h": 888, "d": 2, "alive": 1, "_t": time.time()}
    c8 = b.on_engage_req({"ped": 888, "model": joaat("A_F_M_RhdTownfolk_01"), "outfit": 23, "male": 0, "human": 1, "alive": 1})
    check(any(e[0] == "expected" for e in c8.pending_events), "the wife knows why you came the first time you talk to her")
    # in the middle of it: words yes, body stays
    c8.flags["in_scene"] = True
    ap, notes = actions.plan(["dance", "wave"], c8, b.game.ped(888), b.player_view())
    check(all(not a["prims"] for a in ap), "in a love scene a 'dance'/'wave' doesn't cancel the animation")

    # "Clara, run!" -> she runs; and the dead never speak (Clara answered after she was shot)
    out = b.implied_call(hen, {"say": f"{cname}, run! Get out of here!"}, [], b.game.ped(310033), b.player_view())
    check(out and out[0]["name"] == "order_person" and ("on", 66064, "flee", 80) in out[0]["prims"],
          "'Clara, run!' -> she runs")
    hen2 = person(4242, "A_M_M_RhdTownfolk_01", 30)
    wife_near = {"h": 4343, "m": joaat("A_F_M_RhdTownfolk_01"), "o": 31, "male": 0, "alive": 1, "d": 3, "de": 1.0, "los": 1}
    b.game.near_peds = [wife_near]
    context.system_prompt(hen2, b.game)
    wife_near["alive"] = 0                       # you shot her first
    said.clear()
    hen2.mark("hurt_by_player")
    b.drama.on_kin_killed(hen2, True)
    await _sleep(0.05)
    check(not any(p == 4343 for p, _ in said) and not b.drama.kin_of(hen2), "a dead wife never 'reacts' or speaks again")

    # Elijah (18:57): "Couple? You mean Bob and Mary?" + lead_to without a kind -> he took you to HIS family
    b.journeys.active = None
    eli = person(197130, "A_M_M_RhdTownfolk_01", 40)
    eli.transcript += ["Player: I'm looking for a cuckold couple, take me to them", "Elijah: Couple? You mean Bob and Mary?"]
    b.journeys.start(eli, {"who": "Bob and Mary"})
    check(b.journeys.active and b.journeys.active.kind == "couple", f"'Bob and Mary' the couple -> a COUPLE trip ({b.journeys.active and b.journeys.active.kind})")
    b.journeys.active = None
    eli.transcript += ["Player: take me home to your wife and kids", "Elijah: Fine."]
    b.journeys.start(eli, {"who": "my wife and kids"})
    check(b.journeys.active and b.journeys.active.kind == "family", "'my wife and kids' -> his family")
    b.journeys.active = None
    eli.transcript += ["Player: who knows about the gold?", "Elijah: Old Silas does."]
    b.journeys.start(eli, {"who": "Old Silas, the prospector"})
    check(b.journeys.active and b.journeys.active.kind == "person", "'Old Silas' -> a trip to that person, not to his family")

    # 0.5.6: TYPE_INSTEAD_OF_VOICE - hold X, type, Enter: no microphone; Esc: nothing happens
    typer = person(5050, "A_M_M_RhdTownfolk_01", 50)
    got = []
    async def fake_turn(conv, wav=None, text=None, reaction=False):
        got.append((conv.ped, wav, text))
    b.run_turn = fake_turn
    started = []
    b.rec.start = lambda: started.append(1) or True
    await b.on_ptt({"ped": 5050, "down": True, "typed": 1})
    await b.on_ptt({"ped": 5050, "down": False, "text": "Evening. Where can I get a drink?"})
    await _sleep(0.01)
    check(not started and got and got[-1] == (5050, None, "Evening. Where can I get a drink?"),
          "typed line -> straight to the person, the microphone is never opened")
    got.clear()
    await b.on_ptt({"ped": 5050, "down": True, "typed": 1})
    await b.on_ptt({"ped": 5050, "down": False, "cancel": True})
    await _sleep(0.01)
    check(not got and b.ptt_ped == 0, "Esc -> nothing is said, you're not stuck 'talking'")
    # the prompt only lists what can happen right now
    walker = person(5151, "A_M_M_RhdTownfolk_01", 51)
    sp = context.system_prompt(walker, b.game)
    check("drive_on" not in sp and "dismount" not in sp and "leave_vehicle" not in sp,
          "someone on foot isn't offered wagon-driving / dismount / get-off-the-wagon (shorter prompt)")
    b.game.peds[5151].update(veh=1, drv=1, _t=time.time())
    sp = context.system_prompt(walker, b.game)
    check("drive_on" in sp and "leave_vehicle" in sp, "...a wagon driver is")


asyncio.run(main())
print(f"\n{ok} passed, {bad} failed")
sys.exit(1 if bad else 0)
