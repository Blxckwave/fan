"""0.3.2: orders that stick (dismount / ride with me + money), report to the law, a real stash."""
import asyncio, os, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod, actions
from npcvoice.brain import Brain
from npcvoice.hashing import joaat
from npcvoice.memory import MemoryStore
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0
def check(c, w):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + w); ok += c; bad += (not c)
class W:
    def __init__(self): self.lines = []
    def is_closing(self): return False
    def write(self, b): self.lines.append(b.decode())


async def main():
    b = Brain(Path(__file__).resolve().parents[1]); b.cfg.fake_ai = True
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory; w = W(); b.asi.writer = w
    b.game.player = {"x": 0, "y": 0, "z": 0, "mounted": 1, "cash": 5000}
    woman = {"ped": 40, "model": joaat("A_F_M_ValTownfolk_01"), "outfit": 4, "male": 0, "human": 1, "alive": 1}
    b.game.peds[40] = {"h": 40, "d": 2, "alive": 1, "x": 2, "y": 0, "_t": time.time()}
    conv = b.on_engage_req(woman)
    conv.ident.persona["cash"] = 20.0

    # the 0.3.1 bug: "she gave me money but never got on the horse" - the coin emote replaced the mount task
    ap, notes = actions.plan(["ride_with_me", {"name": "give_money", "args": {"amount": 5}}], conv, b.game.ped(40), b.player_view())
    names = [a["name"] for a in ap]
    gm = next(a for a in ap if a["name"] == "give_money")
    check(names == ["ride_with_me", "give_money"], f"ride_with_me + give_money both approved ({names}, {notes})")
    check(("money", 500) in gm["prims"] and not any(p[0] == "emote" for p in gm["prims"]),
          f"the money is paid but no coin emote on top of the mount ({gm['prims']})")
    check(any("without the gesture" in n for n in notes), "the AI is told the gesture was skipped")

    # dismount + nod: nothing on top of the dismount
    b.game.peds[40]["mounted"] = 1
    ap, notes = actions.plan(["dismount", "nod"], conv, b.game.ped(40), b.player_view())
    check([a["name"] for a in ap] == ["dismount", "nod"] and not ap[1]["prims"], "dismount + nod: the nod is dropped")
    # stop following while riding with you -> gets off
    ap, _ = actions.plan(["stop_following"], conv, b.game.ped(40), b.player_view())
    check(("dismount",) in ap[0]["prims"], f"'you're free' while on your horse -> she gets off ({ap[0]['prims']})")
    b.game.peds[40]["mounted"] = 0

    # report to the law: a lawman within the scan -> she runs to HIM
    law_m = joaat("S_M_M_ValDeputy_01")
    cls = b.peddb.classify(law_m, True)
    if cls.get("role") != "lawman":
        law_m = next((int(k) for k, v in b.peddb.db.items() if v.get("role") == "lawman"), law_m) if hasattr(b.peddb, "db") else law_m
    b.game.near_peds = [{"h": 77, "m": law_m, "male": 1, "alive": 1, "d": 18, "x": 18, "y": 0}]
    check(b.law.nearest_lawman({40}) == 77 or b.peddb.classify(law_m, True).get("role") != "lawman",
          f"lawman found in the nearby scan (role={b.peddb.classify(law_m, True).get('role')})")
    pv = b.player_view(); pv["lawman"] = b.law.nearest_lawman({40})
    ap, notes = actions.plan([{"name": "report_to_law", "args": {"crime": "robbery", "what": "he robbed me"}}],
                             conv, b.game.ped(40), pv)
    check(ap and ("goto_player", 1.6, 2.0, f"t={pv['lawman']}") in ap[0]["prims"], f"report_to_law -> runs to the lawman ({ap[0]['prims'] if ap else notes})")
    check(ap and ap[0]["act"].ends, "...and the conversation ends (she's gone to him)")
    # no lawman: walks off, the town hears of it (heat) -> lawmen question you later
    pv["lawman"] = 0
    ap, _ = actions.plan([{"name": "report_to_law", "args": {"crime": "murder", "what": "he shot Bill"}}], conv, b.game.ped(40), pv)
    check(("wander",) in ap[0]["prims"], "no lawman around -> she heads off (to the sheriff)")
    b.execute(conv, ap[0])
    from npcvoice import world
    check(world.heat(b.memory, b.game.place(), b.game.game_minutes_total) >= 3, "the report is a witnessed deed: lawmen here will come for you")
    # only the law can arrest; the law can't report itself
    check("arrest" not in actions.catalog_text(False) and "arrest" in actions.catalog_text(False, law=True), "only lawmen get 'arrest'")
    lconv = b.on_engage_req({"ped": 77, "model": law_m, "outfit": 9, "male": 1, "human": 1, "alive": 1})
    b.game.peds[77] = {"h": 77, "d": 3, "alive": 1, "_t": time.time()}
    if lconv and lconv.flags.get("is_law"):
        ap, notes = actions.plan([{"name": "arrest", "args": {"crime": "robbery"}}], lconv, b.game.ped(77), b.player_view())
        check(ap and ("crime", "CRIME_ROBBERY", 0) in ap[0]["prims"], f"arrest -> the crime goes to the game's law ({ap[0]['prims'] if ap else notes})")
        w.lines.clear(); b.execute(lconv, ap[0])
        check(any(l.startswith("crime ") and "CRIME_ROBBERY" in l and l.strip().endswith(" 77") for l in w.lines),
              f"crime command sent with the lawman as witness ({[l for l in w.lines if l.startswith('crime')]})")
    else:
        check(False, "lawman conversation flagged is_law")

    # a REAL stash: marked on the map, money when you reach the box
    b.journeys.active = None
    conv2 = b.on_engage_req({"ped": 41, "model": joaat("A_M_M_ValFarmer_01"), "outfit": 5, "male": 1, "human": 1, "alive": 1})
    b.game.peds[41] = {"h": 41, "d": 2, "alive": 1, "_t": time.time()}
    ap, notes = actions.plan([{"name": "mark_stash", "args": {"what": "my pa's strongbox", "dollars": 60}}], conv2, b.game.ped(41), b.player_view())
    w.lines.clear(); b.execute(conv2, ap[0])
    j = b.journeys.active
    check(j and j.kind == "stash" and not j.guided and j.plan.get("dollars") == 60, f"mark_stash -> a stash journey, $60 ({j and j.plan})")
    check(any(l.startswith("route ") for l in w.lines), "yellow line on the map")
    d = (j.dest[0] ** 2 + j.dest[1] ** 2) ** 0.5
    check(240 <= d <= 910, f"close enough to ride to ({d:.0f} m)")
    check(not conv2.companion, "he doesn't come along (you go alone)")
    # pretend you rode there and the box got spawned
    j.state = "spawned"; j.spawned = [{"role": "loot", "x": j.dest[0], "y": j.dest[1], "z": 0, "h": 9001}]
    b.game.player.update({"x": j.dest[0] - 20, "y": j.dest[1]})
    await b.journeys.tick()
    check(j.state == "looting" and any(l.startswith("route_clear") for l in w.lines), "arrive -> the line disappears")
    w.lines.clear()
    b.game.player.update({"x": j.dest[0] - 1.0, "y": j.dest[1]})
    await b.journeys.tick()
    check(any(l.startswith("money ") and l.strip().endswith(" 6000") for l in w.lines), f"walk up to the box -> $60 in your pocket ({w.lines})")
    check(j.state == "arrived", "stash done")


asyncio.run(main())
print(f"\n{ok} passed, {bad} failed")
sys.exit(1 if bad else 0)
