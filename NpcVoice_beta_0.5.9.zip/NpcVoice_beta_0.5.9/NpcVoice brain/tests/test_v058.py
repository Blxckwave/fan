"""0.5.8 - from your game after 0.5.7:
  The woman said her husband was nearby, then told a story of her husband being killed -> facts about your own people.
  You killed her; her husband, far away behind a wall, talked about her death -> people only know what they see / hear.
  She begged for her life with "I know a place" and the yellow line moved -> a trip that's on stays on.
  The house couple at night: dressed, standing, never noticed you -> the scene always starts (bed or floor), NpcHookups'
  own way (attached, pos=1..3), and a stranger inside their house is noticed.
  The old couple kept chatting after you shot one -> alarm: everything stops, the other one reacts.
  A couple doing it in the saloon next to people -> never in front of onlookers; a couple's home is a home.
  Every line calm and the same -> the voice follows the words and the moment."""
import asyncio, os, sys, tempfile, time, types
from pathlib import Path
from urllib.parse import unquote
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod, actions, context, surroundings, llm
from npcvoice import household as H
from npcvoice.brain import Brain
from npcvoice.conversation import Conversation
from npcvoice.hashing import joaat
from npcvoice.memory import MemoryStore
from npcvoice.perception import weapon_is_loud
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0


def check(c, w):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + w); ok += c; bad += (not c)


ROOT = Path(__file__).resolve().parents[1]
_sleep = asyncio.sleep
async def nosleep(t=0, *a): await _sleep(0)
H.asyncio = types.SimpleNamespace(**{k: getattr(asyncio, k) for k in dir(asyncio) if not k.startswith("__")})
H.asyncio.sleep = nosleep
HOUSE = "lak_loveshack_int"


class W:
    def __init__(self): self.lines = []
    def is_closing(self): return False
    def write(self, b): self.lines.append(unquote(b.decode().strip()))


class Plugin(W):
    def __init__(self, b, place, beds=True):
        super().__init__()
        self.b, self.place, self.h, self.beds = b, place, 6000, beds
        b.asi_info = {"caps": ["home_scan", "use_point", "couple_pose", "nh_pos", "undress_wait"]}

    def write(self, raw):
        line = unquote(raw.decode().strip()); self.lines.append(line); tok = line.split(" ")
        loop = asyncio.get_running_loop()
        if tok[0] == "spawn":
            self.h += 1
            loop.call_soon(self.b.couples.on_spawned, {"seq": int(tok[1]), "h": self.h})
            self.b.game.peds[self.h] = {"h": self.h, "alive": 1, "x": float(tok[4]), "y": float(tok[5]), "z": float(tok[6]),
                                        "d": 30.0, "los": 0, "hp": 150, "_t": time.time()}
        elif tok[0] == "find_bed" and self.beds:
            loop.call_soon(self.b.couples.on_bed, {"seq": int(tok[1]), "ok": 1, "x": self.place["x"] + 2.4,
                                                   "y": self.place["y"] + 3, "z": self.place["z"], "hd": 90, "src": "object"})
        elif tok[0] == "home_scan":
            loop.call_soon(self.b.households.on_home, {"seq": int(tok[1]), "pts": []})


def fresh():
    b = Brain(ROOT); b.cfg.fake_ai = True; b.cfg.households = False
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory
    surroundings.NAMES.clear(); surroundings.PAIRS.clear()
    return b


async def households_part():
    for beds in (True, False):
        b = fresh(); b.cfg.households = True; b.cfg.pose_seconds = 0.05
        tmp = Path(tempfile.mkdtemp())
        b.households.path = tmp / "households.json"; b.households.data = {"version": 1, "homes": {}}
        place = next(p for p in b.db.places if p["name"] == HOUSE)
        plug = Plugin(b, place, beds); b.asi.writer = plug
        hh = b.households
        said = []
        async def fake_say(ped, ident, text, emo, gesture=True):
            said.append((ped, text, emo)); return 0.0
        b.say_line = fake_say
        turns = []
        async def fake_turn(conv, reaction=False, **k):
            turns.append(conv)
        b.run_turn = fake_turn

        def at(hr, mn=0, dow=3, dist=40.0):
            b.game.world = {"hr": hr, "mn": mn, "dow": dow}
            b.game.player = {"x": place["x"] + dist, "y": place["y"], "z": place["z"], "crouch": 0}
            for p in b.game.peds.values():
                p["d"] = dist

        async def tick(n=1):
            for _ in range(n):
                await hh.tick()
                for _ in range(5):
                    await _sleep(0)

        at(10, 0)
        await tick(2)
        lv = hh.live.get(HOUSE)
        rec = hh.data["homes"][HOUSE]
        start, _ = H.love_window(rec["seed"], 3)
        n0 = len(plug.lines)
        at(int(start), int(round((start % 1) * 60)) + 5)
        await tick(2)
        cpl = [l for l in plug.lines[n0:] if l.startswith("couple ")]
        if beds:
            check(lv["love"].get("on") and cpl and "pos=" in cpl[0], f"the night starts NpcHookups' way: {cpl[:1]}")
            mine = {str(lv["a"]["h"]), str(lv["b"]["h"])}
            check(len([l for l in plug.lines[n0:] if " undress" in l and l.split(" ")[2] in mine]) == 2, "both are undressed (the plugin waits until "
                                                                              "they're streamed in)")
            # ── shot: everything stops at once and the other one reacts ──
            a, bb = lv["a"]["h"], lv["b"]["h"]
            b.game.peds[bb].update(d=5, los=1, x=place["x"] + 2, y=place["y"] + 2)
            b.speaking = {"ped": a, "until": time.time() + 5}
            stopped = []
            b.voice.stop = lambda: stopped.append(1)
            b.game.peds[a]["alive"] = 0
            n1 = len(plug.lines)
            await tick(1)
            check(lv.get("alarm") and lv.get("widowed"), "one of them shot dead -> the house is in alarm")
            check(any(l.startswith("couple_stop ") for l in plug.lines[n1:]), "...the scene stops at once")
            check(stopped, "...the line in their mouth is cut off")
            await _sleep(0); await _sleep(0); await _sleep(0)
            conv = b.convs.get(bb)
            ev = [e for e in (conv.pending_events if conv else []) if e[0] == "home_alarm"]
            check(conv and ev and "SHOT" in ev[0][1] and "DEAD" in ev[0][1], f"...the survivor saw it and reacts: {ev[0][1][:80] if ev else '-'}")
            check(turns and turns[-1] is conv, "...right away (a reaction turn)")
            nsaid = len(said)
            lv["next_chat"] = 0
            await tick(2)
            check(len(said) == nsaid, "no more calm chatting after a killing")
        else:
            check(lv["love"].get("on") and cpl, "no bed found in time -> still their night (a blanket on the floor), "
                                                "never two dressed people standing there")
            # ── a stranger inside their house by day ──
            at(10, 30)
            lv["love"]["on"] = False
            await tick(1)
            a = lv["a"]["h"]
            at(10, 35, dist=2.0)
            b.game.peds[a].update(d=3.0, los=1, x=place["x"] + 1.0, y=place["y"])     # inside, sweeping
            b.game.peds[lv["b"]["h"]].update(x=place["x"] + 9, y=place["y"] + 9, los=0, d=12)   # out in the yard
            await tick(1)
            await _sleep(0)
            conv = b.convs.get(a) or b.convs.get(lv["b"]["h"])
            ev = [e for e in (conv.pending_events if conv else []) if e[0] == "intruder"]
            check(lv.get("intruded") and ev, "you walk into their house -> they notice you and speak up")
            check(conv and conv.ped == a, "...the one inside notices, not the one out in the yard")


async def perception_part():
    b = fresh(); b.asi.writer = W()
    gun, knife = joaat("WEAPON_REVOLVER_CATTLEMAN"), joaat("WEAPON_MELEE_KNIFE")
    check(weapon_is_loud(b, gun) and not weapon_is_loud(b, knife), "a revolver is loud, a knife is not")
    P = b.perception
    b.game.player = {"x": 0, "y": 0, "z": 0, "wpn": gun}
    r = P.death_guess(1, 2, {"de": 80, "elos": 0}, gun)
    check(not r["saw"] and r["heard"] == "shot", f"behind a wall 80 m away, a gun: he heard a shot, saw nothing ({r})")
    r = P.death_guess(1, 2, {"de": 80, "elos": 0}, knife)
    check(not r["saw"] and not r["heard"], "behind a wall, a knife: he knows nothing")
    r = P.death_guess(1, 2, {"de": 12, "elos": 1}, gun)
    check(r["saw"], "12 m, in sight: he saw it")
    r = P.death_guess(1, 2, {"de": 400, "elos": 0}, gun)
    check(not r["saw"] and not r["heard"], "400 m away: nothing")

    # the man you talk to; you kill someone far off behind a wall, with a gun / a knife
    V = joaat("Valentine"); cot = joaat("A_M_M_ValFarmer_01")
    b.game.on_tick({"p": {"x": 0, "y": 0, "z": 0, "wpn": gun}, "w": {"town": V}, "peds": [{"h": 20, "d": 3, "alive": 1}]},
                   b.memory.player)
    man = b.memory.create(cot, 1, b.peddb.classify(cot, True), "Valentine", 0)
    conv = Conversation(20, man, b.peddb.classify(cot, True)); conv.engaged_ok = True; b.convs[20] = conv
    wife = {"h": 91, "d": 5, "de": 78, "m": joaat("A_F_M_ValTownfolk_01"), "o": 2, "male": 0, "alive": 1, "elos": 0}
    b.on_nearby({"eng": 20, "peds": [wife]})
    conv.pending_events.clear()
    b.on_nearby({"eng": 20, "peds": [dict(wife, alive=0, kp=1)]})
    kinds = [e[0] for e in conv.pending_events]
    check("new_body" not in kinds and "heard_shot" in kinds, f"far away behind a wall: only the shot, not her death ({kinds})")
    txt = " ".join(e[1] for e in conv.pending_events)
    check("never say anyone is dead" in txt and "KILLED" not in txt, "...and he's told he doesn't know who was hit")
    check(not any("killed" in e["what"] for e in man.d.get("events", [])), "...he doesn't 'remember' a killing he never saw")
    b.game.player["wpn"] = knife
    other = dict(wife, h=92, o=3)
    b.on_nearby({"eng": 20, "peds": [dict(wife, alive=0, kp=1), other]})
    conv.pending_events.clear()
    b.on_nearby({"eng": 20, "peds": [dict(wife, alive=0, kp=1), dict(other, alive=0, kp=1)]})
    check(not conv.pending_events, "a knife, far away, out of sight: nothing at all")


async def facts_part():
    b = fresh(); b.asi.writer = W()
    V = joaat("Valentine"); m = joaat("A_F_M_ValTownfolk_01")
    b.game.on_tick({"p": {"x": 0, "y": 0, "z": 0}, "w": {"town": V}, "peds": [{"h": 30, "d": 3, "alive": 1}]}, b.memory.player)
    she = b.memory.create(m, 7, b.peddb.classify(m, False), "Valentine", 0)
    she.persona["family"] = "married, 2 children at home"
    conv = Conversation(30, she, b.peddb.classify(m, False)); conv.engaged_ok = True; b.convs[30] = conv
    hub = {"h": 31, "d": 4, "de": 1.0, "m": joaat("A_M_M_ValTownfolk_01"), "o": 5, "male": 1, "alive": 1, "elos": 1}
    b.game.near_peds = [hub]
    sp = context.system_prompt(conv, b.game)
    check("FACTS ABOUT YOUR OWN PEOPLE" in sp and "is ALIVE and right here" in sp and "Never tell a story" in sp,
          "her husband next to her: 'ALIVE and right here - never a story of him dying'")
    b.note_told_facts(conv, "My husband Earl works the mill. We got two girls.")
    sp = context.system_prompt(conv, b.game)
    check("My husband Earl works the mill" in sp, "what she told you about her family comes back to her (consistent)")
    # a widow on a wagon seat beside a man: he's not her (late) husband
    surroundings.NAMES.clear(); surroundings.PAIRS.clear()
    w2 = b.memory.create(m, 8, b.peddb.classify(m, False), "Valentine", 0)
    w2.persona["family"] = "widowed"
    c2 = Conversation(32, w2, b.peddb.classify(m, False)); c2.engaged_ok = True
    r = surroundings.relation(c2, dict(hub, h=33, o=6), b.peddb.classify(hub["m"], True), "Valentine", b.memory)
    check(r["rel"] not in ("your husband",), f"a widow's companion is not her husband ({r['rel']})")


async def trips_part():
    b = fresh(); w = W(); b.asi.writer = w
    V = joaat("Valentine"); m = joaat("A_F_M_ValTownfolk_01")
    b.game.on_tick({"p": {"x": -300, "y": 800, "z": 100}, "w": {"town": V}, "peds": [{"h": 40, "d": 3, "alive": 1}]}, b.memory.player)
    b.game.player = {"x": -300, "y": 800, "z": 100}
    she = b.memory.create(m, 9, b.peddb.classify(m, False), "Valentine", 0)
    conv = Conversation(40, she, b.peddb.classify(m, False)); conv.engaged_ok = True; b.convs[40] = conv
    b.journeys.start(conv, {"kind": "family", "who": "my sister"})
    j = b.journeys.active
    check(j and j.state == "route", "a trip to her sister is on")
    dest = list(j.dest)
    ap, _ = actions.plan([{"name": "lead_to", "args": {"kind": "place", "who": "a place I know"}}], conv, b.game.ped(40), b.player_view())
    ap = b.trip_guard(conv, "please don't kill me", ap)
    check(not any(a["name"] == "lead_to" for a in ap), "begging, 'I know a place': no new trip")
    check(b.journeys.active is j and list(j.dest) == dest, "...the yellow line stays where it was")
    check(any("already on the way" in r for r in conv.last_results), "...and she's told there's no new place")
    # a couple's home is a home, even when they talked about the saloon
    import random
    for i in range(5):
        p = b.db.pick_destination(-300, 800, "they drink at the saloon in Valentine", ["house"], 200, 900, random.Random(i),
                                  only=["house", "cabin", "farmhouse", "shack", "mansion"])
        if p and p["kind"] not in ("house", "cabin", "farmhouse", "shack", "mansion"):
            check(False, f"a couple's place was a {p['kind']}"); break
    else:
        check(True, "a couple's place is always a home (never the saloon they talked about)")


async def love_public_part():
    b = fresh(); w = W(); b.asi.writer = w
    V = joaat("Valentine"); m = joaat("A_F_M_ValTownfolk_01")
    b.game.on_tick({"p": {"x": 0, "y": 0, "z": 0}, "w": {"town": V},
                    "peds": [{"h": 50, "d": 2, "alive": 1, "x": 1, "y": 0, "z": 0}]}, b.memory.player)
    b.game.peds[50].update(x=1, y=0, z=0, _t=time.time())
    she = b.memory.create(m, 11, b.peddb.classify(m, False), "Valentine", 0)
    conv = Conversation(50, she, b.peddb.classify(m, False)); conv.engaged_ok = True; b.convs[50] = conv
    conv.flags["bed"] = {"x": 1, "y": 1, "z": 0, "hd": 0, "src": "object"}
    b.game.near_peds = [{"h": 60, "d": 4, "x": 3, "y": 1, "z": 0, "alive": 1, "los": 1},
                        {"h": 61, "d": 5, "x": 4, "y": -1, "z": 0, "alive": 1, "los": 1}]
    ap, _ = actions.plan([{"name": "make_love", "args": {"with": "me"}}], conv, b.game.ped(50), b.player_view())
    if ap:
        b.execute(conv, ap[0])
    check(not any(l.startswith(("couple ", "hk_start ")) for l in w.lines), "two people watching in the saloon: no scene")
    check(any("NOT HERE" in r for r in conv.last_results), "...she's told: not here, somewhere private")
    b.game.near_peds = []
    w.lines.clear()
    ap, _ = actions.plan([{"name": "make_love", "args": {"with": "me"}}], conv, b.game.ped(50), b.player_view())
    if ap:
        b.execute(conv, ap[0])
    c = [l for l in w.lines if l.startswith("couple ")]
    b.asi_info = {"caps": ["nh_pos"]}
    check(c, "alone, on her bed: it happens")


async def voice_part():
    check(llm.tts_style("terrified")[0] == "fearful" and llm.tts_style("passionate")[0] == "", "voice styles: terrified -> "
                                                                                                "fearful, passionate -> from the words")
    r = context.parse_reply('{"say": "Please, mister, I got kids!", "emotion": "terrified"}')
    check(r["emotion"] == "terrified", "the AI's own word for the feeling is kept (0.5.7: forced to 'fluent')")
    r = context.parse_reply('{"say": "Hm.", "emotion": "zzzz"}')
    check(r["emotion"] == "", "an unknown word: no emotion forced - the voice reads it from the words")
    sent = []
    p = llm.Providers.__new__(llm.Providers)
    p._call = lambda svc, path, json_body=None, timeout=0, entries=None: sent.append(json_body) or {"data": {"audio": "00"}}
    p._tts("Oh God, yes", "v1", "passionate", 0, 1.0, [])
    p._tts("Don't shoot!", "v1", "terrified", 0, 1.0, [])
    vs0, vs1 = sent[0]["voice_setting"], sent[1]["voice_setting"]
    check("emotion" not in vs0 and vs0["speed"] > 1.0, f"passionate: no flat emotion forced, a little faster ({vs0})")
    check(vs1.get("emotion") == "fearful" and vs1["speed"] > 1.1, f"terrified: fearful and fast ({vs1})")
    b = fresh(); b.asi.writer = W()
    m = joaat("A_F_M_ValTownfolk_01")
    she = b.memory.create(m, 12, b.peddb.classify(m, False), "Valentine", 0)
    conv = Conversation(70, she, b.peddb.classify(m, False))
    conv.flags["in_scene"] = True
    check(b.real_emotion(conv, "calm")[0] == "passionate", "in the middle of making love nobody sounds 'calm'")
    conv.flags["in_scene"] = False
    she.persona["bravery"] = 0.2
    conv.mark("hurt_by_player")
    check(b.real_emotion(conv, "calm")[0] == "fearful", "just hurt and timid: she sounds afraid, not calm")


async def main():
    await households_part()
    await perception_part()
    await facts_part()
    await trips_part()
    await love_public_part()
    await voice_part()
    print(f"\n{ok} passed, {bad} failed")
    sys.exit(1 if bad else 0)

asyncio.run(main())
