"""Bodies: carried, on the horse, lying around, known victims, dead people not 'recognised' alive."""
import asyncio, os, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod, context
from npcvoice.brain import Brain
from npcvoice.conversation import Conversation
from npcvoice.hashing import joaat
from npcvoice.memory import MemoryStore
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0
def check(c, w):
    global ok, bad
    print(("PASS " if c else "FAIL ") + w); ok += bool(c); bad += (not c)

class W:
    def __init__(self): self.lines = []
    def is_closing(self): return False
    def write(self, b): self.lines.append(b.decode())

async def main():
    b = Brain(Path(__file__).resolve().parents[1]); b.cfg.fake_ai = True
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory; b.asi.writer = W()
    V = joaat("Valentine")
    b.game.on_tick({"p": {"x": 0, "y": 0, "z": 0}, "w": {"town": V}, "peds": []}, b.memory.player)
    m1 = joaat("A_F_M_ValTownfolk_01"); m2 = joaat("A_M_M_ValTownfolk_01")
    martha = b.memory.create(m1, 0xAAAA, b.peddb.classify(m1, False), "Valentine", 0)      # someone you met
    listener = b.memory.create(m2, 0xBBBB, b.peddb.classify(m2, True), "Valentine", 0)
    conv = Conversation(10, listener, b.peddb.classify(m2, True)); conv.engaged_ok = True; b.convs[10] = conv
    tick = lambda p: b.game.on_tick({"p": p, "w": {"town": V}, "peds": [{"h": 10, "d": 3, "alive": 1, "x": 3, "y": 0, "z": 0}]}, b.memory.player)
    tick({"x": 0, "y": 0, "z": 0, "c": 1, "cdead": 1, "cmdl": m1, "coft": 0xAAAA, "ch": 55})
    sp = context.system_prompt(conv, b.game)
    check("DEAD BODY over his shoulder" in sp, "prompt: body on the shoulder")
    check(martha.persona["name"] in sp and "KNOW from town" in sp, f"prompt: knows who it is ({martha.persona['name']}, same town)")
    tick({"x": 0, "y": 0, "z": 0, "hb": 1, "hbdead": 1, "hbmdl": joaat("A_M_M_ValFarmer_01"), "hboft": 1, "hbh": 56})
    sp = context.system_prompt(conv, b.game)
    check("slung over his horse" in sp and "Nobody you recognise" in sp, "prompt: stranger's body on the horse")
    # bodies lying around (first scan = baseline, second scan = a new body appears)
    b.on_nearby({"peds": [{"h": 70, "d": 6, "m": m1, "o": 0xAAAA, "alive": 0}, {"h": 71, "d": 8, "m": m2, "o": 1, "alive": 1}]})
    sp = context.system_prompt(conv, b.game)
    check("DEAD:" in sp and martha.persona["name"] in sp.split("Bodies:")[1], "prompt: body on the ground + who it was")
    check("People around you" in sp and "m away" in sp.split("People around you")[1], "prompt: people around described")
    print("   ---- what the NPC is told ----\n   " + "\n   ".join(l for l in sp.splitlines() if "  - " in l or "About " in l))
    conv.pending_events.clear()
    b.on_nearby({"peds": [{"h": 70, "d": 6, "m": m1, "o": 0xAAAA, "alive": 0}, {"h": 72, "d": 4, "m": m2, "o": 2, "alive": 0}]})
    check(any(e[0] == "new_body" for e in conv.pending_events), "someone dropping dead nearby is an event")
    # a person who died is not 'recognised' alive later
    b.on_event({"kind": "ped_dead", "ped": 10})
    check(listener.d.get("dead") and b.memory.find(m2, 0xBBBB, "Valentine", set()) is None, "dead people are not 'recognised' alive again")

async def first_look():
    b = Brain(Path(__file__).resolve().parents[1]); b.cfg.fake_ai = True; b.cfg.reactions = False
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory; b.asi.writer = W()
    m2 = joaat("A_M_M_ValTownfolk_01")
    conv = Conversation(11, b.memory.create(m2, 5, b.peddb.classify(m2, True), "Valentine", 0), b.peddb.classify(m2, True))
    conv.engaged_ok = True; b.convs[11] = conv
    b.game.on_tick({"p": {"x": 0, "y": 0, "z": 0, "c": 1, "cdead": 1}, "w": {},
                    "peds": [{"h": 11, "d": 3, "alive": 1, "aimed": 1}]}, b.memory.player)
    b.after_tick()
    keys = [e[0] for e in conv.pending_events]
    check("carrying_body" in keys and "aimed" in keys, f"walking up already carrying a body / aiming is noticed at once {keys}")

async def workmate_killed():
    b = Brain(Path(__file__).resolve().parents[1]); b.cfg.fake_ai = True; b.cfg.reactions = False
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory; b.asi.writer = W()
    V = joaat("Valentine"); cot = joaat("A_M_M_ValFarmer_01")
    b.game.on_tick({"p": {"x": 0, "y": 0, "z": 0}, "w": {"town": V}, "peds": [{"h": 20, "d": 3, "alive": 1}]}, b.memory.player)
    worker = b.memory.create(cot, 0x1, b.peddb.classify(cot, True), "Valentine", 0)
    conv = Conversation(20, worker, b.peddb.classify(cot, True)); conv.engaged_ok = True; b.convs[20] = conv
    mate = {"h": 90, "d": 7, "de": 5, "m": cot, "o": 0x2, "male": 1, "alive": 1, "scen": 1, "elos": 1}
    b.on_nearby({"eng": 20, "peds": [mate]})                     # baseline: workmate alive, working
    sp = context.system_prompt(conv, b.game)
    line = [l for l in sp.splitlines() if "m away" in l]
    check(line and "workmate" in line[0] or "friend from work" in line[0] or "boss" in line[0] or "new hand" in line[0],
          f"a fellow worker nearby is a workmate: {line[0].strip() if line else '-'}")
    conv.pending_events.clear()
    b.on_nearby({"eng": 20, "peds": [dict(mate, alive=0, kp=1)]})  # player shoots him
    ev = [e for e in conv.pending_events if e[0] == "new_body"]
    check(ev and "KILLED" in ev[0][1] and "in front of your eyes" in ev[0][1], f"he SAW you kill his workmate: {ev[0][1] if ev else '-'}")
    sp = context.system_prompt(conv, b.game)
    check("the PLAYER killed them" in sp and "you can see the body" in sp, "prompt: the body, who killed them, and that he can see it")
    check(worker.stats["fear"] > 30 and worker.stats["anger"] > 10, f"fear/anger jump {worker.stats}")
    check(any("killed" in e["what"] for e in worker.d["events"]), "remembered: 'he killed ...'")

asyncio.run(main()); asyncio.run(first_look()); asyncio.run(workmate_killed()); print(f"\n{ok} passed, {bad} failed"); sys.exit(1 if bad else 0)
