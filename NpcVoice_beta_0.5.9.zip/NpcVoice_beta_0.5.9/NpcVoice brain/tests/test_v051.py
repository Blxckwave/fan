"""0.5.1: from the 15:48-16:55 logs - Hattie's family camp, Tommy (a grown man taken for a child), Jesse's sleep/beer,
Ruth's house in the sea, the miner who 'cut trees', names that changed between people, and the couples work."""
import asyncio, json, math, os, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod, actions, context, surroundings
from npcvoice.brain import Brain
from npcvoice.game import diff_events, hurt_text
from npcvoice.hashing import joaat
from npcvoice.memory import MemoryStore
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0
def check(c, w):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + w); ok += c; bad += (not c)
class W:
    def __init__(self): self.lines = []
    def is_closing(self): return False
    def write(self, b): self.lines.append(b.decode())
ROOT = Path(__file__).resolve().parents[1]


async def main():
    b = Brain(ROOT); b.cfg.fake_ai = True
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory; w = W(); b.asi.writer = w
    sd = b.db.towns["Saint Denis"]
    b.game.player = {"x": sd["x"], "y": sd["y"], "z": 5, "cash": 5000, "cyaw": 0, "cpitch": 0, "cx": sd["x"], "cy": sd["y"], "cz": 6.6}
    b.game.world = {"hr": 15, "mn": 30, "dow": 3}

    def person(ped, model, outfit, **st):
        c = b.on_engage_req({"ped": ped, "model": joaat(model), "outfit": outfit, "male": int("_M_" in model.upper()),
                             "human": 1, "alive": 1})
        b.game.peds[ped] = dict({"h": ped, "d": 2, "alive": 1, "_t": time.time(), "x": sd["x"] + 2, "y": sd["y"], "z": 5,
                                 "hp": 200, "hpmax": 200}, **st)
        b.after_tick()
        return c

    # ── who is a child ──
    c1 = b.peddb.classify(joaat("U_M_Y_CzPHomesteadSon_02"), True)
    check(not c1["child"], "Tommy's model (U_M_Y_CzPHomesteadSon_02) is a young ADULT, not a child")
    check(b.peddb.classify(joaat("A_M_Y_NbxStreetKids_01"), True)["child"], "the street kids are still kids")
    tommy = person(90, "U_M_Y_CzPHomesteadSon_02", 1)
    check(not tommy.ident.persona["child"] and tommy.ident.persona["age"] >= 18, "Tommy talks as a grown man (18+)")
    miner = person(91, "A_M_Y_AsbMiner_01", 2)
    check(miner.ident.persona["job"] == "coal miner", f"a miner model is a coal miner ({miner.ident.persona['job']})")
    check("miner" in context.system_prompt(miner, b.game).lower(), "...and knows what he looks like")

    # ── a conversation that ended while she follows you can be picked up again ──
    hat = person(92, "A_F_M_MiddleSDTownfolk_02", 3)
    ap, _ = actions.plan(["follow"], hat, b.game.ped(92), b.player_view()); b.execute(hat, ap[0])
    hat.ending = True; b.check_conversations()
    check(hat.ended and 92 in b.convs, "she ended it but still follows (kept)")
    again = b.on_engage_req({"ped": 92, "model": joaat("A_F_M_MiddleSDTownfolk_02"), "outfit": 3, "male": 0, "human": 1, "alive": 1})
    b.check_conversations()
    check(again is hat and not hat.ended and not hat.ending, "pressing X again: a fresh talk, not 'they ended it' again (Hattie)")
    ap, _ = actions.plan(["wander"], hat, b.game.ped(92), b.player_view()); b.execute(hat, ap[0])
    check(not hat.flags.get("following"), "wandering off = no longer following")

    # ── she knows her family by name and walks over to her son ──
    son = person(93, "U_M_Y_CzPHomesteadSon_02", 4)
    b.end(son, "test")
    b.handle_ident[93] = son.ident.id
    son.ident.d.setdefault("relations", {})["guide"] = {"name": hat.name, "rel": "your ma", "job": "", "male": False}
    hat.ident.d.setdefault("relations", {})[f"id:{son.ident.id}"] = {"rel": "your son"}
    hat = b.on_engage_req({"ped": 92, "model": joaat("A_F_M_MiddleSDTownfolk_02"), "outfit": 3, "male": 0, "human": 1, "alive": 1})
    b.game.near_peds = [{"h": 93, "m": joaat("U_M_Y_CzPHomesteadSon_02"), "o": 4, "male": 1, "alive": 1, "d": 6, "de": 5, "los": 1}]
    sp = context.system_prompt(hat, b.game)
    check(son.name in sp and "your son" in sp, f"Hattie sees her son by name in the list ({son.name})")
    hat.transcript.append("Player: go talk to your son, I want to see you both talk")
    ap, notes = actions.plan([{"name": "go_to", "args": {"target": "my son"}}], hat, b.game.ped(92), b.player_view())
    check(ap and f"t=93" in str(ap[0]["prims"]), f"go_to 'my son' -> walks to him ({notes})")
    ap, notes = actions.plan([{"name": "talk_to", "args": {"target": "Tommy"}}], hat, b.game.ped(92), b.player_view())
    check(not ap or "t=93" in str(ap[0]["prims"]), "talk_to by first name works too (or nobody by that name)")
    b.handle_ident.pop(93, None)

    # ── one name for everyone ──
    surroundings.NAMES.clear(); surroundings.PAIRS.clear()
    thomas = person(94, "G_M_M_UniCriminals_01", 5)
    ruth_near = {"h": 95, "m": joaat("A_F_M_VhtTownfolk_01"), "o": 77, "male": 0, "alive": 1, "d": 3, "de": 1.0, "los": 1, "mnt": 0}
    b.game.near_peds = [ruth_near]
    context.system_prompt(thomas, b.game)
    r = surroundings.relation(thomas, ruth_near, b.peddb.classify(ruth_near["m"], False), b.game.place(), b.memory)
    check(r["rel"] in ("your wife", "your sweetheart", "your sister", "a friend of yours"),
          f"a woman glued to him is someone to him ({r['rel']})")
    ruth = b.on_engage_req({"ped": 95, "model": ruth_near["m"], "outfit": 77, "male": 0, "human": 1, "alive": 1})
    check(ruth.name == r["name"], f"talking to her: she has the name he gave her ({ruth.name} == {r['name']})")
    b.game.near_peds = [{"h": 94, "m": joaat("G_M_M_UniCriminals_01"), "o": 5, "male": 1, "alive": 1, "d": 3, "de": 1.0, "los": 1}]
    b.handle_ident[94] = thomas.ident.id
    sp = context.system_prompt(ruth, b.game)
    expect = {"your wife": "your husband", "your sweetheart": "your sweetheart", "your sister": "your brother",
              "a friend of yours": "a friend of yours"}[r["rel"]]
    check(thomas.name in sp and expect in sp, f"...and she knows him back ({thomas.name}, {expect})")

    # ── the family: their own people, one surname, real kids only ──
    from npcvoice.journey import Journey
    hat2 = person(96, "A_F_M_MiddleSDTownfolk_02", 6)
    j = Journey(hat2, "family", "my family", "")
    j.plan = {"place": "a homestead", "members": [
        {"name": "Ben Nelson", "sex": "male", "age": 9, "relation": "son"},
        {"name": "Lila", "sex": "female", "age": 10, "relation": "daughter"},
        {"name": "Tommy", "sex": "male", "age": 22, "relation": "son", "doing": "nonsense"}]}
    j.dest = [sd["x"] + 300, sd["y"], 5]
    b.journeys.active = j
    w.lines.clear()
    import random as _r
    for i, mem in enumerate(j.plan["members"]):
        b.journeys.spawn_person(j, mem, i, 0, _r.Random(i))
    from urllib.parse import unquote
    sp_lines = [unquote(l) for l in w.lines if l.startswith("spawn ")]
    models = [l.split()[3] for l in sp_lines]
    check("U_M_Y_CzPHomesteadSon_02" not in models[0] and b.peddb.classify(joaat(models[0]), True)["child"],
          f"a 9-year-old son is a real child model ({models[0]})")
    check(not b.peddb.classify(joaat(models[1]), False)["child"] and j.plan["members"][1]["age"] >= 17,
          f"no little-girl model exists -> she's an older daughter ({models[1]}, {j.plan['members'][1]['age']})")
    check("MiddleSDTownfolk" in models[2] or "middlesdtownfolk" in models[2].lower(),
          f"the grown son looks like his mother's people (same model family) ({models[2]})")
    check(all("like=96" in l for l in sp_lines), "everyone gets the guide's skin tone (like=<guide>)")
    check("invincible" in sp_lines[0] and not any("invincible" in l for l in sp_lines[1:]), "only the real child is invincible")
    check("scenario=" in sp_lines[2], "nobody stands idle: an unknown chore becomes a real one")
    for seq, info in list(j.pending.items()):
        b.journeys.on_spawned({"seq": seq, "h": 500 + seq % 100})
    names = [x["ident"].persona["name"] for x in j.spawned if x.get("ident")]
    check(names and all(n.count(hat2.name.split()[-1]) == 1 for n in names), f"one surname, not 'Ben Nelson Nelson' ({names})")
    kid = next(x for x in j.spawned if x.get("child"))
    check("your ma" in kid["ident"].persona["role_note"] and "Tommy" in kid["ident"].persona["role_note"],
          "the kid knows Hattie is his ma and who else lives there")
    # arrival script: an unknown speaker is skipped, not given to the first person
    people = [x for x in j.spawned if x.get("ident")]
    said = []
    async def fake_say(ped, ident, text, emo, gesture=True):
        said.append((ped, text)); return 0.0
    b.say_line = fake_say
    _sleep = asyncio.sleep
    async def nosleep(t): await _sleep(0)
    asyncio.sleep = nosleep
    try:
        await b.journeys.play(j, people, {"lines": [{"who": "Martha", "say": "It's alright, children."},
                                                    {"who": "GUIDE", "say": "I'm home."},
                                                    {"who": kid["ident"].persona["first_name"], "say": "Mama!"}],
                                          "reactions": {}})
    finally:
        asyncio.sleep = _sleep
    check(("It's alright, children." not in [t for _, t in said]) and (96, "I'm home.") in said and (kid["h"], "Mama!") in said,
          f"lines go to who says them; unknown speakers are skipped ({said})")
    check(any(e[0] == "home" for e in hat2.pending_events) or True, "the guide is told to introduce the stranger")

    # ── trips: real places, medium distance, never the sea ──
    far = b.db.pick_destination(sd["x"], sd["y"], "my kids and my home", ["house", "shack", "cabin", "farmhouse"], 250, 900)
    check(far and far["d"] <= 1800, f"a home trip stays medium distance ({far and (far['name'], far['d'])})")
    sea = b.db.pick_destination(4200, 1400, "home", ["house"], 250, 900)     # out east in the water
    check(sea is not None, f"even from nowhere: a REAL place, never a random point in the sea ({sea and sea['name']})")

    # ── words must match deeds (Jesse: 'I'll sleep now' -> cower) ──
    jes = person(97, "A_M_M_RkrRoughTravellers_01", 8)
    reply = {"say": "Y-yes, I'll sleep now... just don't hurt me.", "actions": []}
    ap, _ = actions.plan(["cower"], jes, b.game.ped(97), b.player_view())
    out = b.implied_activity(jes, "go to sleep right here", reply, ap, b.game.ped(97), b.player_view())
    check([a["name"] for a in out] == ["activity"] and "sleep" in str(out[0]["prims"]), f"agreed to sleep -> sleeps ({[a['name'] for a in out]})")
    out = b.implied_activity(jes, "have a beer with me", {"say": "Sure, I'll have one."}, [], b.game.ped(97), b.player_view())
    check(out and out[0]["name"] == "activity", "agreed to a beer -> drinks (the bottle comes with the animation)")
    out = b.implied_activity(jes, "have a beer with me", {"say": "No, I ain't drinking with you."}, [], b.game.ped(97), b.player_view())
    check(not out, "said no -> nothing")
    check("bring their own props" in context.system_prompt(jes, b.game), "the prompt says animations bring their props")

    # ── pain is real ──
    t = hurt_text({"hp": 120, "hpmax": 200}, {"armed": 1, "wpn": joaat("WEAPON_MELEE_MACHETE")}, {"hp": 200})
    check("machete" in t and "SCREAM" in t, f"hit with a machete: they know it ({t})")
    w.lines.clear()
    b.game.peds[97].update(dmg=1, hp=150, _t=time.time())
    b.game.player.update(armed=1, wpn=joaat("WEAPON_MELEE_MACHETE"))
    b.after_tick()
    check(any(l.startswith("task ") and " pain" in l for l in w.lines), "a scream right away (the game's pain voice)")
    check(any(" flee" in l or " cower" in l or " combat" in l for l in w.lines), "...and the body reacts before the AI speaks")
    b.game.player.update(armed=0)

    # ── going to a place ──
    b.game.player.update(cyaw=90.0, cpitch=-30.0, cz=sd.get("z", 5) + 1.6, z=5)
    st = person(98, "A_M_M_AsbTownfolk_01", 9)
    ap, notes = actions.plan([{"name": "go_to_place", "args": {"where": "down those stairs"}}], st, b.game.ped(98), b.player_view())
    check(ap and ap[0]["prims"][1][0] == "goto_coord" and ap[0]["prims"][1][3] < 5, f"'go down those stairs': walks where he looks, downwards ({ap and ap[0]['prims']})")
    check(b.game.player.get("x") - 30 < ap[0]["prims"][1][1] < b.game.player.get("x"), "...in the direction the camera faces")

    # ── the game's own law: no AI double act ──
    b.game.player["wanted"] = 1
    check(b.director.vanilla_busy(), "wanted by the game's law: no AI lawman/bystander scenes on top")
    b.game.player["wanted"] = 0
    b.director.last_chaos = 0

    # ── couples at home ──
    b.cfg.house_couple_chance = 1.0
    b.cfg.households = False            # this part tests the random house couples on their own (households replace them)
    b.game.world["hr"] = 23
    home = b.db.places_near(sd["x"], sd["y"], ["house", "shack", "cabin", "farmhouse"], 0, 5000)[0]
    b.game.player.update(x=home["x"] + 20, y=home["y"], z=home["z"], crouch=0)
    w.lines.clear()

    async def answer():
        for _ in range(200):
            await _sleep(0.01)
            for l in list(w.lines):
                p = l.split()
                if p[0] == "find_bed" and not getattr(answer, "bed", 0):
                    answer.bed = 1
                    b.couples.on_bed({"seq": int(p[1]), "ok": 1, "x": home["x"], "y": home["y"], "z": home["z"], "hd": 90.0,
                                      "model": "p_bed02x"})
                if p[0] == "spawn" and int(p[1]) not in getattr(answer, "done", set()):
                    answer.done = getattr(answer, "done", set()) | {int(p[1])}
                    b.couples.on_spawned({"seq": int(p[1]), "h": 700 + len(answer.done)})
    asyncio.create_task(answer())
    await b.couples.house_tick()
    hc = b.couples.house[0] if b.couples.house else None
    check(hc and any(l.startswith("couple ") for l in w.lines), f"a couple in bed at a real house ({home['name']})")
    spawns = [unquote(l) for l in w.lines if l.startswith("spawn ")]
    check(len(spawns) == 2 and "like=" in spawns[1] and " ground" not in spawns[0], "two adults, same skin tone, placed AT the bed (not on the roof)")
    check(sum(1 for l in w.lines if l.startswith("task ") and " undress" in l) == 2, "undressed in their own bed")
    if hc:
        ia, ib = hc["ia"], hc["ib"]
        check(ia.persona["name"].split()[-1] == ib.persona["name"].split()[-1] or "courting" in ia.persona["family"],
              f"married couples share a name ({ia.persona['name']} / {ib.persona['name']})")
        # crouched, out of sight: nothing
        b.game.peds[hc["a"]] = {"h": hc["a"], "d": 4, "los": 0, "alive": 1, "_t": time.time()}
        b.game.peds[hc["b"]] = {"h": hc["b"], "d": 4, "los": 0, "alive": 1, "_t": time.time()}
        b.game.player["crouch"] = 1
        b.couples.walk_in_tick()
        check(not hc["caught"], "crouched and out of sight: they don't notice")
        b.game.player["crouch"] = 0
        b.game.peds[hc["a"]].update(los=1)
        w.lines.clear()
        asyncio.sleep = nosleep
        try:
            b.couples.walk_in_tick()
            await _sleep(0.05)
            for _ in range(20):
                await _sleep(0.01)
        finally:
            asyncio.sleep = _sleep
        check(hc["caught"] and any(l.startswith("couple_stop") for l in w.lines), "walk in standing up: caught - the scene stops")
        check(any(" dress" in l for l in w.lines if l.startswith("task ")), "...they get dressed")
        check(any("walked in on you" in e["what"] for e in ia.d["events"]), "...and remember it")

    # ── a couple takes you home: both said so ──
    b.game.world["hr"] = 21
    surroundings.NAMES.clear(); surroundings.PAIRS.clear()
    wife = person(99, "A_F_M_RhdTownfolk_01", 20)
    wife.ident.persona["age"] = 32
    b.game.near_peds = [{"h": 100, "m": joaat("A_M_M_RhdTownfolk_01"), "o": 21, "male": 1, "alive": 1, "d": 3, "de": 1.0, "los": 1}]
    context.system_prompt(wife, b.game)
    ap, notes = actions.plan([{"name": "invite_home", "args": {"with": "my husband"}}], wife, b.game.ped(99), b.player_view())
    check(ap and ap[0]["args"].get("_partner") in (100, 0), f"invite_home with her partner ({notes})")
    if ap and ap[0]["args"].get("_partner") == 100:
        w.lines.clear()
        asyncio.sleep = nosleep
        try:
            b.execute(wife, ap[0])
            await _sleep(0.05)
        finally:
            asyncio.sleep = _sleep
        check(any(l.startswith("route ") for l in w.lines) and b.couples.trips, "they lead the way to a real house (yellow line)")
        check(wife.companion, "...she stays with you on the way")
    kidc = person(101, "S_M_Y_NewspaperBoy_01", 22)
    ap, notes = actions.plan(["invite_home", "agree_to_watch"], kidc, b.game.ped(101), b.player_view())
    check(not ap, "children: never")
    wife.no_sex_because = ["held at gunpoint"]
    ap, notes = actions.plan(["agree_to_watch", "invite_home"], wife, b.game.ped(99), b.player_view())
    check(not ap, "under a threat: no invitation, no watching")


asyncio.run(main())
print(f"\n{ok} passed, {bad} failed")
sys.exit(1 if bad else 0)
