"""File link: segments roll over and are cleaned up, heartbeat names the session, a game restart is a new session."""
import asyncio, os, sys, tempfile, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from npcvoice import log as logmod
from npcvoice.filelink import FileLink
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0
def check(c, w):
    global ok, bad
    print(("PASS " if c else "FAIL ") + w); ok += bool(c); bad += (not c)

class FakeAsi:
    writer = None
    @property
    def up(self): return self.writer is not None
class FakeBrain:
    def __init__(self): self.asi = FakeAsi(); self.got = []; self.lost = 0
    async def on_msg(self, m): self.got.append(m)
    def on_game_lost(self): self.lost += 1

async def main():
    d = Path(tempfile.mkdtemp()); b = FakeBrain(); fl = FileLink(b, d)
    (d / "session.txt").write_text("111\n")
    (d / "a2b_111_0.txt").write_bytes(b''.join(json.dumps({"t": "x", "i": i}).encode() + b"\n" for i in range(3)))
    (d / "a2b_111_0.txt").open("ab").write(b'{"t":"x","i":')          # half-written line
    for _ in range(3): await fl.step()
    check([m["i"] for m in b.got] == [0, 1, 2], "reads complete lines only")
    with (d / "a2b_111_0.txt").open("ab") as f: f.write(b'3}\n')
    (d / "a2b_111_1.txt").write_bytes(b'{"t":"x","i":4}\n')
    for _ in range(4): await fl.step()
    check([m["i"] for m in b.got] == [0, 1, 2, 3, 4], "finishes a split line, then rolls to the next segment")
    check(not (d / "a2b_111_0.txt").exists(), "a fully read segment is deleted")
    check(isinstance(b.asi.writer, object) and b.asi.writer is not None, "game attached as soon as data arrives")
    b.asi.writer.write(b"hello_ack 1\n")
    check((d / "b2a_111_0.txt").read_text() == "hello_ack 1\n", "brain -> game messages land in b2a_<session>_0")
    task = asyncio.create_task(fl.run()); await asyncio.sleep(0.7); task.cancel()
    check(int((d / "brain_alive.txt").read_text().split()[0]) == 111, "heartbeat names the session it serves")
    (d / "session.txt").write_text("222\n"); (d / "a2b_222_0.txt").write_bytes(b'{"t":"x","i":9}\n')
    for _ in range(3): await fl.step()
    check(b.got[-1]["i"] == 9 and b.lost == 1 and not (d / "b2a_111_0.txt").exists(), "game restart = new session, old files cleaned")
asyncio.run(main()); print(f"\n{ok} passed, {bad} failed"); sys.exit(1 if bad else 0)
