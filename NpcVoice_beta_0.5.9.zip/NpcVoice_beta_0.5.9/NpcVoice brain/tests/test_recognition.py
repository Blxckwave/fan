"""A remembered enemy who sees you calls out on their own (nemesis behaviour)."""
import asyncio, os, sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod
from npcvoice.brain import Brain
from npcvoice.hashing import joaat
from npcvoice.memory import MemoryStore

ROOT = Path(__file__).resolve().parents[1]
logmod.setup(Path(tempfile.mkdtemp()))

class W:
    def __init__(self): self.lines = []
    def is_closing(self): return False
    def write(self, b): self.lines.append(b.decode())

async def main():
    b = Brain(ROOT)
    b.cfg.fake_ai = True; b.cfg.recognition_chance = 1.0
    b.memory = MemoryStore(Path(tempfile.mkdtemp()))
    b.asi.writer = W()
    b.game.world = {"town": joaat("Valentine")}
    model, outfit = joaat("A_M_M_ValFarmer_01"), 0xBEEF
    ident = b.memory.create(model, outfit, b.peddb.classify(model, True), "Valentine", 0)
    ident.adjust({"anger": 15, "fear": 15, "trust": -15}); ident.adjust({"anger": 15, "trust": -15}); ident.adjust({"anger": 15}); ident.adjust({"anger": 15, "fear": 15})
    ident.add_event("he hogtied you and left you in the mud", 0, "Valentine", 3)
    b.game.peds[777] = {"h": 777, "d": 9, "alive": 1, "x": 9, "y": 0, "z": 0, "_t": __import__("time").time()}
    b.on_nearby({"peds": [{"h": 777, "d": 9, "m": model, "o": outfit, "male": 1, "alive": 1, "los": 1}]})
    await asyncio.sleep(0.3)
    sent = "".join(b.asi.writer.lines)
    ok1 = "engage_ok 777" in sent
    ok2 = "say 777" in sent
    conv = b.convs.get(777)
    ok3 = conv is not None and conv.ident.id == ident.id
    sp = conv and __import__("npcvoice.context", fromlist=["x"]).system_prompt(conv, b.game)
    ok4 = bool(sp) and "hogtied you" in sp and ident.d["nemesis"]["rank"] in sp
    for c, w in [(ok1, "known enemy is engaged by the brain on sight"), (ok2, "they speak first (spontaneous call-out)"),
                 (ok3, "it is the remembered identity"), (ok4, f"prompt carries the grudge + memory ({ident.d['nemesis']['rank']})")]:
        print(("PASS " if c else "FAIL ") + w)
    return all([ok1, ok2, ok3, ok4])

sys.exit(0 if asyncio.run(main()) else 1)
