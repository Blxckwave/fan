"""The real scene path (AI patched out): what the AI is asked to write, and that the script is played out."""
import asyncio, json, os, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod, world
from npcvoice.brain import Brain
from npcvoice.hashing import joaat
from npcvoice.memory import MemoryStore
from npcvoice.director import TPL, Cand
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0
def check(c, w):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + w); ok += c; bad += (not c)
class W:
    def __init__(self): self.lines = []
    def is_closing(self): return False
    def write(self, b): self.lines.append(b.decode())

async def main():
    b = Brain(Path(__file__).resolve().parents[1]); b.cfg.fake_ai = False
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory; b.asi.writer = W()
    V = joaat("Valentine")
    b.game.on_tick({"p": {"x": 0, "y": 0, "z": 0}, "w": {"town": V, "st": joaat("NewHanover"), "hr": 21, "mn": 5,
                    "wx": joaat("RAIN")}, "peds": []}, b.memory.player)
    world.add_deed(b.memory, "Valentine", "New Hanover", "THE_STRANGER shot a man (rancher) dead", 3, 0, 4)
    m, f = joaat("A_M_M_ValTownfolk_01"), joaat("A_F_M_ValTownfolk_01")
    near = [{"h": 1, "d": 6, "x": 6, "y": 0, "z": 0, "m": m, "o": 11, "male": 1, "alive": 1},
            {"h": 2, "d": 7, "x": 7, "y": 1, "z": 0, "m": f, "o": 12, "male": 0, "alive": 1}]
    b.game.near_peds = near
    now = time.time()
    for p in near:
        b.game.peds[p["h"]] = dict(p, _t=now)
    seen = {}
    def fake_chat(messages, explicit, max_tokens=260, temperature=0.9):
        seen["user"] = messages[-1]["content"]
        return json.dumps({"lines": [{"who": "A", "say": "Bess, did you hear? Old Tom got shot by the livery.", "emotion": "whisper", "act": "point"},
                                     {"who": "B", "say": "Hush, Walter, that's him right there!", "emotion": "fearful", "act": "tremble"}],
                           "outcome": "walk_off_together", "summary": "A married couple whispered about the killing and hurried off."}), {"model": "test"}, []
    b.ai.chat = fake_chat
    b.ai.tts = lambda *a, **k: (None, "no tts in test")
    cands = [Cand(p["h"], p, b.peddb.classify(p["m"], bool(p["male"]))) for p in near]
    async def quick_hold(s, secs):
        await asyncio.sleep(0.2)
    b.director.hold = quick_hold
    tpl = TPL["couple"]
    b.director.start(tpl, cands[0], cands[1])
    for _ in range(60):
        await asyncio.sleep(0.2)
        for p in near:
            b.game.peds[p["h"]]["_t"] = time.time()
        if any(">> say 2" in l or l.startswith("say 2") for l in b.asi.writer.lines):
            break
    u = seen.get("user", "")
    sent = "".join(b.asi.writer.lines)
    check("your wife" in u and "your husband" in u, "they're cast as husband and wife")
    check("muddy livestock town" in u, "the town's lore is in the prompt")
    heard = world.rumours(b.memory, "Valentine", "New Hanover", b.game.game_minutes_total, b.handle_ident[1], 3)
    check(("Rumours going around" in u and "shot a man" in u) if heard else "Rumours going around" not in u,
          "rumours he has heard about your killing are in the prompt")
    import random as _r
    share = sum(bool(world.rumours(b.memory, "Valentine", "New Hanover", 0, f"seed{i}", 3)) for i in range(400)) / 400
    check(0.7 < share < 0.95, f"a fresh, witnessed killing reaches most locals ({share:.0%} heard)")
    far = sum(bool(world.rumours(b.memory, "Strawberry", "West Elizabeth", 0, f"seed{i}", 3)) for i in range(400)) / 400
    check(far == 0, "...but not people in another state")
    check("stands about" in u and "matches the description" in u, "they know you're standing right there, and who you might be")
    check("night" in u and "rain" in u, "time and weather")
    check("say 1 " in sent and "say 2 " in sent, "both spouses speak their lines")
    check("emote" in sent and "KIT_EMOTE_ACTION_POINT_1" in sent, "line actions are played (pointing)")
    rel = b.memory.ids[b.handle_ident[1]].d.get("relations", {})
    check(any(r["rel"] == "your wife" for r in rel.values()), "he remembers her as his wife")
    for _ in range(80):
        await asyncio.sleep(0.25)
        for p in near:
            b.game.peds[p["h"]]["_t"] = time.time()
        if not b.director.scenes:
            break
    sent = "".join(b.asi.writer.lines)
    check("task" in sent and "follow" in sent, "outcome: they walk off together (she follows him)")
    check("actor 1 0" in sent and "actor 2 0" in sent, "both released at the end")
    check(any("[couple" in s["text"] for s in b.memory.ids[b.handle_ident[2]].d["summaries"]), "she remembers the scene")
asyncio.run(main()); print(f"\n{ok} passed, {bad} failed"); sys.exit(1 if bad else 0)
