"""Fixes from the 0.1.3 in-game log: dead men don't talk, fear sounds afraid, robbed = all the money at once."""
import asyncio, os, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod, actions
from npcvoice.brain import Brain
from npcvoice.hashing import joaat
from npcvoice.memory import MemoryStore
from npcvoice.data import CHILD_PED
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0
def check(c, w):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + w); ok += c; bad += (not c)
class W:
    def __init__(self): self.lines = []
    def is_closing(self): return False
    def write(self, b): self.lines.append(b.decode())

async def main():
    b = Brain(Path(__file__).resolve().parents[1]); b.cfg.fake_ai = True
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory; b.asi.writer = W()
    m = joaat("A_M_M_ValTownfolk_01")
    info = {"ped": 30, "model": m, "outfit": 3, "male": 1, "human": 1, "alive": 1, "mission": 0}
    b.game.peds[30] = {"h": 30, "d": 3, "alive": 1, "aimed": 1, "_t": time.time()}
    conv = b.on_engage_req(info)
    conv.ident.persona["bravery"] = 0.2
    conv.ident.persona["cash"] = 7.5
    # voice follows fear
    emo, speed = b.real_emotion(conv, "calm")
    check(emo == "fearful" and speed > 1.0, f"a gun on a timid man -> fearful, faster voice ({emo}, {speed})")
    # robbery: everything at once
    conv.mark("threatened")
    ap, notes = actions.plan(["give_money"], conv, b.game.ped(30), b.player_view())
    check(ap and ap[0]["prims"][-1] == ("money", 750), f"robbed -> hands over ALL $7.50 at once {ap[0]['prims'] if ap else notes}")
    ap2, notes2 = actions.plan(["give_money"], conv, b.game.ped(30), b.player_view())
    check(not ap2 and "no money left" in notes2[0], "...and can't pay twice: his pockets are empty")
    # dead men tell no tales
    await b.on_msg({"t": "event", "kind": "ped_dead", "ped": 30})
    n0 = len(b.asi.writer.lines)
    await b.speak(conv, "I ain't dead yet!", "angry", False, conv.gen)
    check(not any(l.startswith("say 30") for l in b.asi.writer.lines[n0:]), "a dead man says nothing")
    dur = await b.say_line(30, conv.ident, "Boo", "calm")
    check(dur == 0, "...not even in a scene")
    # cowboys are adults
    check(not CHILD_PED.search("U_M_M_WtCCowboy_04") and CHILD_PED.search("S_M_Y_NewspaperBoy_01"), "cowboys are not children (newspaper boys are)")

asyncio.run(main()); print(f"\n{ok} passed, {bad} failed"); sys.exit(1 if bad else 0)
