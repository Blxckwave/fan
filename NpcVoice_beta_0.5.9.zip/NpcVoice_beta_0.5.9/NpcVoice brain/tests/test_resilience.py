"""Short link dropouts don't make the brain forget the conversation; PTT info re-engages a forgotten ped."""
import asyncio, os, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from npcvoice import log as logmod
from npcvoice.brain import Brain
from npcvoice.hashing import joaat
from npcvoice.memory import MemoryStore
logmod.setup(Path(tempfile.mkdtemp()))
ok = bad = 0
def check(c, w):
    global ok, bad
    c = bool(c); print(("PASS " if c else "FAIL ") + w); ok += c; bad += (not c)
class W:
    def __init__(self): self.lines = []
    def is_closing(self): return False
    def write(self, b): self.lines.append(b.decode())

async def main():
    b = Brain(Path(__file__).resolve().parents[1]); b.cfg.fake_ai = True
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory; b.asi.writer = W()
    os.environ["NPCVOICE_RIG_SAY"] = "50:hello|60:hello"
    m = joaat("A_M_M_ValTownfolk_01")
    info = {"ped": 50, "model": m, "outfit": 7, "male": 1, "human": 1, "alive": 1, "mission": 0}
    b.game.peds[50] = {"h": 50, "d": 3, "alive": 1, "_t": time.time()}
    b.on_engage_req(info)
    b.on_game_lost()                       # link dropped for a moment
    check(b.convs[50].engaged_ok, "conversation survives a short link dropout")
    await b.on_ptt({"down": True, **info}); await b.on_ptt({"down": False, "ped": 50}); await asyncio.sleep(0.2)
    check(any(l.startswith("say 50") for l in b.asi.writer.lines), "X after the dropout still gets an answer")
    # brain forgot the ped completely (e.g. restarted) but the game still has it engaged
    b.game.peds[60] = {"h": 60, "d": 3, "alive": 1, "_t": time.time()}
    await b.on_ptt({"down": True, **dict(info, ped=60, outfit=8)}); await b.on_ptt({"down": False, "ped": 60}); await asyncio.sleep(0.2)
    check(60 in b.convs and any(l.startswith("say 60") for l in b.asi.writer.lines), "unknown ped in a PTT is engaged on the fly and answered")
async def no_talk_over():
    b = Brain(Path(__file__).resolve().parents[1]); b.cfg.fake_ai = True
    b.memory = MemoryStore(Path(tempfile.mkdtemp())); b.game.memory = b.memory; b.asi.writer = W()
    m = joaat("A_M_M_ValTownfolk_01")
    info = {"ped": 70, "model": m, "outfit": 9, "male": 1, "human": 1, "alive": 1, "mission": 0}
    b.game.peds[70] = {"h": 70, "d": 3, "alive": 1, "_t": time.time()}
    conv = b.on_engage_req(info)
    slow = asyncio.Event()
    orig = b.fake_llm
    def slow_llm(*a):
        return orig(*a)
    async def slow_turn():
        conv.gen += 1; g = conv.gen; conv.busy = True
        await asyncio.sleep(0.3)                     # 'thinking'
        await b.speak(conv, "I was about to say something", "calm", False, g)
    t = asyncio.create_task(slow_turn())
    await asyncio.sleep(0.05)
    await b.on_ptt({"down": True, **info})          # player starts talking while the NPC is thinking
    await t
    check(not any(l.startswith("say 70") for l in b.asi.writer.lines), "a line being prepared is dropped when you press X")
    check(any(l.startswith("hush") for l in b.asi.writer.lines), "X sends 'hush' to the game")

asyncio.run(main()); asyncio.run(no_talk_over()); print(f"\n{ok} passed, {bad} failed"); sys.exit(1 if bad else 0)
