NpcVoice.asi.0.5.6-original = the plugin before households (no furniture, no position changes).
To go back: copy it next to RDR2.exe as NpcVoice.asi (and set households = 0 in NpcVoice_brain.ini if you like).
NpcVoice.asi.0.5.6 = the 0.5.6 plugin (households, type-instead). Use it only with the 0.5.6 brain - the 0.5.7 brain
expects the 0.5.7 plugin (version check).
NpcVoice.asi.0.5.7 = the 0.5.7 plugin (love scenes with clips side by side, no attach). Use it only with the 0.5.7 brain -
the 0.5.8 brain expects the 0.5.8 plugin (version check).
