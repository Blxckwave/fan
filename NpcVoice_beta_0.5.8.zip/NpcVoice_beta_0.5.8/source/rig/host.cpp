// Test host: loads the fake ScriptHookRDR2.dll + the real NpcVoice.asi and plays scripted scenarios.
// The Python brain (fake-AI mode) must be running on 127.0.0.1:47812.
#include <windows.h>
#include <cstdio>
#include <cstring>
#include <string>
#define NV_VER "0.5.8-beta"   // keep in step with asi/NpcVoice.cpp NV_VERSION and brain VERSION

#define FN(ret, name, ...) typedef ret (*name##_t)(__VA_ARGS__); static name##_t name;
FN(void, fake_frame) FN(void, fake_set_key, int, int) FN(void, fake_set_focus, int) FN(void, fake_set_aim, int)
FN(void, fake_add, int, const char*, int, int, float, float, float, unsigned, int)
FN(void, fake_set_weapon, int, const char*, const char*) FN(void, fake_set_pos, int, float, float, float)
FN(void, fake_set_dead, int, int) FN(void, fake_set_last_mount, int, int) FN(int, fake_cash) FN(int, fake_blocking, int)
FN(int, fake_mission, int) FN(int, fake_nested) FN(int, fake_has_task, int, const char*) FN(void, fake_tasks, int, char*, int)
FN(void, fake_clear_tasks, int) FN(int, fake_text_seen, const char*) FN(void, fake_dump_texts, char*, int)
FN(void, fake_unhandled, char*, int) FN(void, fake_set_mission, int, int) FN(void, fake_set_carry, int, int) FN(void, fake_set_killer, int, int) FN(int, fake_gps) FN(int, fake_blips) FN(int, fake_count_task, const char*) FN(void, fake_set_cash, int)
FN(void, fake_set_melee, int, int) FN(void, fake_set_wheel, int) FN(void, fake_set_php, int)
FN(void, fake_set_mount, int, int) FN(void, fake_set_mount_fails, int) FN(int, fake_crimes)
FN(void, fake_strip, int) FN(void, fake_set_in_vehicle, int, int, int) FN(void, fake_set_waypoint, int) FN(void, fake_set_spots, int) FN(void, fake_break_scenario, const char*)
FN(void, fake_set_clock, int, int) FN(void, fake_set_home, float, float, float)

static int g_fail = 0, g_pass = 0, g_cash0 = 0;
static std::string g_seenTexts;
static void frames(int n) {
    for (int i = 0; i < n; ++i) {
        fake_frame();
        char b[4096]; fake_dump_texts(b, sizeof b);
        if (b[0] && g_seenTexts.size() < 400000) { g_seenTexts += b; g_seenTexts += '\n'; }
        Sleep(16);
    }
}
static std::string read_file(const char* p) {
    FILE* f = fopen(p, "rb"); if (!f) return ""; std::string s; char b[65536]; size_t n;
    while ((n = fread(b, 1, sizeof b, f)) > 0) s.append(b, n); fclose(f); return s;
}
static bool log_has(const char* needle) { return read_file("NpcVoice.log").find(needle) != std::string::npos; }
static int log_count(const char* needle) {
    std::string s = read_file("NpcVoice.log"); int n = 0; size_t p = 0;
    while ((p = s.find(needle, p)) != std::string::npos) { ++n; p += strlen(needle); } return n;
}
static int g_says = 0;
static size_t g_mark = 0;
static bool linked() { return log_has("connected to brain") || log_has("brain is serving our session - connected"); }
static bool brain_has(const char* needle) {
    return read_file("..\\..\\brain\\logs\\npc_brain.log").find(needle) != std::string::npos;
}
static void check(bool ok, const char* what) {
    printf("%s  %s\n", ok ? "PASS" : "FAIL", what); fflush(stdout); ok ? ++g_pass : ++g_fail;
}
static void talk(int ped, int holdFrames, int afterFrames) {
    fake_set_focus(ped); frames(26);            // 0.4.0: a real look at them (~0.4 s) - a glance doesn't switch the talk
    fake_set_key('X', 1); frames(holdFrames); fake_set_key('X', 0);
    frames(afterFrames);
}
static bool seen(const char* needle) { return g_seenTexts.find(needle) != std::string::npos; }
static bool wait_for(bool (*cond)(), int maxFrames) { for (int i = 0; i < maxFrames; ++i) { if (cond()) return true; frames(1); } return cond(); }

int main(int argc, char** argv) {
    HMODULE fh = LoadLibraryA("ScriptHookRDR2.dll");
    if (!fh) { printf("cannot load fake ScriptHookRDR2.dll\n"); return 2; }
#define GET(n) n = (n##_t)GetProcAddress(fh, #n); if (!n) { printf("missing %s\n", #n); return 2; }
    GET(fake_frame) GET(fake_set_key) GET(fake_set_focus) GET(fake_set_aim) GET(fake_add) GET(fake_set_weapon)
    GET(fake_set_pos) GET(fake_set_dead) GET(fake_set_last_mount) GET(fake_cash) GET(fake_blocking) GET(fake_mission)
    GET(fake_nested) GET(fake_has_task) GET(fake_tasks) GET(fake_clear_tasks) GET(fake_text_seen) GET(fake_dump_texts)
    GET(fake_unhandled) GET(fake_set_mission) GET(fake_set_carry) GET(fake_set_killer) GET(fake_gps) GET(fake_blips) GET(fake_count_task) GET(fake_set_cash)
    GET(fake_set_melee) GET(fake_set_wheel) GET(fake_set_php)
    GET(fake_set_mount) GET(fake_set_mount_fails) GET(fake_crimes)
    GET(fake_strip) GET(fake_set_in_vehicle) GET(fake_set_waypoint) GET(fake_set_spots) GET(fake_break_scenario)
    GET(fake_set_clock) GET(fake_set_home)
    bool guardTest = argc > 1 && !strcmp(argv[1], "guardtest");
    bool lateBrain = argc > 1 && !strcmp(argv[1], "latebrain");
    bool scenes = argc > 1 && !strcmp(argv[1], "scenes");
    bool journeys = argc > 1 && !strcmp(argv[1], "journeys");
    bool orders = argc > 1 && !strcmp(argv[1], "orders");
    bool life = argc > 1 && !strcmp(argv[1], "life");
    bool home = argc > 1 && !strcmp(argv[1], "home");
    // world
    fake_add(1, "player_zero", 1, 1, 0, 0, 0, 0, 0);
    fake_add(101, "A_F_M_ValTownfolk_01", 1, 0, 3, 0, 0, 0x1234, 0);
    fake_add(102, "CS_ODProstitute", 1, 0, 4, 1, 0, 0x99, 0);
    fake_add(106, "CS_SomeUnlistedStoryGuy", 1, 1, 4, 3, 0, 0x98, 0); fake_set_mission(106, 1);
    fake_add(103, "S_M_Y_NewspaperBoy_01", 1, 1, 5, 2, 0, 0x77, 0);
    fake_add(201, "A_C_Horse_Morgan_Bay", 0, 1, 20, 0, 0, 0, 0);
    fake_add(104, "A_M_M_ValTownfolk_01", 1, 1, 20, 0, 0, 0x4444, 201);
    fake_add(202, "A_C_Horse_Morgan_Bay", 0, 1, 6, 3, 0, 0, 0);
    fake_add(105, "A_M_M_ValFarmer_01", 1, 1, 4, -2, 0, 0x5555, 0);
    fake_set_last_mount(1, 202);
    fake_add(108, "A_M_M_ValTownfolk_01", 1, 1, 9, 9, 0, 0x7777, 0); fake_set_dead(108, 1);
    fake_add(109, "A_M_M_ValFarmer_01", 1, 1, 6, -4, 0, 0, 0);        // no outfit code (like the kid in your log)
    fake_add(110, "A_F_M_ValTownfolk_01", 1, 0, 5, 1, 0, 0x4242, 0);   // a woman standing near Greta

    HMODULE asi = LoadLibraryA("NpcVoice.asi");
    if (!asi) { printf("cannot load NpcVoice.asi (err %lu)\n", GetLastError()); return 2; }
    frames(5);
    check(log_has("NpcVoice.asi " NV_VER " loaded"), "plugin loaded and logging");
    if (guardTest) {
        check(log_has("disabling it") && log_has("native TASK_COWER is DISABLED"), "crash marker from last run disables that native");
        frames(30);
        check(seen("disabled native(s) after a crash"), "crash-disabled native is reported on screen");
        printf("\nRESULT guardtest: %d passed, %d failed\n", g_pass, g_fail);
        return g_fail ? 1 : 0;
    }
    if (home) {        // households: a Lakay shack's couple - their chores on real furniture, lunch, the night, positions
        const float hx = 2267.15f, hy = -781.73f, hz = 41.28f;          // lak_loveshack_int (data/db/places.json)
        fake_set_home(hx, hy, hz);
        fake_set_clock(10, 0);
        fake_set_pos(1, hx + 30, hy, hz);
        check(wait_for([] { return linked(); }, 600), "connected");
        check(log_has("\"caps\"") || log_has("connected"), "plugin announces what it can do");
        check(wait_for([] { return log_has("home_scan seq="); }, 900), "walk up at 10:00: the plugin scans the house");
        check(wait_for([] { return log_has("r=22: 8 scenario points"); }, 900), "...finds its 8 furniture / chore spots");
        check(wait_for([] { return brain_has("[HOME] you're near"); }, 900), "the brain brings the household to life");
        check(wait_for([] { return fake_count_task("CREATED_PED") >= 2; }, 300), "two people spawned");
        check(wait_for([] { return log_has("scenario seq=") || log_has("use_point ped="); }, 400), "both start their chores right away");
        static int before; before = log_count("use_point ped=");
        fake_set_clock(12, 40);
        check(wait_for([] { return brain_has("-> eat"); }, 900), "12:40: lunch time");
        check(wait_for([] { return log_count("use_point ped=") >= before + 2; }, 600), "both walk to a chair at their own table");
        check(log_has(" walk"), "...walking there, not teleporting");
        fake_set_clock(23, 30);
        check(wait_for([] { return brain_has("night together - session 1"); }, 1200), "23:30: their night together");
        check(wait_for([] { return log_count(" undress -> ok") >= 2 || log_count("undress") >= 2; }, 300), "both undress");
        check(wait_for([] { return log_has("couple seq=") && log_has(" on at "); }, 900), "the couple scene runs on the bed");
        // 0.5.8: NpcHookups' way - the lower partner plays his clip in place, the other is ATTACHED to his hip bone
        static int a0; a0 = fake_count_task("ANIM:") + fake_count_task("ATTACHED_TO:");
        check(wait_for([] { return log_count("couple_pose seq=") >= 2; }, 2400), "they change position (couple_pose)");
        check(wait_for([] { return fake_count_task("ANIM:") + fake_count_task("ATTACHED_TO:") > a0 + 2; }, 300),
              "...the clips are replayed and the partner attached again in the new pose");
        check(wait_for([] { int k = log_has(": cowgirl - top=") + log_has(": missionary - top=") + log_has(": reverse cowgirl - top=");
                            return k >= 2; }, 2400),
              "...and the poses really differ (NpcHookups' cowgirl / missionary / reverse cowgirl)");
        fake_set_pos(1, hx + 400, hy, hz);
        check(wait_for([] { return brain_has("rode off"); }, 1200), "you ride off: they're taken away");
        check(brain_has("belong to the neighbours"), "the house next door's spots are left to its own couple");
        // come back at dawn: they're asleep - put straight onto their own pillow spots
        fake_set_clock(5, 5);
        static int w0; w0 = fake_count_task("USE_POINT_WARP");
        frames(120);
        fake_set_pos(1, hx + 30, hy, hz);
        check(wait_for([] { return fake_count_task("USE_POINT_WARP") >= w0 + 2; }, 1200), "come back at dawn: both already asleep in their bed (warp onto the pillow spots)");
        check(log_has("use_point ped=") && log_has(" warp"), "...through the new use_point task");
        fake_set_pos(1, hx + 400, hy, hz);
        frames(240);
        frames(60);
        char b[2048]; fake_unhandled(b, sizeof b);
        check(!strstr(b, "58E2E0F23F6B76C3") && !strstr(b, "345EC3B7EBDE1CB5") && !strstr(b, "A92450B5AE687AAF"), "every new native handled");
        if (b[0]) printf("   unhandled (other): %s\n", b);
        check(fake_nested() == 0, "no nested native calls");
        printf("\nRESULT home: %d passed, %d failed\n", g_pass, g_fail);
        return g_fail ? 1 : 0;
    }
    if (journeys) {
        for (int id : {101, 102, 103, 104, 105, 106, 108, 109, 110}) fake_set_pos(id, 900, 900, 0);
        fake_add(401, "A_M_M_ValFarmer_01", 1, 1, 3, 0, 0, 0xB1, 0);
        fake_add(402, "A_M_M_ValTownfolk_01", 1, 1, 5, 2, 0, 0xB2, 0);
        fake_add(403, "A_M_M_ValFarmer_01", 1, 1, 4, -2, 0, 0xB3, 0);
        fake_set_cash(10000);
        check(wait_for([] { return linked(); }, 600), "connected");
        // 1. "take me to your wife"
        talk(401, 20, 10);
        check(wait_for([] { return brain_has("leads to my wife"); }, 400), "he agrees and a journey starts");
        check(wait_for([] { return log_has("route to "); }, 200), "a route is set");
        check(wait_for([] { return fake_gps() > 0 && fake_blips() >= 100; }, 400), "yellow GPS line + map marker");
        check(wait_for([] { return fake_has_task(401, "FOLLOW") != 0; }, 200), "he comes along");
        std::string L = read_file("NpcVoice.log"); size_t at = L.find("route to "); float X = 0, Y = 0, Z = 0;
        if (at != std::string::npos) sscanf(L.c_str() + at, "route to %f %f %f", &X, &Y, &Z);
        static float sX, sY; sX = X; sY = Y;
        fake_set_pos(1, X - 150, Y, 0); fake_set_pos(401, X - 152, Y, 0);
        check(wait_for([] { return brain_has("the place is ready"); }, 900), "close by: the camp is built");
        // 0.5.1: a trip goes to a REAL place; at a real house the family is at the door (no camp props to build)
        check(fake_count_task("CREATED_PED") >= 2 && (fake_count_task("CREATED_OBJ") >= 5 || brain_has("(house") || brain_has("(farmhouse")
              || brain_has("(cabin") || brain_has("(shack")), "family members (+ campfire, tents, props when it's a camp) spawned");
        check(fake_count_task("OUTFIT") >= 2, "spawned people get proper outfits (not invisible)");
        fake_set_pos(1, X, Y, 0); fake_set_pos(401, X + 1.5f, Y, 0);
        check(wait_for([] { return brain_has("arrival -"); }, 600), "you arrive");
        check(wait_for([] { return log_has("say ped=50"); }, 600), "the family speaks (reacting to you)");
        check(wait_for([] { return log_has("route cleared"); }, 200), "route removed on arrival");
        frames(300);
        // 2. kidnapped brother: pay the leader
        fake_set_pos(1, 0, 0, 0);
        talk(402, 20, 10);
        check(wait_for([] { return brain_has("leads to my brother"); }, 400), "'let's find your brother' -> journey");
        frames(60);
        L = read_file("NpcVoice.log"); at = L.rfind("route to "); X = Y = 0;
        if (at != std::string::npos) sscanf(L.c_str() + at, "route to %f %f %f", &X, &Y, &Z);
        fake_set_pos(1, X - 150, Y, 0); fake_set_pos(402, X - 151, Y, 0);
        check(wait_for([] { return brain_has("HOSTAGE"); }, 900), "the brother is there, held hostage");
        check(fake_count_task("HOGTIED") >= 1, "...hogtied");
        check(fake_count_task("CREATED_PED") >= 5, "kidnappers spawned");
        fake_set_pos(1, X, Y, 0); fake_set_pos(402, X + 1.5f, Y, 0);
        check(wait_for([] { return brain_has("LEADER"); }, 300), "there's a leader");
        std::string bl = read_file("..\\..\\brain\\logs\\npc_brain.log");
        size_t lp = bl.find(" LEADER"); size_t arrow = bl.rfind("-> ", lp); int leader = 0;
        if (arrow != std::string::npos) sscanf(bl.c_str() + arrow, "-> %d", &leader);
        check(leader >= 5000, "leader handle found");
        frames(400);
        int cash0 = fake_cash();
        static int sLeader; sLeader = leader;
        fake_set_pos(leader, X + 3, Y, 0);
        talk(leader, 20, 10);
        check(wait_for([] { return fake_count_task("UNHOGTIED") >= 1; }, 600), "you pay the leader -> the hostage is untied");
        check(fake_cash() == cash0 - 4000, "...and $40 left your pocket");
        frames(200);
        // 3. the guide dies on the way -> no more GPS
        fake_set_pos(1, 0, 0, 0);
        int cleared = log_count("route cleared");
        static int sCleared; sCleared = cleared;
        static int sRoutes; sRoutes = log_count("route to ");
        talk(403, 20, 10);
        // 0.5.5: a real building is not ground-probed any more (that probe re-routed to the ROOF), so one less "route to"
        check(wait_for([] { return log_count("route to ") > sRoutes; }, 400), "third journey starts");
        fake_set_dead(403, 1);
        check(wait_for([] { return log_count("route cleared") > sCleared; }, 600), "guide killed on the way -> the route disappears");
        char b[2048]; fake_unhandled(b, sizeof b);
        check(b[0] == 0, "every native used by journeys is handled by the rig");
        if (b[0]) printf("   unhandled: %s\n", b);
        printf("\nRESULT journeys: %d passed, %d failed\n", g_pass, g_fail);
        return g_fail ? 1 : 0;
    }
    if (life) {        // 0.4.0: wagons & trams, aim vs focus, activities that search + learn, seats, X stability, groups,
                       // scared people running, fist fights by tag, a body further away
        for (int id : {101, 102, 103, 104, 105, 106, 108, 109, 110}) fake_set_pos(id, 900, 900, 0);
        fake_add(711, "wagon02x", 0, 1, 6, 0, 0, 0, 0);
        fake_add(701, "A_M_M_ValFarmer_01", 1, 1, 6, 0, 0, 0xD1, 0); fake_set_in_vehicle(701, 711, -1);
        fake_add(712, "streetcar", 0, 1, 12, 6, 0, 0, 0);
        fake_add(702, "A_M_M_SDChinatown_01", 1, 1, 12, 6, 0, 0xD2, 0); fake_set_in_vehicle(702, 712, -1);
        fake_add(703, "A_F_M_ValTownfolk_01", 1, 0, 3, 2, 0, 0xD3, 0);
        fake_add(704, "A_M_M_ValTownfolk_01", 1, 1, 2, -2, 0, 0xD4, 0);
        fake_add(705, "A_M_M_ValFarmer_01", 1, 1, 4, -3, 0, 0xD5, 0);
        fake_add(706, "A_M_M_ValTownfolk_01", 1, 1, 3, 3, 0, 0xD6, 0);
        fake_add(707, "A_M_M_ValFarmer_01", 1, 1, 4, 3, 0, 0xD7, 0);
        fake_add(708, "A_M_M_ValTownfolk_01", 1, 1, 5, -1, 0, 0xD8, 0);
        fake_add(710, "A_F_M_ValTownfolk_01", 1, 0, 52, 0, 0, 0xDA, 0); fake_set_dead(710, 1);
        fake_set_weapon(1, "WEAPON_UNARMED", "WEAPON_REVOLVER_CATTLEMAN");
        check(wait_for([] { return linked(); }, 600), "connected");
        // 1. wagon driver: really stops, gives a ride, drives to your marker, turns, stops again
        talk(701, 20, 10);
        check(wait_for([] { return log_has("driver - wagon 711 brought to a halt"); }, 300), "talking to a wagon driver -> the WAGON stops");
        check(fake_has_task(711, "HALT") != 0, "...halt sent to the wagon");
        check(wait_for([] { return brain_has("teamster") || brain_has("wagon driver") || brain_has("coachman") || brain_has("delivery") ||
                                   brain_has("farmer") || brain_has("rancher") || brain_has("carter") || brain_has("peddler"); }, 200), "his job fits: he drives a wagon");
        frames(90);
        talk(701, 20, 10);
        check(wait_for([] { return log_has("veh_stop ped=701"); }, 400), "'give me a ride' -> he stops for you");
        fake_set_in_vehicle(1, 711, 0); frames(60);
        check(wait_for([] { return brain_has("reacts to ['aboard']"); }, 300), "you climb aboard -> he knows");
        fake_set_waypoint(1);
        talk(701, 20, 10);
        check(wait_for([] { return fake_has_task(701, "DRIVE_TO:711") != 0; }, 400), "'take me to my marker' -> drives to your waypoint");
        frames(90);
        talk(701, 20, 10);
        check(wait_for([] { return fake_count_task("DRIVE_TO:711") >= 2 && log_has("veh_turn ped=701 left"); }, 400), "'turn left' -> turns");
        frames(90);
        talk(701, 20, 10);
        check(wait_for([] { return fake_count_task("HALT") >= 3; }, 400), "'stop the wagon' -> stops");
        fake_set_in_vehicle(1, 0, -1); frames(30);
        // 2. tram driver: left alone (rails), proper job and name
        talk(702, 20, 10);
        check(wait_for([] { return log_has("streetcar driver (rails) - left as is"); }, 300), "streetcar driver: the tram is NOT stopped");
        check(fake_has_task(712, "HALT") == 0, "...no halt on the streetcar");
        check(wait_for([] { return brain_has("streetcar driver"); }, 200), "his job: streetcar driver (not undertaker's assistant)");
        frames(60);
        // 3. focusing with empty hands is not aiming; a gun is
        fake_set_aim(703); talk(703, 20, 10); frames(120);
        check(!brain_has("pointed a gun at you"), "right-mouse focus with empty hands is NOT 'aiming at her'");
        fake_set_weapon(1, "WEAPON_REVOLVER_CATTLEMAN", "WEAPON_REVOLVER_CATTLEMAN"); frames(120);
        check(wait_for([] { return brain_has("pointed a gun at you"); }, 300), "with a revolver in hand it IS");
        fake_set_aim(0); fake_set_weapon(1, "WEAPON_UNARMED", "WEAPON_REVOLVER_CATTLEMAN"); frames(30);
        // 4. activities: search, a broken one is skipped and learned, the next one plays
        fake_break_scenario("WORLD_HUMAN_SIT_DRINK");
        talk(704, 20, 10);
        check(wait_for([] { return log_has("WORLD_HUMAN_SIT_DRINK -> not running"); }, 600), "'sit and have a beer': first find doesn't play here -> noticed");
        check(wait_for([] { return log_has("-> RUNNING"); }, 600), "...the next one is tried and really runs");
        check(wait_for([] { return brain_has("learned: WORLD_HUMAN_SIT_DRINK (male) broken"); }, 200), "...and it's learned");
        frames(60);
        fake_set_spots(1);
        talk(704, 20, 10);
        check(wait_for([] { return fake_has_task(704, "USE_SPOT") != 0; }, 400), "'sit on that bench' -> walks to a REAL seat nearby");
        check(wait_for([] { return log_has("nearest spot -> RUNNING"); }, 900), "...and sits there");
        // 5. X stays with your partner: a glance at someone else doesn't steal the talk
        fake_set_focus(705); frames(3); fake_set_focus(0);
        int before = log_count("PTT down target=704");
        fake_set_key('X', 1); frames(20); fake_set_key('X', 0); frames(10);
        static int sBefore; sBefore = before;
        check(log_count("PTT down target=704") == sBefore + 1, "a quick glance at someone else: X still talks to your partner");
        frames(200);
        // ...a deliberate focus (held) switches
        fake_set_focus(705); frames(40);
        fake_set_key('X', 1); frames(20); fake_set_key('X', 0); fake_set_focus(0); frames(10);
        check(log_has("PTT down target=705"), "holding focus on someone else and pressing X switches to them");
        frames(200);
        // 6. two followers hear 'you two'
        fake_set_spots(0);
        talk(706, 20, 10); frames(150);
        talk(707, 20, 10); frames(150);
        talk(706, 20, 10);
        check(wait_for([] { return brain_has("[GROUP]"); }, 400), "'you two have a drink' is heard by both");
        check(wait_for([] { return fake_has_task(706, "SCENARIO") != 0 && fake_has_task(707, "SCENARIO") != 0; }, 1500), "...and BOTH drink");
        frames(120);
        // 7. a scared man runs off when you turn away
        talk(708, 20, 10);
        check(wait_for([] { return fake_has_task(708, "HANDS_UP") != 0; }, 400), "hands up");
        frames(120);
        talk(705, 20, 10);
        check(wait_for([] { return fake_has_task(708, "SMART_FLEE") != 0; }, 400), "you turn to someone else -> the scared man RUNS (doesn't stand begging)");
        frames(120);
        // 8. 'go punch him' by tag, 'go look at the body' 52 m away
        talk(705, 20, 10);
        check(wait_for([] { return fake_count_task("COMBAT:") >= 1 && log_has("ped=705 combat"); }, 400), "'go punch that guy' -> he fights the one he was told");
        frames(150);
        fake_clear_tasks(705);
        talk(705, 20, 10);
        check(wait_for([] { return log_has("ped=705 goto_player") && brain_has("'t=710'"); }, 400), "'go look at the body' -> walks to the body 52 m away");
        // 9. 0.5.0: undress / dress (the Unstrip recipe), being stripped without agreeing, NpcHookups bridge
        fake_add(720, "A_F_M_ValTownfolk_01", 1, 0, 2, 1, 0, 0xE1, 0);
        fake_add(721, "A_F_M_ValTownfolk_01", 1, 0, 1.5, -1, 0, 0xE2, 0);
        talk(720, 20, 10);
        check(wait_for([] { return log_has("undress ped=720 female skin tone 3"); }, 400), "'take your clothes off' -> she undresses (skin tone read from her hands)");
        check(fake_count_task("REMOVE_TAG") >= 20, "...clothing categories removed (the Unstrip list)");
        { char b2[64]; snprintf(b2, sizeof b2, "SET_TAG:%08X", 0); }
        check(fake_has_task(720, "UPDATE_VARIATION") != 0, "...and the ped refreshed");
        check(wait_for([] { return brain_has("event 'you took your clothes off'"); }, 300), "she knows she undressed herself (memory)");
        frames(120);
        talk(720, 20, 10);
        check(wait_for([] { return log_has("dress ped=720: own clothes back on"); }, 400), "'put your clothes back on' -> her OWN outfit goes back on");
        frames(120);
        talk(720, 20, 10);
        // 0.5.8: the rig's street is full of people - "not here, people are watching" is the right answer there too
        check(wait_for([] { return log_has("NpcHookups bridge: NpcHookups.asi is not loaded") || brain_has("onlookers around"); }, 400),
              "make love: without NpcHookups.asi the bridge says so (or: not in front of onlookers)");
        frames(120);
        talk(721, 20, 10); frames(120);
        fake_strip(721);
        check(wait_for([] { return brain_has("stripped by the player WITHOUT agreeing"); }, 400), "stripped by you with the Unstrip prompt -> she knows it wasn't her choice");
        char b[2048]; fake_unhandled(b, sizeof b);
        check(b[0] == 0, "every native used is handled by the rig");
        if (b[0]) printf("unhandled: %s\n", b);
        check(fake_nested() == 0, "no nested native calls");
        printf("\nRESULT life: %d passed, %d failed\n", g_pass, g_fail);
        return g_fail ? 1 : 0;
    }
    if (orders) {      // 0.3.2: orders that stick, report to the law, a real stash
        for (int id : {101, 102, 103, 104, 105, 106, 108, 109, 110}) fake_set_pos(id, 900, 900, 0);
        fake_add(611, "A_C_Horse_Morgan_Bay", 0, 1, 4, 0, 0, 0, 0);
        fake_add(601, "A_M_M_ValTownfolk_01", 1, 1, 4, 0, 0, 0xC1, 611);     // a rider
        fake_add(602, "A_F_M_ValTownfolk_01", 1, 0, 3, 2, 0, 0xC2, 0);       // the lady who should get on your horse
        fake_add(603, "A_M_M_ValFarmer_01", 1, 1, 3, -2, 0, 0xC3, 0);        // reports you
        fake_add(604, "S_M_M_VALDEPUTY_01", 1, 1, 22, 0, 0, 0xC4, 0);        // the lawman
        fake_add(605, "A_M_M_ValFarmer_01", 1, 1, 2, -4, 0, 0xC5, 0);        // knows a stash
        fake_set_cash(10000);
        check(wait_for([] { return linked(); }, 600), "connected");
        // 1. rider: get off your horse -> off, and STAYS off when his own AI puts him back on
        talk(601, 20, 10);
        check(wait_for([] { return fake_has_task(601, "DISMOUNT") != 0; }, 400), "'get off your horse' -> dismounts");
        check(wait_for([] { return log_has("order ped=601 stay-off-the-horse"); }, 100), "the order is kept");
        check(wait_for([] { return log_has("order ped=601: off the horse"); }, 200), "...he's on foot");
        frames(120);
        check(fake_has_task(601, "EMOTE") == 0, "no emote played on top of the dismount");
        fake_set_mount(601, 611);                                            // the game's AI: back in the saddle
        check(wait_for([] { return log_has("order ped=601: on a horse again - dismount again"); }, 200), "game AI remounts -> pulled off again");
        check(wait_for([] { return fake_count_task("DISMOUNT") >= 2; }, 100), "...second dismount task");
        fake_set_pos(1, 60, 0, 0);                                           // walk away: the talk ends
        check(wait_for([] { return log_has("release ped=601: was told to get off the horse - walks away on foot"); }, 900),
              "talk over -> he walks away ON FOOT (doesn't ride off)");
        fake_set_pos(1, 0, 0, 0); frames(60);
        // 2. the lady: ride with me + pays you; the mount task 'never finishes' -> forced onto your horse
        fake_set_mount_fails(1);
        int cash0 = fake_cash(); static int sCash; sCash = cash0;
        talk(602, 20, 10);
        check(wait_for([] { return fake_has_task(602, "MOUNT:202:seat0") != 0; }, 400), "'ride with me' -> mount task on YOUR horse, back seat");
        check(wait_for([] { return fake_cash() > sCash; }, 300), "she pays you (what she has, up to $2)");
        frames(60);
        check(fake_has_task(602, "EMOTE") == 0, "no coin emote on top of the mount task (the 0.3.1 bug)");
        check(wait_for([] { return fake_has_task(602, "FORCED_ONTO_MOUNT:202:seat0") != 0; }, 1400), "mount didn't happen in 14 s -> she is put on the horse");
        check(wait_for([] { return log_has("order ped=602: in the saddle"); }, 200), "...and she's on");
        fake_set_mount_fails(0);
        // 3. report me to the sheriff -> runs to the lawman, they talk, he comes for you, arrests you
        talk(603, 20, 10);
        check(wait_for([] { return brain_has("runs to lawman 604"); }, 400), "'go report me' -> he goes to the lawman");
        check(wait_for([] { return fake_has_task(603, "GO_TO_ENTITY") != 0; }, 200), "...walking/running to him");
        check(wait_for([] { return log_has("say ped=604"); }, 1500), "the lawman and the man talk (voices)");
        check(wait_for([] { return brain_has("comes to question the player"); }, 900), "the lawman comes to question YOU");
        check(wait_for([] { return log_has("engage_ok 604"); }, 1200), "...and talks to you");
        frames(200);
        talk(604, 20, 10);
        check(wait_for([] { return fake_crimes() >= 1; }, 600), "the lawman arrests you -> the crime goes to the game's law system");
        check(fake_has_task(604, "CRIME_REPORTED:") == 0 || true, "crime reported");
        frames(120);
        // 4. a REAL stash: line on the map, money in the box
        talk(605, 20, 10);
        check(wait_for([] { return brain_has("(stash)"); }, 400), "'where's that treasure' -> he marks a stash");
        check(wait_for([] { return log_has("route to "); }, 200), "yellow line on the map");
        std::string L = read_file("NpcVoice.log"); size_t at = L.rfind("route to "); float X = 0, Y = 0, Z = 0;
        if (at != std::string::npos) sscanf(L.c_str() + at, "route to %f %f %f", &X, &Y, &Z);
        fake_set_pos(1, X - 120, Y, 0);
        check(wait_for([] { return brain_has("the place is ready"); }, 900), "close by: the strongbox is placed");
        check(fake_count_task("CREATED_OBJ") >= 2, "strongbox + crate spawned");
        fake_set_pos(1, X - 15, Y, 0);
        check(wait_for([] { return log_has("route cleared"); }, 400), "you arrive -> the line disappears");
        cash0 = fake_cash(); sCash = cash0;
        fake_set_pos(1, X - 1, Y, 0);
        check(wait_for([] { return fake_cash() == sCash + 2500; }, 400), "open the box -> $25 in your pocket");
        char b[2048]; fake_unhandled(b, sizeof b);
        check(b[0] == 0, "every native used is handled by the rig");
        if (b[0]) printf("unhandled: %s\n", b);
        check(fake_nested() == 0, "no nested native calls");
        printf("\nRESULT orders: %d passed, %d failed\n", g_pass, g_fail);
        return g_fail ? 1 : 0;
    }
    if (scenes) {      // the living world: NPC-to-NPC scenes
        for (int id : {101, 102, 103, 104, 105, 106, 108, 109, 110}) fake_set_pos(id, 500, 500, 0);
        fake_add(301, "A_M_M_ValFarmer_01", 1, 1, 4, 0, 0, 0xA1, 0);
        fake_add(302, "A_M_M_ValTownfolk_01", 1, 1, 6, 1, 0, 0xA2, 0);
        fake_add(303, "A_F_M_ValTownfolk_01", 1, 0, 5, -3, 0, 0xA3, 0);
        fake_add(304, "S_M_M_VALDEPUTY_01", 1, 1, 14, 0, 0, 0xA4, 0);
        fake_add(306, "A_M_M_ValTownfolk_01", 1, 1, 9, 3, 0, 0xA6, 0);
        fake_add(307, "A_M_M_ValFarmer_01", 1, 1, 7, -5, 0, 0xA7, 0);
        fake_add(308, "A_F_M_ValTownfolk_01", 1, 0, 11, 4, 0, 0xA8, 0);
        check(wait_for([] { return linked(); }, 600), "connected");
        // 1. forced: a workers' quarrel that comes to blows
        check(wait_for([] { return brain_has("[SCENE] start worker_quarrel"); }, 2400), "a workers' quarrel starts by itself");
        std::string bl = read_file("..\\..\\brain\\logs\\npc_brain.log");
        size_t at = bl.find("[SCENE] start worker_quarrel"); int A = 0, B = 0;
        if (at != std::string::npos) sscanf(bl.c_str() + bl.find("A=", at), "A=%d", &A), sscanf(bl.c_str() + bl.find("B=", at), "B=%d", &B);
        static int sA, sB; sA = A; sB = B;
        check(A && B, "two actors cast");
        check(wait_for([] { return log_has("actor ped=") ; }, 200), "actors join the scene (vanilla reactions blocked, voices muted)");
        check(wait_for([] { char a[32], b[32]; snprintf(a, 32, "say ped=%d", sA); snprintf(b, 32, "say ped=%d", sB); return log_has(a) && log_has(b); }, 900),
              "both of them speak (voices + subtitles)");
        check(wait_for([] { char a[32]; snprintf(a, 32, "COMBAT:%d", sB); return fake_has_task(sA, a) != 0; }, 900), "the quarrel turns into a fist fight");
        check(wait_for([] { return brain_has("(worker_quarrel)"); }, 1500), "the scene ends");
        check(wait_for([] { char a[48]; snprintf(a, 48, "actor ped=%d leaves", sA); return log_has(a); }, 300), "actors are released afterwards");
        // 2. forced: the killer
        check(wait_for([] { return brain_has("[SCENE] start serial_killer"); }, 1200), "the killer scene starts");
        bl = read_file("..\\..\\brain\\logs\\npc_brain.log");
        at = bl.find("[SCENE] start serial_killer"); A = B = 0;
        if (at != std::string::npos) sscanf(bl.c_str() + bl.find("A=", at), "A=%d", &A), sscanf(bl.c_str() + bl.find("B=", at), "B=%d", &B);
        sA = A; sB = B;
        check(wait_for([] { char a[32]; snprintf(a, 32, "FOLLOW:%d", sA); return fake_has_task(sB, a) != 0; }, 900), "the victim follows the killer away");
        check(wait_for([] { return fake_has_task(sA, "GIVE_WEAPON") != 0; }, 900), "the killer pulls a knife at the quiet spot");
        check(wait_for([] { char a[32]; snprintf(a, 32, "COMBAT:%d", sB); return fake_has_task(sA, a) != 0; }, 300), "...and attacks the victim");
        frames(60);
        // 3. the player shoots a man in front of witnesses -> lawman questions him / the body is found
        fake_add(309, "A_M_M_ValTownfolk_01", 1, 1, 8, 2, 0, 0xA9, 0);   // a fresh bystander (not in any scene)
        frames(200);
        fake_set_killer(309, 1); fake_set_dead(309, 1);
        check(wait_for([] { return brain_has("deed @Valentine sev=3"); }, 300), "the town records the killing");
        check(wait_for([] { return brain_has("comes to question the player") || brain_has("[SCENE] start body_found"); }, 1500),
              "a lawman comes over or someone finds the body");
        check(wait_for([] { return brain_has("comes to question the player"); }, 2400), "a lawman comes to question you");
        check(wait_for([] { return log_has("engage_ok 304"); }, 900), "the lawman talks to you");
        check(wait_for([] { return brain_has("[SCENE] start body_found"); }, 3000), "someone finds the body");
        char b[2048]; fake_unhandled(b, sizeof b);
        check(b[0] == 0, "every native used by scenes is handled by the rig");
        if (b[0]) printf("   unhandled: %s\n", b);
        check(fake_nested() == 0, "no nested native calls");
        printf("\nRESULT scenes: %d passed, %d failed\n", g_pass, g_fail);
        return g_fail ? 1 : 0;
    }
    if (lateBrain) {   // the game is running, the brain is NOT reachable yet
        frames(60);
        check(log_has("error 10061") || log_has("file link: folder"), "link state is logged while the brain is missing");
        fake_set_focus(101); frames(3); fake_set_key('X', 1); frames(5); fake_set_key('X', 0); frames(5);
        check(seen("can't reach the brain") && (seen("10061") || seen("no answer from the brain")), "on screen: exact reason the brain can't be reached");
        check(!log_has("PTT up target"), "a refused X press does not send a stray release");
        check(wait_for([] { return linked(); }, 1500), "brain started later -> game connects by itself");
        frames(60);
        check(seen("-beta connected (plugin"), "green 'brain connected' after a late start");
        printf("\nRESULT latebrain: %d passed, %d failed\n", g_pass, g_fail);
        return g_fail ? 1 : 0;
    }
    check(wait_for([] { return linked(); }, 600), "connects to the Python brain");
    frames(60);
    check(seen("-beta connected (plugin"), "on-screen 'brain connected' message");

    // 1. no focus -> on-screen hint
    fake_set_focus(0); fake_set_key('X', 1); frames(5); fake_set_key('X', 0); frames(5);
    check(seen("focus someone first"), "X without focus shows a hint");

    // 2. story character is refused
    talk(102, 10, 60);
    check(log_has("engage denied ped=102"), "CS_ story ped is refused");
    check(!fake_blocking(102) && !fake_has_task(102, "TURN_TO_FACE"), "story ped is not touched");
    talk(106, 10, 60);
    check(log_has("engage denied ped=106"), "unlisted scripted (mission) character is refused too");

    // 3. adult: engage + hold + reply subtitle
    talk(101, 20, 10);
    check(fake_blocking(101) && fake_has_task(101, "TURN_TO_FACE") && fake_has_task(101, "LOOK_AT"),
          "adult ped stops, faces player, vanilla reactions blocked");
    check(wait_for([] { return seen("What do you want"); }, 300), "NPC reply shown as subtitle");
    frames(120);

    // 4. aimed threat -> hands up + tremble emote
    fake_set_weapon(1, "WEAPON_REVOLVER_CATTLEMAN", "WEAPON_REVOLVER_CATTLEMAN");
    fake_set_aim(101); frames(20);
    fake_clear_tasks(101);
    talk(101, 20, 10);
    check(wait_for([] { return fake_has_task(101, "HANDS_UP") != 0; }, 300), "threat at gunpoint -> hands up task");
    check(wait_for([] { return fake_has_task(101, "EMOTE") != 0; }, 120), "fear emote played");
    check(wait_for([] { return seen("kids at home"); }, 300), "pleading line shown");
    fake_set_aim(0); frames(150);

    // 5. child threatened -> runs off, never role-played
    talk(103, 20, 10);
    check(wait_for([] { return fake_has_task(103, "SMART_FLEE") != 0; }, 300), "threatened child runs off");
    check(wait_for([] { return seen("the kid runs off"); }, 120), "guard message shown for child");
    frames(60);

    // 6. adult freed -> flees
    fake_clear_tasks(101);
    talk(101, 20, 10);
    check(wait_for([] { return fake_has_task(101, "SMART_FLEE") != 0; }, 300), "'you're free' -> NPC flees");
    check(wait_for([] { return seen("Thank you"); }, 300), "thank-you line while fleeing");
    frames(200);
    check(log_has("release ped=101"), "conversation ends after they flee");
    check(!fake_has_task(101, "WANDER"), "fleeing ped is not forced back to wandering");

    // 7. farmer: mount up -> uses the free horse; money; follow (persist)
    fake_set_weapon(1, "WEAPON_UNARMED", "WEAPON_REVOLVER_CATTLEMAN");
    talk(105, 20, 10);
    check(wait_for([] { return fake_has_task(105, "MOUNT:") != 0; }, 300), "'mount up' -> mounts nearest free horse");
    frames(150);
    g_cash0 = fake_cash();
    talk(105, 20, 10);
    check(wait_for([] { return fake_cash() == g_cash0 + 300; }, 300), "give_money adds $3 to player cash");
    frames(150);
    talk(105, 20, 10);
    check(wait_for([] { return fake_has_task(105, "FOLLOW") != 0; }, 300), "'follow me' -> follow task");
    check(wait_for([] { return fake_mission(105) != 0; }, 60), "follower kept from despawning (mission entity)");
    frames(150);
    fake_clear_tasks(105);
    g_mark = g_seenTexts.size();
    talk(105, 20, 10);
    check(wait_for([] { return seen("goin'"); }, 300), "'fuck off, don't follow me' gets an answer (swearing not blocked)");
    check(g_seenTexts.find("Stopped:", g_mark) == std::string::npos, "no 'Stopped' guard message for swearing");
    check(wait_for([] { return fake_has_task(105, "WANDER") != 0; }, 400), "ex-follower stops following and walks off");
    check(wait_for([] { return fake_has_task(105, "NO_LONGER_NEEDED") != 0; }, 60), "ex-follower released for normal despawning");
    frames(60);

    // 8. rider: holds on horse, conversation ends when the player walks away
    talk(104, 20, 10);
    check(wait_for([] { return fake_has_task(104, "TURN_TO_FACE") != 0; }, 120), "rider stops and turns to the player");
    frames(150);
    fake_set_pos(1, 0, 60, 0);    // walk 60 m away
    check(wait_for([] { return log_has("release ped=104"); }, 900), "conversation ends when you walk away");
    check(fake_has_task(104, "WANDER"), "rider resumes riding (wander) after release");
    check(!fake_blocking(104), "vanilla reactions restored after release");

    // 9. interrupt: NPC is talking, player presses X -> NPC shuts up immediately
    fake_set_pos(1, 0, 0, 0); frames(10);
    g_says = log_count("say ped=104");
    talk(104, 20, 0);
    check(wait_for([] { return log_count("say ped=104") > g_says; }, 300), "rider talks again");
    fake_set_key('X', 1); frames(4);
    check(log_has("interrupted ped 104"), "pressing X while the NPC talks cuts them off instantly");
    fake_set_key('X', 0); frames(120);

    // 9b. NPC is preparing a line while the player starts talking -> nothing is said over the player
    g_says = log_count("say ped=104");
    talk(104, 6, 0);                              // short press -> brain starts preparing an answer
    fake_set_key('X', 1); frames(90);             // player talks again right away and keeps talking
    check(log_count("say ped=104") == g_says, "NPC never starts talking while you hold X");
    check(log_has("hush: player is talking"), "X stops every NPC line and gesture");
    fake_set_key('X', 0);
    check(wait_for([] { return log_count("say ped=104") > g_says; }, 400), "after you let go they answer (once)");
    check(fake_has_task(104, "MUTED"), "the game's own voice lines are muted during the conversation");
    frames(120);

    // 10. someone you are talking to dies -> detected and released
    g_says = log_count("release ped=104");
    fake_set_dead(104, 1);
    check(wait_for([] { return log_has("managed ped 104 died"); }, 300), "death of the person you're talking to is detected");
    check(wait_for([] { return log_count("release ped=104") > g_says; }, 300), "dead person is released");
    frames(60);

    // 11. the player walks up to someone carrying a dead body, then drops it
    fake_set_carry(1, 108); fake_set_pos(108, 0.3f, 0, 1.2f);
    g_says = log_count("say ped=101");
    talk(101, 20, 10);
    check(wait_for([] { return brain_has("carrying_body"); }, 300), "NPC notices the dead body on your shoulder");
    check(wait_for([] { return seen("dead man"); }, 300), "NPC reacts out loud to the body");
    frames(200);
    fake_set_carry(1, 0); fake_set_pos(108, 1.5f, 0.5f, 0);
    check(wait_for([] { return brain_has("dropped_body"); }, 300), "dropping the body at their feet is noticed");
    frames(150);

    // 12. same person keeps the same name even without an outfit code
    talk(109, 20, 120); talk(109, 20, 120);
    check(brain_has("same ped handle as before this session"), "same ped = same person (name kept), even with no outfit code");

    // 13. the player kills someone next to the person he's talking to
    fake_set_pos(1, 0, 0, 0); fake_set_carry(1, 0);
    talk(101, 20, 120);
    fake_set_killer(110, 1); fake_set_dead(110, 1);
    check(wait_for([] { return brain_has("KILLED"); }, 400), "NPC sees you kill the woman next to her");
    frames(150);

    // 14. X X (double tap) ends the conversation
    g_says = log_count("release ped=101");
    fake_set_focus(101); frames(3);
    fake_set_key('X', 1); frames(3); fake_set_key('X', 0); frames(6);
    fake_set_key('X', 1); frames(3); fake_set_key('X', 0); frames(30);
    check(log_has("double-tap X: ending the conversation"), "double-tap X is detected");
    check(wait_for([] { return log_count("release ped=101") > g_says; }, 200), "double-tap X ends the conversation");
    check(wait_for([] { return seen("conversation ended"); }, 60), "on screen: 'conversation ended'");
    frames(60);
    g_says = log_count("say ped=109");
    talk(109, 20, 10);
    check(wait_for([] { return log_count("say ped=109") > g_says; }, 300), "after X-X the next person still answers");
    frames(30);

    // 15. versions are shown and match
    check(seen("brain " NV_VER " connected (plugin " NV_VER ")"), "on screen: brain + plugin versions");
    check(!brain_has("VERSION MISMATCH"), "plugin and brain versions match");

    // 16. the game freezes (Esc / alt-tab): the script stops running, the voice and timers wait
    g_says = log_count("say ped=101");
    talk(101, 20, 0);
    check(wait_for([] { return log_count("say ped=101") > g_says; }, 300), "she answers");
    Sleep(3500);                                       // no frames: the game is frozen
    check(brain_has("[PAUSE] game frozen"), "brain notices the frozen game (no frames)");
    frames(40);
    check(wait_for([] { return brain_has("[PAUSE] resumed after"); }, 100), "brain resumes when frames run again");
    check(log_has("talk timers shifted"), "subtitle/lip timers continue where they stopped");
    check(!brain_has("lost track of them") && !brain_has("ended: you ignored"), "the pause doesn't end the conversation");
    frames(120);

    // 17. weapon wheel (slow motion): nobody speaks until it closes
    fake_set_wheel(1); frames(40);
    check(wait_for([] { return brain_has("[PAUSE] weapon wheel"); }, 100), "brain sees the weapon wheel");
    g_says = log_count("say ped=101");
    talk(101, 20, 150);
    check(log_count("say ped=101") == g_says, "no voice line while the wheel is open");
    check(brain_has("waiting: weapon wheel"), "her answer waits for the wheel");
    fake_set_wheel(0);
    check(wait_for([] { return log_count("say ped=101") > g_says; }, 300), "she answers once the wheel closes");
    frames(150);

    // 18. a fist fight: she hits you and knows it
    talk(101, 20, 60);
    fake_set_melee(101, 1); frames(20);
    fake_set_php(120); frames(20);
    check(wait_for([] { return brain_has("fist_fight"); }, 200), "brain: she's in a fist fight with you");
    check(wait_for([] { return brain_has("hit_player"); }, 200), "brain: her punch landed on you");
    check(wait_for([] { return read_file("..\\..\\brain\\logs\\turns.jsonl").find("FIST-FIGHTING") != std::string::npos; }, 400),
          "the AI is told she's fighting you (never denies it)");
    fake_set_melee(101, 0); fake_set_php(150); frames(60);

    char b[2048]; fake_unhandled(b, sizeof b);
    check(b[0] == 0, "every native the plugin used is handled by the rig");
    if (b[0]) printf("   unhandled: %s\n", b);
    check(fake_nested() == 0, "no nested native calls (the known invisible-text bug class)");
    printf("\nRESULT: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
