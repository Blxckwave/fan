// NpcVoice.asi  –  in-game bridge for the NpcVoice Python brain (RDR2 1.0.1311.x, ScriptHookRDR2)
//
// Reads focus / push-to-talk / live state, applies tasks the brain asks for, draws subtitles + errors.
// All "thinking" lives in the Python brain; this plugin only executes.
//
// Safety rules baked in (see README):
//  * every native is listed in g_nat[] with a hash checked against the native DB (build <= 1311);
//  * the first call of every native writes NpcVoice_native_guard.txt BEFORE calling, and clears it after.
//    If the game dies inside that call, the next start disables that native and says so on screen;
//  * native arguments are always evaluated before nativeInit (no nested native calls in a push sequence).

#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cctype>
#include <cstdarg>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <algorithm>

#define NV_VERSION "0.5.8-beta"
// 0.5.7: the game's ped list holds animals, birds and rats too: in St Denis 256 slots ran out before the people
// right next to you (a wagon driver's own passengers!) were reached, so the AI was told "nobody is around".
#define PED_POOL_MAX 1024

// ───────────────────────── ScriptHookRDR2 imports ─────────────────────────
extern "C" {
void scriptRegister(HMODULE module, void (*LP_SCRIPT_MAIN)());
void scriptUnregister(HMODULE module);
void scriptWait(DWORD time);
void nativeInit(uint64_t hash);
void nativePush64(uint64_t val);
uint64_t* nativeCall();
int worldGetAllPeds(int* arr, int arrSize);
}

struct Vector3 { float x; uint32_t _px; float y; uint32_t _py; float z; uint32_t _pz; };

// ───────────────────────── logging ─────────────────────────
static char g_dir[MAX_PATH];
static FILE* g_log = nullptr;
static CRITICAL_SECTION g_logcs;
static void path_of(char* out, const char* name) { snprintf(out, MAX_PATH, "%s\\%s", g_dir, name); }

static void LOG(const char* lvl, const char* fmt, ...) {
    if (!g_log) return;
    EnterCriticalSection(&g_logcs);
    SYSTEMTIME st; GetLocalTime(&st);
    fprintf(g_log, "%02d:%02d:%02d.%03d %s ", st.wHour, st.wMinute, st.wSecond, st.wMilliseconds, lvl);
    va_list ap; va_start(ap, fmt); vfprintf(g_log, fmt, ap); va_end(ap);
    fputc('\n', g_log); fflush(g_log);
    LeaveCriticalSection(&g_logcs);
}
#define LI(...) LOG("INFO ", __VA_ARGS__)
#define LW(...) LOG("WARN ", __VA_ARGS__)
#define LE(...) LOG("ERROR", __VA_ARGS__)
#define LD(...) do { if (g_cfg.debug) LOG("DEBUG", __VA_ARGS__); } while (0)

// ───────────────────────── config ─────────────────────────
struct Cfg {
    int port = 47812;
    int pttKey = 'X';
    int debug = 0;
    float engageMaxDist = 30.f;
    float keepTalkingDist = 25.f;
    float releaseDist = 80.f;
    float subtitleDist = 40.f;
    float subtitleScale = 0.34f;
    int talkFace = 2;           // 0 off, 1 mood request, 2 mood + male facial idle override
    int blockVanillaKeys = 1;
    int typeInstead = 0;          // 0.5.6: 1 = hold X opens a keyboard: type what you say (no microphone, no speech-to-text)
    int blockLockOn = 0;          // 0.5.5: off - blocking the lock-on hid every prompt (Unstrip's strip, rob, ...) mid-talk
    int persistFollowers = 1;
    int nearbyScan = 1;
    int stopAmbientSpeech = 1;
    int tickMs = 100;
    int muteBystanders = 1;       // 0.5.1: while an AI voice talks, the game's ambient chatter around you is hushed
    int painVoice = 1;            // 0.5.1: a managed person you hurt screams (the game's own pain voice)
    char transport[16] = "file";   // file (no networking at all) | tcp
} g_cfg;

static int ini_int(const char* sec, const char* key, int def, const char* file) { return GetPrivateProfileIntA(sec, key, def, file); }
static float ini_float(const char* sec, const char* key, float def, const char* file) {
    char b[64]; char d[64]; snprintf(d, sizeof d, "%g", def);
    GetPrivateProfileStringA(sec, key, d, b, sizeof b, file); return (float)atof(b);
}
static const char* INI_DEFAULT =
    "; NpcVoice.asi settings (restart the game after editing)\r\n"
    "[NpcVoice]\r\n"
    "; must match port in NpcVoice_brain.ini\r\n"
    "PORT=47812\r\n"
    "; push-to-talk key as a Windows virtual-key code (88 = X)\r\n"
    "PTT_KEY=88\r\n"
    "; 1 = very detailed NpcVoice.log\r\n"
    "DEBUG=1\r\n"
    "ENGAGE_MAX_DIST=30\r\n"
    "; keep talking to the same person without re-focusing while within this distance\r\n"
    "KEEP_TALKING_DIST=25\r\n"
    "; safety net: let the person go if you are further than this\r\n"
    "RELEASE_DIST=80\r\n"
    "SUBTITLE_MAX_DIST=40\r\n"
    "SUBTITLE_SCALE=0.34\r\n"
    "; 0 = no face animation, 1 = talking mood, 2 = talking mood + mouth idle (men)\r\n"
    "TALK_FACE=2\r\n"
    "; while you hold the talk key: block the game's own use of that key (X = camera shoulder swap)\r\n"
    "BLOCK_VANILLA_KEYS=1\r\n"
    "; 1 = while you talk to someone, block the game's greet/antagonize lock-on on them (hides ALL their prompts - strip,\r\n"
    "; rob, hogtie... - so it's off; their own vanilla voice lines are muted anyway)\r\n"
    "BLOCK_LOCKON_WHILE_TALKING=0\r\n"
    "; 1 = TYPE instead of talking: hold X (half a second) on someone -> a keyboard opens, type, Enter (Esc cancels).\r\n"
    ";     No microphone, no speech-to-text. X X (double tap) still ends the conversation. 0 = your voice (default)\r\n"
    "TYPE_INSTEAD_OF_VOICE=0\r\n"
    "; keep followers from despawning while they follow you\r\n"
    "PERSIST_FOLLOWERS=1\r\n"
    "; scan for people you met before (recognition)\r\n"
    "NEARBY_SCAN=1\r\n"
    "; silence the game's own ambient lines for the person you talk to\r\n"
    "STOP_AMBIENT_SPEECH=1\r\n"
    "; while one of the AI voices talks, hush the game's own ambient chatter of the people around you (no double voices)\r\n"
    "MUTE_BYSTANDERS_WHILE_TALKING=1\r\n"
    "; someone you're talking to who gets hurt screams with the game's own pain voice\r\n"
    "PAIN_VOICE=1\r\n"
    "; how the game talks to the brain: file = through small files in %LOCALAPPDATA%\\NpcVoice\\link (no networking at all)\r\n"
    "; tcp = local network port 127.0.0.1:PORT\r\n"
    "TRANSPORT=file\r\n"
    "[NATIVES]\r\n"
    "; comma separated native names to never call (filled automatically after a crash)\r\n"
    "DISABLE=\r\n";

// ───────────────────────── natives ─────────────────────────
struct NativeDef { const char* name; uint64_t hash; bool used; bool disabled; };
enum N {
    PLAYER_ID, PLAYER_PED_ID, GET_PLAYER_INTERACTION_TARGET_ENTITY, GET_PLAYER_TARGET_ENTITY,
    GET_ENTITY_PLAYER_IS_FREE_AIMING_AT, IS_PLAYER_FREE_AIMING_AT_ENTITY, DOES_ENTITY_EXIST, IS_ENTITY_DEAD,
    IS_PED_HUMAN, IS_PED_A_PLAYER, IS_PED_MALE, GET_ENTITY_MODEL, GET_ENTITY_COORDS, GET_ENTITY_SPEED,
    GET_ENTITY_HEALTH, GET_ENTITY_MAX_HEALTH, SET_ENTITY_AS_MISSION_ENTITY, SET_ENTITY_AS_NO_LONGER_NEEDED,
    IS_PED_ON_MOUNT, GET_MOUNT, IS_PED_IN_ANY_VEHICLE, GET_VEHICLE_PED_IS_IN, GET_LAST_MOUNT, GET_PLAYERS_LAST_VEHICLE,
    IS_PED_HOGTIED, IS_PED_BEING_HOGTIED, IS_PED_LASSOED, IS_PED_RAGDOLL, IS_PED_IN_COMBAT, IS_PED_FLEEING,
    IS_PED_SHOOTING, GET_CURRENT_PED_WEAPON, SET_CURRENT_PED_WEAPON, GET_BEST_PED_WEAPON, SET_PED_DROPS_INVENTORY_WEAPON,
    IS_PED_USING_ANY_SCENARIO, IS_PED_SITTING, GET_PED_CROUCH_MOVEMENT, GET_PED_DRUNKNESS, GET_CLOCK_HOURS,
    GET_CLOCK_MINUTES, GET_CLOCK_DAY_OF_WEEK, GET_MAP_ZONE_AT_COORDS, GET_PREV_WEATHER_TYPE_HASH_NAME,
    GET_GAMEPLAY_CAM_COORD, GET_GAMEPLAY_CAM_ROT, IS_PAUSE_MENU_ACTIVE, GET_MISSION_FLAG, MONEY_GET_CASH_BALANCE,
    MONEY_INCREMENT_CASH_BALANCE, MONEY_DECREMENT_CASH_BALANCE, TASK_LOOK_AT_ENTITY, TASK_CLEAR_LOOK_AT,
    TASK_TURN_PED_TO_FACE_ENTITY, TASK_STAND_STILL, CLEAR_PED_TASKS, TASK_SMART_FLEE_PED, TASK_HANDS_UP,
    UPDATE_TASK_HANDS_UP_DURATION, TASK_COWER, TASK_FOLLOW_TO_OFFSET_OF_ENTITY, TASK_GO_TO_ENTITY, TASK_WANDER_STANDARD,
    TASK_COMBAT_PED, TASK_SEEK_COVER_FROM_PED, TASK_MOUNT_ANIMAL, TASK_DISMOUNT_ANIMAL, TASK_ENTER_VEHICLE,
    TASK_LEAVE_ANY_VEHICLE, TASK_LEAD_HORSE, TASK_VEHICLE_DRIVE_WANDER, TASK_START_SCENARIO_IN_PLACE_HASH, TASK_PLAY_ANIM,
    REQUEST_ANIM_DICT, HAS_ANIM_DICT_LOADED, DOES_ANIM_DICT_EXIST, TASK_PLAY_EMOTE_WITH_HASH,
    SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, SET_PED_KEEP_TASK, STOP_CURRENT_PLAYING_AMBIENT_SPEECH, STOP_CURRENT_PLAYING_SPEECH, STOP_PED_SPEAKING, GET_PED_SOURCE_OF_DEATH, GIVE_WEAPON_TO_PED, TASK_FOLLOW_NAV_MESH_TO_COORD, CREATE_PED, CREATE_OBJECT, CREATE_VEHICLE, REQUEST_MODEL, HAS_MODEL_LOADED, IS_MODEL_IN_CDIMAGE, SET_MODEL_AS_NO_LONGER_NEEDED, SET_RANDOM_OUTFIT_VARIATION, PLACE_OBJECT_ON_GROUND_PROPERLY, GET_GROUND_Z_FOR_3D_COORD, GET_WATER_HEIGHT_NO_WAVES, BLIP_ADD_FOR_COORDS, SET_BLIP_SPRITE, SET_BLIP_NAME, REMOVE_BLIP, START_GPS_MULTI_ROUTE, ADD_POINT_TO_GPS_MULTI_ROUTE, SET_GPS_MULTI_ROUTE_RENDER, CLEAR_GPS_MULTI_ROUTE, DELETE_ENTITY, SET_ENTITY_HEALTH, SET_ENTITY_INVINCIBLE, TASK_KNOCKED_OUT_AND_HOGTIED, UNHOGTIE_PED, SET_ENTITY_HEADING, IS_CONTROL_PRESSED, IS_DISABLED_CONTROL_PRESSED, IS_PED_IN_MELEE_COMBAT, DISABLE_CONTROL_ACTION,
    VAR_STRING, DISPLAY_TEXT, SET_TEXT_COLOR, SET_TEXT_SCALE, HAS_ENTITY_BEEN_DAMAGED_BY_ENTITY,
    CLEAR_ENTITY_LAST_DAMAGE_ENTITY, HAS_ENTITY_CLEAR_LOS_TO_ENTITY, GET_PED_META_OUTFIT_HASH,
    SET_FACIAL_IDLE_ANIM_OVERRIDE, CLEAR_FACIAL_IDLE_ANIM_OVERRIDE, REQUEST_PED_FACIAL_MOOD_THIS_FRAME,
    IS_THIS_MODEL_A_HORSE, GET_RIDER_OF_MOUNT, IS_MOUNT_SEAT_FREE, IS_VEHICLE_SEAT_FREE,
    GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS, GET_HASH_KEY, CLEAR_PED_SECONDARY_TASK, IS_ENTITY_A_MISSION_ENTITY, IS_PED_CARRYING_SOMETHING, GET_FIRST_ENTITY_PED_IS_CARRYING,
    SET_PED_ONTO_MOUNT, SET_PED_INTO_VEHICLE, SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE, REPORT_CRIME,
    BRING_VEHICLE_TO_HALT, STOP_BRINGING_VEHICLE_TO_HALT, TASK_VEHICLE_DRIVE_TO_COORD, SET_DRIVE_TASK_CRUISE_SPEED,
    IS_WAYPOINT_ACTIVE, GET_WAYPOINT_COORDS, IS_THIS_MODEL_A_TRAIN, GET_PED_IN_VEHICLE_SEAT, GET_ENTITY_HEADING,
    IS_PED_IN_VEHICLE, IS_PED_USING_SCENARIO_HASH, TASK_USE_NEAREST_SCENARIO_TO_COORD, DOES_SCENARIO_EXIST_IN_AREA,
    GET_SCENARIO_POINT_TYPE_PED_IS_USING,
    GET_NUM_COMPONENT_CATEGORIES_IN_PED, GET_PED_COMPONENT_CATEGORY_BY_INDEX, REMOVE_TAG_FROM_META_PED, SET_META_PED_TAG,
    GET_META_PED_ASSET_GUIDS, GET_META_PED_ASSET_TINT, UPDATE_PED_VARIATION, IS_ENTITY_PLAYING_ANIM,
    PLAY_PAIN, GET_NUM_META_PED_OUTFITS, EQUIP_META_PED_OUTFIT_PRESET, GET_PLAYER_WANTED_LEVEL, TASK_PLAY_ANIM_ADVANCED,
    GET_CLOSEST_OBJECT_OF_TYPE, STOP_ANIM_TASK, SET_ENTITY_COORDS, CLEAR_PED_TASKS_IMMEDIATELY, TASK_GO_TO_COORD_ANY_MEANS,
    TASK_LEAVE_VEHICLE, GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS, GET_SCENARIO_POINTS_IN_AREA, GET_SCENARIO_POINT_COORDS,
    GET_SCENARIO_POINT_HEADING, GET_SCENARIO_POINT_TYPE, DISPLAY_ONSCREEN_KEYBOARD, UPDATE_ONSCREEN_KEYBOARD,
    GET_ONSCREEN_KEYBOARD_RESULT, CANCEL_ONSCREEN_KEYBOARD,
    TASK_USE_NEAREST_SCENARIO_TO_COORD_WARP,
    FIND_ENTITY_LOOTING_PED, GET_IS_PED_BEING_ROBBED,
    ATTACH_ENTITY_TO_ENTITY, DETACH_ENTITY, GET_PED_BONE_INDEX, GET_ENTITY_BONE_INDEX_BY_NAME, SET_ENTITY_COORDS_NO_OFFSET,
    SET_ENTITY_COLLISION, SET_ENTITY_NO_COLLISION_ENTITY, SET_PED_CAN_RAGDOLL, IS_ENTITY_ATTACHED_TO_ENTITY,
    SET_ENTITY_VELOCITY, IS_PED_READY_TO_RENDER,
    N_COUNT
};
static NativeDef g_nat[N_COUNT] = {
    {"PLAYER_ID", 0x217E9DC48139933Dull}, {"PLAYER_PED_ID", 0x096275889B8E0EE0ull},
    {"GET_PLAYER_INTERACTION_TARGET_ENTITY", 0x3EE1F7A8C32F24E1ull}, {"GET_PLAYER_TARGET_ENTITY", 0xAE663DDD99C8A670ull},
    {"GET_ENTITY_PLAYER_IS_FREE_AIMING_AT", 0xA6817C110B830EADull}, {"IS_PLAYER_FREE_AIMING_AT_ENTITY", 0x8C67C11C68713D25ull},
    {"DOES_ENTITY_EXIST", 0xD42BD6EB2E0F1677ull}, {"IS_ENTITY_DEAD", 0x7D5B1F88E7504BBAull},
    {"IS_PED_HUMAN", 0xB980061DA992779Dull}, {"IS_PED_A_PLAYER", 0x12534C348C6CB68Bull},
    {"IS_PED_MALE", 0x6D9F5FAA7488BA46ull}, {"GET_ENTITY_MODEL", 0xDA76A9F39210D365ull},
    {"GET_ENTITY_COORDS", 0xA86D5F069399F44Dull}, {"GET_ENTITY_SPEED", 0xFB6BA510A533DF81ull},
    {"GET_ENTITY_HEALTH", 0x82368787EA73C0F7ull}, {"GET_ENTITY_MAX_HEALTH", 0x15D757606D170C3Cull},
    {"SET_ENTITY_AS_MISSION_ENTITY", 0xDC19C288082E586Eull}, {"SET_ENTITY_AS_NO_LONGER_NEEDED", 0x4971D2F8162B9674ull},
    {"IS_PED_ON_MOUNT", 0x460BC76A0E10655Eull}, {"GET_MOUNT", 0xE7E11B8DCBED1058ull},
    {"IS_PED_IN_ANY_VEHICLE", 0x997ABD671D25CA0Bull}, {"GET_VEHICLE_PED_IS_IN", 0x9A9112A0FE9A4713ull},
    {"_GET_LAST_MOUNT", 0x4C8B59171957BCF7ull}, {"GET_PLAYERS_LAST_VEHICLE", 0x2F96E7720B0B19EAull},
    {"IS_PED_HOGTIED", 0x3AA24CCC0D451379ull}, {"IS_PED_BEING_HOGTIED", 0xD453BB601D4A606Eull},
    {"IS_PED_LASSOED", 0x9682F850056C9ADEull}, {"IS_PED_RAGDOLL", 0x47E4E977581C5B55ull},
    {"IS_PED_IN_COMBAT", 0x4859F1FC66A6278Eull}, {"IS_PED_FLEEING", 0xBBCCE00B381F8482ull},
    {"IS_PED_SHOOTING", 0x34616828CD07F1A1ull}, {"GET_CURRENT_PED_WEAPON", 0x3A87E44BB9A01D54ull},
    {"SET_CURRENT_PED_WEAPON", 0xADF692B254977C0Cull}, {"GET_BEST_PED_WEAPON", 0x8483E98E8B888AE2ull},
    {"SET_PED_DROPS_INVENTORY_WEAPON", 0x208A1888007FC0E6ull}, {"IS_PED_USING_ANY_SCENARIO", 0x57AB4A3080F85143ull},
    {"IS_PED_SITTING", 0x84D0BF2B21862059ull}, {"GET_PED_CROUCH_MOVEMENT", 0xD5FE956C70FF370Bull},
    {"_GET_PED_DRUNKNESS", 0x6FB76442469ABD68ull}, {"GET_CLOCK_HOURS", 0xC82CF208C2B19199ull},
    {"GET_CLOCK_MINUTES", 0x4E162231B823DBBFull}, {"GET_CLOCK_DAY_OF_WEEK", 0x4DD02D4C7FB30076ull},
    {"_GET_MAP_ZONE_AT_COORDS", 0x43AD8FC02B429D33ull}, {"_GET_PREV_WEATHER_TYPE_HASH_NAME", 0x4BEB42AEBCA732E9ull},
    {"GET_GAMEPLAY_CAM_COORD", 0x595320200B98596Eull}, {"GET_GAMEPLAY_CAM_ROT", 0x0252D2B5582957A6ull},
    {"IS_PAUSE_MENU_ACTIVE", 0x535384D6067BA42Eull}, {"GET_MISSION_FLAG", 0xB15CD1CF58771DE1ull},
    {"_MONEY_GET_CASH_BALANCE", 0x0C02DABFA3B98176ull}, {"_MONEY_INCREMENT_CASH_BALANCE", 0xBC3422DC91667621ull},
    {"_MONEY_DECREMENT_CASH_BALANCE", 0x466BC8769CF26A7Aull}, {"TASK_LOOK_AT_ENTITY", 0x69F4BE8C8CC4796Cull},
    {"TASK_CLEAR_LOOK_AT", 0x0F804F1DB19B9689ull}, {"TASK_TURN_PED_TO_FACE_ENTITY", 0x5AD23D40115353ACull},
    {"TASK_STAND_STILL", 0x919BE13EED931959ull}, {"CLEAR_PED_TASKS", 0xE1EF3C1216AFF2CDull},
    {"TASK_SMART_FLEE_PED", 0x22B0D0E37CCB840Dull}, {"TASK_HANDS_UP", 0xF2EAB31979A7F910ull},
    {"UPDATE_TASK_HANDS_UP_DURATION", 0xA98FCAFD7893C834ull}, {"TASK_COWER", 0x3EB1FE9E8E908E15ull},
    {"TASK_FOLLOW_TO_OFFSET_OF_ENTITY", 0x304AE42E357B8C7Eull}, {"TASK_GO_TO_ENTITY", 0x6A071245EB0D1882ull},
    {"TASK_WANDER_STANDARD", 0xBB9CE077274F6A1Bull}, {"TASK_COMBAT_PED", 0xF166E48407BAC484ull},
    {"TASK_SEEK_COVER_FROM_PED", 0x84D32B3BEC531324ull}, {"TASK_MOUNT_ANIMAL", 0x92DB0739813C5186ull},
    {"TASK_DISMOUNT_ANIMAL", 0x48E92D3DDE23C23Aull}, {"TASK_ENTER_VEHICLE", 0xC20E50AA46D09CA8ull},
    {"TASK_LEAVE_ANY_VEHICLE", 0x504D54DF3F6F2247ull}, {"TASK_LEAD_HORSE", 0x9A7A4A54596FE09Dull},
    {"TASK_VEHICLE_DRIVE_WANDER", 0x480142959D337D00ull}, {"TASK_START_SCENARIO_IN_PLACE_HASH", 0x524B54361229154Full},
    {"TASK_PLAY_ANIM", 0xEA47FE3719165B94ull}, {"REQUEST_ANIM_DICT", 0xA862A2AD321F94B4ull},
    {"HAS_ANIM_DICT_LOADED", 0x27FF6FE8009B40CAull}, {"DOES_ANIM_DICT_EXIST", 0x537F44CB0D7F150Dull},
    {"TASK_PLAY_EMOTE_WITH_HASH", 0xB31A277C1AC7B7FFull}, {"SET_BLOCKING_OF_NON_TEMPORARY_EVENTS", 0x9F8AA94D6D97DBF4ull},
    {"SET_PED_KEEP_TASK", 0x971D38760FBC02EFull}, {"STOP_CURRENT_PLAYING_AMBIENT_SPEECH", 0xB8BEC0CA6F0EDB0Full},
    {"STOP_CURRENT_PLAYING_SPEECH", 0x79D2F0E66F81D90Dull}, {"STOP_PED_SPEAKING", 0x9D64D7405520E3D3ull},
    {"GET_PED_SOURCE_OF_DEATH", 0x93C8B64DEB84728Cull}, {"GIVE_WEAPON_TO_PED", 0x5E3BDDBCB83F3D84ull},
    {"TASK_FOLLOW_NAV_MESH_TO_COORD", 0x15D3A79D4E44B913ull},
    {"CREATE_PED", 0xD49F9B0955C367DEull},
    {"CREATE_OBJECT", 0x509D5878EB39E842ull},
    {"CREATE_VEHICLE", 0xAF35D0D2583051B0ull},
    {"REQUEST_MODEL", 0xFA28FE3A6246FC30ull},
    {"HAS_MODEL_LOADED", 0x1283B8B89DD5D1B6ull},
    {"IS_MODEL_IN_CDIMAGE", 0xD6F3B6D7716CFF8Eull},
    {"SET_MODEL_AS_NO_LONGER_NEEDED", 0x4AD96EF928BD4F9Aull},
    {"_SET_RANDOM_OUTFIT_VARIATION", 0x283978A15512B2FEull},
    {"PLACE_OBJECT_ON_GROUND_PROPERLY", 0x58A850EAEE20FAA3ull},
    {"GET_GROUND_Z_FOR_3D_COORD", 0x24FA4267BB8D2431ull},
    {"GET_WATER_HEIGHT_NO_WAVES", 0xDCF3690AA262C03Full},
    {"BLIP_ADD_FOR_COORDS", 0x554D9D53F696D002ull},
    {"SET_BLIP_SPRITE", 0x74F74D3207ED525Cull},
    {"_SET_BLIP_NAME", 0x9CB1A1623062F402ull},
    {"REMOVE_BLIP", 0xF2C3C9DA47AAA54Aull},
    {"START_GPS_MULTI_ROUTE", 0x3D3D15AF7BCAAF83ull},
    {"ADD_POINT_TO_GPS_MULTI_ROUTE", 0x64C59DD6834FA942ull},
    {"SET_GPS_MULTI_ROUTE_RENDER", 0x4426D65E029A4DC0ull},
    {"CLEAR_GPS_MULTI_ROUTE", 0x9E0AB9AAEE87CE28ull},
    {"DELETE_ENTITY", 0x4CD38C78BD19A497ull},
    {"SET_ENTITY_HEALTH", 0xAC2767ED8BDFAB15ull},
    {"SET_ENTITY_INVINCIBLE", 0xA5C38736C426FCB8ull},
    {"TASK_KNOCKED_OUT_AND_HOGTIED", 0x42AC6401ABB8C7E5ull},
    {"UNHOGTIE_PED", 0x79559BAD83CCD038ull},
    {"SET_ENTITY_HEADING", 0xCF2B9C0645C4651Bull},
    {"IS_CONTROL_PRESSED", 0xF3A21BCD95725A4Aull}, {"IS_DISABLED_CONTROL_PRESSED", 0xE2587F8CBBD87B1Dull},
    {"IS_PED_IN_MELEE_COMBAT", 0x4E209B2C1EAD5159ull},
    {"DISABLE_CONTROL_ACTION", 0xFE99B66D079CF6BCull}, {"VAR_STRING", 0xFA925AC00EB830B9ull},
    {"_DISPLAY_TEXT", 0xD79334A4BB99BAD1ull}, {"_SET_TEXT_COLOR", 0x50A41AD966910F03ull},
    {"SET_TEXT_SCALE(BH)", 0x4170B650590B3B00ull}, {"HAS_ENTITY_BEEN_DAMAGED_BY_ENTITY", 0x7B6E7BEC1143AC86ull},
    {"CLEAR_ENTITY_LAST_DAMAGE_ENTITY", 0xBB19AC7D4DCEFD0Full}, {"HAS_ENTITY_CLEAR_LOS_TO_ENTITY", 0xFCDFF7B72D23A1ACull},
    {"_GET_PED_META_OUTFIT_HASH", 0x30569F348D126A5Aull}, {"SET_FACIAL_IDLE_ANIM_OVERRIDE", 0xFFC24B988B938B38ull},
    {"CLEAR_FACIAL_IDLE_ANIM_OVERRIDE", 0x726256CC1EEB182Full}, {"_REQUEST_PED_FACIAL_MOOD_THIS_FRAME", 0x8B3B71C80A29A4BBull},
    {"_IS_THIS_MODEL_A_HORSE", 0x772A1969F649E902ull}, {"_GET_RIDER_OF_MOUNT", 0xB676EFDA03DADA52ull},
    {"_IS_MOUNT_SEAT_FREE", 0xAAB0FE202E9FC9F0ull}, {"IS_VEHICLE_SEAT_FREE", 0xE052C1B1CAA4ECE4ull},
    {"GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS", 0xA9C55F1C15E62E06ull}, {"GET_HASH_KEY", 0xFD340785ADF8CFB7ull},
    {"CLEAR_PED_SECONDARY_TASK", 0x176CECF6F920D707ull}, {"IS_ENTITY_A_MISSION_ENTITY", 0x138190F64DB4BBD1ull},
    {"IS_PED_CARRYING_SOMETHING", 0xA911EE21EDF69DAFull}, {"_GET_FIRST_ENTITY_PED_IS_CARRYING", 0xD806CD2A4F2C2996ull},
    // 0.3.2: order keeper (forced mount/seat as the last resort) + the law
    {"SET_PED_ONTO_MOUNT", 0x028F76B6E78246EBull}, {"SET_PED_INTO_VEHICLE", 0xF75B0D629E1C063Dull},
    {"SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE", 0x7A6535691B477C48ull}, {"_REPORT_CRIME", 0xF60386770878A98Full},
    // 0.4.0: drivers that really stop / drive where you say, scenarios that are verified, real seats nearby
    {"BRING_VEHICLE_TO_HALT", 0x260BE8F09E326A20ull}, {"STOP_BRINGING_VEHICLE_TO_HALT", 0x7C06330BFDDA182Eull},
    {"TASK_VEHICLE_DRIVE_TO_COORD", 0xE2A2AA2F659D77A7ull}, {"SET_DRIVE_TASK_CRUISE_SPEED", 0x5C9B84BD7D31D908ull},
    {"IS_WAYPOINT_ACTIVE", 0x202B1BBFC6AB5EE4ull}, {"GET_WAYPOINT_COORDS", 0x29B30D07C3F7873Bull},
    {"IS_THIS_MODEL_A_TRAIN", 0xFC08C8F8C1EDF174ull}, {"GET_PED_IN_VEHICLE_SEAT", 0xBB40DD2270B65366ull},
    {"GET_ENTITY_HEADING", 0xC230DD956E2F5507ull}, {"IS_PED_IN_VEHICLE", 0xA3EE4A07279BB9DBull},
    {"IS_PED_USING_SCENARIO_HASH", 0x34D6AC1157C8226Cull}, {"TASK_USE_NEAREST_SCENARIO_TO_COORD", 0x322BFDEA666E2B0Eull},
    {"DOES_SCENARIO_EXIST_IN_AREA", 0x5A59271FFADD33C1ull}, {"_GET_SCENARIO_POINT_TYPE_PED_IS_USING", 0x2D0571BB55879DA2ull},
    // 0.5.0: undress / dress - the same calls "Unstrip" makes (read from its code); hookup scenes seen by their clip
    {"_GET_NUM_COMPONENT_CATEGORIES_IN_PED", 0xA622E66EEE92A08Dull}, {"_GET_PED_COMPONENT_CATEGORY_BY_INDEX", 0xCCB97B51893C662Full},
    {"REMOVE_TAG_FROM_META_PED", 0xD710A5007C2AC539ull}, {"_SET_META_PED_TAG", 0xBC6DF00D7A4A6819ull},
    {"GET_META_PED_ASSET_GUIDS", 0xA9C28516A6DC9D56ull}, {"GET_META_PED_ASSET_TINT", 0xE7998FEC53A33BBEull},
    {"_UPDATE_PED_VARIATION", 0xCC8CA3E88256E58Full}, {"IS_ENTITY_PLAYING_ANIM", 0xDEE49D5CA6C49148ull},
    // 0.5.1: pain you can hear, families with one skin tone, the game's own wanted state, couples on a real bed
    {"PLAY_PAIN", 0xBC9AE166038A5CECull}, {"GET_NUM_META_PED_OUTFITS", 0x10C70A515BC03707ull},
    {"_EQUIP_META_PED_OUTFIT_PRESET", 0x77FF8D35EEC6BBC4ull}, {"GET_PLAYER_WANTED_LEVEL", 0xABC532F9098BFD9Dull},
    {"TASK_PLAY_ANIM_ADVANCED", 0x83CDB10EA29B370Bull}, {"GET_CLOSEST_OBJECT_OF_TYPE", 0xE143FA2249364369ull},
    {"STOP_ANIM_TASK", 0x97FF36A1D40EA00Aull}, {"SET_ENTITY_COORDS", 0x06843DA7060A026Bull},
    {"CLEAR_PED_TASKS_IMMEDIATELY", 0xAAA34F8A7CB32098ull}, {"TASK_GO_TO_COORD_ANY_MEANS", 0x5BC448CB78FA3E88ull},
    {"TASK_LEAVE_VEHICLE", 0xD3DBCE61A490BE02ull}, {"GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS", 0x1899F328B0E12848ull},
    // 0.5.3: beds inside houses are map furniture, not objects - their SLEEPING SPOTS (scenario points) are findable
    {"GET_SCENARIO_POINTS_IN_AREA", 0x345EC3B7EBDE1CB5ull}, {"_GET_SCENARIO_POINT_COORDS", 0xA8452DD321607029ull},
    {"_GET_SCENARIO_POINT_HEADING", 0xB93EA7184BAA85C3ull}, {"_GET_SCENARIO_POINT_TYPE", 0xA92450B5AE687AAFull},
    // 0.5.6: type instead of talk (the game's own on-screen keyboard)
    {"DISPLAY_ONSCREEN_KEYBOARD", 0x044131118D8DB3CDull}, {"UPDATE_ONSCREEN_KEYBOARD", 0x37DF360F235A3893ull},
    {"GET_ONSCREEN_KEYBOARD_RESULT", 0xAFB4CF58A4A292B1ull}, {"CANCEL_ONSCREEN_KEYBOARD", 0x58A39BE597CE99CDull},
    // households: someone already at the stove / at the table when you walk in (the game's own warp-into-scenario)
    {"TASK_USE_NEAREST_SCENARIO_TO_COORD_WARP", 0x58E2E0F23F6B76C3ull},
    // 0.5.7: who is going through this person's pockets right now (the player looting someone tied up / knocked down)
    {"_FIND_ENTITY_LOOTING_PED", 0xEF2D9ED7CE684F08ull}, {"_GET_IS_PED_BEING_ROBBED", 0xE33F98BD76490ABCull},
    // 0.5.8: love scenes the way NpcHookups really does them (read from its code): the lower partner plays the clip in
    // place, the upper one is ATTACHED to the lower one's hip bone with the original scene's numbers
    {"ATTACH_ENTITY_TO_ENTITY", 0x6B9BBD38AB0796DFull}, {"DETACH_ENTITY", 0x64CDE9D6BF8ECAD3ull},
    {"GET_PED_BONE_INDEX", 0x3F428D08BE5AAE31ull}, {"GET_ENTITY_BONE_INDEX_BY_NAME", 0xBACA8FE9C76C124Eull},
    {"SET_ENTITY_COORDS_NO_OFFSET", 0x239A3351AC1DA385ull}, {"SET_ENTITY_COLLISION", 0xF66F820909453B8Cull},
    {"SET_ENTITY_NO_COLLISION_ENTITY", 0xE037BF068223C38Dull}, {"SET_PED_CAN_RAGDOLL", 0xB128377056A54E2Aull},
    {"IS_ENTITY_ATTACHED_TO_ENTITY", 0x154A3C529497053Eull}, {"SET_ENTITY_VELOCITY", 0x1C99BB7B6E96D16Full},
    // 0.5.8: undress only once the new ped's look has streamed in (NpcHookups' WaitReady does the same)
    {"IS_PED_READY_TO_RENDER", 0xA0BC8FAED8CFEB3Cull},
};

// crash guard for first-time native calls
static char g_guardPath[MAX_PATH];
static std::vector<std::string> g_disabledAtStart;
static void guard_begin(const NativeDef& d) {
    FILE* f = fopen(g_guardPath, "wb");
    if (f) { fprintf(f, "PENDING %s 0x%016llX\n", d.name, (unsigned long long)d.hash); fflush(f); fclose(f); }
    LD("first call of native %s 0x%016llX", d.name, (unsigned long long)d.hash);
}
static void guard_end() { FILE* f = fopen(g_guardPath, "wb"); if (f) fclose(f); }

static inline void push(uint64_t v) { nativePush64(v); }
static inline void push(int v) { nativePush64((uint64_t)(int64_t)v); }
static inline void push(unsigned v) { nativePush64((uint64_t)v); }
static inline void push(bool v) { nativePush64(v ? 1 : 0); }
static inline void push(float f) { uint64_t v = 0; memcpy(&v, &f, sizeof f); nativePush64(v); }
static inline void push(double d) { push((float)d); }
static inline void push(const char* s) { nativePush64((uint64_t)(uintptr_t)s); }
template <typename T> static inline void push(T* p) { nativePush64((uint64_t)(uintptr_t)p); }

static uint64_t g_zero[4] = {0, 0, 0, 0};
template <typename... A> static uint64_t* invoke(int id, A... args) {   // args are already evaluated here
    NativeDef& d = g_nat[id];
    if (d.disabled) { g_zero[0] = g_zero[1] = g_zero[2] = g_zero[3] = 0; return g_zero; }
    bool first = !d.used;
    if (first) guard_begin(d);
    nativeInit(d.hash);
    (push(args), ...);
    uint64_t* r = nativeCall();
    if (first) { guard_end(); d.used = true; }
    return r ? r : g_zero;
}
template <typename... A> static void CallV(int id, A... a) { invoke(id, a...); }
template <typename... A> static int CallI(int id, A... a) { return (int)*invoke(id, a...); }
template <typename... A> static uint32_t CallH(int id, A... a) { return (uint32_t)*invoke(id, a...); }
template <typename... A> static bool CallB(int id, A... a) { return ((uint32_t)*invoke(id, a...)) != 0; }
template <typename... A> static float CallF(int id, A... a) { return *(float*)invoke(id, a...); }
template <typename... A> static Vector3 CallVec(int id, A... a) { return *(Vector3*)invoke(id, a...); }
template <typename... A> static const char* CallS(int id, A... a) { return (const char*)(uintptr_t)*invoke(id, a...); }

static uint32_t joaat(const char* s) {
    uint32_t h = 0;
    for (; *s; ++s) { char c = *s; if (c >= 'A' && c <= 'Z') c += 32; h += (uint8_t)c; h += h << 10; h ^= h >> 6; }
    h += h << 3; h ^= h >> 11; h += h << 15; return h;
}

// ───────────────────────── small helpers ─────────────────────────
static uint64_t now_ms() { return GetTickCount64(); }
static float dist3(const Vector3& a, const Vector3& b) {
    float dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z; return sqrtf(dx * dx + dy * dy + dz * dz);
}
static void json_str(std::string& o, const char* s) {
    o += '"';
    for (; s && *s; ++s) {
        unsigned char c = (unsigned char)*s;
        if (c == '"' || c == '\\') { o += '\\'; o += (char)c; }
        else if (c < 32) { char b[8]; snprintf(b, sizeof b, "\\u%04x", c); o += b; }
        else o += (char)c;
    }
    o += '"';
}
static void jkv(std::string& o, const char* k, double v, bool comma = true) {
    char b[64];
    if (v == (double)(long long)v) snprintf(b, sizeof b, "\"%s\":%lld", k, (long long)v);
    else snprintf(b, sizeof b, "\"%s\":%.3f", k, v);
    if (comma) o += ','; o += b;
}

// ───────────────────────── networking ─────────────────────────
// A dedicated thread owns the socket and uses plain BLOCKING calls. The game's script fiber never touches
// Winsock: it only swaps two queues under a lock. (Real-game finding, 0.1.2: inside RDR2 a non-blocking
// connect() returned failure with WSAGetLastError()==0 - something in the process wraps Winsock and wipes
// the error code - so the "in progress" handshake could never be recognised.)
static CRITICAL_SECTION g_netcs;
static std::vector<std::string> g_inbox;      // lines from the brain (+ "\x01connected"/"\x01disconnected")
static std::string g_outbox;                  // bytes to send
static volatile bool g_netUp = false;         // set by the net thread
static volatile bool g_quit = false;
static bool g_connected = false;              // as seen by the script thread
static uint64_t g_lostAt = 0;
static bool g_helloAck = false;
static int g_connAttempts = 0;
static char g_netErrText[160] = "not tried yet";
static HANDLE g_netThread = nullptr;
static volatile unsigned long g_frames = 0;      // script frames: stops moving when the game is frozen/paused
static void alive_beat(uint64_t& next) {
    uint64_t t = GetTickCount64();
    if (t < next || !g_netUp) return;
    next = t + 500;
    char b[96]; snprintf(b, sizeof b, "{\"t\":\"alive\",\"f\":%lu}\n", (unsigned long)g_frames);
    EnterCriticalSection(&g_netcs); g_outbox += b; LeaveCriticalSection(&g_netcs);
}

static const char* wsa_name(int e) {
    switch (e) {
    case 10061: return "connection refused (brain not listening on this port?)";
    case 10013: return "access denied (firewall/antivirus blocked it)";
    case 10060: return "timed out";
    case 10093: return "Winsock not initialised";
    case 10048: return "address in use";
    case 10049: return "address not available";
    case 10065: return "host unreachable";
    case 0: return "no error code given";
    default: return "see Windows error list";
    }
}
static void net_err(const char* where, int err) {
    char b[160]; snprintf(b, sizeof b, "%s failed: error %d = %s", where, err, wsa_name(err));
    EnterCriticalSection(&g_netcs); snprintf(g_netErrText, sizeof g_netErrText, "%s", b); LeaveCriticalSection(&g_netcs);
    if (g_connAttempts <= 5 || g_connAttempts % 30 == 0) LW("brain connection attempt %d: %s", g_connAttempts, b);
}
static void inbox_push(const std::string& l) { EnterCriticalSection(&g_netcs); g_inbox.push_back(l); LeaveCriticalSection(&g_netcs); }

static DWORD WINAPI net_thread(LPVOID) {
    bool wsa = false;
    while (!g_quit) {
        if (!wsa) {
            WSADATA wd; int r = WSAStartup(MAKEWORD(2, 2), &wd);
            if (r) { LE("WSAStartup failed: %d", r); Sleep(3000); continue; }
            wsa = true; LI("net thread: Winsock ready (%d.%d), target 127.0.0.1:%d", LOBYTE(wd.wVersion), HIBYTE(wd.wVersion), g_cfg.port);
        }
        ++g_connAttempts;
        SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (s == INVALID_SOCKET) {
            int e = WSAGetLastError(); net_err("socket()", e);
            if (e == WSANOTINITIALISED) { wsa = false; LW("Winsock was shut down by someone else - starting it again"); }
            Sleep(2000); continue;
        }
        sockaddr_in a{}; a.sin_family = AF_INET; a.sin_port = htons((u_short)g_cfg.port); a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        if (g_connAttempts <= 5 || g_connAttempts % 30 == 0) LI("brain connection attempt %d -> 127.0.0.1:%d (blocking, net thread)", g_connAttempts, g_cfg.port);
        int cr = connect(s, (sockaddr*)&a, sizeof a);
        int ce = cr == 0 ? 0 : WSAGetLastError();
        if (cr != 0) {
            // trust the socket, not the (possibly wiped) error code: are we actually connected?
            sockaddr_in peer{}; int pl = sizeof peer;
            if (getpeername(s, (sockaddr*)&peer, &pl) == 0) { LW("connect() reported failure (error %d) but the socket IS connected - continuing", ce); cr = 0; }
        }
        if (cr != 0) {
            net_err("connect()", ce);
            if (ce == WSANOTINITIALISED) wsa = false;
            closesocket(s); Sleep(2000); continue;
        }
        int one = 1; setsockopt(s, IPPROTO_TCP, TCP_NODELAY, (const char*)&one, sizeof one);
        DWORD tmo = 40; setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tmo, sizeof tmo);
        LI("connected to brain on port %d after %d attempt(s)", g_cfg.port, g_connAttempts);
        g_connAttempts = 0;
        g_netUp = true; inbox_push("\x01" "connected");
        std::string rx, tx; char buf[8192]; const char* why = "?"; uint64_t nextAlive = 0;
        while (!g_quit) {
            alive_beat(nextAlive);
            EnterCriticalSection(&g_netcs); tx.swap(g_outbox); LeaveCriticalSection(&g_netcs);
            size_t off = 0; bool bad = false;
            while (off < tx.size()) {
                int n = send(s, tx.data() + off, (int)std::min<size_t>(tx.size() - off, 65536), 0);
                if (n <= 0) { why = "send error"; bad = true; LW("send failed: %d", WSAGetLastError()); break; }
                off += n;
            }
            tx.clear();
            if (bad) break;
            int n = recv(s, buf, sizeof buf, 0);
            if (n > 0) {
                rx.append(buf, n);
                size_t pos;
                while ((pos = rx.find('\n')) != std::string::npos) {
                    std::string line = rx.substr(0, pos); rx.erase(0, pos + 1);
                    if (!line.empty() && line.back() == '\r') line.pop_back();
                    if (!line.empty()) inbox_push(line);
                }
            } else if (n == 0) { why = "closed by brain"; break; }
            else {
                int e = WSAGetLastError();
                if (e == WSAETIMEDOUT || e == 0) continue;   // just the 40 ms poll timeout
                why = "recv error"; LW("recv failed: %d", e); break;
            }
        }
        closesocket(s);
        g_netUp = false; inbox_push("\x01" "disconnected");
        LW("brain connection closed (%s)", why);
        Sleep(1000);
    }
    return 0;
}

// ── file link: no sockets at all ──
// session.txt (ASI) names the session; a2b_<sid>_<seg>.txt = game->brain lines, b2a_<sid>_<seg>.txt = brain->game.
// Writers only append; readers delete a segment once the next one exists. brain_alive.txt = "<sid> <ms>" heartbeat.
static char g_linkDir[MAX_PATH] = "";
static void link_path(char* out, const char* name) { snprintf(out, MAX_PATH, "%s\\%s", g_linkDir, name); }
static bool file_age_ms(const char* p, uint64_t& age) {
    WIN32_FILE_ATTRIBUTE_DATA fa;
    if (!GetFileAttributesExA(p, GetFileExInfoStandard, &fa)) return false;
    FILETIME now; GetSystemTimeAsFileTime(&now);
    ULARGE_INTEGER a, b; a.LowPart = fa.ftLastWriteTime.dwLowDateTime; a.HighPart = fa.ftLastWriteTime.dwHighDateTime;
    b.LowPart = now.dwLowDateTime; b.HighPart = now.dwHighDateTime;
    age = b.QuadPart > a.QuadPart ? (b.QuadPart - a.QuadPart) / 10000 : 0; return true;
}
static void link_cleanup(const char* pattern) {
    char pat[MAX_PATH]; link_path(pat, pattern);
    WIN32_FIND_DATAA fd; HANDLE h = FindFirstFileA(pat, &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do { char p[MAX_PATH]; link_path(p, fd.cFileName); DeleteFileA(p); } while (FindNextFileA(h, &fd));
    FindClose(h);
}
static DWORD WINAPI link_thread(LPVOID) {
    char env[MAX_PATH] = "";
    if (GetEnvironmentVariableA("NPCVOICE_LINK_DIR", env, MAX_PATH) && env[0]) snprintf(g_linkDir, MAX_PATH, "%s", env);
    else {
        char la[MAX_PATH] = "";
        if (!GetEnvironmentVariableA("LOCALAPPDATA", la, MAX_PATH)) snprintf(la, MAX_PATH, "%s", g_dir);
        char base[MAX_PATH]; snprintf(base, MAX_PATH, "%s\\NpcVoice", la); CreateDirectoryA(base, nullptr);
        snprintf(g_linkDir, MAX_PATH, "%s\\link", base);
    }
    CreateDirectoryA(g_linkDir, nullptr);
    unsigned long long sid = (GetTickCount64() ^ ((unsigned long long)GetCurrentProcessId() << 20)) & 0xFFFFFFFFFFull;
    link_cleanup("a2b_*.txt"); link_cleanup("b2a_*.txt");
    char p[MAX_PATH], tmp[MAX_PATH];
    link_path(p, "session.txt"); link_path(tmp, "session.tmp");
    FILE* f = fopen(tmp, "wb"); if (f) { fprintf(f, "%llu\n", sid); fclose(f); }
    MoveFileExA(tmp, p, MOVEFILE_REPLACE_EXISTING);
    LI("file link: folder %s, session %llu", g_linkDir, sid);
    EnterCriticalSection(&g_netcs); snprintf(g_netErrText, sizeof g_netErrText, "no answer from the brain in %s", g_linkDir); LeaveCriticalSection(&g_netcs);
    int wseg = 0, rseg = 0; long long roff = 0; std::string rx, tx;
    char wp[MAX_PATH]; char nm[64];
    snprintf(nm, sizeof nm, "a2b_%llu_%d.txt", sid, wseg); link_path(wp, nm);
    FILE* w = fopen(wp, "ab");
    bool up = false; uint64_t lastLog = 0, nextAlive = 0;
    while (!g_quit) {
        alive_beat(nextAlive);
        // brain heartbeat: must name OUR session and be fresh
        // tolerant: a heartbeat we can't read this instant keeps the previous state; lost only after 8 s
        bool alive = up; uint64_t age = 0;
        link_path(p, "brain_alive.txt");
        if (!file_age_ms(p, age)) alive = false;
        else if (age > 8000) alive = false;
        else {
            FILE* hb = fopen(p, "rb");
            if (hb) {
                unsigned long long s2 = 0;
                if (fscanf(hb, "%llu", &s2) == 1) alive = (s2 == sid);
                fclose(hb);
            }
        }
        if (alive != up) {
            up = alive; g_netUp = up;
            if (up) { LI("file link: brain is serving our session - connected"); inbox_push("\x01" "connected"); }
            else { LW("file link: brain heartbeat lost"); inbox_push("\x01" "disconnected"); }
        } else if (!up && GetTickCount64() - lastLog > 30000) { lastLog = GetTickCount64(); LI("file link: waiting for the brain (heartbeat in %s)", g_linkDir); }
        // send
        EnterCriticalSection(&g_netcs); tx.swap(g_outbox); LeaveCriticalSection(&g_netcs);
        if (!tx.empty() && w) {
            fwrite(tx.data(), 1, tx.size(), w); fflush(w); tx.clear();
            if (ftell(w) > 1000000) {
                fclose(w); ++wseg; snprintf(nm, sizeof nm, "a2b_%llu_%d.txt", sid, wseg); link_path(wp, nm); w = fopen(wp, "ab");
            }
        }
        // receive
        snprintf(nm, sizeof nm, "b2a_%llu_%d.txt", sid, rseg); link_path(p, nm);
        bool got = false;
        FILE* r = fopen(p, "rb");
        if (r) {
            if (_fseeki64(r, roff, SEEK_SET) == 0) {
                char buf[16384]; size_t n;
                while ((n = fread(buf, 1, sizeof buf, r)) > 0) { rx.append(buf, n); roff += n; got = true; }
            }
            fclose(r);
            size_t pos;
            while ((pos = rx.find('\n')) != std::string::npos) {
                std::string line = rx.substr(0, pos); rx.erase(0, pos + 1);
                if (!line.empty() && line.back() == '\r') line.pop_back();
                if (!line.empty() && up) inbox_push(line);
            }
            if (!got) {
                char np[MAX_PATH]; snprintf(nm, sizeof nm, "b2a_%llu_%d.txt", sid, rseg + 1); link_path(np, nm);
                if (GetFileAttributesA(np) != INVALID_FILE_ATTRIBUTES) { DeleteFileA(p); ++rseg; roff = 0; }
            }
        }
        Sleep(15);
    }
    if (w) fclose(w);
    return 0;
}

static void net_send(const std::string& line) {
    if (!g_connected) return;
    EnterCriticalSection(&g_netcs);
    if (g_outbox.size() > 512 * 1024) g_outbox.clear();
    g_outbox += line; g_outbox += '\n';
    LeaveCriticalSection(&g_netcs);
}
static void send_hello();
static void net_poll(void (*on_line)(char*)) {
    if (!g_netThread) {
        bool file = _stricmp(g_cfg.transport, "tcp") != 0;
        g_netThread = CreateThread(nullptr, 0, file ? link_thread : net_thread, nullptr, 0, nullptr);
        LI("%s thread %s", file ? "file link" : "net", g_netThread ? "started" : "COULD NOT START");
    }
    std::vector<std::string> in;
    EnterCriticalSection(&g_netcs); in.swap(g_inbox); LeaveCriticalSection(&g_netcs);
    for (auto& l : in) {
        if (l == "\x01" "connected") { g_connected = true; g_lostAt = 0; send_hello(); continue; }
        if (l == "\x01" "disconnected") {
            if (g_connected) { g_lostAt = now_ms(); LW("brain disconnected"); }
            g_connected = false; g_helloAck = false;
            EnterCriticalSection(&g_netcs); g_outbox.clear(); LeaveCriticalSection(&g_netcs);
            continue;
        }
        std::vector<char> v(l.begin(), l.end()); v.push_back(0); on_line(v.data());
    }
}

// ───────────────────────── on-screen text ─────────────────────────
struct Toast { std::string text; uint64_t until; int r, g, b; };
static std::vector<Toast> g_toasts;
static void toast(const char* lvl, int ms, const char* text) {
    int r = 255, g = 255, b = 255;
    if (!strcmp(lvl, "err")) { r = 255; g = 90; b = 80; }
    else if (!strcmp(lvl, "warn")) { r = 255; g = 205; b = 70; }
    else if (!strcmp(lvl, "ok")) { r = 120; g = 230; b = 120; }
    g_toasts.push_back({std::string("NpcVoice: ") + text, now_ms() + (uint64_t)std::max(1000, ms), r, g, b});
    if (g_toasts.size() > 5) g_toasts.erase(g_toasts.begin());
    LI("[SCREEN %s] %s", lvl, text);
}
static void draw_text(const char* text, float x, float y, float scale, int r, int g, int b, int a = 230) {
    // arguments for each native are fully evaluated before its call (no nested native calls)
    CallV(SET_TEXT_SCALE, scale, scale);
    CallV(SET_TEXT_COLOR, r, g, b, a);
    const char* vs = CallS(VAR_STRING, 10, "LITERAL_STRING", text);
    CallV(DISPLAY_TEXT, vs, x, y);
}
static float text_width(size_t chars, float scale) { return chars * 0.0105f * (scale / 0.5f); }

// ───────────────────────── managed peds ─────────────────────────
enum Hold { H_NONE, H_FOOT, H_MOUNT, H_VEHICLE, H_SCENARIO, H_RESTRAINED, H_BUSY, H_COMPANION };
static const char* HOLD_NAME[] = {"none", "foot", "mount", "vehicle", "scenario", "restrained", "busy", "companion"};
struct Managed {
    int ped = 0;
    bool engaged = false, keep = false, overridden = false, blocked = false, persist = false;
    Hold hold = H_NONE;
    char name[64] = "";
    char hud[128] = "";
    uint64_t lookAt = 0, speechStop = 0, handsUpRefresh = 0, engagedAt = 0;
    bool handsUp = false;
    bool actor = false;           // part of an NPC-to-NPC scene run by the brain
    // talking
    uint64_t talkUntil = 0, moodUntil = 0; uint32_t talkMood = 0, emoMood = 0; bool faceOverride = false;
    std::string subtitle;
    int state = 0;  // 0 idle, 1 thinking
    bool damagedFlag = false;
    uint64_t painUntil = 0;       // 0.5.1: don't mute their voice while they scream
    bool wasAimed = false;
    // order keeper (0.3.2): an order the game's own AI is not allowed to undo (dismounted stays off the horse,
    // a passenger stays on, a rider gets on). Checked every 400 ms; the last resort is a forced seat.
    int order = 0;                // O_NONE / O_FOOT / O_MOUNT / O_RIDE / O_VEH
    int oTarget = 0, oSeat = -1, oTries = 0;
    uint64_t oSince = 0, oNext = 0, oFollowAt = 0;
    bool oSettled = false, oFollowDone = true, oNoKnock = false;
    // vehicles (0.4.0): a driver you stopped stays stopped; a driver you sent somewhere goes there
    int vHalt = 0, vDrive = 0; uint64_t vNext = 0; float vDestX = 0, vDestY = 0, vDestZ = 0;
};
enum Order { O_NONE, O_FOOT, O_MOUNT, O_RIDE, O_VEH, O_OUT };
static const char* ORDER_NAME[] = {"none", "stay-off-the-horse", "get-on-a-horse", "ride-with-player", "ride-in-wagon",
                                   "get-off-the-wagon"};
static std::vector<Managed> g_peds;
static Managed* find_m(int ped) { for (auto& m : g_peds) if (m.ped == ped) return &m; return nullptr; }

static int g_player = 0, g_playerId = 0;
static Vector3 g_ppos{};
static int g_focus = 0, g_lastFocus = 0;
static uint64_t g_focusSeen = 0;
static bool g_ptt = false;
static int g_pttPed = 0;
static int g_pendingEngage = 0; static uint64_t g_pendingSince = 0;
static int g_engaged = 0;     // currently talked-to ped
static HANDLE g_hookEvt = nullptr; static uint64_t g_hookCheck = 0; static int g_hookState = -1;
static int (*g_fakeKey)(int) = nullptr;   // test rig only (exported by the fake ScriptHook DLL)

static bool ped_ok(int ped) { return ped && CallB(DOES_ENTITY_EXIST, ped); }
static bool player_weapon_threat();
static void mute_vanilla(int ped);

static int veh_of(int ped); static bool is_driver(int ped, int veh); static bool is_tram(int veh);
static void veh_halt(Managed& m, int veh);
static bool in_couple_scene(int ped);
static int in_hookup(int ped);
// 0.5.5: in ANY love scene - NpcVoice's own or one NpcHookups / NpcHookupsPlus started with their keys
static bool in_love(int ped) { return in_couple_scene(ped) || in_hookup(ped) != 0; }
static void apply_hold(Managed& m) {
    int ped = m.ped;
    if (in_love(ped)) {                  // 0.5.5: talking to someone in the middle of it doesn't stop it
        m.hold = H_SCENARIO;
        CallV(TASK_LOOK_AT_ENTITY, ped, g_player, 4000, 2048, 3, 0); m.lookAt = now_ms() + 3000;
        LI("hold ped=%d kind=in-a-love-scene (nothing interrupted)", ped);
        return;
    }
    bool hog = CallB(IS_PED_HOGTIED, ped), las = CallB(IS_PED_LASSOED, ped), rag = CallB(IS_PED_RAGDOLL, ped);
    bool flee = CallB(IS_PED_FLEEING, ped), comb = CallB(IS_PED_IN_COMBAT, ped, g_player);
    bool mnt = CallB(IS_PED_ON_MOUNT, ped), veh = CallB(IS_PED_IN_ANY_VEHICLE, ped, false);
    bool scen = CallB(IS_PED_USING_ANY_SCENARIO, ped), sit = CallB(IS_PED_SITTING, ped);
    if (m.keep) m.hold = H_COMPANION;
    else if (hog || las || rag) m.hold = H_RESTRAINED;
    else if (flee || comb) m.hold = H_BUSY;
    else if (mnt) m.hold = H_MOUNT;
    else if (veh) m.hold = H_VEHICLE;
    else if (scen || sit) m.hold = H_SCENARIO;
    else m.hold = H_FOOT;
    LI("hold ped=%d kind=%s (hog=%d lasso=%d rag=%d flee=%d combat=%d mount=%d veh=%d scen=%d sit=%d)",
       ped, HOLD_NAME[m.hold], hog, las, rag, flee, comb, mnt, veh, scen, sit);
    switch (m.hold) {
    case H_FOOT: CallV(TASK_TURN_PED_TO_FACE_ENTITY, ped, g_player, -1, 0.f, 0.f, 0.f); break;
    case H_MOUNT: CallV(TASK_TURN_PED_TO_FACE_ENTITY, ped, g_player, -1, 0.f, 0.f, 0.f); break;
    case H_VEHICLE: {
        int v = veh_of(ped);
        if (is_driver(ped, v) && !is_tram(v)) { veh_halt(m, v); LI("hold ped=%d: driver - wagon %d brought to a halt", ped, v); }
        else LI("hold ped=%d: %s - left as is", ped, is_tram(v) ? "streetcar driver (rails)" : "passenger");
        break; }
    default: break;
    }
    if (m.hold != H_BUSY && m.hold != H_COMPANION) { CallV(SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, ped, true); m.blocked = true; }
    CallV(TASK_LOOK_AT_ENTITY, ped, g_player, 4000, 2048, 3, 0);
    m.lookAt = now_ms() + 3000;
}

static void engage(int ped, const char* name) {
    if (!ped_ok(ped) || CallB(IS_ENTITY_DEAD, ped)) {
        LW("engage_ok for ped %d but it is gone/dead", ped);
        std::string o = "{\"t\":\"event\",\"kind\":\"engage_fail\""; jkv(o, "ped", ped); o += "}"; net_send(o);
        return;
    }
    Managed* m = find_m(ped);
    if (!m) { g_peds.push_back(Managed{}); m = &g_peds.back(); m->ped = ped; }
    snprintf(m->name, sizeof m->name, "%s", name);
    if (!m->engaged) {
        m->engaged = true; m->overridden = false; m->engagedAt = now_ms();
        apply_hold(*m);
        if (g_cfg.stopAmbientSpeech && !in_love(ped)) { CallV(STOP_PED_SPEAKING, ped, true); mute_vanilla(ped); }
    }
    if (g_engaged && g_engaged != ped) {
        Managed* o = find_m(g_engaged);
        if (o) { CallV(TASK_LOOK_AT_ENTITY, o->ped, g_player, 1500, 2048, 3, 0); }
    }
    g_engaged = ped;
    LI("engaged ped=%d name='%s' hold=%s", ped, m->name, HOLD_NAME[m->hold]);
}

static void mute_vanilla(int ped) {      // the game's own voice lines for this character
    CallV(STOP_CURRENT_PLAYING_AMBIENT_SPEECH, ped, 0);
    CallV(STOP_CURRENT_PLAYING_SPEECH, ped, 0);
}
static void stop_talk(Managed& m) {
    m.talkUntil = 0; m.subtitle.clear();
    if (m.faceOverride) { CallV(CLEAR_FACIAL_IDLE_ANIM_OVERRIDE, m.ped); m.faceOverride = false; }
}

// ───────────────────────── order keeper (0.3.2) ─────────────────────────
// A script task in RDR2 only lasts until it finishes; then the ped's own AI picks its next move. A rider who was
// told to dismount finishes TASK_DISMOUNT_ANIMAL, has nothing left to do and his ambient brain puts him straight
// back on his horse. An emote or a gesture played on top of TASK_MOUNT_ANIMAL replaces it. So every order that
// changes how someone travels is KEPT here: after it's done they get a follow-up task (face the player), and if
// the game undoes it (back in the saddle, thrown off, never got on) it's issued again; the last resort is a forced
// seat (SET_PED_ONTO_MOUNT / SET_PED_INTO_VEHICLE - the same thing the game does when a mount task times out).
static void send_event(const char* kind, int ped, const char* why = nullptr);
static void order_set(Managed& m, int order, int target, int seat) {
    if (m.oNoKnock && ped_ok(m.ped)) { CallV(SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE, m.ped, 0); m.oNoKnock = false; }
    m.order = order; m.oTarget = target; m.oSeat = seat; m.oTries = 0;
    m.oSince = now_ms(); m.oNext = m.oSince + 400; m.oSettled = false; m.oFollowDone = (order != O_FOOT && order != O_MOUNT);
    m.oFollowAt = 0;
    LI("order ped=%d %s target=%d seat=%d", m.ped, ORDER_NAME[order], target, seat);
}
static void order_clear(Managed& m, const char* why) {
    if (!m.order) return;
    LI("order ped=%d %s cleared (%s)", m.ped, ORDER_NAME[m.order], why);
    if (m.oNoKnock && ped_ok(m.ped)) CallV(SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE, m.ped, 0);
    m.order = O_NONE; m.oNoKnock = false; m.oFollowDone = true;
}
static void order_fail(Managed& m, const char* why) {
    LW("order ped=%d %s given up: %s", m.ped, ORDER_NAME[m.order], why);
    send_event("order_failed", m.ped, why);
    order_clear(m, "failed");
}
static void order_follow_up(Managed& m) {      // what they do once the order is done, so their own AI has no gap
    if (m.engaged || m.keep) CallV(TASK_TURN_PED_TO_FACE_ENTITY, m.ped, g_player, -1, 0.f, 0.f, 0.f);
    else if (m.order == O_FOOT || m.order == O_OUT) CallV(TASK_WANDER_STANDARD, m.ped, 10.0f, 10);
    m.oFollowDone = true;
}
static void order_tick(Managed& m, uint64_t t) {
    if (!m.order || t < m.oNext) return;
    m.oNext = t + 400;
    int ped = m.ped;
    if (CallB(IS_PED_HOGTIED, ped) || CallB(IS_PED_LASSOED, ped) || CallB(IS_PED_RAGDOLL, ped)) { m.oSince = t; return; }
    bool on = CallB(IS_PED_ON_MOUNT, ped);
    int cur = on ? CallI(GET_MOUNT, ped) : 0;
    if (m.order == O_FOOT) {
        if (on) {
            if (m.oSettled || t - m.oSince > 7000) {           // back in the saddle (their own AI) or never got off
                if (m.oTries >= 8) { order_fail(m, "keeps getting back on the horse"); return; }
                ++m.oTries; m.oSettled = false; m.oSince = t; m.oFollowDone = false;
                CallV(TASK_DISMOUNT_ANIMAL, ped, 0, 0, 0, 0, 0);
                LI("order ped=%d: on a horse again - dismount again (%d)", ped, m.oTries);
            }
        } else {
            if (!m.oSettled) { m.oSettled = true; if (!m.oFollowDone && !m.oFollowAt) m.oFollowAt = t + 500; LI("order ped=%d: off the horse", ped); }
            if (!m.oFollowDone && m.oFollowAt && t >= m.oFollowAt) { order_follow_up(m); m.oFollowAt = 0; }
        }
        return;
    }
    if (m.order == O_MOUNT || m.order == O_RIDE) {
        int h = m.oTarget;
        if (!ped_ok(h) || CallB(IS_ENTITY_DEAD, h)) { order_fail(m, "the horse is gone"); return; }
        if (on && cur == h) {
            if (!m.oSettled) {
                m.oSettled = true; m.oTries = 0; LI("order ped=%d: in the saddle (seat %d)", ped, m.oSeat);
                if (m.order == O_RIDE) { CallV(SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE, ped, 1); m.oNoKnock = true; }
                if (!m.oFollowDone) { m.oFollowAt = t + 400; }
            }
            if (!m.oFollowDone && m.oFollowAt && t >= m.oFollowAt) { order_follow_up(m); m.oFollowAt = 0; }
            return;
        }
        if (on && cur != h) {                       // on some other horse: off first
            if (t - m.oSince > 6000) { CallV(TASK_DISMOUNT_ANIMAL, ped, 0, 0, 0, 0, 0); m.oSince = t; LI("order ped=%d: on the wrong horse - getting off", ped); }
            return;
        }
        Vector3 pp = CallVec(GET_ENTITY_COORDS, ped, true, false), hp = CallVec(GET_ENTITY_COORDS, h, true, false);
        float d = dist3(pp, hp);
        int rider = CallI(GET_RIDER_OF_MOUNT, h, false);
        if (m.order == O_RIDE && m.oSettled) {      // was riding behind the player and is off now
            if (rider != g_player) { m.oSince = t; return; }     // the player got off too: wait for him
            m.oSettled = false; m.oSince = t; m.oFollowDone = true;
            CallV(TASK_MOUNT_ANIMAL, ped, h, 8000, m.oSeat, 2.0f, 1, 0, 0);
            LI("order ped=%d: fell/got off while you ride - getting back on", ped);
            return;
        }
        if (m.order == O_MOUNT && m.oSettled) {     // was in the saddle, got off/thrown
            m.oSettled = false; m.oSince = t; m.oFollowDone = false;
        }
        uint64_t wait = m.oTries == 0 ? 14000 : 10000;
        if (t - m.oSince < wait) return;
        if (m.oTries >= 4) { order_fail(m, "could not get on the horse"); return; }
        ++m.oTries; m.oSince = t;
        if (!CallB(IS_MOUNT_SEAT_FREE, h, m.oSeat)) { order_fail(m, m.order == O_RIDE ? "the horse's back seat is taken" : "someone else is on that horse"); return; }
        if (d < 12.f) {
            CallV(SET_PED_ONTO_MOUNT, ped, h, m.oSeat, true);
            LI("order ped=%d: mount task did not get them up in time - FORCED onto horse %d seat %d", ped, h, m.oSeat);
        } else {
            CallV(TASK_MOUNT_ANIMAL, ped, h, 8000, m.oSeat, 2.0f, 1, 0, 0);
            LI("order ped=%d: still not on horse %d (%.0f m) - mount task again (%d)", ped, h, d, m.oTries);
        }
        return;
    }
    if (m.order == O_OUT) {                  // 0.5.1: told to get off the wagon - and STAY off (drivers sat tight in 0.5.0)
        int v = m.oTarget;
        bool in = CallB(IS_PED_IN_ANY_VEHICLE, ped, false);
        if (!in) {
            if (!m.oSettled) { m.oSettled = true; m.oTries = 0; if (!m.oFollowDone && !m.oFollowAt) m.oFollowAt = t + 600; LI("order ped=%d: off the wagon", ped); }
            if (!m.oFollowDone && m.oFollowAt && t >= m.oFollowAt) { order_follow_up(m); m.oFollowAt = 0; }
            return;
        }
        if (m.oSettled) { m.oSettled = false; m.oSince = t; }          // climbed back on by themselves
        if (t - m.oSince < 3500) return;
        if (m.oTries >= 6) { order_fail(m, "won't get off the wagon"); return; }
        ++m.oTries; m.oSince = t;
        int cv = CallI(GET_VEHICLE_PED_IS_IN, ped, false); if (!cv) cv = v;
        if (m.oTries == 1) { CallV(TASK_LEAVE_VEHICLE, ped, cv, 0, 0); LI("order ped=%d: still on the wagon - leave task again", ped); }
        else if (m.oTries == 2) { CallV(TASK_LEAVE_VEHICLE, ped, cv, 16, 0); LI("order ped=%d: still on - leave (flag 16)", ped); }
        else {                                 // the last resort: put them on the ground beside the wagon
            Vector3 side = CallVec(GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS, cv, (m.oTries % 2) ? -2.2f : 2.2f, 0.0f, 0.0f);
            CallV(CLEAR_PED_TASKS_IMMEDIATELY, ped, false, true);
            CallV(SET_ENTITY_COORDS, ped, side.x, side.y, side.z, false, false, false, false);
            LI("order ped=%d: FORCED off the wagon (%d)", ped, m.oTries);
        }
        return;
    }
    if (m.order == O_VEH) {
        int v = m.oTarget;
        if (!ped_ok(v)) { order_fail(m, "the wagon is gone"); return; }
        bool in = CallB(IS_PED_IN_ANY_VEHICLE, ped, false) && CallI(GET_VEHICLE_PED_IS_IN, ped, false) == v;
        if (in) { if (!m.oSettled) { m.oSettled = true; m.oTries = 0; LI("order ped=%d: on the wagon", ped); } return; }
        if (m.oSettled) {                       // got off: only back on while the player is on it
            if (!(CallB(IS_PED_IN_ANY_VEHICLE, g_player, false) && CallI(GET_VEHICLE_PED_IS_IN, g_player, false) == v)) { m.oSince = t; return; }
            m.oSettled = false; m.oSince = t;
            CallV(TASK_ENTER_VEHICLE, ped, v, 10000, m.oSeat, 2.0f, 1, 0);
            return;
        }
        if (t - m.oSince < (m.oTries == 0 ? 16000u : 10000u)) return;
        if (m.oTries >= 4) { order_fail(m, "could not get on the wagon"); return; }
        ++m.oTries; m.oSince = t;
        if (!CallB(IS_VEHICLE_SEAT_FREE, v, m.oSeat)) { order_fail(m, "that wagon seat is taken"); return; }
        Vector3 pp = CallVec(GET_ENTITY_COORDS, ped, true, false), vp = CallVec(GET_ENTITY_COORDS, v, true, false);
        if (dist3(pp, vp) < 12.f) { CallV(SET_PED_INTO_VEHICLE, ped, v, m.oSeat); LI("order ped=%d: FORCED onto wagon %d seat %d", ped, v, m.oSeat); }
        else CallV(TASK_ENTER_VEHICLE, ped, v, 10000, m.oSeat, 2.0f, 1, 0);
    }
}
// ── vehicles (0.4.0) ──
static int veh_of(int ped) { return CallB(IS_PED_IN_ANY_VEHICLE, ped, false) ? CallI(GET_VEHICLE_PED_IS_IN, ped, false) : 0; }
static bool is_driver(int ped, int veh) { return veh && CallI(GET_PED_IN_VEHICLE_SEAT, veh, -1) == ped; }
static bool is_tram(int veh) { return veh && CallB(IS_THIS_MODEL_A_TRAIN, CallH(GET_ENTITY_MODEL, veh)); }
static void veh_halt(Managed& m, int veh) {
    CallV(BRING_VEHICLE_TO_HALT, veh, 6.0f, 60, false);
    m.vHalt = veh; m.vDrive = 0; m.vNext = now_ms() + 3000;
}
static void veh_unhalt(Managed& m) {
    if (m.vHalt && ped_ok(m.vHalt)) CallV(STOP_BRINGING_VEHICLE_TO_HALT, m.vHalt);
    m.vHalt = 0;
}
static void veh_drive_to(Managed& m, int veh, float x, float y, float z, float speed) {
    veh_unhalt(m);
    CallV(TASK_VEHICLE_DRIVE_TO_COORD, m.ped, veh, x, y, z, speed, 0, CallH(GET_ENTITY_MODEL, veh), 786603, 8.0f, -1.0f);
    m.vDrive = veh; m.vDestX = x; m.vDestY = y; m.vDestZ = z; m.vNext = now_ms() + 2000;
}
static void veh_tick(Managed& m, uint64_t t) {
    if ((!m.vHalt && !m.vDrive) || t < m.vNext) return;
    m.vNext = t + 2000;
    int veh = veh_of(m.ped);
    if (!veh || !is_driver(m.ped, veh)) { m.vHalt = m.vDrive = 0; return; }
    if (m.vHalt && CallF(GET_ENTITY_SPEED, veh) > 1.0f) {          // their own AI drove off again: stop again
        CallV(BRING_VEHICLE_TO_HALT, veh, 6.0f, 60, false); LI("vehicle %d of ped %d rolling again - halted again", veh, m.ped);
    }
    if (m.vDrive) {
        Vector3 p = CallVec(GET_ENTITY_COORDS, veh, true, false);
        float dx = p.x - m.vDestX, dy = p.y - m.vDestY;
        if (dx * dx + dy * dy < 14.f * 14.f) {
            m.vDrive = 0; veh_halt(m, veh);
            std::string o = "{\"t\":\"event\",\"kind\":\"veh_arrived\""; jkv(o, "ped", m.ped); o += "}"; net_send(o);
            LI("vehicle %d (driver %d) arrived - stopped", veh, m.ped);
        }
    }
}

// on release (conversation over): an order still counts for the moment they're let go
static void order_release(Managed& m) {
    if (!m.order || !ped_ok(m.ped) || CallB(IS_ENTITY_DEAD, m.ped)) { order_clear(m, "released"); return; }
    int ped = m.ped;
    if (m.order == O_OUT && !CallB(IS_PED_IN_ANY_VEHICLE, ped, false)) {
        CallV(CLEAR_PED_TASKS, ped, false, false);
        CallV(TASK_WANDER_STANDARD, ped, 10.0f, 10);
        LI("release ped=%d: was told to get off the wagon - walks away on foot", ped);
    } else if (m.order == O_FOOT && !CallB(IS_PED_ON_MOUNT, ped)) {
        CallV(CLEAR_PED_TASKS, ped, false, false);
        CallV(TASK_WANDER_STANDARD, ped, 10.0f, 10);          // they walk off on foot, they don't jump back on
        LI("release ped=%d: was told to get off the horse - walks away on foot", ped);
    } else if ((m.order == O_RIDE || m.order == O_VEH) && (CallB(IS_PED_ON_MOUNT, ped) || CallB(IS_PED_IN_ANY_VEHICLE, ped, false))) {
        if (m.order == O_RIDE) CallV(TASK_DISMOUNT_ANIMAL, ped, 0, 0, 0, 0, 0); else CallV(TASK_LEAVE_ANY_VEHICLE, ped, 0, 0);
        LI("release ped=%d: gets off your horse/wagon", ped);
    }
    order_clear(m, "released");
}

static void release(int ped, bool keep, const char* why) {
    Managed* m = find_m(ped);
    if (!m) return;
    LI("release ped=%d keep=%d why='%s' hold=%s overridden=%d persist=%d", ped, keep, why, HOLD_NAME[m->hold], m->overridden, m->persist);
    stop_talk(*m);
    if (ped_ok(ped)) {
        if (g_cfg.stopAmbientSpeech) CallV(STOP_PED_SPEAKING, ped, false);
        if (m->blocked) { CallV(SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, ped, false); m->blocked = false; }
        CallV(TASK_CLEAR_LOOK_AT, ped);
        if (!keep && in_love(ped)) {              // 0.5.5: X-X / turning away doesn't pull them out of a love scene
            LI("release ped=%d: in a love scene - left as they are", ped);
        } else if (!keep) {
            bool alive = !CallB(IS_ENTITY_DEAD, ped);
            bool hadOrder = m->order != O_NONE;
            int rv = veh_of(ped);
            if (m->vHalt || m->vDrive) {
                veh_unhalt(*m); m->vDrive = 0;
                if (alive && rv && is_driver(ped, rv)) { CallV(TASK_VEHICLE_DRIVE_WANDER, ped, rv, 5.0f, 0); hadOrder = true; LI("release ped=%d: drives on", ped); }
            }
            bool passenger = rv && !is_driver(ped, rv);
            if (m->order) order_release(*m);
            else if (alive && !hadOrder && !passenger && !is_tram(rv) && !m->overridden && (m->hold == H_FOOT || m->hold == H_MOUNT || m->hold == H_VEHICLE)) {
                CallV(CLEAR_PED_TASKS, ped, false, false);
                if (m->hold == H_VEHICLE) {
                    int veh = CallI(GET_VEHICLE_PED_IS_IN, ped, false);
                    if (veh) CallV(TASK_VEHICLE_DRIVE_WANDER, ped, veh, 5.0f, 0);
                } else CallV(TASK_WANDER_STANDARD, ped, 10.0f, 10);
            }
            if (m->persist) {
                CallV(SET_PED_KEEP_TASK, ped, false);
                alignas(8) int p = ped; CallV(SET_ENTITY_AS_NO_LONGER_NEEDED, &p); m->persist = false;
            }
        }
    }
    m->engaged = false;
    if (g_engaged == ped) g_engaged = 0;
    if (keep) { m->keep = true; m->hold = H_COMPANION; }
    else { g_peds.erase(std::remove_if(g_peds.begin(), g_peds.end(), [&](const Managed& x) { return x.ped == ped; }), g_peds.end()); }
}

static void send_event(const char* kind, int ped, const char* why) {
    std::string o = "{\"t\":\"event\",\"kind\":"; json_str(o, kind); jkv(o, "ped", ped);
    if (why) { o += ",\"why\":"; json_str(o, why); }
    o += "}"; net_send(o);
}
static void act_result(int seq, bool ok, const char* why) {
    if (!seq) return;
    std::string o = "{\"t\":\"act_result\""; jkv(o, "seq", seq); o += ",\"ok\":"; o += ok ? "true" : "false";
    o += ",\"why\":"; json_str(o, why ? why : ""); o += "}"; net_send(o);
    if (!ok) LW("action seq=%d failed: %s", seq, why);
}

// ───────────────────────── tasks ─────────────────────────
static int nearest_horse(int ped, float maxd) {
    int arr[PED_POOL_MAX]; int n = worldGetAllPeds(arr, PED_POOL_MAX); if (n > PED_POOL_MAX) n = PED_POOL_MAX;
    Vector3 pp = CallVec(GET_ENTITY_COORDS, ped, true, false);
    int best = 0; float bd = maxd;
    for (int i = 0; i < n; ++i) {
        int h = arr[i];
        if (!h || h == ped || h == g_player) continue;
        if (CallB(IS_PED_HUMAN, h) || CallB(IS_ENTITY_DEAD, h)) continue;
        uint32_t mdl = CallH(GET_ENTITY_MODEL, h);
        if (!CallB(IS_THIS_MODEL_A_HORSE, mdl)) continue;
        if (CallI(GET_RIDER_OF_MOUNT, h, false)) continue;
        Vector3 hp = CallVec(GET_ENTITY_COORDS, h, true, false);
        float d = dist3(pp, hp);
        if (d < bd) { bd = d; best = h; }
    }
    return best;
}

// scenario check (0.4.0): a scenario can 'start' and do nothing (needs a prop, wrong sex, wrong place). A few seconds
// later we look whether the ped really runs it and tell the brain, which learns which scenarios work.
struct ScenWatch { int ped; uint32_t hash; std::string name; uint64_t at; int seq; };
static std::vector<ScenWatch> g_scenWatch;
static void scen_watch(int ped, uint32_t hash, const char* name, int ms, int seq = 0) {
    g_scenWatch.erase(std::remove_if(g_scenWatch.begin(), g_scenWatch.end(), [&](const ScenWatch& w) { return w.ped == ped; }), g_scenWatch.end());
    g_scenWatch.push_back({ped, hash, name, now_ms() + (uint64_t)ms, seq});
}
static void scen_watch_tick() {
    uint64_t t = now_ms();
    for (size_t i = 0; i < g_scenWatch.size();) {
        ScenWatch& w = g_scenWatch[i];
        if (t < w.at) { ++i; continue; }
        bool ok = false; int type = 0;
        if (ped_ok(w.ped) && !CallB(IS_ENTITY_DEAD, w.ped)) {
            ok = w.hash ? CallB(IS_PED_USING_SCENARIO_HASH, w.ped, w.hash) : false;
            if (!ok) ok = CallB(IS_PED_USING_ANY_SCENARIO, w.ped);
            if (ok) type = CallI(GET_SCENARIO_POINT_TYPE_PED_IS_USING, w.ped);
        }
        std::string o = "{\"t\":\"scen_check\""; jkv(o, "ped", w.ped); jkv(o, "seq", w.seq); jkv(o, "ok", ok); jkv(o, "type", (double)(uint32_t)type);
        o += ",\"name\":"; json_str(o, w.name.c_str()); o += "}"; net_send(o);
        LI("scenario check ped=%d %s -> %s", w.ped, w.name.c_str(), ok ? "RUNNING" : "not running (broken here)");
        g_scenWatch.erase(g_scenWatch.begin() + i);
    }
}

// skin pieces that exist in the game, as listed in the Unstrip binaries (read, not guessed)
static const char* SKIN_PIECES[] = {
    "FEET_FR1_000_C0_000_AB", "FEET_FR1_000_C0_000_M", "FEET_FR1_000_C0_000_NM", "FEET_FR1_000_C0_001_AB",
    "FEET_FR1_000_C0_001_NM", "FEET_FR1_000_C0_002_AB", "FEET_FR1_000_C0_003_AB", "FEET_FR1_000_C0_004_AB",
    "FEET_FR1_000_C0_005_AB", "FEET_FR1_000_C0_006_AB", "FEET_FR1_000_C0_007_AB", "FEET_FR1_000_C0_008_AB",
    "FEET_FR1_000_C0_009_AB", "FEET_FR1_000_C0_010_AB", "FEET_FR1_000_C0_011_AB", "FEET_FR1_000_C0_011_M",
    "FEET_FR1_000_C0_011_NM", "FEET_FR1_000_C0_021_AB", "FEET_FR1_000_C1_008_AB", "FEET_FR1_000_C1_020_AB",
    "FEET_MR1_000_C0_000_AB", "FEET_MR1_000_C0_000_M", "FEET_MR1_000_C0_000_NM", "FEET_MR1_000_C0_001_AB",
    "FEET_MR1_000_C0_001_NM", "FEET_MR1_000_C0_002_AB", "FEET_MR1_000_C0_003_AB", "FEET_MR1_000_C0_004_AB",
    "FEET_MR1_000_C0_005_AB", "FEET_MR1_000_C0_006_AB", "FEET_MR1_000_C0_007_AB", "FEET_MR1_000_C0_008_AB",
    "FEET_MR1_000_C0_009_AB", "FEET_MR1_000_C0_010_AB", "FEET_MR1_000_C0_011_M", "FEET_MR1_000_C0_011_NM",
    "FEET_MR1_000_C0_012_AB", "FEET_MR1_000_C0_012_M", "FEET_MR1_000_C0_012_NM", "FEET_MR1_000_C0_013_AB",
    "FEET_MR1_000_C0_013_M", "FEET_MR1_000_C0_013_NM", "FEET_MR1_000_C0_016_AB", "FEET_MR1_000_C0_016_NM",
    "FEET_MR1_000_C0_019_AB", "FEET_MR1_000_C0_019_NM", "FEET_MR1_000_C0_020_AB", "FEET_MR1_000_C0_020_NM",
    "FEET_MR1_000_C0_021_AB", "FEET_MR1_000_C0_021_M", "FEET_MR1_000_C0_022_AB", "FEET_MR1_000_C0_025_AB",
    "FEET_MR1_000_C0_025_M", "FEET_MR1_000_C0_025_NM", "FEET_MR1_000_C0_026_AB", "FEET_MR1_000_C0_026_M",
    "FEET_MR1_000_C0_026_NM", "FEET_MR1_000_C0_030_AB", "FEET_MR1_000_C0_032_AB", "FEET_MR1_000_C0_033_AB",
    "FEET_MR1_000_C0_033_NM", "FEET_MR1_000_C0_034_AB", "FEET_MR1_000_C1_008_AB", "HAND_FR1_000_C0_000_AB",
    "HAND_FR1_000_C0_000_M", "HAND_FR1_000_C0_000_NM", "HAND_FR1_000_C0_001_AB", "HAND_FR1_000_C0_001_NM",
    "HAND_FR1_000_C0_002_AB", "HAND_FR1_000_C0_002_NM", "HAND_FR1_000_C0_003_AB", "HAND_FR1_000_C0_004_AB",
    "HAND_FR1_000_C0_005_AB", "HAND_FR1_000_C0_006_AB", "HAND_FR1_000_C0_007_AB", "HAND_FR1_000_C0_008_AB",
    "HAND_FR1_000_C0_009_AB", "HAND_FR1_000_C0_010_AB", "HAND_FR1_000_C0_011_AB", "HAND_FR1_000_C0_011_M",
    "HAND_FR1_000_C0_011_NM", "HAND_FR1_000_C0_019_AB", "HAND_FR1_000_C0_019_NM", "HAND_FR1_000_C0_020_AB",
    "HAND_FR1_000_C0_021_AB", "HAND_FR1_000_C0_022_AB", "HAND_FR1_000_C0_030_AB", "HAND_FR1_000_C0_099_AB",
    "HAND_FR1_000_C1_000_AB", "HAND_FR1_000_C1_001_AB", "HAND_FR1_000_C1_002_AB", "HAND_FR1_000_C1_003_AB",
    "HAND_FR1_000_C1_004_AB", "HAND_FR1_000_C1_005_AB", "HAND_FR1_000_C1_005_M", "HAND_FR1_000_C1_006_AB",
    "HAND_FR1_000_C1_007_AB", "HAND_FR1_000_C1_008_AB", "HAND_FR1_000_C1_009_AB", "HAND_FR1_000_C1_009_NM",
    "HAND_MR1_000_C0_000_AB", "HAND_MR1_000_C0_000_M", "HAND_MR1_000_C0_000_NM", "HAND_MR1_000_C0_001_AB",
    "HAND_MR1_000_C0_001_NM", "HAND_MR1_000_C0_002_AB", "HAND_MR1_000_C0_003_AB", "HAND_MR1_000_C0_004_AB",
    "HAND_MR1_000_C0_005_AB", "HAND_MR1_000_C0_006_AB", "HAND_MR1_000_C0_007_AB", "HAND_MR1_000_C0_008_AB",
    "HAND_MR1_000_C0_009_AB", "HAND_MR1_000_C0_010_AB", "HAND_MR1_000_C0_011_AB", "HAND_MR1_000_C0_011_M",
    "HAND_MR1_000_C0_011_NM", "HAND_MR1_000_C0_012_AB", "HAND_MR1_000_C0_012_M", "HAND_MR1_000_C0_012_NM",
    "HAND_MR1_000_C0_013_AB", "HAND_MR1_000_C0_013_M", "HAND_MR1_000_C0_013_NM", "HAND_MR1_000_C0_016_AB",
    "HAND_MR1_000_C0_016_NM", "HAND_MR1_000_C0_017_AB", "HAND_MR1_000_C0_017_NM", "HAND_MR1_000_C0_019_AB",
    "HAND_MR1_000_C0_019_NM", "HAND_MR1_000_C0_020_AB", "HAND_MR1_000_C0_020_NM", "HAND_MR1_000_C0_021_AB",
    "HAND_MR1_000_C0_022_AB", "HAND_MR1_000_C0_024_AB", "HAND_MR1_000_C0_026_AB", "HAND_MR1_000_C0_026_NM",
    "HAND_MR1_000_C0_027_AB", "HAND_MR1_000_C0_030_AB", "HAND_MR1_000_C0_032_AB", "HAND_MR1_000_C1_000_AB",
    "HAND_MR1_000_C1_001_AB", "HAND_MR1_000_C1_002_AB", "HAND_MR1_000_C1_003_AB", "HAND_MR1_000_C1_004_AB",
    "HAND_MR1_000_C1_005_AB", "HAND_MR1_000_C1_006_AB", "HAND_MR1_000_C1_007_AB", "HAND_MR1_000_C1_008_AB",
    "HAND_MR1_000_C1_009_AB", "HAND_MR1_000_C1_013_AB",
};

// ── undress / dress (0.5.0) ──
// The recipe is the one "Unstrip - Full Nude" / "Unstrip - Male Edition" use, read from their code: save the 16
// outfit slots, remove the clothing categories, put on the game's own nude torso / lower body with the ped's own
// skin tone (taken from the hand albedo), refresh. Dressing again re-applies the 16 saved slots, like their Unstrip.
static const char* CLOTH_UPPER[] = {"shirts_full", "shirts", "vests", "coats", "coats_full", "coats_closed", "dresses", "corsets",
    "gowns", "cloaks", "ponchos", "suspenders", "neckwear", "neckties", "gloves", "gunbelts", "belts", "belt_buckles", "loadouts",
    "holsters_left", "holsters_right", "holsters_crossdraw", "holsters_knife", "satchels", "ammo_pistols"};
static const char* CLOTH_LOWER[] = {"pants", "skirts", "chaps", "aprons", "boots", "boot_accessories", "spats", "shoes"};
static const char* LOWER_F[] = {"LOWERTORSO_FR1_003", "LOWERTORSO_FR1_004", "LOWERTORSO_FR1_005", "LOWERTORSO_FR1_007",
    "LOWERTORSO_FR1_009", "LOWERTORSO_FR1_010"};
struct SavedLook { uint32_t s[16][8]; };
static std::map<int, SavedLook> g_looks;
struct PendingDress { int ped, seq; uint64_t at; };
static std::vector<PendingDress> g_dress;
static bool skin_exists(uint32_t h) {
    static std::vector<uint32_t> hs;
    if (hs.empty()) for (auto* n : SKIN_PIECES) hs.push_back(joaat(n));
    return std::find(hs.begin(), hs.end(), h) != hs.end();
}
static bool in_cat_list(uint32_t c, const char** l, size_t n) { for (size_t i = 0; i < n; ++i) if (joaat(l[i]) == c) return true; return false; }
static void clothes_count(int ped, int& up, int& low) {
    up = low = 0;
    int n = CallI(GET_NUM_COMPONENT_CATEGORIES_IN_PED, ped);
    for (int i = 0; i < n && i < 64; ++i) {
        uint32_t c = CallH(GET_PED_COMPONENT_CATEGORY_BY_INDEX, ped, i);
        if (in_cat_list(c, CLOTH_UPPER, sizeof CLOTH_UPPER / sizeof *CLOTH_UPPER)) ++up;
        else if (in_cat_list(c, CLOTH_LOWER, sizeof CLOTH_LOWER / sizeof *CLOTH_LOWER)) ++low;
    }
}
static bool nude_torso_on(int ped) {
    uint32_t a = joaat("UPPERTORSO_FR1_000"), b = joaat("UPPERTORSO_MR1_000");
    for (int i = 0; i < 16; ++i) {
        alignas(8) uint32_t d = 0, al = 0, nm = 0, mt = 0;
        if (!CallB(GET_META_PED_ASSET_GUIDS, ped, i, &d, &al, &nm, &mt)) continue;
        if (d == a || d == b) return true;
    }
    return false;
}
static void save_look(int ped) {
    if (g_looks.count(ped)) return;
    SavedLook L{};
    for (int i = 0; i < 16; ++i) {
        alignas(8) uint32_t d = 0, al = 0, nm = 0, mt = 0, pal = 0; alignas(8) int t0 = 0, t1 = 0, t2 = 0;
        CallB(GET_META_PED_ASSET_GUIDS, ped, i, &d, &al, &nm, &mt);
        CallB(GET_META_PED_ASSET_TINT, ped, i, &pal, &t0, &t1, &t2);
        uint32_t row[8] = {d, al, nm, mt, pal, (uint32_t)t0, (uint32_t)t1, (uint32_t)t2};
        memcpy(L.s[i], row, sizeof row);
    }
    g_looks[ped] = L;
}
static int skin_tone_raw(int ped, bool male) {      // -1 = can't tell (look not streamed yet / no such hands)
    char b[64];
    for (int i = 0; i < 16; ++i) {
        alignas(8) uint32_t d = 0, al = 0, nm = 0, mt = 0;
        if (!CallB(GET_META_PED_ASSET_GUIDS, ped, i, &d, &al, &nm, &mt) || !al) continue;
        for (int t = 0; t < 35; ++t) for (int c = 0; c < 2; ++c) {
            snprintf(b, sizeof b, "HAND_%s_000_C%d_%03d_AB", male ? "MR1" : "FR1", c, t);
            if (joaat(b) == al) return t;
        }
    }
    return -1;
}
static int skin_tone(int ped, bool male) { int t = skin_tone_raw(ped, male); return t < 0 ? 0 : t; }
static uint32_t skin_piece(const char* part, bool male, int tone, const char* kind) {
    char b[64];
    snprintf(b, sizeof b, "%s_%s_000_C0_%03d_%s", part, male ? "MR1" : "FR1", tone, kind);
    if (skin_exists(joaat(b))) return joaat(b);
    snprintf(b, sizeof b, "%s_%s_000_C0_000_%s", part, male ? "MR1" : "FR1", kind);    // the shared map, as Unstrip does
    return joaat(b);
}
static bool undress_ped(int ped, std::string& why) {
    if (!ped_ok(ped) || CallB(IS_ENTITY_DEAD, ped)) { why = "gone"; return false; }
    bool male = CallB(IS_PED_MALE, ped);
    save_look(ped);
    int tone = skin_tone(ped, male);
    for (auto* c : CLOTH_UPPER) CallV(REMOVE_TAG_FROM_META_PED, ped, joaat(c), 1);
    for (auto* c : CLOTH_LOWER) CallV(REMOVE_TAG_FROM_META_PED, ped, joaat(c), 1);
    uint32_t pal = joaat("METAPED_TINT_GENERIC");
    CallV(SET_META_PED_TAG, ped, joaat(male ? "UPPERTORSO_MR1_000" : "UPPERTORSO_FR1_000"), skin_piece("HAND", male, tone, "AB"),
          skin_piece("HAND", male, tone, "NM"), skin_piece("HAND", male, tone, "M"), pal, 0, 0, 0);
    CallV(SET_META_PED_TAG, ped, joaat(male ? "LOWERTORSO_MR1_000" : LOWER_F[(unsigned)ped % 6]), skin_piece("FEET", male, tone, "AB"),
          skin_piece("FEET", male, tone, "NM"), skin_piece("FEET", male, tone, "M"), pal, 0, 0, 0);
    CallV(UPDATE_PED_VARIATION, ped, true, true, true, true, true);
    LI("undress ped=%d %s skin tone %d (outfit saved: %d slots)", ped, male ? "male" : "female", tone, 16);
    return true;
}
static bool dress_ped(int ped, int seq, std::string& why) {
    if (!ped_ok(ped)) { why = "gone"; return false; }
    if (!g_looks.count(ped)) {             // undressed by something else and nothing saved: a fresh outfit of their own model
        CallV(SET_RANDOM_OUTFIT_VARIATION, ped, true);
        LI("dress ped=%d: no saved look - random outfit of their model", ped);
        return true;
    }
    int n = CallI(GET_NUM_COMPONENT_CATEGORIES_IN_PED, ped);
    std::vector<uint32_t> cats;
    for (int i = 0; i < n && i < 64; ++i) cats.push_back(CallH(GET_PED_COMPONENT_CATEGORY_BY_INDEX, ped, i));
    for (auto c : cats) CallV(REMOVE_TAG_FROM_META_PED, ped, c, 1);
    CallV(UPDATE_PED_VARIATION, ped, true, true, true, true, true);
    g_dress.push_back({ped, seq, now_ms() + 60});           // like Unstrip: a short wait, then the saved slots go back on
    return true;
}
static void dress_tick() {
    uint64_t t = now_ms();
    for (size_t i = 0; i < g_dress.size();) {
        PendingDress p = g_dress[i];
        if (t < p.at) { ++i; continue; }
        g_dress.erase(g_dress.begin() + i);
        auto it = g_looks.find(p.ped);
        if (it == g_looks.end() || !ped_ok(p.ped)) continue;
        for (int k = 0; k < 16; ++k) {
            uint32_t* r = it->second.s[k];
            if (!r[0]) continue;
            CallV(SET_META_PED_TAG, p.ped, r[0], r[1], r[2], r[3], r[4], (int)r[5], (int)r[6], (int)r[7]);
        }
        CallV(UPDATE_PED_VARIATION, p.ped, true, true, true, true, true);
        g_looks.erase(it);
        LI("dress ped=%d: own clothes back on", p.ped);
    }
}
// a hookup scene (NpcHookups / NpcHookupsPlus play this clip pair) - read from NpcHookups.asi
static const char* HOOKUP_DICT = "script_story@sal1@ig@sal1_18_lenny_on_lenny";
static int in_hookup(int ped) {
    if (CallB(IS_ENTITY_PLAYING_ANIM, ped, HOOKUP_DICT, "loop_male", 3)) return 1;
    if (CallB(IS_ENTITY_PLAYING_ANIM, ped, HOOKUP_DICT, "loop_female", 3)) return 2;
    return 0;
}

// ── NpcHookups bridge (0.5.0) ─────────────────────────────────────────────────────────────────────────────────
// Read from NpcHookups.asi (MinGW, symbols kept): Pick(int ped, int which) at RVA 0x8130 is what its own partner keys
// call; g_pending at RVA 0x22440 is the bit set its OnKey (RVA 0x1800) fills and its ScriptMain consumes; bit 0x2 is the
// branch that logs "couple %d stopped, back to normal." (goodbye). BUILD-LOCKED: TimeDateStamp 6AE4B4EA, SizeOfImage
// 0x59000, and the first 16 code bytes of Pick and OnKey must match what was read from that file. Otherwise: off.
static HMODULE g_nh = nullptr; static int g_nhState = -1;
static bool nh_ready() {
    if (g_nhState >= 0) return g_nhState == 1;
    g_nhState = 0;
    HMODULE h = GetModuleHandleA("NpcHookups.asi");
    if (!h) { LI("NpcHookups bridge: NpcHookups.asi is not loaded - couples can't be started from a conversation"); return false; }
    BYTE* b = (BYTE*)h;
    MEMORY_BASIC_INFORMATION mbi{};
    if (!VirtualQuery(b, &mbi, sizeof mbi) || mbi.State != MEM_COMMIT) return false;
    auto* dos = (IMAGE_DOS_HEADER*)b;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return false;
    auto* nt = (IMAGE_NT_HEADERS64*)(b + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return false;
    DWORD stamp = nt->FileHeader.TimeDateStamp, size = nt->OptionalHeader.SizeOfImage;
    if (stamp != 0x6AE4B4EA || size != 0x59000) {
        LW("NpcHookups bridge OFF: NpcHookups.asi is a different build (%08lX / %lX), not touching it", (unsigned long)stamp, (unsigned long)size);
        return false;
    }
    static const BYTE PICK[16] = {0x41,0x57,0x41,0x56,0x41,0x55,0x41,0x54,0x55,0x57,0x56,0x53,0x48,0x81,0xec,0x28};
    static const BYTE ONKEY[16] = {0x44,0x8b,0x5c,0x24,0x38,0x89,0xc8,0x45,0x85,0xdb,0x75,0x3e,0x85,0xc9,0x74,0x3a};
    if (memcmp(b + 0x8130, PICK, 16) || memcmp(b + 0x1800, ONKEY, 16)) {
        LW("NpcHookups bridge OFF: code at Pick/OnKey is not what was analysed - not touching it");
        return false;
    }
    if (!VirtualQuery(b + 0x22440, &mbi, sizeof mbi) || mbi.State != MEM_COMMIT || !(mbi.Protect & (PAGE_READWRITE | PAGE_WRITECOPY))) {
        LW("NpcHookups bridge OFF: its key flags are not writable"); return false;
    }
    g_nh = h; g_nhState = 1;
    LI("NpcHookups bridge ready (build 6AE4B4EA): Pick @+0x8130, key flags @+0x22440");
    return true;
}
static bool nh_pick(int ped, int which) {
    if (!nh_ready()) return false;
    typedef void (*PickFn)(int, int);
    LI("NpcHookups bridge: Pick(ped %d, partner %d)", ped, which);
    ((PickFn)((BYTE*)g_nh + 0x8130))(ped, which);
    return true;
}
static bool nh_goodbye() {
    if (!nh_ready()) return false;
    InterlockedOr((volatile LONG*)((BYTE*)g_nh + 0x22440), 0x2);     // exactly what its own key handler does
    LI("NpcHookups bridge: goodbye sent (couple nearest you stops, back to normal)");
    return true;
}

static int g_tgt = 0;   // target of the current task: the player unless the brain says t=<ped>
// ── 0.5.1: one family, one skin tone ────────────────────────────────────────────────────────────────────────────
// A family member spawned for a trip (spawn flag like=<guide>) gets the guide's skin tone: we read the guide's tone the
// same way undress does (the hand albedo), then step through the model's own outfit presets until the tone matches -
// one preset per few frames, because the look only updates after a frame. No match: the closest one we saw.
struct ToneJob { int ped, tone, idx, n, best, bestDiff, unread; bool male; uint64_t at; };
static std::vector<ToneJob> g_tone;
static void tone_report(int ped, bool ok, int want, int got, const char* how) {
    std::string o = "{\"t\":\"tone\""; jkv(o, "ped", ped); jkv(o, "ok", ok); jkv(o, "want", want); jkv(o, "got", got);
    o += ",\"how\":"; json_str(o, how); o += "}"; net_send(o);
}
static void tone_start(int ped, int ref) {
    if (!ped_ok(ped) || !ped_ok(ref)) { tone_report(ped, true, -1, -1, "no reference"); return; }
    int tone = skin_tone_raw(ref, CallB(IS_PED_MALE, ref));
    if (tone < 0) { LI("tone ped=%d: can't read the guide's skin tone - left as is", ped); tone_report(ped, true, -1, -1, "guide unreadable"); return; }
    int n = CallI(GET_NUM_META_PED_OUTFITS, ped);
    // 0.5.5: the look of a new ped needs time to stream in - read after 600 ms, then one outfit every 400 ms
    g_tone.push_back({ped, tone, -1, n > 60 ? 60 : n, -1, 999, 0, CallB(IS_PED_MALE, ped), now_ms() + 600});
    LI("tone ped=%d: matching skin tone %d of ped %d (%d outfits to try)", ped, tone, ref, n);
}
static void tone_tick() {
    uint64_t t = now_ms();
    for (size_t i = 0; i < g_tone.size();) {
        ToneJob& j = g_tone[i];
        if (t < j.at) { ++i; continue; }
        if (!ped_ok(j.ped)) { g_tone.erase(g_tone.begin() + i); continue; }
        int cur = skin_tone_raw(j.ped, j.male);
        if (cur < 0 && j.unread < 3) { ++j.unread; j.at = t + 400; ++i; continue; }    // not streamed yet: look again
        j.unread = 0;
        if (cur >= 0) {
            int diff = cur > j.tone ? cur - j.tone : j.tone - cur;
            LD("tone ped=%d outfit %d: tone %d (want %d)", j.ped, j.idx, cur, j.tone);
            if (diff < j.bestDiff) { j.bestDiff = diff; j.best = j.idx; }
        }
        if (j.bestDiff == 0 || j.idx + 1 >= j.n) {
            if (j.bestDiff != 0 && j.best >= 0) {
                CallV(EQUIP_META_PED_OUTFIT_PRESET, j.ped, j.best, false);
                CallV(UPDATE_PED_VARIATION, j.ped, true, true, true, true, true);
            }
            bool ok = j.bestDiff <= 1;               // the same skin, or the next shade
            LI("tone ped=%d: %s (outfit %d, off by %d, wanted %d)", j.ped, j.bestDiff == 0 ? "MATCHED" : ok ? "close" : "NO MATCH",
               j.best, j.bestDiff == 999 ? -1 : j.bestDiff, j.tone);
            tone_report(j.ped, ok, j.tone, j.bestDiff == 999 ? -1 : j.bestDiff, j.bestDiff == 0 ? "matched" : ok ? "close" : "no match");
            g_tone.erase(g_tone.begin() + i); continue;
        }
        ++j.idx;
        CallV(EQUIP_META_PED_OUTFIT_PRESET, j.ped, j.idx, false);
        CallV(UPDATE_PED_VARIATION, j.ped, true, true, true, true, true);
        j.at = t + 400;
        ++i;
    }
}

// ── 0.5.1: hush the bystanders while an AI voice talks ─────────────────────────────────────────────────────────────
// The person you talk to was muted already; the lawman and the townsfolk around still shouted their own lines over
// the AI voice. Only ambient SPEECH is stopped (not pain, not screams of people being hurt, not gunfire).
static uint64_t g_hushAllAt = 0;
static void hush_bystanders() {
    if (!g_cfg.muteBystanders) return;
    uint64_t t = now_ms();
    if (t < g_hushAllAt) return;
    bool talking = false;
    for (auto& m : g_peds) if (m.talkUntil > t) { talking = true; break; }
    if (!talking) return;
    g_hushAllAt = t + 300;
    int arr[PED_POOL_MAX]; int n = worldGetAllPeds(arr, PED_POOL_MAX); if (n > PED_POOL_MAX) n = PED_POOL_MAX;
    for (int i = 0; i < n; ++i) {
        int h = arr[i];
        if (!h || h == g_player || !CallB(IS_PED_HUMAN, h) || CallB(IS_ENTITY_DEAD, h)) continue;
        Managed* m = find_m(h);
        if (m && m->painUntil > t) continue;
        if (dist3(CallVec(GET_ENTITY_COORDS, h, true, false), g_ppos) > 30.f) continue;
        if (in_love(h)) continue;                             // 0.5.5: never silence a love scene
        CallV(STOP_CURRENT_PLAYING_AMBIENT_SPEECH, h, 0);
    }
}

// ── 0.5.1: couples on a real bed, run by NpcVoice itself ───────────────────────────────────────────────────────────
// NpcHookups always puts the pair 3 m in front of the player. For couples found at home NpcVoice plays the same clip
// pair (read from NpcHookups: sal1_18 loop_male / loop_female) itself, both partners anchored to the same point on a
// real bed found in the house (or a bedroll on the floor). The scene is kept alive (re-issued if the game drops it)
// until the brain stops it (walked in on, they're done, someone gets hurt).
static const char* BED_MODELS[] = {"p_bed01x", "p_bed02x", "p_bed02bx", "p_bed03x", "p_bed04x", "p_bed05x", "p_bed08x",
    "p_bed09x", "p_bed10x", "p_bed12x", "p_bed13x", "p_bed14x", "p_bed15brassx", "p_bed17x", "p_bed18x", "p_bed20x",
    "p_bed20madex", "p_bed21x", "p_bed22x", "p_bedking01x", "p_bedking02x", "p_bedlog01x", "p_cot01x",
    "p_bedsleptin01x", "p_bedsleptinold04x", "p_amb_mattress04x", "mp007_p_mp_oldmattress01x", "p_cs_mattress01x",
    "p_bedindian01x", "p_bedindian02x", "p_bedmosquitonet01x", "p_bedrollopen01x", "p_gen_bedrollopen01x"};
// households: a couple scene has a POSE - each partner's offset from the anchor (sideways, along, up, in the bed's own
// frame) and rotation (pitch, roll, extra turn), which clip role each one plays (swap), and optionally another clip
// pair (an animation pack). Defaults = exactly the 0.5.1 scene.
// 0.5.8: NpcHookups' own way (read from NpcHookups.asi 6AE4B4EA: Pick -> PlayBase / PinBase / AttachTop / PlayTop):
// the sal1_18 clips do NOT place two bodies by themselves - in the original scene the upper partner is ATTACHED to the
// lower one's hip. So: the lower partner (the man, MEN_TAKE_MALE_ROLE=1) plays his clip in place at the anchor, the upper
// partner plays loop_female attached to his bone 0xA7D8 (else SKEL_Pelvis) with these numbers (its ATT table) and its
// ROT_Z_CORRECTION of -90. 0.5.1-0.5.7 played both clips side by side at one point: both stood up, dressed, "weird".
static const float NH_ATT[3][6] = {
    {-0.35f,  0.13f, 0.99f, -353.f,   15.f,  91.f},     // 1 cowgirl
    { 0.18f,  0.16f, 0.83f, -512.f, -188.f,  77.f},     // 2 missionary
    { 0.19f, -0.13f, 0.87f,  -16.f,   10.f, -89.f},     // 3 reverse cowgirl
};
static const float NH_ROT_Z_CORR = -90.f;
static const char* NH_POS_NAME[4] = {"own offsets", "cowgirl", "missionary", "reverse cowgirl"};
struct Couple { int seq, a, b; float x, y, z, h; int flags; bool on; uint64_t next, deadline;
                std::string dict, clipA, clipB; float off[2][6]; bool swap;
                int pos = 0, base = 0, top = 0, stage = 0; uint64_t stageAt = 0; };
static void couple_defaults(Couple& c) {
    c.dict = HOOKUP_DICT; c.clipA = "loop_male"; c.clipB = "loop_female"; c.swap = false;
    for (auto& r : c.off) for (float& v : r) v = 0.f;
}
static void parse6(const char* s, float* out) {        // "dx,dy,dz,rx,ry,rz"
    for (int i = 0; i < 6 && s && *s; ++i) { out[i] = (float)atof(s); s = strchr(s, ','); if (s) ++s; }
}
static void couple_opts(Couple& c, int n, char** tok, int from) {   // anim=dict,clipA,clipB  pa=...  pb=...  swap=0|1  h=deg  pos=1..3
    for (int i = from; i < n; ++i) {
        const char* t = tok[i];
        if (!strncmp(t, "anim=", 5)) {
            std::string v = t + 5; size_t a = v.find(','), b = a == std::string::npos ? a : v.find(',', a + 1);
            if (a != std::string::npos && b != std::string::npos && a > 0) { c.dict = v.substr(0, a); c.clipA = v.substr(a + 1, b - a - 1); c.clipB = v.substr(b + 1); }
            else { c.dict = HOOKUP_DICT; c.clipA = "loop_male"; c.clipB = "loop_female"; }
        }
        else if (!strncmp(t, "pa=", 3)) parse6(t + 3, c.off[0]);
        else if (!strncmp(t, "pb=", 3)) parse6(t + 3, c.off[1]);
        else if (!strncmp(t, "swap=", 5)) c.swap = atoi(t + 5) != 0;
        else if (!strncmp(t, "h=", 2)) c.h = (float)atof(t + 2);
        else if (!strncmp(t, "pos=", 4)) { int p = atoi(t + 4); c.pos = (p >= 1 && p <= 3) ? p : 0; }
    }
    if (c.pos && c.dict != HOOKUP_DICT) c.pos = 0;      // an animation pack's own clips: its own offsets
}
static std::vector<Couple> g_couples;
static bool in_couple_scene(int ped) { for (auto& c : g_couples) if (c.on && (c.a == ped || c.b == ped)) return true; return false; }
static void bed_reply(int seq, int obj, const char* model) {
    std::string o = "{\"t\":\"bed\""; jkv(o, "seq", seq); jkv(o, "ok", obj != 0);
    if (obj) {
        Vector3 p = CallVec(GET_ENTITY_COORDS, obj, true, false);
        jkv(o, "x", p.x); jkv(o, "y", p.y); jkv(o, "z", p.z); jkv(o, "hd", CallF(GET_ENTITY_HEADING, obj));
        o += ",\"model\":"; json_str(o, model); o += ",\"src\":\"object\"";
    }
    o += "}"; net_send(o);
}
static void bed_reply_at(int seq, float x, float y, float z, float hd, const char* what, const char* src) {
    std::string o = "{\"t\":\"bed\""; jkv(o, "seq", seq); jkv(o, "ok", 1);
    jkv(o, "x", x); jkv(o, "y", y); jkv(o, "z", z); jkv(o, "hd", hd);
    o += ",\"model\":"; json_str(o, what); o += ",\"src\":"; json_str(o, src); o += "}"; net_send(o);
}
// the game's own "sleep in a bed" spots inside houses (the points its NPCs use to lie down)
static const char* BED_SCENARIOS[] = {"PROP_HUMAN_SLEEP_BED_PILLOW", "PROP_HUMAN_SLEEP_BED_PILLOW_HIGH",
    "PROP_HUMAN_SLEEP_BED_PILLOW_LEFT", "PROP_HUMAN_SLEEP_BED_PILLOW_RIGHT", "PROP_CAMP_JACK_ES_SLEEP_BED_PILLOW_LEFT",
    "PROP_PLAYER_SLEEP_BED", "PROP_CAMP_BILL_SLEEP"};       // real beds first (index < 5); camp spots last
static bool bed_spot(float x, float y, float z, float r, Vector3& out, float& hd, std::string& type) {
    alignas(8) int64_t pts[64] = {0};
    int n = CallI(GET_SCENARIO_POINTS_IN_AREA, x, y, z, r, pts, 64);
    if (n < 0) n = 0; if (n > 64) n = 64;
    float bd = 1e9f; bool found = false;
    Vector3 c{}; c.x = x; c.y = y; c.z = z;
    for (int i = 0; i < n; ++i) {
        int sp = (int)pts[i];
        if (!sp) continue;
        uint32_t th = CallH(GET_SCENARIO_POINT_TYPE, sp);
        const char* hit = nullptr; int rank = 0;
        for (auto* nm : BED_SCENARIOS) { if (joaat(nm) == th) { hit = nm; break; } ++rank; }
        if (!hit) continue;
        Vector3 p = CallVec(GET_SCENARIO_POINT_COORDS, sp, true);
        float d = dist3(p, c) + (rank >= 5 ? 1000.f : 0.f);       // any real bed in the house beats a camp spot
        if (d < bd) { bd = d; out = p; hd = CallF(GET_SCENARIO_POINT_HEADING, sp, true); type = hit; found = true; }
    }
    LI("bed_spot at %.0f %.0f r=%.0f: %d scenario points, bed spot %s", x, y, r, n, found ? type.c_str() : "none");
    return found;
}
static void find_bed(int seq, float x, float y, float z, float r) {
    int best = 0; float bd = 1e9f; const char* bm = "";
    Vector3 c{}; c.x = x; c.y = y; c.z = z;
    for (auto* mdl : BED_MODELS) {
        int o = CallI(GET_CLOSEST_OBJECT_OF_TYPE, x, y, z, r, joaat(mdl), false, false, false);
        if (!o || !ped_ok(o)) continue;
        float d = dist3(CallVec(GET_ENTITY_COORDS, o, true, false), c);
        if (d < bd) { bd = d; best = o; bm = mdl; }
    }
    LI("find_bed seq=%d at %.0f %.0f r=%.0f -> %s %d", seq, x, y, r, best ? bm : "none", best);
    if (best) { bed_reply(seq, best, bm); return; }
    Vector3 sp{}; float hd = 0.f; std::string type;
    if (bed_spot(x, y, z, r, sp, hd, type)) { bed_reply_at(seq, sp.x, sp.y, sp.z, hd, type.c_str(), "scenario"); return; }
    // last resort: a blanket on the floor of the place itself ("old shack, sheet on the floor")
    alignas(8) float gz = 0.f;
    float fz = CallB(GET_GROUND_Z_FOR_3D_COORD, x, y, z + 1.2f, &gz, false) ? gz : z;
    LI("find_bed seq=%d: no bed, no sleeping spot - the floor at %.1f %.1f %.1f", seq, x, y, fz);
    bed_reply_at(seq, x, y, fz, 0.f, "floor", "floor");
}
// households: every scenario point in and around a house (chairs at the table, the stove, the wash basin, the porch
// bench, the woodpile, the beds...) -> the brain plans the couple's day on their REAL furniture
static void home_scan(int seq, float x, float y, float z, float r) {
    alignas(8) int64_t pts[128] = {0};
    int n = CallI(GET_SCENARIO_POINTS_IN_AREA, x, y, z, r, pts, 128);
    if (n < 0) n = 0; if (n > 128) n = 128;
    std::string o = "{\"t\":\"home\""; jkv(o, "seq", seq); o += ",\"pts\":[";
    int k = 0;
    for (int i = 0; i < n; ++i) {
        int sp = (int)pts[i];
        if (!sp) continue;
        uint32_t th = CallH(GET_SCENARIO_POINT_TYPE, sp);
        Vector3 p = CallVec(GET_SCENARIO_POINT_COORDS, sp, true);
        float hd = CallF(GET_SCENARIO_POINT_HEADING, sp, true);
        char b[128]; snprintf(b, sizeof b, "%s[%u,%.2f,%.2f,%.2f,%.0f]", k ? "," : "", th, p.x, p.y, p.z, hd);
        o += b; ++k;
    }
    o += "]}"; net_send(o);
    LI("home_scan seq=%d at %.0f %.0f r=%.0f: %d scenario points", seq, x, y, r, k);
}
static const char* couple_clip(const Couple& c, int k) {
    int peds[2] = {c.a, c.b};
    bool male = ped_ok(peds[k]) && CallB(IS_PED_MALE, peds[k]);
    bool otherMale = ped_ok(peds[1 - k]) && CallB(IS_PED_MALE, peds[1 - k]);
    bool roleA = (male && !(otherMale && k == 1)) || (!male && !otherMale && k == 0);
    if (c.swap) roleA = !roleA;                      // the other one takes the lead / is on top
    return roleA ? c.clipA.c_str() : c.clipB.c_str();
}
static void couple_stop_anims(const Couple& c, int ped) {
    if (!ped_ok(ped)) return;
    CallV(STOP_ANIM_TASK, ped, HOOKUP_DICT, "loop_male", 1.0f);
    CallV(STOP_ANIM_TASK, ped, HOOKUP_DICT, "loop_female", 1.0f);
    if (c.dict != HOOKUP_DICT) { CallV(STOP_ANIM_TASK, ped, c.dict.c_str(), c.clipA.c_str(), 1.0f); CallV(STOP_ANIM_TASK, ped, c.dict.c_str(), c.clipB.c_str(), 1.0f); }
}
// ── the NpcHookups recipe ──
static const char* nh_base_clip(const Couple& c) { return c.pos == 2 ? "loop_female" : "loop_male"; }
static void nh_roles(Couple& c) {
    bool am = ped_ok(c.a) && CallB(IS_PED_MALE, c.a), bm = ped_ok(c.b) && CallB(IS_PED_MALE, c.b);
    c.base = c.a; c.top = c.b;                          // NpcHookups MEN_TAKE_MALE_ROLE=1: the man is the lower partner
    if (!am && bm) { c.base = c.b; c.top = c.a; }
    if (c.swap) std::swap(c.base, c.top);
}
static void nh_play(int ped, const char* clip) {
    CallV(TASK_PLAY_ANIM, ped, HOOKUP_DICT, clip, 8.0f, -8.0f, -1, 1, 0.0f, false, 0, false, "", false);
}
static int nh_bone(int base) {
    int bone = CallI(GET_PED_BONE_INDEX, base, 0xA7D8);                  // the bone the original scene uses
    if (bone <= 0) bone = CallI(GET_ENTITY_BONE_INDEX_BY_NAME, base, "SKEL_Pelvis");
    return bone;
}
static void nh_attach(const Couple& c) {
    const float* a = NH_ATT[c.pos - 1];
    int bone = nh_bone(c.base);
    CallV(SET_ENTITY_COLLISION, c.top, false, false);
    CallV(SET_ENTITY_VELOCITY, c.top, 0.0f, 0.0f, 0.0f);
    if (bone > 0)
        CallV(ATTACH_ENTITY_TO_ENTITY, c.top, c.base, bone, a[0], a[1], a[2], a[3], a[4], a[5] + NH_ROT_Z_CORR,
              false, false, false, false, 2, true, false, false);
    else
        CallV(ATTACH_ENTITY_TO_ENTITY, c.top, c.base, 0, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, false, false, false, false, 2, true, false, false);
    LI("couple seq=%d: %s - top=%d attached to base=%d bone %d offset %.2f %.2f %.2f rot %.0f %.0f %.0f", c.seq, NH_POS_NAME[c.pos],
       c.top, c.base, bone, a[0], a[1], a[2], a[3], a[4], a[5] + NH_ROT_Z_CORR);
}
static void nh_pin_base(const Couple& c) {         // PinBase: the lower partner sank or popped up -> back to the anchor
    Vector3 p = CallVec(GET_ENTITY_COORDS, c.base, true, false);
    if (p.z < c.z - 0.5f || p.z > c.z + 2.5f) {
        CallV(SET_ENTITY_VELOCITY, c.base, 0.0f, 0.0f, 0.0f);
        CallV(SET_ENTITY_COORDS_NO_OFFSET, c.base, c.x, c.y, c.z, false, false, false);
        LI("couple seq=%d: lower partner was at z %.2f (scene %.2f) -> put back", c.seq, p.z, c.z);
    }
}
static void nh_release(const Couple& c) {          // detach, collision and ragdoll back (NpcHookups' ResetForScene)
    if (ped_ok(c.top)) {
        if (ped_ok(c.base) && CallB(IS_ENTITY_ATTACHED_TO_ENTITY, c.top, c.base)) CallV(DETACH_ENTITY, c.top, true, true);
        CallV(SET_ENTITY_COLLISION, c.top, true, true);
    }
    for (int p2 : {c.base, c.top}) if (ped_ok(p2)) CallV(SET_PED_CAN_RAGDOLL, p2, true);
}
static void couple_play(Couple& c, bool force = false) {
    if (c.pos) {                                     // keep the NpcHookups scene alive (RESTART_CLIP_AFTER_MS)
        if (c.stage < 2) return;
        if (!ped_ok(c.base) || !ped_ok(c.top)) return;
        if (force || !CallB(IS_ENTITY_PLAYING_ANIM, c.base, HOOKUP_DICT, nh_base_clip(c), 3)) nh_play(c.base, nh_base_clip(c));
        nh_pin_base(c);
        if (force || !CallB(IS_ENTITY_ATTACHED_TO_ENTITY, c.top, c.base)) {
            if (!force) LI("couple seq=%d: upper partner came loose -> re-attaching", c.seq);
            nh_attach(c);
        }
        if (force || !CallB(IS_ENTITY_PLAYING_ANIM, c.top, HOOKUP_DICT, "loop_female", 3)) nh_play(c.top, "loop_female");
        return;
    }
    int peds[2] = {c.a, c.b};
    float hr = c.h * 3.14159265f / 180.f, ch = cosf(hr), sh = sinf(hr);
    for (int k = 0; k < 2; ++k) {
        int ped = peds[k];
        if (!ped_ok(ped)) continue;
        const char* clip = couple_clip(c, k);
        if (!force && CallB(IS_ENTITY_PLAYING_ANIM, ped, c.dict.c_str(), clip, 3)) continue;
        const float* o = c.off[k];                   // offset in the anchor's frame: x = sideways, y = along, z = up
        float x = c.x + o[0] * ch - o[1] * sh, y = c.y + o[0] * sh + o[1] * ch, z = c.z + o[2];
        CallV(TASK_PLAY_ANIM_ADVANCED, ped, c.dict.c_str(), clip, x, y, z, o[3], o[4], c.h + o[5], 8.0f, -8.0f, -1, c.flags, 0.0f, 0, 0, 0);
    }
}
static void couple_end_peds(const Couple& c, bool clear) {
    if (c.pos) nh_release(c);
    for (int p2 : {c.a, c.b}) {
        if (!ped_ok(p2)) continue;
        couple_stop_anims(c, p2);
        if (clear) CallV(CLEAR_PED_TASKS, p2, false, false);
    }
}
static void couple_tick() {
    uint64_t t = now_ms();
    for (size_t i = 0; i < g_couples.size();) {
        Couple& c = g_couples[i];
        bool withPlayer = c.b == g_player || c.a == g_player;
        if (t < c.next && !(withPlayer && c.on)) { ++i; continue; }
        if (!c.on) {
            if (!CallB(HAS_ANIM_DICT_LOADED, c.dict.c_str())) {
                CallV(REQUEST_ANIM_DICT, c.dict.c_str());
                c.next = t + 100;
                if (t > c.deadline) { act_result(c.seq, false, "couple clips did not load"); g_couples.erase(g_couples.begin() + i); continue; }
                ++i; continue;
            }
            int peds[2] = {c.a, c.b};
            if (c.pos && c.stage == 1) {             // the lower partner is in his clip: now the upper one goes on top
                if (!CallB(IS_ENTITY_PLAYING_ANIM, c.base, HOOKUP_DICT, nh_base_clip(c), 3) && t < c.stageAt + 1500) {
                    c.next = t + 50; ++i; continue;
                }
                nh_pin_base(c);
                nh_attach(c);
                nh_play(c.top, "loop_female");
                c.stage = 2; c.on = true;
                LI("couple seq=%d peds base=%d top=%d on at %.1f %.1f %.1f h=%.0f - %s (NpcHookups' way)", c.seq, c.base, c.top,
                   c.x, c.y, c.z, c.h, NH_POS_NAME[c.pos]);
                act_result(c.seq, true, "");
                c.next = t + 900; ++i; continue;
            }
            for (int ped : peds) {
                if (!ped_ok(ped)) continue;
                Managed* m = find_m(ped);
                if (m) { order_clear(*m, "couple"); m->overridden = true; }
                if (c.pos && ped_ok(c.a) && ped_ok(c.b)) {       // a pose change: whoever was attached lets go first
                    for (int o : {c.a, c.b}) if (o != ped && CallB(IS_ENTITY_ATTACHED_TO_ENTITY, ped, o)) CallV(DETACH_ENTITY, ped, true, true);
                }
                CallV(CLEAR_PED_TASKS_IMMEDIATELY, ped, false, true);
                if (c.pos) CallV(SET_ENTITY_COORDS_NO_OFFSET, ped, c.x, c.y, c.z, false, false, false);
                else CallV(SET_ENTITY_COORDS, ped, c.x, c.y, c.z, false, false, false, false);
                CallV(SET_ENTITY_HEADING, ped, c.h);
                if (ped != g_player) { CallV(SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, ped, true); CallV(SET_PED_KEEP_TASK, ped, true); }
                if (c.pos) CallV(SET_PED_CAN_RAGDOLL, ped, false);
            }
            if (c.pos) {
                nh_roles(c);
                CallV(SET_ENTITY_NO_COLLISION_ENTITY, c.a, c.b, true);
                CallV(SET_ENTITY_NO_COLLISION_ENTITY, c.b, c.a, true);
                nh_play(c.base, nh_base_clip(c));
                c.stage = 1; c.stageAt = t; c.next = t + 50;
                ++i; continue;
            }
            c.on = true;
            couple_play(c);
            LI("couple seq=%d peds %d+%d on at %.1f %.1f %.1f h=%.0f flags=%d clips %s %s/%s%s", c.seq, c.a, c.b, c.x, c.y, c.z, c.h, c.flags,
               c.dict.c_str(), c.clipA.c_str(), c.clipB.c_str(), c.swap ? " swapped" : "");
            act_result(c.seq, true, "");
            c.next = t + 3000; ++i; continue;
        }
        bool aOk = ped_ok(c.a) && !CallB(IS_ENTITY_DEAD, c.a), bOk = ped_ok(c.b) && !CallB(IS_ENTITY_DEAD, c.b);
        if (!aOk || !bOk) {
            LI("couple seq=%d over: someone is gone", c.seq);
            couple_end_peds(c, false);
            send_event("couple_over", c.a, "someone is gone");
            g_couples.erase(g_couples.begin() + i); continue;
        }
        if (withPlayer) {                            // the player can always get up: jump or sprint ends it
            static uint32_t jump = joaat("INPUT_JUMP"), sprint = joaat("INPUT_SPRINT");
            if (CallB(IS_CONTROL_PRESSED, 0, jump) || CallB(IS_CONTROL_PRESSED, 0, sprint)) {
                couple_end_peds(c, true);
                LI("couple seq=%d: the player got up", c.seq);
                send_event("couple_over", c.a == g_player ? c.b : c.a, "the player got up");
                g_couples.erase(g_couples.begin() + i); continue;
            }
        }
        if (t < c.next) { ++i; continue; }
        couple_play(c);          // the game sometimes drops a looping clip or the attachment (an event, a bump): put it back
        c.next = t + (c.pos ? 900 : 3000);
        ++i;
    }
}
static void couple_stop(int ped) {
    for (size_t i = 0; i < g_couples.size(); ++i) {
        Couple& c = g_couples[i];
        if (c.a != ped && c.b != ped) continue;
        couple_end_peds(c, true);
        LI("couple seq=%d stopped (peds %d+%d)", c.seq, c.a, c.b);
        g_couples.erase(g_couples.begin() + i);
        return;
    }
}

// ── 0.5.8: undress when the ped is really there ──────────────────────────────────────────────────────────────────
// Your 0.5.7 household couple stayed dressed: they were undressed the moment they spawned, before their look had
// streamed in, and the wife's skin-tone matching then put outfit presets back on her for up to 24 s. Now: wait until
// the ped is ready to render and no skin-tone job runs for them, undress, look again 1.5 s later, retry up to 3 times.
struct UndressJob { int ped, tries, waits; bool check; uint64_t at; };
static std::vector<UndressJob> g_undress;
static bool tone_busy(int ped) { for (auto& j : g_tone) if (j.ped == ped) return true; return false; }
static void undress_later(int ped) {
    for (auto& j : g_undress) if (j.ped == ped) { j.tries = 0; j.waits = 0; j.check = false; j.at = now_ms(); return; }
    g_undress.push_back({ped, 0, 0, false, now_ms()});
}
static void undress_cancel(int ped) {
    for (size_t i = 0; i < g_undress.size(); ++i) if (g_undress[i].ped == ped) { g_undress.erase(g_undress.begin() + i); return; }
}
static void undress_tick() {
    uint64_t t = now_ms();
    for (size_t i = 0; i < g_undress.size();) {
        UndressJob& j = g_undress[i];
        if (t < j.at) { ++i; continue; }
        if (!ped_ok(j.ped) || CallB(IS_ENTITY_DEAD, j.ped)) { g_undress.erase(g_undress.begin() + i); continue; }
        if (!j.check) {
            if ((tone_busy(j.ped) || !CallB(IS_PED_READY_TO_RENDER, j.ped)) && j.waits < 60) { ++j.waits; j.at = t + 500; ++i; continue; }
            std::string why;
            undress_ped(j.ped, why);
            j.check = true; j.at = t + 1500; ++i; continue;
        }
        int up = 0, low = 0; clothes_count(j.ped, up, low);
        if (up == 0 || nude_torso_on(j.ped)) {
            LI("undress ped=%d: done (%d clothing pieces left below)", j.ped, low);
            g_undress.erase(g_undress.begin() + i); continue;
        }
        if (++j.tries < 3) {
            LI("undress ped=%d: %d upper clothing pieces still on - again (%d)", j.ped, up, j.tries);
            g_looks.erase(j.ped);                    // what's on now is what goes back on later
            j.check = false; j.at = t + 300; ++i; continue;
        }
        LW("undress ped=%d: gave up - %d upper pieces stay on", j.ped, up);
        g_undress.erase(g_undress.begin() + i);
    }
}

static bool do_task(Managed* m, int ped, const char* name, int argc, char** argv, std::string& why) {
    auto F = [&](int i, float d) { return i < argc ? (float)atof(argv[i]) : d; };
    auto I = [&](int i, int d) { return i < argc ? atoi(argv[i]) : d; };
    uint32_t unarmed = joaat("WEAPON_UNARMED");
    if (!strcmp(name, "clear")) CallV(CLEAR_PED_TASKS, ped, false, false);
    else if (!strcmp(name, "stand")) { CallV(TASK_TURN_PED_TO_FACE_ENTITY, ped, g_tgt, I(0, -1), 0.f, 0.f, 0.f); if (m) m->lookAt = 0; }
    else if (!strcmp(name, "face")) CallV(TASK_TURN_PED_TO_FACE_ENTITY, ped, g_tgt, I(0, 8000), 0.f, 0.f, 0.f);
    else if (!strcmp(name, "look")) { CallV(TASK_LOOK_AT_ENTITY, ped, g_tgt, I(0, 8000), 2048, 3, 0); if (m) m->lookAt = now_ms() + I(0, 8000); }
    else if (!strcmp(name, "look_clear")) { CallV(TASK_CLEAR_LOOK_AT, ped); if (m) m->lookAt = UINT64_MAX; }
    else if (!strcmp(name, "flee")) { if (m && m->blocked) { CallV(SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, ped, false); m->blocked = false; }
        if (m) m->handsUp = false; CallV(TASK_SMART_FLEE_PED, ped, g_tgt, F(0, 150.f), -1, 0, 3.0f, 0); }
    else if (!strcmp(name, "follow")) CallV(TASK_FOLLOW_TO_OFFSET_OF_ENTITY, ped, g_tgt, F(0, 1.2f), F(1, -1.8f), 0.f, F(2, 2.0f), -1, 2.5f, true, false, false, false, false, false);
    else if (!strcmp(name, "goto_player")) CallV(TASK_GO_TO_ENTITY, ped, g_tgt, -1, F(0, 1.6f), F(1, 1.2f), 0.f, 0);
    else if (!strcmp(name, "wander")) CallV(TASK_WANDER_STANDARD, ped, 10.0f, 10);
    else if (!strcmp(name, "hands_up")) { CallV(TASK_HANDS_UP, ped, I(0, 120000), g_tgt, -1, 0); if (m) { m->handsUp = true; m->handsUpRefresh = now_ms() + 50000; } }
    else if (!strcmp(name, "cower")) CallV(TASK_COWER, ped, I(0, 60000), g_tgt, (const char*)nullptr);
    else if (!strcmp(name, "combat")) { if (m && m->blocked) { CallV(SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, ped, false); m->blocked = false; }
        CallV(TASK_COMBAT_PED, ped, g_tgt, 0, 16); }
    else if (!strcmp(name, "cover")) CallV(TASK_SEEK_COVER_FROM_PED, ped, g_tgt, -1, 0, 0, 0);
    else if (!strcmp(name, "mount_near")) {
        int horse = CallI(GET_LAST_MOUNT, ped);
        if (horse && (!ped_ok(horse) || CallB(IS_ENTITY_DEAD, horse) || CallI(GET_RIDER_OF_MOUNT, horse, false) ||
                      dist3(CallVec(GET_ENTITY_COORDS, horse, true, false), CallVec(GET_ENTITY_COORDS, ped, true, false)) > 35.f)) horse = 0;
        if (!horse) horse = nearest_horse(ped, 30.f);
        if (!horse) { why = "no free horse within 30 m"; return false; }
        CallV(TASK_MOUNT_ANIMAL, ped, horse, 12000, -1, 2.0f, 1, 0, 0);    // timer: the game seats them itself after 12 s
        if (m) order_set(*m, O_MOUNT, horse, -1);
        LI("mount_near ped=%d horse=%d", ped, horse);
    } else if (!strcmp(name, "ride_with_player")) {
        int mount = CallB(IS_PED_ON_MOUNT, g_player) ? CallI(GET_MOUNT, g_player) : 0;
        int veh = CallB(IS_PED_IN_ANY_VEHICLE, g_player, false) ? CallI(GET_VEHICLE_PED_IS_IN, g_player, false) : 0;
        Vector3 pp = CallVec(GET_ENTITY_COORDS, ped, true, false);
        if (!mount && !veh) {
            int lm = CallI(GET_LAST_MOUNT, g_player);
            if (lm && ped_ok(lm) && !CallB(IS_ENTITY_DEAD, lm) && dist3(CallVec(GET_ENTITY_COORDS, lm, true, false), pp) < 35.f) mount = lm;
            else {
                int lv = CallI(GET_PLAYERS_LAST_VEHICLE);
                if (lv && ped_ok(lv) && dist3(CallVec(GET_ENTITY_COORDS, lv, true, false), pp) < 35.f) veh = lv;
            }
        }
        if (mount) {
            if (!CallB(IS_MOUNT_SEAT_FREE, mount, 0)) { why = "the horse's back seat is taken"; return false; }
            CallV(TASK_MOUNT_ANIMAL, ped, mount, 12000, 0, 2.0f, 1, 0, 0);
            if (m) order_set(*m, O_RIDE, mount, 0);
            LI("ride_with_player ped=%d -> horse %d seat 0", ped, mount);
        } else if (veh) {
            int maxp = CallI(GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS, veh), seat = -2;
            for (int s = 0; s < maxp && s < 8; ++s) if (CallB(IS_VEHICLE_SEAT_FREE, veh, s)) { seat = s; break; }
            if (seat == -2) { why = "no free seat on the wagon"; return false; }
            CallV(TASK_ENTER_VEHICLE, ped, veh, 15000, seat, 2.0f, 1, 0);
            if (m) order_set(*m, O_VEH, veh, seat);
            LI("ride_with_player ped=%d -> vehicle %d seat %d", ped, veh, seat);
        } else { why = "no horse or wagon of yours nearby"; return false; }
    } else if (!strcmp(name, "dismount")) {
        if (!CallB(IS_PED_ON_MOUNT, ped)) { if (m) { order_set(*m, O_FOOT, 0, -1); m->oSettled = true; } why = "already on foot"; return true; }
        CallV(TASK_DISMOUNT_ANIMAL, ped, 0, 0, 0, 0, 0);
        if (m) order_set(*m, O_FOOT, 0, -1);      // and STAY off: the order keeper puts them back down if their AI remounts
    }
    else if (!strcmp(name, "leave_vehicle")) {
        int v = veh_of(ped);
        if (!v) { why = "already off the wagon"; if (m) { order_set(*m, O_OUT, 0, -1); m->oSettled = true; } return true; }
        if (m && is_driver(ped, v) && !m->vHalt) veh_halt(*m, v);       // a driver stops the wagon before he climbs down
        CallV(TASK_LEAVE_VEHICLE, ped, v, 0, 0);
        if (m) order_set(*m, O_OUT, v, -1);
        LI("leave_vehicle ped=%d wagon=%d%s", ped, v, is_driver(ped, v) ? " (driver)" : "");
    }
    else if (!strcmp(name, "lead_horse")) {
        int horse = CallI(GET_LAST_MOUNT, ped);
        if (!horse || !ped_ok(horse)) horse = nearest_horse(ped, 20.f);
        if (!horse) { why = "no horse to lead"; return false; }
        CallV(TASK_LEAD_HORSE, ped, horse);
    } else if (!strcmp(name, "holster")) CallV(SET_CURRENT_PED_WEAPON, ped, unarmed, true, 0, false, false);
    else if (!strcmp(name, "draw")) {
        uint32_t w = CallH(GET_BEST_PED_WEAPON, ped, false, false);
        if (!w || w == unarmed) { why = "no weapon"; return false; }
        CallV(SET_CURRENT_PED_WEAPON, ped, w, true, 0, false, false);
    } else if (!strcmp(name, "drop_weapon")) {
        alignas(8) uint64_t wb = 0;
        CallB(GET_CURRENT_PED_WEAPON, ped, &wb, false, 0, false);
        uint32_t w = (uint32_t)wb;
        if (!w || w == unarmed) { w = CallH(GET_BEST_PED_WEAPON, ped, false, false); }
        if (!w || w == unarmed) { why = "nothing to drop"; return false; }
        CallV(SET_PED_DROPS_INVENTORY_WEAPON, ped, w, 0.f, 0.5f, 0.f, 30);
        CallV(SET_CURRENT_PED_WEAPON, ped, unarmed, true, 0, false, false);
    } else if (!strcmp(name, "block")) { bool on = I(0, 1) != 0; CallV(SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, ped, on); if (m) m->blocked = on; }
    else if (!strcmp(name, "keep")) CallV(SET_PED_KEEP_TASK, ped, I(0, 1) != 0);
    else if (!strcmp(name, "persist")) {
        bool on = I(0, 1) != 0;
        if (on && g_cfg.persistFollowers && m && !m->persist) { CallV(SET_ENTITY_AS_MISSION_ENTITY, ped, true, true); m->persist = true; }
        else if (!on && m && m->persist) { alignas(8) int p = ped; CallV(SET_ENTITY_AS_NO_LONGER_NEEDED, &p); m->persist = false; }
    } else if (!strcmp(name, "unhogtie")) { CallV(UNHOGTIE_PED, ped, 0, 0u, "", "", 0.0f);
    } else if (!strcmp(name, "goto_coord")) {
        if (argc < 3) { why = "goto_coord needs x y z"; return false; }
        CallV(TASK_FOLLOW_NAV_MESH_TO_COORD, ped, F(0, 0.f), F(1, 0.f), F(2, 0.f), F(3, 1.0f), -1, 1.5f, 0, 40000.0f);
    } else if (!strcmp(name, "give_weapon")) {
        if (argc < 1) { why = "give_weapon needs a weapon name"; return false; }
        uint32_t w = joaat(argv[0]);
        CallH(GIVE_WEAPON_TO_PED, ped, w, 1, true, false, 0, false, 0.5f, 1.0f, joaat("ADD_REASON_DEFAULT"), false, 0.0f, false);
        CallV(SET_CURRENT_PED_WEAPON, ped, w, true, 0, false, false);
    } else if (!strncmp(name, "veh_", 4)) {                 // 0.4.0: driving
        int veh = veh_of(ped);
        if (!veh) { why = "not in a wagon"; return false; }
        if (!is_driver(ped, veh)) { why = "not the one driving"; return false; }
        if (is_tram(veh)) { why = "it's a streetcar on rails - it only stops at its stops"; return false; }
        if (!m) { why = "not managed"; return false; }
        if (!strcmp(name, "veh_stop")) { veh_halt(*m, veh); LI("veh_stop ped=%d wagon=%d", ped, veh); }
        else if (!strcmp(name, "veh_go")) { veh_unhalt(*m); m->vDrive = 0; CallV(TASK_VEHICLE_DRIVE_WANDER, ped, veh, F(0, 6.0f), 0); LI("veh_go ped=%d", ped); }
        else if (!strcmp(name, "veh_speed")) { CallV(SET_DRIVE_TASK_CRUISE_SPEED, ped, F(0, 6.0f)); LI("veh_speed ped=%d %.1f", ped, F(0, 6.0f)); }
        else if (!strcmp(name, "veh_to")) { if (argc < 3) { why = "veh_to needs x y z"; return false; } veh_drive_to(*m, veh, F(0, 0), F(1, 0), F(2, 0), F(3, 7.0f)); LI("veh_to ped=%d %.0f %.0f", ped, F(0, 0), F(1, 0)); }
        else if (!strcmp(name, "veh_waypoint")) {
            if (!CallB(IS_WAYPOINT_ACTIVE)) { why = "there's no waypoint on your map"; return false; }
            Vector3 w = CallVec(GET_WAYPOINT_COORDS);
            veh_drive_to(*m, veh, w.x, w.y, w.z, F(0, 7.0f)); LI("veh_waypoint ped=%d -> %.0f %.0f", ped, w.x, w.y);
        } else if (!strcmp(name, "veh_turn")) {            // left / right / back at the next chance: a point beside the road ahead
            float h = CallF(GET_ENTITY_HEADING, veh) * 0.0174533f;
            float fx = -sinf(h), fy = cosf(h), side = (argc > 0 && argv[0][0] == 'l') ? 1.f : -1.f;
            bool back = argc > 0 && argv[0][0] == 'b';
            Vector3 p = CallVec(GET_ENTITY_COORDS, veh, true, false);
            float tx = back ? p.x - fx * 80.f : p.x + fx * 30.f - fy * side * 60.f;   // left of (fx,fy) is (-fy,fx)
            float ty = back ? p.y - fy * 80.f : p.y + fy * 30.f + fx * side * 60.f;
            veh_drive_to(*m, veh, tx, ty, p.z, F(1, 6.0f)); LI("veh_turn ped=%d %s -> %.0f %.0f", ped, argc > 0 ? argv[0] : "?", tx, ty);
        } else { why = std::string("unknown task ") + name; return false; }
    } else if (!strcmp(name, "undress")) {
        if (!ped_ok(ped) || CallB(IS_ENTITY_DEAD, ped)) { why = "gone"; return false; }
        undress_later(ped);                                 // 0.5.8: once the ped is streamed in, checked and retried
    } else if (!strcmp(name, "dress")) {
        undress_cancel(ped);
        if (!dress_ped(ped, 0, why)) return false;
    } else if (!strcmp(name, "use_spot")) {               // walk to the nearest real bench/chair/bar/fire spot and use it
        Vector3 p = CallVec(GET_ENTITY_COORDS, ped, true, false);
        float r = F(0, 15.0f);
        if (!CallB(DOES_SCENARIO_EXIST_IN_AREA, p.x, p.y, p.z, r, true, 0, false)) {
            scen_watch(ped, 0, "nearest spot", 0);                       // answers 'not running' right away
            why = "no bench, chair or spot free nearby"; return false;
        }
        CallV(TASK_USE_NEAREST_SCENARIO_TO_COORD, ped, p.x, p.y, p.z, r, -1, false, false, false, false);
        if (m) m->overridden = true;
        scen_watch(ped, 0, "nearest spot", 9000);
        LI("use_spot ped=%d r=%.0f", ped, r);
    } else if (!strcmp(name, "use_point")) {             // households: use THIS chair / stove / basin (a point from home_scan)
        if (argc < 3) { why = "use_point needs x y z"; return false; }
        float x = F(0, 0.f), y = F(1, 0.f), z = F(2, 0.f), r = F(3, 1.0f);
        bool warp = I(4, 0) != 0; int ms = I(5, -1);
        if (!CallB(DOES_SCENARIO_EXIST_IN_AREA, x, y, z, r, true, 0, false)) {
            scen_watch(ped, 0, "home spot", 0);
            why = "that spot is taken or gone"; return false;
        }
        if (warp) CallV(TASK_USE_NEAREST_SCENARIO_TO_COORD_WARP, ped, x, y, z, r, ms, false, false, false, false);
        else CallV(TASK_USE_NEAREST_SCENARIO_TO_COORD, ped, x, y, z, r, ms, false, false, false, false);
        if (m) m->overridden = true;
        scen_watch(ped, 0, "home spot", warp ? 2500 : 15000);
        LI("use_point ped=%d %.1f %.1f %.1f r=%.1f %s", ped, x, y, z, r, warp ? "warp" : "walk");
    } else if (!strcmp(name, "goto_any")) {              // 0.5.1: go somewhere by any means (rides if on a horse)
        if (argc < 3) { why = "goto_any needs x y z"; return false; }
        CallV(TASK_GO_TO_COORD_ANY_MEANS, ped, F(0, 0.f), F(1, 0.f), F(2, 0.f), F(3, 2.0f), 0, false, 0, -1.0f);
        if (m) m->overridden = true;
    } else if (!strcmp(name, "ride_behind")) {           // 0.5.1: get on behind someone (t=<rider>) on their horse
        int rider = g_tgt;
        int mount = (rider && ped_ok(rider) && CallB(IS_PED_ON_MOUNT, rider)) ? CallI(GET_MOUNT, rider) : 0;
        if (!mount) { why = "they're not on a horse"; return false; }
        if (!CallB(IS_MOUNT_SEAT_FREE, mount, 0)) { why = "the back seat is taken"; return false; }
        CallV(TASK_MOUNT_ANIMAL, ped, mount, 12000, 0, 2.0f, 1, 0, 0);
    } else if (!strcmp(name, "pain")) {                  // 0.5.1: a scream + their own fear/flight is allowed again
        if (m && m->blocked) { CallV(SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, ped, false); m->blocked = false; }
        if (!m || now_ms() >= m->painUntil) { CallV(PLAY_PAIN, ped, I(0, 1), 0.0f, false, false); if (m) m->painUntil = now_ms() + 2500; }
    } else { why = std::string("unknown task ") + name; return false; }
    return true;
}

// ───────────────────────── incoming commands ─────────────────────────
static int unhex(char c) { return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1; }
static void pct_decode(char* s) {
    char* o = s;
    for (char* p = s; *p; ++p) {
        if (*p == '%' && p[1] && p[2] && unhex(p[1]) >= 0 && unhex(p[2]) >= 0) { *o++ = (char)(unhex(p[1]) * 16 + unhex(p[2])); p += 2; }
        else *o++ = *p;
    }
    *o = 0;
}

struct PendingSpawn { int seq; std::string kind, model, flags; float x, y, z, h; uint64_t deadline; };
static std::vector<PendingSpawn> g_spawns;
static int g_routeBlip = 0; static float g_route[3]; static bool g_routeOn = false; static uint64_t g_routeRefresh = 0;
static char g_routeName[64] = "";

static void spawn_reply(int seq, int h, const char* kind, const char* why) {
    std::string o = "{\"t\":\"spawned\""; jkv(o, "seq", seq); jkv(o, "h", h); o += ",\"kind\":"; json_str(o, kind);
    o += ",\"why\":"; json_str(o, why ? why : ""); o += "}"; net_send(o);
}
static float ground_z(float x, float y, float zHint) {
    alignas(8) float gz = 0.f; alignas(8) uint64_t pad = 0; (void)pad;
    if (CallB(GET_GROUND_Z_FOR_3D_COORD, x, y, zHint + 60.f, &gz, false)) return gz;
    return zHint;
}
static void pump_spawns() {
    for (size_t i = 0; i < g_spawns.size();) {
        PendingSpawn& sp = g_spawns[i];
        uint32_t mdl = joaat(sp.model.c_str());
        if (!CallB(HAS_MODEL_LOADED, mdl)) {
            if (now_ms() > sp.deadline) { LW("spawn seq=%d model %s did not load", sp.seq, sp.model.c_str()); spawn_reply(sp.seq, 0, sp.kind.c_str(), "model did not load"); g_spawns.erase(g_spawns.begin() + i); }
            else { CallV(REQUEST_MODEL, mdl, false); ++i; }
            continue;
        }
        float z = sp.z;
        if (sp.flags.find("floor") != std::string::npos) {     // 0.5.5: at a building - the ground right under them, not the roof
            alignas(8) float gz = 0.f;
            if (CallB(GET_GROUND_Z_FOR_3D_COORD, sp.x, sp.y, sp.z + 1.5f, &gz, false)) z = gz;
        } else if (sp.flags.find("ground") != std::string::npos) z = ground_z(sp.x, sp.y, sp.z);
        int h = 0;
        if (sp.kind == "obj") {
            h = CallI(CREATE_OBJECT, mdl, sp.x, sp.y, z, false, false, false, false, false);
            if (h) { CallB(PLACE_OBJECT_ON_GROUND_PROPERLY, h, true); CallV(SET_ENTITY_HEADING, h, sp.h); }
        } else if (sp.kind == "veh") {
            h = CallI(CREATE_VEHICLE, mdl, sp.x, sp.y, z, sp.h, false, false, false, false);
        } else {
            h = CallI(CREATE_PED, mdl, sp.x, sp.y, z, sp.h, false, false, false, false);
            if (h) CallV(SET_RANDOM_OUTFIT_VARIATION, h, true);
        }
        CallV(SET_MODEL_AS_NO_LONGER_NEEDED, mdl);
        if (h) {
            CallV(SET_ENTITY_AS_MISSION_ENTITY, h, true, true);
            if (sp.flags.find("invincible") != std::string::npos) CallV(SET_ENTITY_INVINCIBLE, h, true);
            if (sp.flags.find("hogtied") != std::string::npos) CallV(TASK_KNOCKED_OUT_AND_HOGTIED, h, 0.0f, 0);
            if (sp.flags.find("dead") != std::string::npos) CallV(SET_ENTITY_HEALTH, h, 0, 0);
            size_t wp = sp.flags.find("weapon=");
            if (wp != std::string::npos) {
                std::string w = sp.flags.substr(wp + 7); w = w.substr(0, w.find(','));
                uint32_t wh = joaat(w.c_str());
                CallH(GIVE_WEAPON_TO_PED, h, wh, 30, false, true, 0, false, 0.5f, 1.0f, joaat("ADD_REASON_DEFAULT"), false, 0.0f, false);
            }
            size_t lk = sp.flags.find("like=");
            if (lk != std::string::npos && sp.kind == "ped") tone_start(h, atoi(sp.flags.c_str() + lk + 5));
            size_t sc = sp.flags.find("scenario=");
            if (sc != std::string::npos) {
                std::string n = sp.flags.substr(sc + 9); n = n.substr(0, n.find(','));
                CallV(TASK_START_SCENARIO_IN_PLACE_HASH, h, joaat(n.c_str()), -1, false, 0u, -1.0f, false);
            }
        }
        LI("spawn seq=%d %s %s at %.1f %.1f %.1f -> %d (%s)", sp.seq, sp.kind.c_str(), sp.model.c_str(), sp.x, sp.y, z, h, sp.flags.c_str());
        spawn_reply(sp.seq, h, sp.kind.c_str(), h ? "" : "create failed");
        g_spawns.erase(g_spawns.begin() + i);
    }
}
static void draw_route() {
    if (!g_routeOn) return;
    uint64_t t = now_ms();
    if (t < g_routeRefresh) return;
    g_routeRefresh = t + 5000;       // the line starts where you are: redraw as you move
    CallV(START_GPS_MULTI_ROUTE, joaat("COLOR_YELLOW"), true, true);
    CallV(ADD_POINT_TO_GPS_MULTI_ROUTE, g_ppos.x, g_ppos.y, g_ppos.z, false);
    CallV(ADD_POINT_TO_GPS_MULTI_ROUTE, g_route[0], g_route[1], g_route[2], false);
    CallV(SET_GPS_MULTI_ROUTE_RENDER, true);
}
static void route_set(float x, float y, float z, const char* name) {
    if (g_routeBlip) { alignas(8) int b = g_routeBlip; CallV(REMOVE_BLIP, &b); g_routeBlip = 0; }
    g_routeBlip = CallI(BLIP_ADD_FOR_COORDS, joaat("BLIP_STYLE_OBJECTIVE"), x, y, z);
    if (g_routeBlip) {
        CallV(SET_BLIP_SPRITE, g_routeBlip, joaat("blip_camp"), true);
        const char* vs = CallS(VAR_STRING, 10, "LITERAL_STRING", name);
        CallV(SET_BLIP_NAME, g_routeBlip, vs);
    }
    g_route[0] = x; g_route[1] = y; g_route[2] = z; g_routeOn = true; g_routeRefresh = 0;
    snprintf(g_routeName, sizeof g_routeName, "%s", name);
    LI("route to %.1f %.1f %.1f '%s' blip=%d", x, y, z, name, g_routeBlip);
}
static void route_clear() {
    if (g_routeBlip) { alignas(8) int b = g_routeBlip; CallV(REMOVE_BLIP, &b); g_routeBlip = 0; }
    if (g_routeOn) { CallV(CLEAR_GPS_MULTI_ROUTE); g_routeOn = false; LI("route cleared"); }
}

struct PendingAnim { int seq, ped, flags, ms; std::string dict, name; uint64_t deadline; };
static std::vector<PendingAnim> g_anims;

static void on_line(char* line) {
    char* tok[24]; int n = 0;
    for (char* p = strtok(line, " "); p && n < 24; p = strtok(nullptr, " ")) { pct_decode(p); tok[n++] = p; }
    if (!n) return;
    const char* c = tok[0];
    LD("<< %s %s %s %s", c, n > 1 ? tok[1] : "", n > 2 ? tok[2] : "", n > 3 ? tok[3] : "");
    if (!strcmp(c, "hello_ack")) { g_helloAck = true; LI("brain hello_ack version %s", n > 1 ? tok[1] : "?"); }
    else if (!strcmp(c, "toast") && n >= 4) toast(tok[1], atoi(tok[2]), tok[3]);
    else if (!strcmp(c, "engage_ok") && n >= 3) { int ped = atoi(tok[1]); if (g_pendingEngage == ped) g_pendingEngage = 0; engage(ped, tok[2]); }
    else if (!strcmp(c, "engage_deny") && n >= 2) { int ped = atoi(tok[1]); if (g_pendingEngage == ped) g_pendingEngage = 0; LI("engage denied ped=%d (%s)", ped, n > 2 ? tok[2] : ""); }
    else if (!strcmp(c, "engage")) { LD("engage hint ped=%s", n > 1 ? tok[1] : "?"); }
    else if (!strcmp(c, "hud") && n >= 3) { Managed* m = find_m(atoi(tok[1])); if (m) snprintf(m->hud, sizeof m->hud, "%s", tok[2]); }
    else if (!strcmp(c, "state") && n >= 3) { Managed* m = find_m(atoi(tok[1])); if (m) m->state = !strcmp(tok[2], "thinking") ? 1 : 0; }
    else if (!strcmp(c, "override") && n >= 2) { Managed* m = find_m(atoi(tok[1])); if (m) m->overridden = true; }
    else if (!strcmp(c, "actor") && n >= 3) {
        int ped = atoi(tok[1]); bool on = atoi(tok[2]) != 0;
        Managed* m = find_m(ped);
        if (on) {
            if (!ped_ok(ped) || CallB(IS_ENTITY_DEAD, ped)) { send_event("actor_gone", ped); return; }
            if (!m) { g_peds.push_back(Managed{}); m = &g_peds.back(); m->ped = ped; m->hold = H_NONE; }
            m->actor = true;
            if (!m->blocked) { CallV(SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, ped, true); m->blocked = true; }
            if (g_cfg.stopAmbientSpeech && !in_love(ped)) { CallV(STOP_PED_SPEAKING, ped, true); mute_vanilla(ped); }
            LI("actor ped=%d joins a scene", ped);
        } else if (m && m->actor) {
            m->actor = false;
            if (!m->engaged && !m->keep) {
                stop_talk(*m);
                if (ped_ok(ped)) {
                    if (m->blocked) CallV(SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, ped, false);
                    if (g_cfg.stopAmbientSpeech) CallV(STOP_PED_SPEAKING, ped, false);
                    CallV(TASK_CLEAR_LOOK_AT, ped);
                }
                g_peds.erase(std::remove_if(g_peds.begin(), g_peds.end(), [&](const Managed& x) { return x.ped == ped; }), g_peds.end());
            }
            LI("actor ped=%d leaves the scene", ped);
        }
    }
    else if (!strcmp(c, "spawn") && n >= 8) {
        PendingSpawn sp{atoi(tok[1]), tok[2], tok[3], n > 8 ? tok[8] : "", (float)atof(tok[4]), (float)atof(tok[5]),
                        (float)atof(tok[6]), (float)atof(tok[7]), now_ms() + 8000};
        uint32_t mdl = joaat(sp.model.c_str());
        if (!CallB(IS_MODEL_IN_CDIMAGE, mdl)) { LW("spawn: model %s not in the game", sp.model.c_str()); spawn_reply(sp.seq, 0, sp.kind.c_str(), "no such model"); return; }
        CallV(REQUEST_MODEL, mdl, false);
        g_spawns.push_back(sp);
    }
    else if (!strcmp(c, "despawn") && n >= 3) {
        alignas(8) int h = atoi(tok[1]);
        if (ped_ok(h)) {
            if (!strcmp(tok[2], "delete")) CallV(DELETE_ENTITY, &h);
            else CallV(SET_ENTITY_AS_NO_LONGER_NEEDED, &h);
        }
    }
    else if (!strcmp(c, "probe") && n >= 5) {
        int seq = atoi(tok[1]); float x = (float)atof(tok[2]), y = (float)atof(tok[3]), z = (float)atof(tok[4]);
        alignas(8) float gz = 0.f, wh = 0.f;
        bool ok = CallB(GET_GROUND_Z_FOR_3D_COORD, x, y, z + 300.f, &gz, false);
        bool water = CallB(GET_WATER_HEIGHT_NO_WAVES, x, y, ok ? gz : z, &wh) && wh > (ok ? gz : z) + 0.3f;
        std::string o = "{\"t\":\"probe\""; jkv(o, "seq", seq); jkv(o, "ok", ok); jkv(o, "x", x); jkv(o, "y", y);
        jkv(o, "z", ok ? gz : z); jkv(o, "water", water); o += "}"; net_send(o);
    }
    else if (!strcmp(c, "crime") && n >= 5) {        // crime <seq> <CRIME_x> <bounty> <witness ped>: the game's own law system
        int seq = atoi(tok[1]), wit = atoi(tok[4]);
        uint32_t ct = joaat(tok[2]);
        if (!g_player) { act_result(seq, false, "no player"); return; }
        CallV(REPORT_CRIME, g_playerId, ct, atoi(tok[3]), (wit && ped_ok(wit)) ? wit : 0, true);
        LI("crime seq=%d reported to the law: %s bounty=%s witness=%d", seq, tok[2], tok[3], wit);
        act_result(seq, true, "");
    }
    else if (!strcmp(c, "hk_start") && n >= 4) {     // hk_start <seq> <pedA> <pedB | 0 = with the player>
        int seq = atoi(tok[1]), a = atoi(tok[2]), b2 = atoi(tok[3]);
        if (!ped_ok(a) || CallB(IS_ENTITY_DEAD, a) || (b2 && (!ped_ok(b2) || CallB(IS_ENTITY_DEAD, b2)))) { act_result(seq, false, "someone is gone"); return; }
        if (!nh_ready()) { act_result(seq, false, "NpcHookups is not installed (or another build)"); return; }
        Managed* ma = find_m(a); Managed* mb = b2 ? find_m(b2) : nullptr;
        if (ma) { order_clear(*ma, "hookup"); ma->overridden = true; }
        if (mb) { order_clear(*mb, "hookup"); mb->overridden = true; }
        nh_pick(a, 1);
        nh_pick(b2 ? b2 : a, 2);           // the same ped twice = "with Arthur" (NpcHookupsPlus takes that pair over)
        act_result(seq, true, "");
    }
    else if (!strcmp(c, "los") && n >= 4) {          // 0.5.8: los <seq> <observer> <target>: can this person SEE that one?
        int seq = atoi(tok[1]), a = atoi(tok[2]), b2 = atoi(tok[3]);
        if (b2 == -1) b2 = g_player;
        bool ok = ped_ok(a) && ped_ok(b2) && !CallB(IS_ENTITY_DEAD, a);
        bool see = ok && CallB(HAS_ENTITY_CLEAR_LOS_TO_ENTITY, a, b2, 17);
        float d = ok ? dist3(CallVec(GET_ENTITY_COORDS, a, true, false), CallVec(GET_ENTITY_COORDS, b2, true, false)) : -1.f;
        std::string o = "{\"t\":\"los\""; jkv(o, "seq", seq); jkv(o, "ok", ok); jkv(o, "see", see); jkv(o, "d", d); o += "}";
        net_send(o);
    }
    else if (!strcmp(c, "find_bed") && n >= 6) find_bed(atoi(tok[1]), (float)atof(tok[2]), (float)atof(tok[3]), (float)atof(tok[4]), (float)atof(tok[5]));
    else if (!strcmp(c, "couple") && n >= 8) {     // couple <seq> <pedA> <pedB | -1 = the player> x y z heading [flags]
        int seq = atoi(tok[1]), a = atoi(tok[2]), b2 = atoi(tok[3]);
        if (b2 == -1) b2 = g_player;
        if (!ped_ok(a) || !ped_ok(b2) || CallB(IS_ENTITY_DEAD, a) || CallB(IS_ENTITY_DEAD, b2)) { act_result(seq, false, "someone is gone"); return; }
        couple_stop(a); couple_stop(b2);
        Couple cp{seq, a, b2, (float)atof(tok[4]), (float)atof(tok[5]), (float)atof(tok[6]), (float)atof(tok[7]),
                  n > 8 && isdigit((unsigned char)tok[8][0]) ? atoi(tok[8]) : 3593, false, 0, now_ms() + 10000, "", "", "", {}, false};
        couple_defaults(cp);
        couple_opts(cp, n, tok, 8);
        if (!CallB(DOES_ANIM_DICT_EXIST, cp.dict.c_str())) {
            LW("couple seq=%d: anim dict %s is not installed - using the built-in clips", seq, cp.dict.c_str());
            cp.dict = HOOKUP_DICT; cp.clipA = "loop_male"; cp.clipB = "loop_female";
        }
        CallV(REQUEST_ANIM_DICT, cp.dict.c_str());
        g_couples.push_back(cp);
    }
    else if (!strcmp(c, "couple_pose") && n >= 3) {   // couple_pose <seq> <ped> [anim=..] [pa=..] [pb=..] [swap=..] [h=..]
        int seq = atoi(tok[1]), ped = atoi(tok[2]);
        if (ped == -1) ped = g_player;
        Couple* cp = nullptr;
        for (auto& c2 : g_couples) if (c2.a == ped || c2.b == ped) { cp = &c2; break; }
        if (!cp) { act_result(seq, false, "no couple scene"); return; }
        std::string oldDict = cp->dict;
        if (cp->pos) nh_release(*cp);                    // 0.5.8: let go before the new position is set up
        for (int p2 : {cp->a, cp->b}) couple_stop_anims(*cp, p2);
        couple_defaults(*cp);
        couple_opts(*cp, n, tok, 3);
        if (cp->pos) {                                   // NpcHookups' way: placed again, lower partner first, then attached
            cp->on = false; cp->stage = 0; cp->next = 0; cp->deadline = now_ms() + 10000; cp->seq = seq;
            CallV(REQUEST_ANIM_DICT, cp->dict.c_str());
            LI("couple_pose seq=%d peds %d+%d -> %s%s", seq, cp->a, cp->b, NH_POS_NAME[cp->pos], cp->swap ? " (roles swapped)" : "");
            return;
        }
        if (!CallB(DOES_ANIM_DICT_EXIST, cp->dict.c_str())) {
            LW("couple_pose seq=%d: anim dict %s is not installed - built-in clips", seq, cp->dict.c_str());
            cp->dict = HOOKUP_DICT; cp->clipA = "loop_male"; cp->clipB = "loop_female";
        }
        if (cp->on && CallB(HAS_ANIM_DICT_LOADED, cp->dict.c_str())) couple_play(*cp, true);
        else { CallV(REQUEST_ANIM_DICT, cp->dict.c_str()); cp->on = false; cp->deadline = now_ms() + 10000; cp->seq = seq; }
        LI("couple_pose seq=%d peds %d+%d: %s %s/%s%s pa=%.2f,%.2f,%.2f,%.0f,%.0f,%.0f pb=%.2f,%.2f,%.2f,%.0f,%.0f,%.0f", seq, cp->a, cp->b,
           cp->dict.c_str(), cp->clipA.c_str(), cp->clipB.c_str(), cp->swap ? " swapped" : "",
           cp->off[0][0], cp->off[0][1], cp->off[0][2], cp->off[0][3], cp->off[0][4], cp->off[0][5],
           cp->off[1][0], cp->off[1][1], cp->off[1][2], cp->off[1][3], cp->off[1][4], cp->off[1][5]);
        if (cp->on) act_result(seq, true, "");
    }
    else if (!strcmp(c, "home_scan") && n >= 6) home_scan(atoi(tok[1]), (float)atof(tok[2]), (float)atof(tok[3]), (float)atof(tok[4]), (float)atof(tok[5]));
    else if (!strcmp(c, "couple_stop") && n >= 3) { int seq = atoi(tok[1]); couple_stop(atoi(tok[2])); act_result(seq, true, ""); }
    else if (!strcmp(c, "hk_stop") && n >= 2) { int seq = atoi(tok[1]); act_result(seq, nh_goodbye(), "NpcHookups not available"); }
    else if (!strcmp(c, "route") && n >= 5) route_set((float)atof(tok[1]), (float)atof(tok[2]), (float)atof(tok[3]), tok[4]);
    else if (!strcmp(c, "route_clear")) route_clear();
    else if (!strcmp(c, "hush")) {
        for (auto& m : g_peds) {
            if (m.talkUntil > now_ms() || m.state == 1) {
                stop_talk(m);
                if (ped_ok(m.ped) && !in_love(m.ped)) { CallV(CLEAR_PED_SECONDARY_TASK, m.ped); mute_vanilla(m.ped); }
            }
            m.state = 0;
        }
        LI("hush: player is talking - every NPC line and gesture stopped");
    }
    else if (!strcmp(c, "say") && n >= 7) {
        int ped = atoi(tok[1]); Managed* m = find_m(ped);
        if (g_ptt) { LI("say for ped %d dropped: the player is talking", ped); return; }
        if (ped_ok(ped) && CallB(IS_ENTITY_DEAD, ped)) { LI("say for ped %d dropped: dead", ped); return; }
        if (!m || !ped_ok(ped)) { LW("say for unknown ped %d", ped); return; }
        m->talkUntil = now_ms() + (uint64_t)atoi(tok[2]);
        m->talkMood = (uint32_t)strtoul(tok[3], nullptr, 10); m->emoMood = (uint32_t)strtoul(tok[4], nullptr, 10);
        m->moodUntil = m->talkUntil + 6000;
        m->subtitle = std::string(tok[5]) + ": " + tok[6];
        for (int i = 7; i < n; ++i) { m->subtitle += ' '; m->subtitle += tok[i]; }
        if (g_cfg.stopAmbientSpeech) mute_vanilla(ped);
        if (g_cfg.talkFace >= 2 && CallB(IS_PED_MALE, ped) && !m->faceOverride) {
            CallV(SET_FACIAL_IDLE_ANIM_OVERRIDE, ped, "mood_talking_normal", "face_human@gen_male@base"); m->faceOverride = true;
        }
        LI("say ped=%d %dms '%s'", ped, atoi(tok[2]), m->subtitle.c_str());
    }
    else if (!strcmp(c, "say_stop") && n >= 2) { Managed* m = find_m(atoi(tok[1])); if (m) { stop_talk(*m); LI("say_stop ped=%d", m->ped); } }
    else if (!strcmp(c, "release") && n >= 3) release(atoi(tok[1]), atoi(tok[2]) != 0, n > 3 ? tok[3] : "");
    else if (!strcmp(c, "mood") && n >= 4) { Managed* m = find_m(atoi(tok[1])); if (m) { m->emoMood = (uint32_t)strtoul(tok[2], nullptr, 10); m->moodUntil = now_ms() + atoi(tok[3]); } }
    else if (!strcmp(c, "money") && n >= 3) {
        int seq = atoi(tok[1]), cents = atoi(tok[2]);
        if (cents > 0 && cents <= 50000) { CallB(MONEY_INCREMENT_CASH_BALANCE, cents, joaat("ADD_REASON_DEFAULT")); act_result(seq, true, "received"); }
        else if (cents < 0 && -cents <= 50000) {
            int have = CallI(MONEY_GET_CASH_BALANCE);
            if (have >= -cents) { CallB(MONEY_DECREMENT_CASH_BALANCE, -cents); act_result(seq, true, "paid"); }
            else act_result(seq, false, "not enough cash");
        } else act_result(seq, false, "bad amount");
        LI("money %+d cents (seq %d)", cents, seq);
    }
    else if (!strcmp(c, "task") && n >= 4) {
        int seq = atoi(tok[1]), ped = atoi(tok[2]);
        Managed* m = find_m(ped);
        if (!ped_ok(ped) || CallB(IS_ENTITY_DEAD, ped)) { act_result(seq, false, "ped gone or dead"); return; }
        std::string why;
        char* args[24]; int na = 0; g_tgt = g_player;
        for (int i = 4; i < n; ++i) {
            if (!strncmp(tok[i], "t=", 2)) { int t2 = atoi(tok[i] + 2); if (t2 && ped_ok(t2)) g_tgt = t2; else { act_result(seq, false, "target gone"); return; } }
            else args[na++] = tok[i];
        }
        if (m && m->order) {
            // a new way of moving ends the order; on foot, walking off / hands up / cowering still means 'stay off the horse'
            static const char* newMove[] = {"flee", "combat", "follow", "goto_player", "goto_coord", "cover"};
            static const char* newSeat[] = {"wander", "hands_up", "cower", "leave_vehicle"};
            for (auto* w : newMove) if (!strcmp(tok[3], w)) { order_clear(*m, tok[3]); break; }
            if (m->order && m->order != O_FOOT && m->order != O_OUT) for (auto* w : newSeat) if (!strcmp(tok[3], w)) { order_clear(*m, tok[3]); break; }
        }
        if (m && m->order) {
            if (!strcmp(tok[3], "stand") || !strcmp(tok[3], "face") || !strcmp(tok[3], "lead_horse") || !strcmp(tok[3], "wander") ||
                !strcmp(tok[3], "hands_up") || !strcmp(tok[3], "cower")) { m->oFollowDone = true; m->oFollowAt = 0; }
            else if (!strcmp(tok[3], "clear") && m->order == O_FOOT && m->oSettled) { m->oFollowDone = false; m->oFollowAt = now_ms() + 800; }
        }
        bool ok = do_task(m, ped, tok[3], na, args, why);
        static const char* moving[] = {"flee", "follow", "wander", "combat", "cover", "goto_player", "mount_near",
                                       "ride_with_player", "lead_horse", "look_clear", "dismount", "leave_vehicle"};
        bool mv = false; for (auto* w : moving) if (!strcmp(tok[3], w)) mv = true;
        if (m && m->engaged && !mv && m->lookAt != UINT64_MAX) m->lookAt = 0;   // keep the head on the player
        LI("task seq=%d ped=%d %s%s%s -> %s %s", seq, ped, tok[3], n > 4 ? " " : "", n > 4 ? tok[4] : "", ok ? "ok" : "FAIL", why.c_str());
        act_result(seq, ok, why.c_str());
    }
    else if (!strcmp(c, "emote") && n >= 6) {
        int seq = atoi(tok[1]), ped = atoi(tok[2]), cat = atoi(tok[3]), mode = atoi(tok[5]);
        if (!ped_ok(ped)) { act_result(seq, false, "ped gone"); return; }
        uint32_t h = joaat(tok[4]);
        bool upper = mode != 2;
        Managed* om = find_m(ped);
        // an emote is a full task: on top of a mount/dismount it cancels it (0.3.1 bug: "she gave me money but never
        // got on the horse" - the coin emote replaced her mount task). Passengers and people mid-order don't emote.
        if (om && om->order && (!om->oSettled || om->order == O_RIDE || om->order == O_VEH || om->order == O_MOUNT)) {
            LI("emote seq=%d ped=%d %s skipped: busy with order %s", seq, ped, tok[4], ORDER_NAME[om->order]);
            act_result(seq, true, "skipped (busy getting on/off a horse)");
            return;
        }
        if (om && om->order == O_FOOT) { om->oFollowDone = false; om->oFollowAt = now_ms() + 5000; }
        CallV(TASK_PLAY_EMOTE_WITH_HASH, ped, cat, mode, h, upper, upper, false, false, false);
        LI("emote seq=%d ped=%d %s cat=%d mode=%d", seq, ped, tok[4], cat, mode);
        act_result(seq, true, "");
    }
    else if (!strcmp(c, "scen") && n >= 5) {
        int seq = atoi(tok[1]), ped = atoi(tok[2]);
        if (!ped_ok(ped)) { act_result(seq, false, "ped gone"); return; }
        Managed* m = find_m(ped); if (m) { m->overridden = true; if (m->order == O_FOOT) { m->oFollowDone = true; m->oFollowAt = 0; } }
        CallV(TASK_START_SCENARIO_IN_PLACE_HASH, ped, joaat(tok[3]), atoi(tok[4]), true, 0u, -1.0f, false);
        scen_watch(ped, joaat(tok[3]), tok[3], 3500, seq);
        LI("scenario seq=%d ped=%d %s", seq, ped, tok[3]);
        act_result(seq, true, "");
    }
    else if (!strcmp(c, "anim") && n >= 7 && g_ptt) { act_result(atoi(tok[1]), false, "player is talking"); }
    else if (!strcmp(c, "anim") && n >= 7) {
        PendingAnim a{atoi(tok[1]), atoi(tok[2]), atoi(tok[5]), atoi(tok[6]), tok[3], tok[4], now_ms() + 2500};
        if (!CallB(DOES_ANIM_DICT_EXIST, a.dict.c_str())) { act_result(a.seq, false, "anim dict does not exist"); return; }
        CallV(REQUEST_ANIM_DICT, a.dict.c_str());
        g_anims.push_back(a);
    }
    else LW("unknown command '%s' (%d tokens)", c, n);
}

static void pump_anims() {
    for (size_t i = 0; i < g_anims.size();) {
        PendingAnim& a = g_anims[i];
        if (CallB(HAS_ANIM_DICT_LOADED, a.dict.c_str())) {
            if (ped_ok(a.ped)) {
                CallV(TASK_PLAY_ANIM, a.ped, a.dict.c_str(), a.name.c_str(), 4.0f, -4.0f, a.ms ? a.ms : -1, a.flags, 0.0f, false, 0, false, "", false);
                LI("anim seq=%d ped=%d %s/%s flags=%d", a.seq, a.ped, a.dict.c_str(), a.name.c_str(), a.flags);
                act_result(a.seq, true, "");
            } else act_result(a.seq, false, "ped gone");
            g_anims.erase(g_anims.begin() + i);
        } else if (now_ms() > a.deadline) {
            act_result(a.seq, false, "anim dict did not load"); g_anims.erase(g_anims.begin() + i);
        } else ++i;
    }
}

// ───────────────────────── outgoing state ─────────────────────────
static void send_hello() {
    std::string o = "{\"t\":\"hello\",\"ver\":\"" NV_VERSION "\",\"dir\":"; json_str(o, g_dir);
    o += ",\"disabled\":[";
    for (size_t i = 0; i < g_disabledAtStart.size(); ++i) { if (i) o += ','; json_str(o, g_disabledAtStart[i].c_str()); }
    o += "]"; jkv(o, "ptt_key", g_cfg.pttKey);
    o += ",\"caps\":[\"home_scan\",\"use_point\",\"couple_pose\",\"nh_pos\",\"undress_wait\",\"los\"]}";      // households: what this build can do
    net_send(o);
}

static void ped_info(std::string& o, int ped) {
    uint32_t model = CallH(GET_ENTITY_MODEL, ped);
    uint32_t outfit = CallH(GET_PED_META_OUTFIT_HASH, ped);
    jkv(o, "ped", ped); jkv(o, "model", model); jkv(o, "outfit", outfit);
    jkv(o, "male", CallB(IS_PED_MALE, ped)); jkv(o, "human", CallB(IS_PED_HUMAN, ped));
    jkv(o, "alive", !CallB(IS_ENTITY_DEAD, ped)); jkv(o, "mission", CallB(IS_ENTITY_A_MISSION_ENTITY, ped));
    int v = veh_of(ped);
    if (v) { jkv(o, "veh", 1); jkv(o, "drv", is_driver(ped, v)); jkv(o, "tram", is_tram(v)); jkv(o, "vm", CallH(GET_ENTITY_MODEL, v)); }
    jkv(o, "mnt", CallB(IS_PED_ON_MOUNT, ped));
}

// 0.5.7: who shares this person's horse or wagon - read straight from the seats, never from the area scan, so a
// driver always knows his own passengers and a woman riding behind a man always knows who holds the reins.
static void mates_json(std::string& o, int ped) {
    static std::map<int, std::pair<uint64_t, std::string>> cache;          // re-read twice a second per ped
    auto& c = cache[ped];
    uint64_t t = now_ms();
    if (t < c.first) { o += c.second; return; }
    std::string s = ",\"mates\":[";
    bool first = true;
    auto add = [&](int h, const char* how) {
        if (!h || h == ped || h == g_player || !ped_ok(h) || !CallB(IS_PED_HUMAN, h)) return;
        if (!first) s += ','; first = false;
        s += "{"; jkv(s, "h", h, false); jkv(s, "m", CallH(GET_ENTITY_MODEL, h)); jkv(s, "o", CallH(GET_PED_META_OUTFIT_HASH, h));
        jkv(s, "male", CallB(IS_PED_MALE, h)); jkv(s, "alive", !CallB(IS_ENTITY_DEAD, h));
        s += ",\"how\":"; json_str(s, how); s += "}";
    };
    int v = veh_of(ped);
    if (v) {
        int drv = CallI(GET_PED_IN_VEHICLE_SEAT, v, -1);
        add(drv, "driver");
        int maxp = CallI(GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS, v);
        for (int st = 0; st < maxp && st < 8; ++st) add(CallI(GET_PED_IN_VEHICLE_SEAT, v, st), "passenger");
    } else if (CallB(IS_PED_ON_MOUNT, ped)) {
        int mount = CallI(GET_MOUNT, ped);
        int rider = mount ? CallI(GET_RIDER_OF_MOUNT, mount, false) : 0;
        if (rider && rider != ped) add(rider, "rider");                // they hold the reins, this one sits behind
        else if (mount) {                                              // this one rides: who sits behind them?
            Vector3 mp = CallVec(GET_ENTITY_COORDS, ped, true, false);
            int arr[PED_POOL_MAX]; int n = worldGetAllPeds(arr, PED_POOL_MAX); if (n > PED_POOL_MAX) n = PED_POOL_MAX;
            for (int i = 0; i < n; ++i) {
                int h = arr[i];
                if (!h || h == ped || h == g_player || !CallB(IS_PED_HUMAN, h)) continue;
                if (dist3(CallVec(GET_ENTITY_COORDS, h, true, false), mp) > 3.f) continue;
                if (CallB(IS_PED_ON_MOUNT, h) && CallI(GET_MOUNT, h) == mount) add(h, "behind");
            }
        }
    }
    s += "]";
    c = {t + 500, s};
    o += s;
}
static bool looted_by_player(int ped) {     // the player is going through their pockets / satchel right now
    return CallI(FIND_ENTITY_LOOTING_PED, ped) == g_player || CallB(GET_IS_PED_BEING_ROBBED, ped, g_playerId, false);
}

static void ped_tick(std::string& o, Managed& m, const Vector3& cam) {
    int ped = m.ped;
    Vector3 p = CallVec(GET_ENTITY_COORDS, ped, true, false);
    bool alive = !CallB(IS_ENTITY_DEAD, ped);
    alignas(8) uint64_t wb = 0;
    CallB(GET_CURRENT_PED_WEAPON, ped, &wb, false, 0, false);
    uint32_t w = (uint32_t)wb, unarmed = joaat("WEAPON_UNARMED");
    uint32_t best = CallH(GET_BEST_PED_WEAPON, ped, false, false);
    // 0.4.0: holding right mouse with empty hands is the game's FOCUS (greet/antagonize lock-on), not aiming. 0.3.x
    // reported it as "the player is aiming at you" -> friendly people (a tram driver!) threw their hands up.
    bool aimed = false;
    if (player_weapon_threat()) {
        aimed = CallB(IS_PLAYER_FREE_AIMING_AT_ENTITY, g_playerId, ped);
        if (!aimed) { alignas(8) uint64_t t = 0; if (CallB(GET_ENTITY_PLAYER_IS_FREE_AIMING_AT, g_playerId, &t) && (int)t == ped) aimed = true; }
    }
    bool dmg = CallB(HAS_ENTITY_BEEN_DAMAGED_BY_ENTITY, ped, g_player, true, true);
    if (dmg) CallV(CLEAR_ENTITY_LAST_DAMAGE_ENTITY, ped);
    o += "{"; jkv(o, "h", ped, false);
    jkv(o, "x", p.x); jkv(o, "y", p.y); jkv(o, "z", p.z); jkv(o, "d", dist3(p, g_ppos));
    jkv(o, "alive", alive); jkv(o, "hp", CallI(GET_ENTITY_HEALTH, ped)); jkv(o, "hpmax", CallI(GET_ENTITY_MAX_HEALTH, ped, false));
    jkv(o, "hog", CallB(IS_PED_HOGTIED, ped)); jkv(o, "bhog", CallB(IS_PED_BEING_HOGTIED, ped)); jkv(o, "lasso", CallB(IS_PED_LASSOED, ped));
    jkv(o, "rag", CallB(IS_PED_RAGDOLL, ped)); jkv(o, "flee", CallB(IS_PED_FLEEING, ped)); jkv(o, "comb", CallB(IS_PED_IN_COMBAT, ped, g_player));
    jkv(o, "scen", CallB(IS_PED_USING_ANY_SCENARIO, ped)); jkv(o, "sit", CallB(IS_PED_SITTING, ped));
    jkv(o, "mnt", CallB(IS_PED_ON_MOUNT, ped)); jkv(o, "veh", CallB(IS_PED_IN_ANY_VEHICLE, ped, false));
    jkv(o, "spd", CallF(GET_ENTITY_SPEED, ped)); jkv(o, "armed", w && w != unarmed); jkv(o, "wpn", w);
    jkv(o, "hasw", best && best != unarmed); jkv(o, "los", CallB(HAS_ENTITY_CLEAR_LOS_TO_ENTITY, g_player, ped, 17));
    jkv(o, "drunk", CallF(GET_PED_DRUNKNESS, ped)); jkv(o, "aimed", aimed); jkv(o, "dmg", dmg);
    jkv(o, "melee", CallB(IS_PED_IN_MELEE_COMBAT, ped));
    jkv(o, "eng", m.engaged); jkv(o, "talk", m.talkUntil > now_ms());
    if (alive && dist3(p, g_ppos) < 6.f) jkv(o, "lt", looted_by_player(ped));
    if (alive) mates_json(o, ped);
    {   int v = veh_of(ped);
        if (!v && CallB(IS_PED_ON_MOUNT, ped)) { int mh = CallI(GET_MOUNT, ped); jkv(o, "mh", mh);
            int r = mh ? CallI(GET_RIDER_OF_MOUNT, mh, false) : 0; if (r && r != ped) jkv(o, "mr", r); }
        if (v) { jkv(o, "vh", v); jkv(o, "drv", is_driver(ped, v)); jkv(o, "tram", is_tram(v)); jkv(o, "vspd", CallF(GET_ENTITY_SPEED, v));
                 jkv(o, "pin", CallB(IS_PED_IN_VEHICLE, g_player, v, false)); jkv(o, "vhalt", m.vHalt != 0); jkv(o, "vdrive", m.vDrive != 0); }
        jkv(o, "keep", m.keep); }
    {   static std::map<int, std::pair<uint64_t, std::string>> cache;     // clothing is read once a second per ped
        auto& c = cache[ped];
        if (now_ms() >= c.first) {
            int up = 0, low = 0; clothes_count(ped, up, low);
            char b[96]; snprintf(b, sizeof b, ",\"cu\":%d,\"cl\":%d,\"nude\":%d,\"hk\":%d", up, low, nude_torso_on(ped) ? 1 : 0, in_hookup(ped));
            c = {now_ms() + 1000, b};
        }
        o += c.second; }
    o += "}";
    if (dmg && alive && g_cfg.painVoice && now_ms() >= m.painUntil) {      // 0.5.1: they SCREAM - right now, not after the AI
        CallV(PLAY_PAIN, ped, 1, 0.0f, false, false);
        m.painUntil = now_ms() + 2500;
        LI("pain ped=%d (hurt by the player)", ped);
    }
    if (dmg && m.blocked) { CallV(SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, ped, false); m.blocked = false; send_event("danger", ped, "damaged by player"); }
    (void)cam;
}

static uint64_t g_nextTick = 0, g_nextNearby = 0;
static void send_tick() {
    Vector3 cam = CallVec(GET_GAMEPLAY_CAM_COORD);
    Vector3 rot = CallVec(GET_GAMEPLAY_CAM_ROT, 2);
    alignas(8) uint64_t wb = 0;
    CallB(GET_CURRENT_PED_WEAPON, g_player, &wb, false, 0, false);
    uint32_t w = (uint32_t)wb, unarmed = joaat("WEAPON_UNARMED");
    bool mnt = CallB(IS_PED_ON_MOUNT, g_player), veh = CallB(IS_PED_IN_ANY_VEHICLE, g_player, false);
    int lm = CallI(GET_LAST_MOUNT, g_player), lv = CallI(GET_PLAYERS_LAST_VEHICLE);
    float lmd = 999.f, lvd = 999.f;
    if (lm && ped_ok(lm)) lmd = dist3(CallVec(GET_ENTITY_COORDS, lm, true, false), g_ppos);
    if (lv && ped_ok(lv)) lvd = dist3(CallVec(GET_ENTITY_COORDS, lv, true, false), g_ppos);
    std::string o = "{\"t\":\"tick\""; jkv(o, "ms", (double)now_ms());
    o += ",\"p\":{"; jkv(o, "x", g_ppos.x, false); jkv(o, "y", g_ppos.y); jkv(o, "z", g_ppos.z);
    jkv(o, "cx", cam.x); jkv(o, "cy", cam.y); jkv(o, "cz", cam.z); jkv(o, "cyaw", rot.z); jkv(o, "cpitch", rot.x);
    jkv(o, "mounted", mnt); jkv(o, "veh", veh); jkv(o, "crouch", CallB(GET_PED_CROUCH_MOVEMENT, g_player));
    jkv(o, "armed", w && w != unarmed); jkv(o, "wpn", w); jkv(o, "shoot", CallB(IS_PED_SHOOTING, g_player));
    jkv(o, "scen", CallB(IS_PED_USING_ANY_SCENARIO, g_player)); jkv(o, "cash", CallI(MONEY_GET_CASH_BALANCE));
    jkv(o, "hp", CallI(GET_ENTITY_HEALTH, g_player)); jkv(o, "hpmax", CallI(GET_ENTITY_MAX_HEALTH, g_player, false));
    jkv(o, "lm_d", lmd); jkv(o, "lv_d", lvd); jkv(o, "focus", g_focus); jkv(o, "ptt", g_ptt);
    jkv(o, "wanted", CallI(GET_PLAYER_WANTED_LEVEL, g_playerId));
    // what the player is carrying on his shoulder, and what is slung over his horse
    auto carried = [&](int carrier, const char* pre) {
        int c = CallB(IS_PED_CARRYING_SOMETHING, carrier) ? CallI(GET_FIRST_ENTITY_PED_IS_CARRYING, carrier) : 0;
        char k[16];
        snprintf(k, sizeof k, "%s", pre); jkv(o, k, c != 0);
        if (c && ped_ok(c) && CallB(IS_PED_HUMAN, c)) {
            snprintf(k, sizeof k, "%sdead", pre); jkv(o, k, CallB(IS_ENTITY_DEAD, c));
            snprintf(k, sizeof k, "%shog", pre); jkv(o, k, CallB(IS_PED_HOGTIED, c));
            snprintf(k, sizeof k, "%smdl", pre); jkv(o, k, CallH(GET_ENTITY_MODEL, c));
            snprintf(k, sizeof k, "%soft", pre); jkv(o, k, CallH(GET_PED_META_OUTFIT_HASH, c));
            snprintf(k, sizeof k, "%sh", pre); jkv(o, k, c);
        }
    };
    carried(g_player, "c");
    int horse = mnt ? CallI(GET_MOUNT, g_player) : (lmd < 12.f ? lm : 0);
    if (horse && ped_ok(horse)) carried(horse, "hb");
    o += "},\"w\":{";
    jkv(o, "hr", CallI(GET_CLOCK_HOURS), false); jkv(o, "mn", CallI(GET_CLOCK_MINUTES)); jkv(o, "dow", CallI(GET_CLOCK_DAY_OF_WEEK));
    jkv(o, "st", CallH(GET_MAP_ZONE_AT_COORDS, g_ppos.x, g_ppos.y, g_ppos.z, 0));
    jkv(o, "town", CallH(GET_MAP_ZONE_AT_COORDS, g_ppos.x, g_ppos.y, g_ppos.z, 1));
    jkv(o, "dist", CallH(GET_MAP_ZONE_AT_COORDS, g_ppos.x, g_ppos.y, g_ppos.z, 10));
    jkv(o, "wx", CallH(GET_PREV_WEATHER_TYPE_HASH_NAME)); jkv(o, "pause", CallB(IS_PAUSE_MENU_ACTIVE));
    jkv(o, "mission", CallB(GET_MISSION_FLAG)); jkv(o, "hook", g_hookState == 1);
    uint32_t wheel = joaat("INPUT_OPEN_WHEEL_MENU");
    jkv(o, "wheel", CallB(IS_CONTROL_PRESSED, 0, wheel) || CallB(IS_DISABLED_CONTROL_PRESSED, 0, wheel));
    o += "},\"peds\":[";
    bool first = true;
    for (auto& m : g_peds) {
        if (!ped_ok(m.ped)) continue;
        if (!first) o += ','; first = false;
        ped_tick(o, m, cam);
    }
    o += "]}";
    net_send(o);
}

static void send_nearby() {
    int arr[PED_POOL_MAX]; int n = worldGetAllPeds(arr, PED_POOL_MAX); if (n > PED_POOL_MAX) n = PED_POOL_MAX;
    struct C { int h; float d; };
    std::vector<C> cs;
    int eng = (g_engaged && ped_ok(g_engaged)) ? g_engaged : 0;
    for (int i = 0; i < n; ++i) {
        int h = arr[i];
        if (!h || h == g_player || h == eng || !CallB(IS_PED_HUMAN, h)) continue;
        Vector3 p = CallVec(GET_ENTITY_COORDS, h, true, false);
        float d = dist3(p, g_ppos);
        bool dead = CallB(IS_ENTITY_DEAD, h);
        if (d <= (dead ? 70.f : 45.f)) cs.push_back({h, dead ? d - 1000.f : d});   // 0.4.0: bodies first, never crowded out
    }
    std::sort(cs.begin(), cs.end(), [](const C& a, const C& b) { return a.d < b.d; });
    { int nd = 0; std::vector<C> keep;
      for (auto& c : cs) { if (c.d < 0) { if (nd < 6) { c.d += 1000.f; keep.push_back(c); } ++nd; } else if (keep.size() < 30) keep.push_back(c); }
      cs.swap(keep); }
    Vector3 ep{}; if (eng) ep = CallVec(GET_ENTITY_COORDS, eng, true, false);
    std::string o = "{\"t\":\"nearby\""; jkv(o, "eng", eng); o += ",\"peds\":[";
    for (size_t i = 0; i < cs.size(); ++i) {
        int h = cs[i].h; bool alive = !CallB(IS_ENTITY_DEAD, h);
        if (i) o += ',';
        Vector3 hp = CallVec(GET_ENTITY_COORDS, h, true, false);
        o += "{"; jkv(o, "h", h, false); jkv(o, "d", cs[i].d);
        jkv(o, "x", hp.x); jkv(o, "y", hp.y); jkv(o, "z", hp.z);
        jkv(o, "m", CallH(GET_ENTITY_MODEL, h)); jkv(o, "o", CallH(GET_PED_META_OUTFIT_HASH, h));
        jkv(o, "male", CallB(IS_PED_MALE, h)); jkv(o, "alive", alive);
        jkv(o, "los", (alive && cs[i].d < 18.f) ? CallB(HAS_ENTITY_CLEAR_LOS_TO_ENTITY, h, g_player, 17) : false);
        if (alive) { jkv(o, "comb", CallB(IS_PED_IN_COMBAT, h, 0)); jkv(o, "mission", CallB(IS_ENTITY_A_MISSION_ENTITY, h)); }
        if (eng) {   // from the point of view of the person you're talking to
            Vector3 p = CallVec(GET_ENTITY_COORDS, h, true, false);
            float de = dist3(p, ep);
            jkv(o, "de", de);
            jkv(o, "elos", de < 40.f ? CallB(HAS_ENTITY_CLEAR_LOS_TO_ENTITY, eng, h, 17) : false);
        }
        if (alive && cs[i].d < 30.f) { int hk = in_hookup(h); if (hk) jkv(o, "hk", hk); }
        if (alive) { jkv(o, "scen", CallB(IS_PED_USING_ANY_SCENARIO, h)); jkv(o, "spd", CallF(GET_ENTITY_SPEED, h));
                     jkv(o, "flee", CallB(IS_PED_FLEEING, h)); jkv(o, "mnt", CallB(IS_PED_ON_MOUNT, h));
                     int vh = veh_of(h); if (vh) { jkv(o, "vh", vh); jkv(o, "drv", is_driver(h, vh)); }
                     else if (CallB(IS_PED_ON_MOUNT, h)) { int mh = CallI(GET_MOUNT, h); jkv(o, "mh", mh);
                         int r = mh ? CallI(GET_RIDER_OF_MOUNT, mh, false) : 0; if (r && r != h) jkv(o, "mr", r); }
                     if (cs[i].d < 25.f) { jkv(o, "hog", CallB(IS_PED_HOGTIED, h)); uint32_t bw = CallH(GET_BEST_PED_WEAPON, h, false, false); jkv(o, "hasw", bw && bw != joaat("WEAPON_UNARMED")); }
                     if (cs[i].d < 6.f) { jkv(o, "lt", looted_by_player(h)); jkv(o, "nude", nude_torso_on(h)); } }
        else jkv(o, "kp", CallI(GET_PED_SOURCE_OF_DEATH, h) == g_player);
        o += "}";
    }
    o += "]}";
    net_send(o);
}

// ───────────────────────── input / focus ─────────────────────────
static bool key_down(int vk) {
    if (g_fakeKey) return g_fakeKey(vk) != 0;
    HWND fg = GetForegroundWindow(); DWORD pid = 0;
    if (fg) GetWindowThreadProcessId(fg, &pid);
    if (pid != GetCurrentProcessId()) return false;
    return (GetAsyncKeyState(vk) & 0x8000) != 0;
}

static uint32_t g_playerWeapon = 0; static uint64_t g_playerWeaponAt = 0;
static bool player_weapon_threat() {        // a gun, a bow, a knife, a thrown weapon - not fists, lasso, lantern, binoculars...
    uint64_t t = now_ms();
    if (t - g_playerWeaponAt > 200) {
        alignas(8) uint64_t wb = 0; CallB(GET_CURRENT_PED_WEAPON, g_player, &wb, false, 0, false);
        g_playerWeapon = (uint32_t)wb; g_playerWeaponAt = t;
    }
    static const char* harmless[] = {"WEAPON_UNARMED", "WEAPON_LASSO", "WEAPON_LASSO_REINFORCED", "WEAPON_MELEE_LANTERN",
        "WEAPON_MELEE_DAVY_LANTERN", "WEAPON_MELEE_LANTERN_ELECTRIC", "WEAPON_MELEE_TORCH", "WEAPON_KIT_BINOCULARS",
        "WEAPON_KIT_CAMERA", "WEAPON_FISHINGROD", "WEAPON_KIT_METAL_DETECTOR", "WEAPON_MOONSHINEJUG_MP", "WEAPON_MELEE_HAMMER"};
    if (!g_playerWeapon) return false;
    for (auto* h : harmless) if (g_playerWeapon == joaat(h)) return false;
    return true;
}

// focus fallback: the game won't lock on to some people (hands up, cowering, in a wagon). While right mouse /
// lock-on is held, pick the person the camera is pointing at (smallest angle, within 5 degrees + body width).
static int camera_pick() {
    Vector3 cam = CallVec(GET_GAMEPLAY_CAM_COORD), rot = CallVec(GET_GAMEPLAY_CAM_ROT, 2);
    float px = rot.x * 0.0174533f, yz = rot.z * 0.0174533f;
    float fx = -sinf(yz) * cosf(px), fy = cosf(yz) * cosf(px), fz = sinf(px);
    int arr[PED_POOL_MAX]; int n = worldGetAllPeds(arr, PED_POOL_MAX); if (n > PED_POOL_MAX) n = PED_POOL_MAX;
    int best = 0; float bestScore = 1e9f;
    for (int i = 0; i < n; ++i) {
        int h = arr[i];
        if (!h || h == g_player || !CallB(IS_PED_HUMAN, h)) continue;
        Vector3 p = CallVec(GET_ENTITY_COORDS, h, true, false);
        if (dist3(p, g_ppos) > g_cfg.engageMaxDist) continue;
        float dx = p.x - cam.x, dy = p.y - cam.y, dz = p.z + 0.4f - cam.z;
        float len = sqrtf(dx * dx + dy * dy + dz * dz); if (len < 0.5f) continue;
        float along = dx * fx + dy * fy + dz * fz; if (along <= 0) continue;
        float off = sqrtf(std::max(0.f, len * len - along * along));     // metres off the camera line
        float allowed = 0.45f + along * 0.0875f;                          // body width + ~5 degrees
        if (off > allowed) continue;
        float score = off / allowed + along * 0.01f;
        if (score < bestScore) { bestScore = score; best = h; }
    }
    return best;
}

static int detect_focus() {
    alignas(8) uint64_t e = 0; int ent = 0;
    if (CallB(GET_PLAYER_INTERACTION_TARGET_ENTITY, g_playerId, &e, false, false)) ent = (int)e;
    if (!ent) { e = 0; if (CallB(GET_PLAYER_TARGET_ENTITY, g_playerId, &e)) ent = (int)e; }
    if (!ent) { e = 0; if (CallB(GET_ENTITY_PLAYER_IS_FREE_AIMING_AT, g_playerId, &e)) ent = (int)e; }
    if (!ent || ent == g_player || !ped_ok(ent)) return 0;
    if (!CallB(IS_PED_HUMAN, ent) || CallB(IS_PED_A_PLAYER, ent)) return 0;
    Vector3 p = CallVec(GET_ENTITY_COORDS, ent, true, false);
    if (dist3(p, g_ppos) > g_cfg.engageMaxDist) return 0;
    return ent;
}

static uint64_t g_pttDownAt = 0;
static uint64_t g_focusSince = 0, g_resumeAt = 0, g_lastFocusHeld = 0;
// 0.4.0 - who does X talk to? (0.3.x: after Esc the game's auto lock-on, or a ped you glanced at 1.5 s ago, stole the talk)
//   1. you deliberately focus someone NOW (held >= 0.35 s, started after the game came back from a pause) -> them
//   2. otherwise the person you're talking to, if within KEEP_TALKING_DIST          -> them (X never jumps away)
//   3. nobody: a focus you JUST let go (< 0.5 s ago, held >= 0.25 s)               -> them
//   4. nobody at all: your companions within 15 m hear you (the brain talks to the group)
static bool focus_deliberate(uint64_t t, uint64_t minHold) {
    return g_focus && t - g_focusSince >= minHold && g_focusSince >= g_resumeAt + 700;
}
static int pick_talk_target() {
    uint64_t t = now_ms();
    int partner = 0;
    if (g_engaged && ped_ok(g_engaged) && !CallB(IS_ENTITY_DEAD, g_engaged)) {
        Vector3 p = CallVec(GET_ENTITY_COORDS, g_engaged, true, false);
        if (dist3(p, g_ppos) <= g_cfg.keepTalkingDist) partner = g_engaged;
    }
    if (g_focus && g_focus == partner) return partner;
    if (!partner && g_focus) return g_focus;                 // nobody to stay with: whoever you focus, at once
    if (focus_deliberate(t, 350)) return g_focus;
    if (partner) return partner;
    if (g_lastFocus && t - g_focusSeen < 500 && g_lastFocusHeld >= 250 && g_focusSeen >= g_resumeAt + 700 &&
        ped_ok(g_lastFocus) && !CallB(IS_ENTITY_DEAD, g_lastFocus)) return g_lastFocus;
    int best = 0; float bd = 15.f;
    for (auto& m : g_peds) {
        if (!m.keep || !ped_ok(m.ped) || CallB(IS_ENTITY_DEAD, m.ped)) continue;
        float d = dist3(CallVec(GET_ENTITY_COORDS, m.ped, true, false), g_ppos);
        if (d < bd) { bd = d; best = m.ped; }
    }
    return best;
}
static void on_ptt_down() {
    g_pttDownAt = now_ms();
    g_pttPed = -1;                 // stays -1 unless this press is actually sent to the brain
    int target = pick_talk_target();
    if (!g_connected) {
        char err[160]; EnterCriticalSection(&g_netcs); snprintf(err, sizeof err, "%s", g_netErrText); LeaveCriticalSection(&g_netcs);
        char b[300]; snprintf(b, sizeof b, "can't reach the brain (%s: %s) - is run_npc_brain.bat open?", g_cfg.transport, err);
        toast("err", 6000, b); g_pttPed = -1; return;
    }
    if (!target) { toast("info", 2500, "focus someone first (hold right mouse on them), then hold X"); return; }
    if (CallB(IS_ENTITY_DEAD, target)) { toast("info", 2500, "they can't hear you anymore"); return; }
    for (auto& m : g_peds) {
        if (m.talkUntil > now_ms()) { stop_talk(m); if (ped_ok(m.ped)) CallV(CLEAR_PED_SECONDARY_TASK, m.ped); LI("interrupted ped %d", m.ped); }
        if (ped_ok(m.ped) && g_cfg.stopAmbientSpeech && !in_love(m.ped)) mute_vanilla(m.ped);
    }
    Managed* m = find_m(target);
    if (!m || !m->engaged) {
        std::string o = "{\"t\":\"engage_req\""; ped_info(o, target); o += "}"; net_send(o);
        g_pendingEngage = target; g_pendingSince = now_ms();
    }
    g_pttPed = target;
    std::string o = "{\"t\":\"ptt\",\"down\":true"; ped_info(o, target); if (g_cfg.typeInstead) jkv(o, "typed", 1); o += "}"; net_send(o);
    LI("PTT down target=%d (focus=%d engaged=%d)", target, g_focus, g_engaged);
}
static uint64_t g_lastTapAt = 0;
// ── 0.5.6: type instead of talk ──────────────────────────────────────────────────────────────────────────────────
static bool g_typing = false, g_keyHeld = false, g_keyFired = false; static uint64_t g_keyDownAt = 0;
static void typed_send(const std::string& text) {
    std::string o = "{\"t\":\"ptt\",\"down\":false"; jkv(o, "ped", g_pttPed);
    if (!text.empty()) { o += ",\"text\":"; json_str(o, text.c_str()); } else o += ",\"cancel\":true";
    o += "}"; net_send(o);
    LI("typed to ped %d: '%s'", g_pttPed, text.empty() ? "(cancelled)" : text.c_str());
    g_pttPed = 0; g_ptt = false; g_typing = false;
}
static void typed_tick() {
    if (!g_typing) return;
    int st = CallI(UPDATE_ONSCREEN_KEYBOARD);
    if (st == 0) return;                                   // still typing
    std::string text;
    if (st == 1) { const char* r = CallS(GET_ONSCREEN_KEYBOARD_RESULT); if (r) text = r; }
    typed_send(text);                                      // 1 = Enter, 2 = Esc, 3 = closed some other way
}
static void typed_key(bool down, uint64_t t) {
    if (g_typing) return;
    if (down && !g_keyHeld) { g_keyHeld = true; g_keyFired = false; g_keyDownAt = t; return; }
    if (down && g_keyHeld && !g_keyFired && t - g_keyDownAt >= 400) {   // held: open the keyboard for this person
        g_keyFired = true; g_ptt = true;
        on_ptt_down();
        if (g_pttPed > 0) { CallV(DISPLAY_ONSCREEN_KEYBOARD, 0, "", "", "", "", "", "", 200); g_typing = true; LI("keyboard open for ped %d", g_pttPed); }
        else { g_ptt = false; g_pttPed = 0; }
        return;
    }
    if (!down && g_keyHeld) {
        g_keyHeld = false;
        if (g_keyFired) return;
        if (g_lastTapAt && t - g_lastTapAt < 800 && g_engaged) {         // X X still ends the conversation
            std::string o = "{\"t\":\"dismiss\""; jkv(o, "ped", g_engaged); o += "}"; net_send(o);
            LI("double-tap X: ending the conversation with ped %d", g_engaged);
            toast("info", 2500, "conversation ended");
            g_lastTapAt = 0; return;
        }
        g_lastTapAt = t;
    }
}
static void on_ptt_up() {
    uint64_t t = now_ms();
    bool tap = t - g_pttDownAt < 350;
    if (tap && g_lastTapAt && t - g_lastTapAt < 800 && g_engaged) {     // X-X : end this conversation
        std::string o = "{\"t\":\"dismiss\""; jkv(o, "ped", g_engaged); o += "}"; net_send(o);
        LI("double-tap X: ending the conversation with ped %d", g_engaged);
        toast("info", 2500, "conversation ended");
        g_lastTapAt = 0; g_pttPed = 0;
        return;
    }
    g_lastTapAt = tap ? t : 0;
    if (g_pttPed < 0) { g_pttPed = 0; return; }   // the press was refused, nothing to finish
    std::string o = "{\"t\":\"ptt\",\"down\":false"; jkv(o, "ped", g_pttPed); o += "}"; net_send(o);
    LI("PTT up target=%d", g_pttPed);
}

// ───────────────────────── per-frame upkeep ─────────────────────────
static void upkeep() {
    uint64_t t = now_ms();
    bool playerShooting = false; bool shootChecked = false;
    for (size_t i = 0; i < g_peds.size();) {
        Managed& m = g_peds[i];
        if (!ped_ok(m.ped)) { LI("managed ped %d no longer exists", m.ped); send_event("ped_gone", m.ped); g_peds.erase(g_peds.begin() + i); if (g_engaged == m.ped) g_engaged = 0; continue; }
        if (CallB(IS_ENTITY_DEAD, m.ped)) { LI("managed ped %d died", m.ped); send_event("ped_dead", m.ped); int p = m.ped; ++i; release(p, false, "died"); i = 0; continue; }
        Vector3 p = CallVec(GET_ENTITY_COORDS, m.ped, true, false);
        float d = dist3(p, g_ppos);
        if (m.engaged && d > g_cfg.releaseDist) { int pp = m.ped; send_event("released", pp, "too far"); release(pp, false, "too far"); i = 0; continue; }
        if (m.engaged) {
            if (t >= m.lookAt && m.hold != H_RESTRAINED) { CallV(TASK_LOOK_AT_ENTITY, m.ped, g_player, 4000, 2048, 3, 0); m.lookAt = t + 3000; }
            if (g_cfg.stopAmbientSpeech && t >= m.speechStop && t >= m.painUntil) {
                m.speechStop = t + 250;
                if (!in_love(m.ped)) mute_vanilla(m.ped);    // 0.5.5: NpcHookups' moans are game voice lines - keep them
            }
            if (!shootChecked) { playerShooting = CallB(IS_PED_SHOOTING, g_player); shootChecked = true; }
            if (playerShooting && m.blocked && d < 45.f) { CallV(SET_BLOCKING_OF_NON_TEMPORARY_EVENTS, m.ped, false); m.blocked = false; send_event("danger", m.ped, "player shooting"); LI("danger: unblocked ped %d (player shooting)", m.ped); }
        }
        if (m.order) order_tick(m, t);
        if (m.vHalt || m.vDrive) veh_tick(m, t);
        if (m.actor && !m.engaged && g_cfg.stopAmbientSpeech && t >= m.speechStop && t >= m.painUntil) { m.speechStop = t + 250; if (!in_love(m.ped)) mute_vanilla(m.ped); }
        if (m.handsUp && t >= m.handsUpRefresh) { CallV(UPDATE_TASK_HANDS_UP_DURATION, m.ped, 60000); m.handsUpRefresh = t + 50000; }
        if (g_cfg.talkFace) {
            if (m.talkUntil > t) CallV(REQUEST_PED_FACIAL_MOOD_THIS_FRAME, m.ped, m.talkMood ? m.talkMood : 1751822680u, 6);
            else {
                if (m.talkUntil && m.talkUntil <= t) { if (m.faceOverride) { CallV(CLEAR_FACIAL_IDLE_ANIM_OVERRIDE, m.ped); m.faceOverride = false; } }
                if (m.emoMood && m.moodUntil > t) CallV(REQUEST_PED_FACIAL_MOOD_THIS_FRAME, m.ped, m.emoMood, 6);
            }
        }
        ++i;
    }
    if (g_pendingEngage && t - g_pendingSince > 3000) { toast("warn", 3000, "brain did not answer in time"); g_pendingEngage = 0; }
    if (!g_connected && g_lostAt && t - g_lostAt > 5000) {
        while (!g_peds.empty()) release(g_peds.front().ped, false, "brain disconnected");
        g_lostAt = 0;
    }
}

static void draw_ui() {
    uint64_t t = now_ms();
    float sc = g_cfg.subtitleScale;
    // subtitles of whoever is talking (closest first)
    for (auto& m : g_peds) {
        if (m.talkUntil + 1200 < t || m.subtitle.empty()) continue;
        Vector3 p = CallVec(GET_ENTITY_COORDS, m.ped, true, false);
        if (dist3(p, g_ppos) > g_cfg.subtitleDist) continue;
        // wrap at ~64 chars
        std::vector<std::string> lines; std::string cur; const std::string& s = m.subtitle;
        size_t i = 0;
        while (i < s.size()) {
            size_t sp = s.find(' ', i); if (sp == std::string::npos) sp = s.size();
            std::string w = s.substr(i, sp - i);
            if (cur.size() + w.size() + 1 > 64 && !cur.empty()) { lines.push_back(cur); cur.clear(); }
            if (!cur.empty()) cur += ' '; cur += w; i = sp + 1;
        }
        if (!cur.empty()) lines.push_back(cur);
        if (lines.size() > 4) lines.erase(lines.begin(), lines.end() - 4);
        float y = 0.88f - 0.035f * (lines.size() - 1);
        for (auto& l : lines) { draw_text(l.c_str(), 0.5f - text_width(l.size(), sc) / 2, y, sc, 255, 255, 255); y += 0.035f; }
        break;
    }
    // status line for the engaged person
    Managed* e = g_engaged ? find_m(g_engaged) : nullptr;
    if (e) {
        char b[200];
        const char* st = g_ptt ? "Listening..." : e->state == 1 ? "Thinking..." : e->talkUntil > t ? "" : "Hold X to talk";
        snprintf(b, sizeof b, "%s%s%s", e->hud[0] ? e->hud : e->name, st[0] ? "  |  " : "", st);
        int r = g_ptt ? 255 : 200, g = g_ptt ? 120 : 200, bl = g_ptt ? 100 : 200;
        draw_text(b, 0.5f - text_width(strlen(b), 0.28f) / 2, 0.80f, 0.28f, r, g, bl, 200);
    } else if (g_ptt) {
        draw_text("Listening...", 0.47f, 0.80f, 0.28f, 255, 120, 100, 200);
    }
    // toasts (errors / info) top-left
    float y = 0.04f;
    for (auto it = g_toasts.begin(); it != g_toasts.end();) {
        if (it->until < t) { it = g_toasts.erase(it); continue; }
        draw_text(it->text.c_str(), 0.015f, y, 0.27f, it->r, it->g, it->b, 235); y += 0.03f; ++it;
    }
}

static void poll_hookups() {
    uint64_t t = now_ms();
    if (t < g_hookCheck) return;
    g_hookCheck = t + 1000;
    if (!g_hookEvt) g_hookEvt = OpenEventA(SYNCHRONIZE, FALSE, "NpcHookupsPlus_SceneActive");
    int st = 0;
    if (g_hookEvt) st = WaitForSingleObject(g_hookEvt, 0) == WAIT_OBJECT_0 ? 1 : 0;
    if (st != g_hookState) { LI("NpcHookups scene event: %s (event %s)", st ? "ACTIVE" : "inactive", g_hookEvt ? "found" : "not found"); g_hookState = st; }
}

// ───────────────────────── startup ─────────────────────────
static void load_config() {
    char ini[MAX_PATH]; path_of(ini, "NpcVoice.ini");
    if (GetFileAttributesA(ini) == INVALID_FILE_ATTRIBUTES) {
        FILE* f = fopen(ini, "wb"); if (f) { fputs(INI_DEFAULT, f); fclose(f); }
    }
    g_cfg.port = ini_int("NpcVoice", "PORT", 47812, ini);
    g_cfg.pttKey = ini_int("NpcVoice", "PTT_KEY", 'X', ini);
    g_cfg.debug = ini_int("NpcVoice", "DEBUG", 1, ini);
    g_cfg.engageMaxDist = ini_float("NpcVoice", "ENGAGE_MAX_DIST", 30.f, ini);
    g_cfg.keepTalkingDist = ini_float("NpcVoice", "KEEP_TALKING_DIST", 25.f, ini);
    g_cfg.releaseDist = ini_float("NpcVoice", "RELEASE_DIST", 80.f, ini);
    g_cfg.subtitleDist = ini_float("NpcVoice", "SUBTITLE_MAX_DIST", 40.f, ini);
    g_cfg.subtitleScale = ini_float("NpcVoice", "SUBTITLE_SCALE", 0.34f, ini);
    g_cfg.talkFace = ini_int("NpcVoice", "TALK_FACE", 2, ini);
    g_cfg.blockVanillaKeys = ini_int("NpcVoice", "BLOCK_VANILLA_KEYS", 1, ini);
    g_cfg.blockLockOn = ini_int("NpcVoice", "BLOCK_LOCKON_WHILE_TALKING", 0, ini);
    g_cfg.typeInstead = ini_int("NpcVoice", "TYPE_INSTEAD_OF_VOICE", 0, ini);
    if (g_cfg.typeInstead) LI("TYPE_INSTEAD_OF_VOICE=1: hold X to type what you say (no microphone)");
    g_cfg.persistFollowers = ini_int("NpcVoice", "PERSIST_FOLLOWERS", 1, ini);
    g_cfg.nearbyScan = ini_int("NpcVoice", "NEARBY_SCAN", 1, ini);
    g_cfg.stopAmbientSpeech = ini_int("NpcVoice", "STOP_AMBIENT_SPEECH", 1, ini);
    g_cfg.muteBystanders = ini_int("NpcVoice", "MUTE_BYSTANDERS_WHILE_TALKING", 1, ini);
    g_cfg.painVoice = ini_int("NpcVoice", "PAIN_VOICE", 1, ini);
    GetPrivateProfileStringA("NpcVoice", "TRANSPORT", "file", g_cfg.transport, sizeof g_cfg.transport, ini);
    if (_stricmp(g_cfg.transport, "tcp") != 0) snprintf(g_cfg.transport, sizeof g_cfg.transport, "file");
    // natives disabled by the user or by a previous crash
    char dis[4096]; GetPrivateProfileStringA("NATIVES", "DISABLE", "", dis, sizeof dis, ini);
    FILE* gf = fopen(g_guardPath, "rb");
    if (gf) {
        char b[256] = {0}; size_t r = fread(b, 1, sizeof b - 1, gf); fclose(gf); b[r] = 0;
        char name[128] = {0};
        if (sscanf(b, "PENDING %127s", name) == 1) {
            LE("last session died inside the FIRST call of native %s – disabling it", name);
            std::string nd = dis; if (!nd.empty()) nd += ","; nd += name;
            WritePrivateProfileStringA("NATIVES", "DISABLE", nd.c_str(), ini);
            snprintf(dis, sizeof dis, "%s", nd.c_str());
            guard_end();
        }
    }
    for (char* p = strtok(dis, ", "); p; p = strtok(nullptr, ", ")) {
        for (auto& d : g_nat) if (!_stricmp(d.name, p)) { d.disabled = true; g_disabledAtStart.push_back(d.name); LW("native %s is DISABLED", d.name); }
    }
    LI("transport: %s", g_cfg.transport);
    LI("config: port=%d ptt_key=%d debug=%d engage=%.0f keep=%.0f release=%.0f subdist=%.0f face=%d block_keys=%d persist=%d",
       g_cfg.port, g_cfg.pttKey, g_cfg.debug, g_cfg.engageMaxDist, g_cfg.keepTalkingDist, g_cfg.releaseDist, g_cfg.subtitleDist,
       g_cfg.talkFace, g_cfg.blockVanillaKeys, g_cfg.persistFollowers);
}

static void script_main() {
    LI("script thread started");
    bool disabledToastShown = false;
    uint32_t switchShoulder = joaat("INPUT_SWITCH_SHOULDER");
    uint32_t lockonPos = joaat("INPUT_INTERACT_LOCKON_POS"), lockonNeg = joaat("INPUT_INTERACT_LOCKON_NEG");
    uint32_t wheelCtl = joaat("INPUT_OPEN_WHEEL_MENU");
    uint32_t aimCtl = joaat("INPUT_AIM");
    uint64_t lastFrame = 0; bool wheelHeld = false;
    while (true) {
        g_frames++;
        {   // game frozen (Esc/alt-tab: this loop didn't run) or weapon wheel open (slow motion, brain pauses the voice):
            // push lip/subtitle timers forward so the line resumes where it stopped instead of being cut
            uint64_t t = now_ms(), dt = lastFrame ? t - lastFrame : 0; lastFrame = t;
            if (dt > 400 || (wheelHeld && dt < 400)) {
                for (auto& m : g_peds) { if (m.talkUntil > t - dt) m.talkUntil += dt; if (m.moodUntil > t - dt) m.moodUntil += dt; }
                if (dt > 400) { LI("game was frozen for %llu ms - talk timers shifted", (unsigned long long)dt); g_resumeAt = t; }
            }
        }
        g_playerId = CallI(PLAYER_ID);
        g_player = CallI(PLAYER_PED_ID);
        if (g_player && ped_ok(g_player)) {
            g_ppos = CallVec(GET_ENTITY_COORDS, g_player, true, false);
            if (!disabledToastShown && !g_disabledAtStart.empty()) {
                std::string s = "disabled native(s) after a crash: ";
                for (auto& d : g_disabledAtStart) { s += d; s += ' '; }
                toast("warn", 12000, s.c_str()); disabledToastShown = true;
            }
            net_poll(on_line);
            bool paused = CallB(IS_PAUSE_MENU_ACTIVE);
            wheelHeld = CallB(IS_CONTROL_PRESSED, 0, wheelCtl) || CallB(IS_DISABLED_CONTROL_PRESSED, 0, wheelCtl);
            int f = paused ? 0 : detect_focus();
            if (!f && !paused && (CallB(IS_CONTROL_PRESSED, 0, aimCtl) || CallB(IS_DISABLED_CONTROL_PRESSED, 0, aimCtl) ||
                                  CallB(IS_CONTROL_PRESSED, 0, lockonPos) || CallB(IS_CONTROL_PRESSED, 0, lockonNeg)))
                f = camera_pick();
            if (paused) g_resumeAt = now_ms();
            if (f) { g_lastFocus = f; g_focusSeen = now_ms(); g_lastFocusHeld = now_ms() - (f == g_focus ? g_focusSince : now_ms()); }
            if (f != g_focus) {
                g_focus = f; g_focusSince = now_ms();
                std::string o = "{\"t\":\"focus\""; jkv(o, "ped", f); o += "}"; net_send(o);
                LD("focus -> %d", f);
            }
            if (g_cfg.typeInstead) {
                bool down = !paused && !g_typing && key_down(g_cfg.pttKey);
                typed_key(down, now_ms());
                typed_tick();
                if ((g_keyHeld || g_typing) && g_cfg.blockVanillaKeys) CallV(DISABLE_CONTROL_ACTION, 0, switchShoulder, true);
            } else {
            bool down = !paused && key_down(g_cfg.pttKey);
            if (down && !g_ptt) { g_ptt = true; on_ptt_down(); }
            else if (!down && g_ptt) { g_ptt = false; on_ptt_up(); }
            if (g_ptt && g_cfg.blockVanillaKeys) CallV(DISABLE_CONTROL_ACTION, 0, switchShoulder, true);
            }
            if (g_engaged && g_cfg.blockVanillaKeys && g_cfg.blockLockOn) {   // vanilla greet/antagonize lines (opt-in)
                CallV(DISABLE_CONTROL_ACTION, 0, lockonPos, true);
                CallV(DISABLE_CONTROL_ACTION, 0, lockonNeg, true);
            }
            upkeep();
            pump_anims();
            scen_watch_tick();
            dress_tick();
            tone_tick();
            undress_tick();
            couple_tick();
            hush_bystanders();
            pump_spawns();
            draw_route();
            poll_hookups();
            uint64_t t = now_ms();
            if (g_connected && t >= g_nextTick && (!g_peds.empty() || g_ptt)) { send_tick(); g_nextTick = t + g_cfg.tickMs; }
            else if (g_connected && t >= g_nextTick + 900) { send_tick(); g_nextTick = t + 1000; }
            if (g_connected && g_cfg.nearbyScan && t >= g_nextNearby) { send_nearby(); bool anyActor = false; for (auto& m : g_peds) if (m.actor) anyActor = true;
                g_nextNearby = t + ((g_engaged || anyActor) ? 1000 : 2000); }
            if (!paused) draw_ui();
        }
        scriptWait(0);
    }
}

BOOL APIENTRY DllMain(HMODULE hInstance, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        InitializeCriticalSection(&g_logcs);
        InitializeCriticalSection(&g_netcs);
        GetModuleFileNameA(hInstance, g_dir, MAX_PATH);
        char* s = strrchr(g_dir, '\\'); if (s) *s = 0;
        char lp[MAX_PATH]; path_of(lp, "NpcVoice.log");
        g_log = fopen(lp, "wb");
        path_of(g_guardPath, "NpcVoice_native_guard.txt");
        LI("NpcVoice.asi %s loaded from %s (built " __DATE__ " " __TIME__ ")", NV_VERSION, g_dir);
        load_config();
        HMODULE sh = GetModuleHandleA("ScriptHookRDR2.dll");
        if (sh) g_fakeKey = (int (*)(int))GetProcAddress(sh, "fake_key_down");
        if (g_fakeKey) LW("TEST RIG detected (fake_key_down export) – keyboard comes from the rig");
        scriptRegister(hInstance, script_main);
    } else if (reason == DLL_PROCESS_DETACH) {
        LI("unloading");
        g_quit = true;
        scriptUnregister(hInstance);
        if (g_log) fclose(g_log);
    }
    return TRUE;
}
