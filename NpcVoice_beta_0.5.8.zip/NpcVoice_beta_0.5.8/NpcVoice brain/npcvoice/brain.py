"""The NpcVoice brain: TCP server for NpcVoice.asi, conversation orchestration, reactions, recognition."""
from __future__ import annotations

import asyncio
import json
import os
import random
import re
import threading
import time
import traceback
from pathlib import Path
from urllib.parse import quote

from . import VERSION
from . import actions as acts
from . import context as ctxm
from . import safety
from .audio import Recorder, Voice3D
from .config import Config
from .conversation import Conversation
from .data import MOODS, PedDB
from .game import Game, diff_events
from .llm import KeyManager, Providers, stable_pick, tts_style
from .log import log, turn as log_turn
from .memory import MemoryStore
from . import world
from .director import Director
from .journey import Journeys
from .couples import Couples
from .household import Households
from .perception import Perception
from .drama import Drama
from .witness import Witness
from .law import LawDesk
from .activities import Activities, concepts_of
from .gamedb import GameDB
from . import daylife

AGE_VOICES = {
    "female": {
        "young": ["English_radiant_girl", "English_Upbeat_Woman", "English_captivating_female1", "English_Soft-spokenGirl"],
        "mid": ["English_CalmWoman", "English_Graceful_Lady", "English_captivating_female1", "English_MatureBoss"],
        "mature": ["English_Wiselady", "English_SentimentalLady", "English_AssertiveQueen", "English_Graceful_Lady"],
        "child": ["English_PlayfulGirl", "English_Kind-heartedGirl", "English_LovelyGirl"],
    },
    "male": {
        "young": ["English_ReservedYoungMan", "English_Gentle-voiced_man", "English_Jovialman"],
        "mid": ["English_magnetic_voiced_man", "English_Trustworth_Man", "English_Diligent_Man", "English_PatientMan",
                "English_Debator"],
        "mature": ["English_ManWithDeepVoice", "English_Deep-VoicedGentleman", "English_MaturePartner",
                   "English_expressive_narrator"],
        "child": ["English_ReservedYoungMan", "English_Gentle-voiced_man"],
    },
}
EMOTION_MOOD = {"happy": "MoodHappy", "sad": "MoodSad", "angry": "MoodAngry", "fearful": "MoodScared",
                "disgusted": "MoodDisgust", "surprised": "MoodNervous", "calm": "MoodNormalNeutral",
                "fluent": "MoodNormalNeutral", "whisper": "MoodSeductive"}
GESTURE_BY_EMOTION = {"angry": ["angry_", "annoyed_", "stern_"], "fearful": ["defensive_plead", "neutral_appease", "calm_down"],
                      "sad": ["empathise_", "negative_"], "happy": ["happy_", "positive_"], "surprised": ["confused_", "surprised_"],
                      "disgusted": ["negative_", "annoyed_dismiss"], "calm": ["neutral_"], "fluent": ["neutral_", "positive_"]}
MEMORY_EVENTS = {"aimed": ("pointed a gun at you", 2), "hogtied": ("hogtied you", 3), "freed": ("untied you", 3),
                 "hurt_by_player": ("hurt you", 3), "shots": ("fired a gun near you", 2), "lassoed": ("lassoed you", 2)}
GROUP_RE = re.compile(r"\b(both of you|you two|you both|the two of you|all of you|every ?one|every ?body|y'?all|you guys|"
                      r"you lot|boys|ladies|gents|gentlemen|folks|fellas|the both of you)\b")
PERSONAL_EVENTS = {"looted", "violation_close", "mates", "stripped", "undressed", "dressed", "scene_over", "appointment", "aimed", "hurt_by_player", "hogtied", "lassoed", "freed", "fist_fight", "hit_player", "aboard",
                   "got_off", "arrived", "found_dead", "found_horse", "stash_found", "hostage_freed", "questioning"}
ACTION_MEMORY = {"hands_up": "you put your hands up for him", "surrender": "you surrendered to him",
                 "follow": "you went along with him", "ride_with_me": "you rode with him", "flee": "you ran from him",
                 "attack": "you attacked him", "give_money": "you gave him money", "take_money": "he paid you",
                 "beg": "you begged him for your life", "kneel": "you knelt before him"}


# 0.5.7: what the people next to them SEE them do (a passenger watching the driver)
ACTION_SEEN = {"leave_vehicle": "is climbing down off the wagon", "dismount": "is getting off the horse",
               "hands_up": "put their hands up", "surrender": "surrendered", "flee": "is running away",
               "attack": "is fighting him", "stop_wagon": "stopped the wagon", "drive_on": "is driving on",
               "give_money": "handed him money", "beg": "is begging him", "cower": "is cowering",
               "kneel": "got down on their knees", "follow": "is going with him", "ride_with_me": "is getting on his horse"}


def enc(*tokens) -> str:
    return " ".join(quote(str(t), safe="._-:@") for t in tokens)


class Asi:
    """Command channel to NpcVoice.asi."""

    def __init__(self):
        self.writer: asyncio.StreamWriter | None = None
        self.seq = 0
        self.pending: dict[int, tuple[int, str, str]] = {}   # seq -> (ped, action, prim)

    @property
    def up(self):
        return self.writer is not None and not self.writer.is_closing()

    def send(self, *tokens):
        line = enc(*tokens)
        if not self.up:
            log.debug("[ASI] (not connected) drop: %s", line[:200])
            return
        log.debug("[ASI] >> %s", line[:300])
        self.writer.write((line + "\n").encode("ascii", "replace"))

    def next(self, ped, action, prim) -> int:
        self.seq += 1
        self.pending[self.seq] = (ped, action, prim)
        if len(self.pending) > 400:
            for k in sorted(self.pending)[:200]:
                self.pending.pop(k, None)
        return self.seq

    def prim(self, ped: int, action: str, p: tuple):
        kind = p[0]
        if kind == "on":                       # ("on", other_ped, <prim...>): steer someone else
            return self.prim(int(p[1]), action, tuple(p[2:]))
        if kind == "emote":
            self.send("emote", self.next(ped, action, kind), ped, p[1], p[2], p[3])
        elif kind == "scenario":
            self.send("scen", self.next(ped, action, kind), ped, p[1], p[2])
        elif kind == "anim":
            self.send("anim", self.next(ped, action, kind), ped, p[1], p[2], p[3], p[4])
        elif kind == "mood":
            self.send("mood", ped, MOODS.get(p[1], 0), p[2])
        elif kind == "money":
            self.send("money", self.next(ped, action, kind), int(p[1]))
        elif kind == "hookup":                 # ("hookup", other ped | 0 = with the player): NpcHookups does the scene
            self.send("hk_start", self.next(ped, action, kind), ped, int(p[1]))
        elif kind == "hookup_stop":
            self.send("hk_stop", self.next(ped, action, kind))
        elif kind == "crime":                  # ("crime", CRIME_x, bounty): reported by THIS ped (the lawman)
            self.send("crime", self.next(ped, action, kind), p[1], int(p[2]), ped)
        else:
            self.send("task", self.next(ped, action, kind), ped, *p)

    def toast(self, level: str, secs: float, text: str):
        log.log({"err": 40, "warn": 30}.get(level, 20), "[SCREEN %s] %s", level, text)
        self.send("toast", level, int(secs * 1000), ctxm.ascii_subtitle(text)[:180])


class Brain:
    def __init__(self, root: Path):
        self.root = root
        self.cfg = Config(root / "NpcVoice_brain.ini")
        self.km = KeyManager(self.cfg.keys_file)
        self.km.on_problem = self.key_problem         # a key out of credit / refused: on screen + in both logs
        self._key_notes: dict[tuple, float] = {}
        self.ai = Providers(self.km)
        self.peddb = PedDB(root / "data" / "rdr2_peds.json")
        self.memory = MemoryStore(root / "npc_memory")
        self.game = Game()
        self.game.memory = self.memory
        self._dead_seen: set[int] = set()
        self.asi = Asi()
        self.rec = Recorder(self.cfg.input_device)
        self.voice = Voice3D(self.cfg.near_m, self.cfg.far_m, self.cfg.master_volume)
        self.convs: dict[int, Conversation] = {}
        self.active: int = 0                 # ped currently being talked to
        self.speaking: dict = {}             # {ped, until, conv}
        self.ptt_ped = 0
        self.last_recognition = 0.0
        self.recog_cooldown: dict[str, float] = {}
        self.loop: asyncio.AbstractEventLoop | None = None
        self.asi_info: dict = {}
        self.rig_i = 0
        self.director = Director(self)
        self.journeys = Journeys(self)
        self.couples = Couples(self)
        self.perception = Perception(self)     # 0.5.8: who could see / hear what just happened
        self.households = Households(self)     # every home: a couple with a day (and a night) of their own
        self.drama = Drama(self)
        self.witness = Witness(self)
        self.game.witness = self.witness       # 0.5.7: the prompt always holds the people on the same horse/wagon
        self.law = LawDesk(self)
        self.db = GameDB(root / "data" / "db")
        self.game.db = self.db          # 0.5.1: the prompt lists the real places around the NPC
        try:
            scen_names = list(json.loads((root / "data" / "scenarios.json").read_text(encoding="utf-8")))
        except Exception:
            scen_names = []
        self.activities = Activities(scen_names, root / "data" / "learned_activities.json")
        self.act_tasks: dict[int, asyncio.Task] = {}
        self.scen_waiters: dict[int, asyncio.Future] = {}
        self.env_journey_variant = os.environ.get('NPCVOICE_JOURNEY_VARIANT', '')
        self.env_force_scenes = [x for x in os.environ.get('NPCVOICE_FORCE_SCENES', '').split(',') if x]
        from . import surroundings as _sur
        _sur.HANDLE_IDENT.clear()
        self.handle_ident: dict[int, str] = _sur.HANDLE_IDENT     # 0.5.1: shared, so everyone uses the same names
        self.last_ptt_up = 0.0
        # game freeze / pause / weapon wheel: the voice, scenes, reactions and timers stop with the game
        self.frozen = False
        self.frozen_why = ""
        self.frozen_since = 0.0
        self.thawed_at = 0.0
        self.frame = -1
        self.frame_t = 0.0                   # wall time the game's frame counter last moved
        self.alive_seen = False              # the plugin sends frame beats (0.3.1+)
        self.rig_used: dict[int, int] = {}

    def key_problem(self, svc: str, tail: str, why: str, seconds: float):
        """A key is benched (no credit, refused, rate limit): logged as an error, shown in the game (and so in
        NpcVoice.log too), at most once every 10 minutes per key and reason. The other keys carry on."""
        if "rate limit" in why or "429" in why:
            log.info("[KEYS] %s key %s: %s - the other keys carry on", svc, tail, why)
            return
        k = (svc, tail, why)
        if time.time() - self._key_notes.get(k, 0) < 600:
            return
        self._key_notes[k] = time.time()
        left = len(self.km.candidates(svc))
        name = {"minimax": "MiniMax (voices)", "openrouter": "OpenRouter (AI)"}.get(svc, svc)
        msg = (f"{name} key {tail}: {why}" + ("" if seconds == float("inf") else f" (retry in {int(seconds)}s)") +
               (f" - {left} other key(s) carry on" if left else " - NO other key left: " +
                ("voices are subtitles only" if svc == "minimax" else "replies fail")))
        log.error("[KEYS] %s", msg)
        if self.loop and self.asi.up:
            self.loop.call_soon_threadsafe(self.asi.toast, "err", 12, msg)

    # ── startup ──────────────────────────────────────────────
    def banner(self):
        log.info("NpcVoice brain %s", VERSION)
        log.info("config: %s", json.dumps(self.cfg.dump()))
        log.info("keys: %s (from %s)", self.km.summary(), self.km.source)
        log.info("ped DB: %d models | remembered people: %d", self.peddb.count, len(self.memory.ids))
        log.info("mic: %s | audio out: %s | fake_ai=%s", "ok" if self.rec.available else "MISSING",
                 "ok" if self.voice.ok else "MISSING", self.cfg.fake_ai)
        if not self.km.keys and not self.cfg.fake_ai:
            log.error("NO API KEYS FOUND – put audio_interest_keys.json next to npc_brain.py")

    async def run(self):
        self.loop = asyncio.get_running_loop()
        self.banner()
        from .filelink import FileLink
        self.filelink = FileLink(self)
        asyncio.create_task(self.filelink.run())
        try:
            server = await asyncio.start_server(self.on_client, "127.0.0.1", self.cfg.port)
        except OSError as e:
            log.warning("TCP port %d not available (%s) – using the file link only", self.cfg.port, e)
            server = None
        log.info("waiting for the game … (file link: %s | tcp: 127.0.0.1:%d) – start RDR2 with NpcVoice.asi installed",
                 self.filelink.folder, self.cfg.port)
        threading.Thread(target=self.console, daemon=True, name="console").start()
        if not self.cfg.fake_ai:
            await asyncio.to_thread(self.rec.open)
        asyncio.create_task(self.housekeeping())
        if server is None:
            await asyncio.Event().wait()
        async with server:
            await server.serve_forever()

    # ── connection ───────────────────────────────────────────
    async def on_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        peer = writer.get_extra_info("peername")
        if self.asi.up:
            log.warning("second game connection from %s – replacing the old one", peer)
            self.asi.writer.close()
        self.asi.writer = writer
        log.info("game connected from %s", peer)
        try:
            while True:
                line = await reader.readline()
                if not line:
                    break
                try:
                    msg = json.loads(line.decode("utf-8", "replace"))
                except json.JSONDecodeError:
                    log.warning("[ASI] bad line: %r", line[:200])
                    continue
                try:
                    await self.on_msg(msg)
                except Exception:
                    log.error("handler crashed on %s:\n%s", msg.get("t"), traceback.format_exc())
                    self.asi.toast("err", 6, "NpcVoice brain error – see npc_brain.log")
        except (ConnectionError, asyncio.IncompleteReadError) as e:
            log.warning("game connection lost: %s", e)
        finally:
            log.info("game disconnected")
            if self.asi.writer is writer:
                self.asi.writer = None
                self.on_game_lost()

    def on_game_lost(self):
        # keep conversations: a short dropout must not make the brain forget who you're talking to
        self.voice.stop()
        self.speaking = {}

    async def on_msg(self, m: dict):
        t = m.get("t")
        if t == "tick":
            self.frame_t = time.time()       # a tick is only sent by a running game frame
            self.game.on_tick(m, self.memory.player)
            self.after_tick()
        elif t == "alive":
            f = int(m.get("f", 0))
            if f != self.frame:
                self.frame, self.frame_t = f, time.time()
            self.alive_seen = True
            self.update_freeze()
        elif t == "hello":
            self.asi_info = m
            log.info("[ASI] hello: %s", json.dumps(m))
            self.asi.send("hello_ack", VERSION)
            asyncio.create_task(asyncio.to_thread(self.native_proof, m.get("dir", "")))
            dis = m.get("disabled") or []
            if dis:
                self.asi.toast("warn", 10, f"NpcVoice: {len(dis)} native(s) disabled after a crash: {', '.join(dis)[:120]}")
            bad = [] if (self.km.keys or self.cfg.fake_ai) else ["no API keys"]
            if not self.rec.available and not self.cfg.fake_ai:
                bad.append("no microphone library")
            if not self.voice.ok:
                bad.append("no audio output")
            if bad:
                self.asi.toast("err", 12, "NpcVoice brain problem: " + ", ".join(bad))
            else:
                self.asi.toast("ok", 6, f"brain {VERSION} connected (plugin {m.get('ver', '?')}). Focus a person, hold X to talk.")
            if m.get("ver") != VERSION:
                log.warning("VERSION MISMATCH: plugin NpcVoice.asi %s, brain %s", m.get("ver"), VERSION)
                self.asi.toast("err", 20, f"VERSION MISMATCH: NpcVoice.asi is {m.get('ver', '?')}, brain is {VERSION}. "
                                          "Close RDR2 fully and copy the new NpcVoice.asi next to RDR2.exe.")
        elif t == "engage_req":
            self.on_engage_req(m)
        elif t == "ptt":
            await self.on_ptt(m)
        elif t == "event":
            self.on_event(m)
        elif t == "act_result":
            self.on_act_result(m)
        elif t == "spawned":
            if self.couples.owns(int(m.get("seq", 0))):
                self.couples.on_spawned(m)
            else:
                self.journeys.on_spawned(m)
        elif t == "bed":
            self.couples.on_bed(m)
        elif t == "los":
            self.perception.on_los(m)
        elif t == "home":
            self.households.on_home(m)
        elif t == "tone":
            self.journeys.on_tone(m)
        elif t == "probe":
            self.journeys.on_probe(m)
        elif t == "scen_check":
            fut = self.scen_waiters.pop(int(m.get("ped", 0)), None)
            if fut and not fut.done():
                fut.set_result(m)
        elif t == "dismiss":
            # the second tap's 'press' has no 'release': finish it here so the brain doesn't think you're still talking
            self.ptt_ped = 0
            self.last_ptt_up = time.time()
            await asyncio.to_thread(self.rec.stop)
            for c in self.convs.values():
                c.listening = False
            conv = self.convs.get(int(m.get("ped", 0)))
            if conv and not conv.ended:
                self.interrupt("player dismissed them")
                conv.gen += 1
                conv.ident.add_event("he cut you off and walked away from the conversation",
                                     self.game.game_minutes_total, self.game.place(), 1)
                self.end(conv, "you ended the conversation (X X)", release_tasks=not conv.companion)
        elif t == "nearby":
            self.on_nearby(m)
        elif t == "focus":
            log.debug("[ASI] focus %s", m)
        elif t == "log":
            log.log({"E": 40, "W": 30}.get(m.get("lvl"), 20), "[ASI] %s", m.get("text"))
        else:
            log.debug("[ASI] unhandled %s", m)

    # ── engage ───────────────────────────────────────────────
    def classify(self, m):
        return self.peddb.classify(int(m.get("model", 0)), bool(m.get("male")) if "male" in m else None)

    def on_engage_req(self, m: dict, forced_ident=None, reason="player", side=False):
        """side=True (0.5.7): someone pulled INTO the talk (a passenger on the same wagon, the woman behind him on his
        horse) - they get their own person/memory/voice, without sending the one you talk to away."""
        ped = int(m["ped"])
        cls = self.classify(m)
        log.info("[ENGAGE] request ped=%d model=%s(%08x) outfit=%08x story=%s child=%s known=%s role=%s",
                 ped, cls["model_name"], int(m.get("model", 0)) & 0xFFFFFFFF, int(m.get("outfit", 0)) & 0xFFFFFFFF,
                 cls["story"], cls["child"], cls["known"], cls["role"])
        if not cls["known"] and m.get("mission"):
            cls["story"] = True       # unlisted model controlled by a script: treat as a story character
        if cls["story"]:
            self.asi.send("engage_deny", ped, "story")
            self.asi.toast("info", 4, "That's a story character - NpcVoice leaves them alone.")
            return None
        if cls["nonhuman"] or not m.get("human", 1):
            self.asi.send("engage_deny", ped, "nonhuman")
            return None
        if not m.get("alive", 1):
            self.asi.send("engage_deny", ped, "dead")
            self.asi.toast("info", 3, "They can't hear you anymore.")
            return None
        conv = self.convs.get(ped)
        if conv and conv.ended and not conv.companion:
            conv = None
        if not conv:
            zone = self.game.place()
            active_ids = {c.ident.id for c in self.convs.values() if c.ident and not c.ended}
            ident = forced_ident
            hid = self.handle_ident.get(ped)
            if not ident and hid and hid in self.memory.ids and not self.memory.ids[hid].d.get("dead") and \
                    self.memory.ids[hid].d.get("model") == int(m.get("model", 0)) & 0xFFFFFFFF:
                ident = self.memory.ids[hid]
                log.info("[ENGAGE] same ped handle as before this session -> same person %s", ident.persona["name"])
            ident = ident or self.memory.find(int(m.get("model", 0)), int(m.get("outfit", 0)), zone, active_ids)
            # 0.5.5: only someone who really MET you before recognises you (Hans's wife and kids, spawned a minute ago,
            # all said "you recognise this man")
            returning = ident is not None and int(ident.d.get("times_met", 0) or 0) > 0
            if not ident:
                ident = self.memory.create(int(m.get("model", 0)), int(m.get("outfit", 0)), cls, zone,
                                           self.game.game_minutes_total)
                # 0.5.1: if somebody already told you who this is ("that's Winifred, my neighbour"), that's who it is
                from .surroundings import NAMES, key_of
                pre = NAMES.get(key_of({"m": m.get("model", 0), "o": m.get("outfit", 0), "h": ped}))
                if pre and pre.get("name"):
                    ident.persona["name"] = pre["name"]
                    ident.persona["first_name"] = pre["name"].split()[0]
                    log.info("[ENGAGE] %s is the name others here already used for this person", pre["name"])
                self.fit_job_to_situation(ident, m)
                if not self.cfg.fake_ai:
                    asyncio.create_task(self.enrich_backstory(ident))
            ident.d["times_met"] += 1
            ident.d["last_seen"] = time.time()
            ident.d["last_zone"] = zone
            ident.dirty()
            conv = Conversation(ped, ident, cls)
            if ident.d.get("bed"):
                conv.flags["bed"] = ident.d["bed"]          # 0.5.1: their home's real bed (a couple you were sent to)
            from .surroundings import key_of as _k
            conv._key = _k({"m": m.get("model", 0), "o": m.get("outfit", 0), "h": ped})
            conv.flags["is_law"] = cls.get("role") == "lawman"
            pp = self.game.ped(ped) or {}
            daylife.assign_places(ident, self.db, pp.get("x", self.game.player.get("x", 0)), pp.get("y", self.game.player.get("y", 0)))
            open_appts = [a for a in ident.d.get("appointments", []) if not a.get("done")]
            if returning and open_appts:
                a0 = open_appts[-1]
                a0["done"] = True
                conv.pending_events.append(("appointment", f"You had agreed to meet him at {a0['where']} ({a0['when']}) - "
                                                           f"and here he is, at {self.game.place()}.", 1))
            self.convs[ped] = conv
            self.handle_ident[ped] = ident.id
            log.info("[ENGAGE] %s %s (%s, %s, %s) met=%d rank=%s", "RETURNING" if returning else "new",
                     ident.persona["name"], ident.persona["job"], ident.persona["temperament"],
                     "child" if ident.persona.get("child") else f"age {ident.persona['age']}",
                     ident.d["times_met"], ident.d["nemesis"]["rank"])
            if returning:
                conv.pending_events.append(("recognised", "You recognise this man – you've met him before.", 2))
            for ev in ident.d.pop("on_meet", []) or []:
                conv.pending_events.append(("expected", ev, 3))
        if side:
            if conv.ended:
                conv.ending, conv.after_actions, conv.pending_events = False, [], []
                conv.busy = conv.listening = False
            conv.ended = False
            conv.engaged_ok = True
            conv.touch()
            self.asi.send("actor", ped, 1)          # the plugin looks after them (ticks, tasks) like a scene actor
            return conv
        mates_of_new = {int(x.get("h", 0)) for x in self.witness.mates_of(conv)}
        for other in list(self.convs.values()):
            if other is not conv and not other.ended and not other.companion and not self.same_household(conv, other) \
                    and other.ped not in mates_of_new and other.flags.get("mate_of") != ped:
                self.end(other, "you turned to someone else")
        self.director.on_player_engage(ped)
        # 0.5.1: a companion conversation that ENDED stays in self.convs (she keeps following); re-engaging reused it
        # with conv.ending still set, so check_conversations ended it again 0.1 s later - every X press did nothing
        # but "listening" (Hattie at her family's camp, 16:14). A new talk starts clean.
        if conv.ended:
            conv.ending = False
            conv.after_actions = []
            conv.pending_events = []
            conv.busy = False
            conv.listening = False
        conv.ended = False
        conv.engaged_ok = True
        conv.touch()
        self.active = ped
        self.asi.send("engage_ok", ped, ctxm.ascii_subtitle(conv.name))
        self.asi.send("hud", ped, ctxm.ascii_subtitle(f"{conv.name} - {conv.ident.persona['job']}"))
        return conv

    DRIVER_JOBS = ["teamster hauling freight", "wagon driver for the general store", "coachman", "delivery man",
                   "farmer bringing goods to market", "carter hauling lumber", "peddler with a goods wagon"]
    DRIVER_OK = ("driver", "teamster", "coach", "carter", "delivery", "peddler", "farmer", "rancher", "homestead", "freight",
                 "stable", "outlaw", "moonshine", "trader", "salesman")

    def fit_job_to_situation(self, ident, m: dict):
        """0.4.0: the job has to fit what they're doing (a tram driver was an 'undertaker's assistant')."""
        p = ident.persona
        if p.get("child") or p.get("role") in ("lawman", "guard", "doctor", "clergy", "soldier"):
            return
        if m.get("tram") and m.get("drv"):
            p["job"] = "streetcar driver for the Saint Denis Tramway Company"
            p["today"] = "driving the streetcar on its route, on duty"
        elif m.get("drv"):
            if not any(k in p["job"] for k in self.DRIVER_OK):
                p["job"] = stable_pick(self.DRIVER_JOBS, ident.id)
            p["today"] = stable_pick(["hauling a load to the next town", "delivering goods", "heading home with supplies",
                                      "picking up a delivery", "taking the wagon to be mended"], ident.id + "t")
        elif m.get("veh") and m.get("tram"):
            p["today"] = "riding the streetcar across town"
        elif m.get("mnt") and p["today"] in ("waiting for someone who is late", "killing time"):
            p["today"] = "riding to the next town"
        ident.dirty()

    async def enrich_backstory(self, ident):
        p = ident.persona
        prompt = [{"role": "system", "content": "You write short character backstories for a western set in 1899."},
                  {"role": "user", "content": "Write a vivid 2-3 sentence backstory (plain text, no names of real people) "
                                              "for this person, consistent with every detail:\n" + json.dumps(p)}]
        raw, conf, errs = await asyncio.to_thread(self.ai.chat, prompt, False, 160, 0.95)
        if raw and not raw.strip().startswith("{"):
            p["backstory"] = raw.strip()[:500]
            ident.dirty()
            log.info("[MEM] backstory for %s: %s", p["name"], p["backstory"])
        elif raw:
            try:
                j = json.loads(re.search(r"\{.*\}", raw, re.S).group(0))
                p["backstory"] = str(next(iter(j.values())))[:500]
                ident.dirty()
            except Exception:
                pass

    # ── push to talk ─────────────────────────────────────────
    async def on_ptt(self, m: dict):
        ped = int(m.get("ped", 0))
        if m.get("down"):
            self.ptt_ped = ped
            if self.speaking:
                self.interrupt("player started talking")
            # X stops EVERYTHING: any line being prepared (reply or spontaneous reaction) is cancelled
            for c in self.convs.values():
                if c.busy:
                    c.gen += 1
                    c.busy = False
                    log.info("[PTT] cancelled %s's pending line - the player is talking", c.name)
                if c.after_actions:
                    c.after_actions = []
            self.asi.send("hush")
            conv = self.convs.get(ped)
            if (not conv or not conv.engaged_ok or conv.ended) and m.get("model"):
                log.info("[PTT] ped %d not engaged on the brain side – engaging now from the PTT info", ped)
                conv = self.on_engage_req(m)
            if conv:
                conv.listening = True
                conv.touch()
            if m.get("typed"):            # 0.5.6: TYPE_INSTEAD_OF_VOICE - the line comes typed, no microphone
                self.typing = True
                log.info("[PTT] down ped=%d (typing)", ped)
                return
            try:
                ok = await asyncio.wait_for(asyncio.to_thread(self.rec.start), 4)
            except asyncio.TimeoutError:
                ok = False
                log.error("[MIC] microphone did not respond within 4 s")
            if not ok and not self.cfg.fake_ai:
                self.asi.toast("err", 5, "Microphone not available - check npc_brain.log")
            log.info("[PTT] down ped=%d", ped)
        else:
            self.last_ptt_up = time.time()
            if getattr(self, "typing", False) or m.get("cancel"):
                self.typing = False
                conv = self.convs.get(ped) or self.convs.get(self.ptt_ped)
                self.ptt_ped = 0
                if conv:
                    conv.listening = False
                    conv.touch()
                text = str(m.get("text") or "").strip()
                log.info("[PTT] typed to ped=%d: %r", ped, text or "(cancelled)")
                if text and conv and conv.engaged_ok:
                    asyncio.create_task(self.run_turn(conv, text=text))
                return
            try:
                wav, secs, peak = await asyncio.wait_for(asyncio.to_thread(self.rec.stop), 4)
            except asyncio.TimeoutError:
                wav, secs, peak = None, 0.0, 0
                self.asi.toast("err", 5, "Microphone stopped responding - see npc_brain.log")
            conv = self.convs.get(ped) or self.convs.get(self.ptt_ped)
            self.ptt_ped = 0
            log.info("[PTT] up ped=%d %.2fs peak=%d debug_text=%r", ped, secs, peak, m.get("text"))
            if not conv or not conv.engaged_ok:
                log.info("[PTT] no engaged conversation for ped %d – ignored", ped)
                return
            conv.listening = False
            conv.touch()
            if m.get("text"):            # rig / console testing
                asyncio.create_task(self.run_turn(conv, text=m["text"]))
                return
            if self.cfg.fake_ai and secs < 0.35:   # test rig: scripted utterances, no microphone
                q = [x.split(":", 1) for x in os.environ.get("NPCVOICE_RIG_SAY", "").split("|") if ":" in x]
                idx = next((i for i, (p_, t) in enumerate(q) if int(p_) == conv.ped and i > self.rig_used.get(conv.ped, -1)), None)
                if idx is None and not any(int(p_) == conv.ped for p_, t in q):      # '0:' = anyone else
                    idx = next((i for i, (p_, t) in enumerate(q) if int(p_) == 0 and i > self.rig_used.get(0, -1)), None)
                    if idx is not None:
                        self.rig_used[0] = idx
                text = q[idx][1] if idx is not None else "hello there"
                if idx is not None:
                    self.rig_used[conv.ped] = idx
                self.rig_i += 1
                log.info("[RIG] scripted utterance #%d: %r", self.rig_i, text)
                asyncio.create_task(self.run_turn(conv, text=text))
                return
            if secs < 0.35:
                log.info("[PTT] tap (%.2fs) - not speech", secs)
                return
            if peak < 250:
                self.asi.toast("info", 2.5, "Didn't catch that (too quiet - check your microphone).")
                return
            asyncio.create_task(self.run_turn(conv, wav=wav))

    def interrupt(self, why: str):
        sp = self.speaking
        if not sp:
            return
        self.voice.stop()
        conv = sp.get("conv")
        self.asi.send("say_stop", sp["ped"])
        if conv:
            done = max(0.0, min(1.0, (time.time() - sp["start"]) / max(0.1, sp["until"] - sp["start"])))
            conv.pending_events.append(("interrupted", f"The player cut you off mid-sentence ({int(done * 100)}% said).", 1))
            if conv.after_actions:
                log.info("[TURN] dropped %d after-actions (interrupted)", len(conv.after_actions))
                conv.after_actions = []
            conv.ending = False
        log.info("[VOICE] interrupted ped=%d: %s", sp["ped"], why)
        self.speaking = {}

    # ── a turn: STT → LLM → actions → TTS ───────────────────
    async def run_turn(self, conv: Conversation, wav: bytes | None = None, text: str | None = None,
                       reaction: bool = False):
        if conv.ended and reaction:          # 0.5.0: a finished conversation never talks again on its own
            log.info("[TURN] %s: conversation already over - no reaction", conv.name)
            return
        conv.gen += 1
        gen = conv.gen
        conv.busy = True
        t0 = time.time()
        rec = {"ped": conv.ped, "who": conv.name, "id": conv.ident.id, "reaction": reaction}
        try:
            self.asi.send("state", conv.ped, "thinking")
            utterance = text
            if wav is not None:
                utterance, errs = await asyncio.to_thread(self.fake_stt if self.cfg.fake_ai else self.ai.stt, wav)
                rec["stt_errors"] = errs
                if not utterance:
                    self.asi.toast("err", 5, "Speech-to-text failed: " + (errs[-1] if errs else "no text")[:120])
                    return
            rec["t_stt"] = round(time.time() - t0, 2)
            if gen != conv.gen:
                if utterance:
                    conv.unanswered.append(utterance)
                log.info("[TURN] superseded after STT (%r)", utterance)
                return
            if utterance and conv.unanswered:
                utterance = " ... ".join(conv.unanswered + [utterance])
                conv.unanswered = []
            play = conv.flags.get("play")
            if utterance and play and str(play.get("stop_word", "")).lower() in utterance.lower():
                conv.flags["play"] = None              # the stop word ends it, whoever says it
                conv.pending_events.append(("stop_word", "He said the stop word - the game is over, right now.", 3))
            t_wait = time.time()        # 0.3.2: never decide on an empty state (first tick after engaging can lag)
            while time.time() - self.game.ped(conv.ped).get("_t", 0) > 2 and time.time() - t_wait < 1.5:
                await asyncio.sleep(0.1)
            if utterance and not reaction and not getattr(conv, "_group_turn", False):
                if not conv.flags.get("mate_of"):
                    self.witness.bring_in_mates(conv)      # 0.5.7: the people on his seat hear every word
                routed = self.route_group(conv, utterance)
                if routed is not conv:          # he was talking to someone else in the group
                    conv.unanswered = []
                    return
            if utterance:
                log.info("[TURN] PLAYER -> %s: %r", conv.name, utterance)
                conv.transcript.append(f"Player: {utterance}")
            ped = self.game.ped(conv.ped)
            player = self.player_view()
            # safety: what the player says is never filtered except children / rape wording
            if utterance and (safety.is_threat(utterance) or ped.get("aimed")):
                conv.mark("threatened")
            ped_ctx = dict(ped, hook=bool(self.game.world.get("hook")))
            verdict = safety.check_turn(utterance or "", conv, ped_ctx)
            rec["verdict"] = {"block": verdict.block, "explicit_route": verdict.explicit_route,
                              "no_sex_because": verdict.no_sex_because}
            if verdict.block:
                log.warning("[GUARD] %s: %s", conv.name, verdict.block)
                self.asi.toast("warn", 5, "Stopped: " + verdict.block)
                if verdict.child_flee:
                    for p in acts.A["flee"].run(None):
                        self.asi.prim(conv.ped, "flee", p)
                    conv.ending = True
                return
            conv.no_sex_because = verdict.no_sex_because
            events = [e[1] for e in conv.pending_events]
            conv.pending_events = []
            results, conv.last_results = conv.last_results, []
            sys_prompt = ctxm.system_prompt(conv, self.game, compact=verdict.explicit_route)
            user_msg = ctxm.player_turn_text(conv, utterance, events, results, ctxm.pressure_note(conv, self.game))
            messages = [{"role": "system", "content": sys_prompt}] + conv.history[-(8 if verdict.explicit_route else 16):] + \
                       [{"role": "user", "content": user_msg}]
            if verdict.explicit_route:      # 0.5.5: the storytelling models need the format said last, plainly
                messages.append({"role": "system", "content": "Answer as " + conv.ident.persona["first_name"] + " with ONE "
                                 "JSON object only. \"say\" holds ONLY the words you speak out loud - no narration, no "
                                 "describing yourself, no 'he/she does...'. Put what you DO in \"actions\"."})
            rec.update({"utterance": utterance, "events": events, "results": results,
                        "system": sys_prompt, "user": user_msg})
            if self.cfg.fake_ai:
                raw, model, errs = self.fake_llm(utterance or "", events, conv), {"model": "fake"}, []
            else:
                raw, model, errs = await asyncio.to_thread(self.ai.chat, messages, verdict.explicit_route)
            ok_reply, why_bad = safety.reply_ok(ctxm.parse_reply(raw)["say"], verdict) if raw else (True, "")
            if raw and not ok_reply:
                log.warning("[GUARD] NPC reply rejected (%s), regenerating: %r", why_bad, raw[:160])
                rec["rejected_reply"] = {"why": why_bad, "raw": raw}
                messages = messages + [{"role": "system", "content": "Your last reply was not allowed: nothing sexual can "
                                        "happen right now because you are " + ", ".join(verdict.no_sex_because or ["not able to"]) +
                                        ". React in character (fear, anger, disgust, pleading...) instead."}]
                if self.cfg.fake_ai:
                    raw = json.dumps({"say": "Get away from me!", "emotion": "angry", "actions": []})
                else:
                    raw, model, errs = await asyncio.to_thread(self.ai.chat, messages, False)
                if not raw or not safety.reply_ok(ctxm.parse_reply(raw)["say"], verdict)[0]:
                    log.warning("[GUARD] second reply also rejected – using a plain in-character line")
                    raw = json.dumps({"say": random.choice(["Don't you touch me!", "Get away from me!", "No. Not like this.",
                                                            "Let me go, damn you!"]),
                                      "emotion": "angry", "actions": [], "feelings": {"anger": 5, "trust": -5}})
            rec.update({"raw": raw, "model": model.get("model"), "llm_errors": errs, "t_llm": round(time.time() - t0, 2)})
            if not raw:
                self.asi.toast("err", 6, "AI reply failed: " + (errs[-1] if errs else "empty")[:120])
                return
            if gen != conv.gen:
                log.info("[TURN] superseded after LLM")
                if utterance:
                    conv.unanswered.append(utterance)
                return
            reply = ctxm.parse_reply(raw)
            reply["say"] = ctxm.strip_narration(reply["say"], conv.ident.persona.get("first_name", ""))
            rec["parsed"] = {k: v for k, v in reply.items()}
            ped = self.game.ped(conv.ped)
            player = self.player_view()
            player["lawman"] = self.law.nearest_lawman({conv.ped})
            approved, notes = acts.plan(reply["actions"], conv, ped, player)
            approved = self.implied_activity(conv, utterance, reply, approved, ped, player)
            approved = self.implied_love(conv, utterance, reply, approved, ped, player)
            approved = self.implied_follow(conv, utterance, reply, approved, ped, player)
            approved = self.implied_mark(conv, utterance, reply, approved, ped, player)
            approved = self.implied_call(conv, reply, approved, ped, player)
            approved = self.local_guard(conv, utterance, approved)
            approved = self.trip_guard(conv, utterance, approved)
            rec["actions_ok"] = [{"name": a["name"], "when": a["when"], "args": a["args"], "prims": a["prims"]}
                                 for a in approved]
            conv.flags["_last_actions"] = [ACTION_SEEN.get(a["name"], a["name"].replace("_", " ")) for a in approved]
            rec["actions_rejected"] = notes
            if notes:
                log.info("[ACT] rejected: %s", notes)
                conv.last_results.extend(f"{n}" for n in notes)
            # memory
            changed = conv.ident.adjust(reply["feelings"], "turn")
            rec["feelings_changed"] = changed
            if reply["remember"]:
                conv.ident.remember_fact(reply["remember"])
            conv.history.append({"role": "user", "content": user_msg})
            conv.history.append({"role": "assistant", "content": json.dumps(
                {"say": reply["say"], "emotion": reply["emotion"], "actions": [a["name"] for a in approved]})})
            conv.history = conv.history[-24:]
            if reply["say"]:
                conv.transcript.append(f"{conv.name}: {reply['say']}")
                self.note_told_facts(conv, reply["say"])
            conv.turns += 1
            conv.touch()
            # execute (never while the game is paused/frozen: it all happens when you come back)
            if self.frozen:
                log.info("[TURN] waiting: %s", self.frozen_why)
                await self.wait_unfrozen()
                if gen != conv.gen or self.dead(conv.ped):
                    log.info("[TURN] dropped after the pause (%s)", "superseded" if gen != conv.gen else "they died")
                    return
            now_acts = [a for a in approved if a["when"] != "after"]
            conv.after_actions = [a for a in approved if a["when"] == "after"]
            for a in now_acts:
                self.execute(conv, a)
            emote_now = any(p[0] == "emote" for a in now_acts for p in a["prims"])
            if reply["end"] or any(a["act"].ends for a in approved):
                conv.ending = True
            if reply["say"]:
                await self.speak(conv, reply["say"], reply["emotion"], gesture=not emote_now and not now_acts, gen=gen)
            else:
                self.run_after_actions(conv)
            rec["t_total"] = round(time.time() - t0, 2)
            log.info("[TURN] %s (%s, %s) says %r actions=%s end=%s in %.1fs",
                     conv.name, model.get("model"), reply["_parsed"], reply["say"],
                     [a["name"] + ("@after" if a["when"] == "after" else "") for a in approved], conv.ending,
                     rec["t_total"])
        except Exception as e:
            log.error("[TURN] crashed: %s\n%s", e, traceback.format_exc())
            rec["crash"] = repr(e)
            self.asi.toast("err", 6, f"NpcVoice turn failed: {e}"[:150])
        finally:
            if gen == conv.gen:
                conv.busy = False
                if not self.speaking:
                    self.asi.send("state", conv.ped, "idle")
            log_turn(rec)

    def execute(self, conv: Conversation, a: dict):
        if a["name"] == "make_love":           # 0.5.0: the other person must have said yes themselves
            other = int(a["args"].get("_with") or 0)
            oc = self.convs.get(other) if other else None
            watchers = self.couples.onlookers(conv.ped, other)
            if other and not (oc and not oc.ended and oc.flags.get("consent_love")):
                who = oc.name if oc else "that person"
                conv.last_results.append(f"make_love: {who} hasn't said yes - nothing happens until they want it too")
                log.info("[LOVE] %s wants %d but they haven't agreed - not started", conv.name, other)
                a = dict(a, prims=[p for p in a["prims"] if p[0] not in ("hookup", "undress")])
            elif watchers:
                # 0.5.8: "a cuck couple doing it in the saloon next to people" - not in front of strangers
                conv.last_results.append(f"make_love: NOT HERE - {watchers} other people can see you. Nobody does that in "
                                         "public in 1899: say so, and take him somewhere private (invite_home) if you want it")
                log.info("[LOVE] %s: not started - %d onlookers around", conv.name, watchers)
                a = dict(a, prims=[p for p in a["prims"] if p[0] not in ("hookup", "undress")])
            else:
                g = self.game
                partner = oc.name if oc else "the stranger"
                conv.flags["hookup_with"] = other or "player"
                conv.ident.add_event(f"you made love with {partner}", g.game_minutes_total, g.place(), 3)
                if oc:
                    oc.flags["hookup_with"] = conv.ped
                    oc.ident.add_event(f"you made love with {conv.name}", g.game_minutes_total, g.place(), 3)
                bed = conv.flags.get("bed") or (oc.flags.get("bed") if oc else None)
                if bed:          # 0.5.1: on the real bed of the house - NpcVoice runs it (0.5.8: NpcHookups' way, attached)
                    a = dict(a, prims=[p for p in a["prims"] if p[0] != "hookup"])
                    self.couples.make_love(conv, other)
                    log.info("[LOVE] %s + %s: on the bed (NpcVoice's own scene)", conv.name, partner)
                else:
                    log.info("[LOVE] %s + %s: scene asked of NpcHookups", conv.name, partner)
        for k, v in a["act"].sets.items():
            conv.flags[k] = v
        if a["name"] in ("follow", "ride_with_me") and conv.seconds_since("threatened") < 300:
            conv.flags["captive"] = True
        if a["act"].overrides_hold and a["prims"]:
            self.asi.send("override", conv.ped)
        primary = any(p[0] not in ("look", "look_clear", "keep", "persist", "block", "mood", "money", "emote", "anim",
                                   "holster", "draw", "drop_weapon", "crime") for p in a["prims"])
        if primary:
            self.stop_activity(conv.ped)       # a new task replaces whatever they were doing
        for p in a["prims"]:
            if p[0] == "activity":
                self.start_activity(conv, str(p[1]))
            elif p[0] == "activity_after":     # ("activity_after", ms, what): once they got there
                self.start_activity(conv, str(p[2]), delay=float(p[1]) / 1000)
            elif p[0] == "activity_stop":
                conv.flags["doing"] = ""
            else:
                self.asi.prim(conv.ped, a["name"], p)
        if a["name"] == "lead_to":
            self.journeys.start(conv, a["args"])
        if a["name"] == "stop_making_love":
            self.couples.stop_for(conv.ped, f"{conv.name} stopped it")
        if a["name"] == "invite_home":
            self.couples.lead_home(conv, int(a["args"].get("_partner") or 0), str(a["args"].get("why", "")))
        if a["name"] == "agree_to_watch":
            conv.ident.add_event("you wanted to watch your partner with the stranger - your own wish", self.game.game_minutes_total,
                                 self.game.place(), 2)
        if a["name"] == "undress":
            conv.mark("self_undress")
        if a["name"] == "start_play":
            conv.flags["play"] = {"stop_word": a["args"].get("stop_word", "red"), "lead": a["args"].get("who_leads", "him")}
            conv.ident.add_event("you agreed to a game of dominance with him", self.game.game_minutes_total, self.game.place(), 2)
        if a["name"] == "take_item":
            conv.ident.add_event(f"he gave you {a['args'].get('item', 'a gift')}", self.game.game_minutes_total, self.game.place(), 2)
        if a["name"] == "take_bribe":
            conv.ident.add_event(f"he paid you ${a['args'].get('amount', '?')} to keep quiet", self.game.game_minutes_total,
                                 self.game.place(), 2)
        if a["name"] == "work_for_him":
            conv.ident.add_event(f"he hired you to watch his back (${a['args'].get('amount', '?')})", self.game.game_minutes_total,
                                 self.game.place(), 2)
        if a["name"] == "meet_later":
            daylife.add_appointment(conv.ident, str(a["args"].get("where") or "the saloon"), str(a["args"].get("when") or "later"),
                                    self.game.game_minutes_total)
        if a["name"] == "mark_stash":
            self.journeys.start(conv, dict(a["args"], kind="stash"), guided=False)
        if a["name"] == "mark_person":
            k = str(a["args"].get("kind", "person")).lower()
            self.journeys.start(conv, dict(a["args"], kind=k if any(w in k for w in ("couple", "enemy", "place", "saloon",
                                                                                    "hotel", "brothel", "doctor")) else "person"),
                                guided=False)
        if a["name"] == "cancel_trip" and self.journeys.active and self.journeys.active.guide == conv.ped:
            self.journeys.cancel(self.journeys.active, f"{conv.name} called it off")
        if a["name"] == "report_to_law":
            self.law.start(conv, a["args"], int(a["args"].get("_law") or 0))
        if a["name"] == "arrest":
            g = self.game
            world.add_deed(self.memory, g.place(), g.zone()["state"],
                           f"{conv.name} the lawman put THE_STRANGER under arrest ({a['args'].get('crime', 'trouble')})",
                           3, g.game_minutes_total, 1)
            self.asi.toast("err", 6, "You're wanted - the law is coming for you.")
        if a["name"] == "release_hostage":
            for p in self.journeys.release_hostage(conv):
                self.asi.prim(conv.ped, "release_hostage", p)
        if a["name"] in ACTION_MEMORY:
            conv.ident.add_event(ACTION_MEMORY[a["name"]], self.game.game_minutes_total, self.game.place(),
                                 3 if a["name"] in ("attack", "surrender", "beg", "ride_with_me") else 2)
        if a["name"] == "give_money" and (conv.flags.get("hands_up") or conv.seconds_since("threatened") < 180):
            world.add_deed(self.memory, self.game.place(), self.game.zone()["state"],
                           f"THE_STRANGER robbed {conv.name} at gunpoint", 2, self.game.game_minutes_total,
                           self.game.near.get("people", 0))
        if a["name"] in ("take_money", "give_money", "drop_money"):
            amt = a["args"].get("amount", "?")
            conv.last_results.append(f"{a['name']} ${amt}: done")
        log.info("[ACT] %s -> %s %s prims=%s", conv.name, a["name"], a["args"] or "", a["prims"])

    # ── activities (0.4.0) ──
    # ── clothes and intimacy awareness (0.5.0) ──
    def watch_body(self, conv: Conversation, cur: dict):
        """Undressed / dressed / in a love scene: noticed, attributed (who did it), remembered, reacted to."""
        g = self.game
        cu, cl = cur.get("cu"), cur.get("cl")
        if cu is not None and cl is not None:
            clothed = (cu + cl) > 0 and not cur.get("nude")
            if clothed:
                conv.flags["_had_clothes"] = True
            naked = bool(cur.get("nude")) or ((cu + cl) == 0 and bool(conv.flags.get("_had_clothes")))
            was = bool(conv.flags.get("naked"))
            if naked and not was:
                self.on_undressed(conv, cur)
            elif was and clothed:
                conv.flags["naked"] = False
                conv.pending_events.append(("dressed", "You're dressed again.", 1))
                conv.ident.add_event("you got dressed again", g.game_minutes_total, g.place(), 1)
            if naked:
                conv.flags["naked"] = True
        hk = int(cur.get("hk") or 0)
        if hk and not conv.flags.get("in_scene"):
            conv.flags["in_scene"] = True
            conv.flags["scene_started"] = time.time()
        elif not hk and conv.flags.get("in_scene"):
            conv.flags["in_scene"] = False
            dur = time.time() - conv.flags.get("scene_started", time.time())
            partner = conv.flags.get("hookup_with")
            who = "the stranger" if partner == "player" else (self.convs[partner].name if partner in self.convs else "your partner")
            conv.ident.add_event(f"you made love with {who} ({int(dur // 60)} min)", g.game_minutes_total, g.place(), 3)
            conv.pending_events.append(("scene_over", f"You just finished making love with {who}. How do you feel?", 2))

    def on_undressed(self, conv: Conversation, cur: dict):
        g = self.game
        conv.flags["naked"] = True
        child = bool(conv.ident.persona.get("child"))
        if conv.seconds_since("self_undress") < 25:
            conv.ident.add_event("you took your clothes off", g.game_minutes_total, g.place(), 2)
            return
        if cur.get("hk") or conv.flags.get("hookup_with"):
            conv.ident.add_event("you were undressed for love-making", g.game_minutes_total, g.place(), 2)
            return
        near = cur.get("d", 99) < 3.5
        if child:
            log.warning("[GUARD] a child was undressed - they run off")
            self.asi.toast("warn", 5, "The kid runs off.")
            for p in acts.A["flee"].run(None):
                self.asi.prim(conv.ped, "flee", p)
            conv.ending = True
            return
        if not near:
            conv.pending_events.append(("undressed", "Your clothes are gone - someone undressed you. You're NAKED.", 3))
            return
        consent = conv.flags.get("consent_undress") or conv.flags.get("consent_love")
        if consent and not getattr(conv, "no_sex_because", None):
            conv.pending_events.append(("undressed", "He took your clothes off, the way you wanted. You're naked now.", 2))
            conv.ident.add_event("he undressed you - you wanted it", g.game_minutes_total, g.place(), 2)
            return
        log.info("[BODY] %s was stripped by the player WITHOUT agreeing", conv.name)
        conv.flags["violated"] = True
        conv.mark("threatened")
        conv.mark("stripped")                 # 0.5.7: their kin who see it react (drama.py)
        conv.pending_events.append(("stripped", "!! The stranger just STRIPPED YOU NAKED against your will. React as a real person "
                                                "would: outrage, shame, cover yourself, slap him, scream for help, run, or swear "
                                                "you'll get the law on him. Nothing about this is sexual to you.", 3))
        conv.ident.add_event("he stripped you naked against your will", g.game_minutes_total, g.place(), 3)
        conv.ident.adjust({"anger": 30, "fear": 20, "trust": -35, "attraction": -25}, "stripped", cap=40)
        world.add_deed(self.memory, g.place(), g.zone()["state"], f"THE_STRANGER stripped {conv.name} naked in public", 2,
                       g.game_minutes_total, g.near.get("people", 0))

    # ── several people at once (0.4.0) ──
    def listeners(self, conv: Conversation) -> list[Conversation]:
        """Other people who hear you right now: the ones with you (companions) or that you talked to a moment ago."""
        now, out = time.time(), []
        for c in self.convs.values():
            if c is conv or c.ended or not c.engaged_ok or self.dead(c.ped):
                continue
            d = self.game.ped(c.ped).get("d", 99)
            if d <= 15 and (c.companion or now - c.last_activity < 60):
                out.append(c)
        return out

    def route_group(self, conv: Conversation, utterance: str) -> Conversation:
        others = self.listeners(conv)
        mates = [c for c in self.witness.mate_convs(conv) if c is not conv]
        others += [c for c in mates if c not in others]
        if not others:
            return conv
        low = utterance.lower()
        first = lambda c: c.ident.persona.get("first_name", "").lower()
        named = [c for c in others if first(c) and re.search(r"\b" + re.escape(first(c)) + r"\b", low)]
        me_named = bool(first(conv)) and re.search(r"\b" + re.escape(first(conv)) + r"\b", low)
        group = bool(GROUP_RE.search(low))
        if named and not me_named and not group:
            tgt = named[0]
            log.info("[GROUP] said to %s (by name), not %s", tgt.name, conv.name)
            tgt.touch()
            self.active = tgt.ped
            asyncio.create_task(self.run_turn(tgt, text=utterance))
            return tgt
        for c in mates:                 # 0.5.7: they always HEAR it (and remember), even when it isn't about them
            c.pending_events.append(("overheard", f"(Right next to you, the stranger said to {conv.ident.persona['first_name']}: "
                                                  f"\"{utterance[:200]}\")", 1))
            c.touch()
        about_mates = bool(mates) and self.witness.mates_should_answer(utterance, conv)
        if group or named or about_mates:
            followers = others if group else named if named else []
            followers += [c for c in mates if about_mates and c not in followers]
            log.info("[GROUP] %s + %s all hear: %r", conv.name, [c.name for c in followers], utterance)
            asyncio.create_task(self.group_followups(conv, followers, utterance))
        return conv

    async def group_followups(self, first: Conversation, followers: list[Conversation], utterance: str):
        names = ", ".join([first.ident.persona["first_name"]] + [c.ident.persona["first_name"] for c in followers])
        for c in followers:
            t0 = time.time()
            await asyncio.sleep(0.5)
            while (first.busy or self.speaking or any(x.busy for x in followers)) and time.time() - t0 < 40:
                await asyncio.sleep(0.25)
            if c.ended or self.dead(c.ped) or self.ptt_ped:
                continue
            if c.flags.get("mate_of") == first.ped or first.flags.get("mate_of") == c.ped or \
                    c.ped in {int(x.get("h", 0)) for x in self.witness.mates_of(first)}:
                c.pending_events = [e for e in c.pending_events if e[0] != "overheard"]
                c.pending_events.append(("mates", self.witness.mate_followup_event(first, c), 2))
            else:
                c.pending_events.append(("group", f"He's talking to all of you together ({names}) - the others answer too.", 1))
            c._group_turn = True
            try:
                await self.run_turn(c, text=utterance)
            finally:
                c._group_turn = False
            t1 = time.time()
            while self.speaking and time.time() - t1 < 30:
                await asyncio.sleep(0.25)

    def talking_recently(self, secs: float) -> bool:
        """Is the player in a live conversation (not counting companions just tagging along)?"""
        now = time.time()
        return bool(self.ptt_ped) or any(c.busy or (not c.ended and c.engaged_ok and now - c.last_activity < secs
                                                     and (self.active == c.ped or not c.companion))
                                         for c in self.convs.values())

    def stop_activity(self, ped: int):
        t = self.act_tasks.pop(ped, None)
        if t and not t.done():
            t.cancel()

    def start_activity(self, conv: Conversation, what: str, delay: float = 0.0):
        self.stop_activity(conv.ped)
        self.act_tasks[conv.ped] = asyncio.create_task(self.run_activity(conv, what, delay))

    async def scen_try(self, ped: int, prim: tuple, timeout: float) -> dict:
        fut = asyncio.get_running_loop().create_future()
        old = self.scen_waiters.pop(ped, None)
        if old and not old.done():
            old.cancel()
        self.scen_waiters[ped] = fut
        self.asi.prim(ped, "activity", prim)
        try:
            return await asyncio.wait_for(fut, timeout)
        except asyncio.TimeoutError:
            return {"ok": False, "why": "no answer"}
        finally:
            if self.scen_waiters.get(ped) is fut:
                self.scen_waiters.pop(ped, None)

    async def run_activity(self, conv: Conversation, what: str, delay: float = 0.0):
        """Search the game's scenarios for it, try the best ones until one REALLY plays, learn from it."""
        ped, ident = conv.ped, conv.ident
        male = ident.persona["sex"] == "male"
        try:
            if delay:
                await asyncio.sleep(delay)
            await self.wait_unfrozen()
            # 0.5.0: the player's own words count too ("sit down and finish your coffee" -> the AI only wrote "sit")
            said = next((t[len("Player: "):] for t in reversed(conv.transcript) if t.startswith("Player: ")), "")
            if said and set(concepts_of(said)) - set(concepts_of(what)):
                what = f"{what} {said}"
            cands, cons = self.activities.candidates(what, male)
            log.info("[ACTIVITY] %s: %r -> %s -> candidates %s", conv.name, what, cons, cands)
            self.asi.send("override", ped)
            tried = []
            if self.activities.wants_furniture(cons, what) or not cands:
                r = await self.scen_try(ped, ("use_spot", 15), 14)
                if r.get("ok"):
                    nice = self.activities_pretty(r.get("type"), what)
                    conv.flags["doing"] = nice
                    conv.last_results.append(f"activity: you are now {nice} (a real spot nearby)")
                    log.info("[ACTIVITY] %s uses a real spot nearby (%s)", conv.name, nice)
                    return
                tried.append("a spot nearby")
            for sc in cands:
                if self.dead(ped):
                    return
                r = await self.scen_try(ped, ("scenario", sc, -1), 7)
                ok = bool(r.get("ok"))
                self.activities.learn(sc, male, ok)
                if ok:
                    nice = sc.replace("WORLD_HUMAN_", "").replace("PROP_HUMAN_", "").replace("WORLD_CAMP_", "").replace("_", " ").lower()
                    conv.flags["doing"] = nice
                    conv.last_results.append(f"activity: you are now doing it ({nice})")
                    return
                tried.append(sc)
            em = self.activities.emote_for(cons)
            if em:
                self.asi.prim(ped, "activity", ("emote", em[0], em[1], 0))
                conv.last_results.append(f"activity: only managed a quick gesture for '{what}' (nothing else worked here)")
                log.info("[ACTIVITY] %s: no scenario worked for %r - emote %s", conv.name, what, em[1])
                return
            conv.last_results.append(f"activity '{what}' isn't possible here (tried {len(tried)} ways) - say so if it matters")
            log.info("[ACTIVITY] %s: nothing worked for %r", conv.name, what)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            log.error("[ACTIVITY] crashed: %s\n%s", e, traceback.format_exc())

    def activities_pretty(self, type_hash, what: str) -> str:
        from .hashing import joaat
        try:
            th = int(type_hash or 0) & 0xFFFFFFFF
        except (TypeError, ValueError):
            th = 0
        if th:
            for n in self.activities.all:
                if joaat(n) == th:
                    return n.replace("PROP_HUMAN_", "").replace("WORLD_HUMAN_", "").replace("_", " ").lower()
        return what

    def run_after_actions(self, conv: Conversation):
        aa, conv.after_actions = conv.after_actions, []
        for a in aa:
            self.execute(conv, a)

    def dead(self, ped: int) -> bool:
        p = self.game.ped(ped)
        if p and not p.get("alive", 1):
            return True
        if int(ped) in self._dead_seen:          # 0.5.5: people we don't tick (Clara) are known dead from the scan
            return True
        q = next((x for x in self.game.near_peds if int(x.get("h", 0)) == int(ped)), None)
        return bool(q) and not q.get("alive", 1)

    def real_emotion(self, conv: Conversation, emotion: str) -> tuple[str, float]:
        """The voice follows the situation: a gun on them or hands up = they sound afraid (and talk faster)."""
        pd = self.game.ped(conv.ped) or {}
        brave = conv.ident.persona.get("bravery", 0.5)
        st = conv.ident.stats
        flat = emotion in ("calm", "fluent", "happy", "whisper", "", "neutral")
        under_threat = pd.get("aimed") or conv.flags.get("hands_up") or pd.get("hog") or conv.seconds_since("aimed") < 20
        if under_threat and brave < 0.65 and flat:
            return "fearful", 1.12
        # 0.5.8: the rest of the situation too - just hurt, someone just killed in front of them, terrified or furious
        if conv.seconds_since("hurt_by_player") < 30 and flat:
            return ("angry", 1.12) if brave >= 0.6 else ("fearful", 1.15)
        if conv.seconds_since("threatened") < 30 and flat and st.get("fear", 0) >= 45:
            return "fearful", 1.1
        if flat and emotion != "whisper" and st.get("anger", 0) >= 60 and st.get("fear", 0) < 40:
            return "angry", 1.05
        if conv.flags.get("in_scene") and emotion in ("calm", "fluent", "neutral"):
            return "passionate", 1.0                  # in the middle of making love nobody sounds "calm"
        if conv.flags.get("grieving") and flat:
            return "sad", 0.92
        return emotion, (1.1 if emotion in ("fearful", "angry") else 1.0)

    async def speak(self, conv: Conversation, text: str, emotion: str, gesture: bool, gen: int):
        p = conv.ident.persona
        if self.dead(conv.ped):
            log.info("[VOICE] %s is dead - silent", conv.name)
            return
        emotion, speed = self.real_emotion(conv, emotion)
        mp3, err, voice, pitch = await self.tts_line(conv.ident, text, emotion, speed)
        if self.frozen:
            log.info("[VOICE] %s's line held: %s", conv.name, self.frozen_why)
            await self.wait_unfrozen()
        if gen != conv.gen or self.ptt_ped or self.dead(conv.ped):
            log.info("[VOICE] not speaking: %s", "player is talking" if self.ptt_ped else
                     "they died" if self.dead(conv.ped) else "superseded")
            return
        if self.speaking and self.speaking.get("scene"):
            self.asi.send("say_stop", self.speaking["ped"])
        if mp3:
            dur = self.voice.play(mp3, conv.ped)
        else:
            if not self.cfg.fake_ai:
                self.asi.toast("err", 5, f"Voice (TTS) failed - subtitles only: {err}"[:150])
            dur = max(1.6, len(text.split()) * 0.36)
        self.asi.send("say", conv.ped, int(dur * 1000), MOODS.get("MoodTalkingHappy" if tts_style(emotion)[0] == "happy" else "MoodTalking", 0),
                      MOODS.get(EMOTION_MOOD.get(tts_style(emotion)[0] or emotion, "MoodNormalNeutral"), 0),
                      ctxm.ascii_subtitle(p["name"].split()[0]), ctxm.ascii_subtitle(text))
        pst = self.game.ped(conv.ped)
        standing_free = not any(pst.get(k) for k in ("mnt", "veh", "scen", "sit", "hog", "lasso", "rag", "flee", "comb"))
        if gesture and standing_free and not conv.flags.get("hands_up") and not conv.flags.get("cowering"):
            g = acts.gesture(acts.ActCtx(conv, {}, {}, {}), GESTURE_BY_EMOTION.get(tts_style(emotion)[0] or emotion, ["neutral_"]))
            for pr in g:
                self.asi.prim(conv.ped, "talk_gesture", pr)
        self.speaking = {"ped": conv.ped, "start": time.time(), "until": time.time() + dur, "conv": conv}
        log.info("[VOICE] %s speaks %.1fs voice=%s pitch=%s emotion=%s", conv.name, dur, voice, pitch, emotion)

    async def say_line(self, ped: int, ident, text: str, emotion: str, gesture: bool = True) -> float:
        """A line in an NPC-to-NPC scene: voice + subtitle + face; never while the player is talking."""
        if not text or self.ptt_ped or self.dead(ped):
            return 0.0
        mp3, err, voice, pitch = await self.tts_line(ident, text, emotion)
        await self.wait_unfrozen()
        if self.dead(ped) or self.ptt_ped or (self.speaking and not self.speaking.get("scene")):
            return 0.0
        dur = self.voice.play(mp3, ped) if mp3 else max(1.6, len(text.split()) * 0.36)
        self.asi.send("say", ped, int(dur * 1000), MOODS.get("MoodTalkingHappy" if tts_style(emotion)[0] == "happy" else "MoodTalking", 0),
                      MOODS.get(EMOTION_MOOD.get(tts_style(emotion)[0] or emotion, "MoodNormalNeutral"), 0),
                      ctxm.ascii_subtitle(ident.persona["name"].split()[0]), ctxm.ascii_subtitle(text))
        pst = self.game.ped(ped)
        if gesture and not any(pst.get(k) for k in ("mnt", "veh", "scen", "sit", "hog", "flee", "comb")):
            g = acts.gesture(type("C", (), {"male": ident.persona["sex"] == "male"})(),
                             GESTURE_BY_EMOTION.get(tts_style(emotion)[0] or emotion, ["neutral_"]))
            for pr in g:
                self.asi.prim(ped, "talk_gesture", pr)
        self.speaking = {"ped": ped, "start": time.time(), "until": time.time() + dur, "conv": None, "scene": True}
        log.info("[SCENE LINE] %s: %r (%.1fs, %s)", ident.persona["name"], text, dur, emotion)
        return dur

    async def tts_line(self, ident, text: str, emotion: str, speed: float = 1.0):
        """-> (mp3 | None, error, voice used, pitch). 0.5.8: voice cloning removed - every person has a stock AI voice
        picked for their sex and age, kept for good."""
        voice, pitch = self.voice_for_ident(ident)
        if self.cfg.fake_ai:
            return None, "fake", voice, pitch
        mp3, err = await asyncio.to_thread(self.ai.tts, text, voice, emotion, pitch, speed)
        return mp3, err, voice, pitch

    def voice_for(self, conv: Conversation):
        return self.voice_for_ident(conv.ident)

    def voice_for_ident(self, ident):
        d = ident.d
        if not d.get("voice"):
            p = ident.persona
            sex = "male" if p["sex"] == "male" else "female"
            br = "child" if p.get("child") else "young" if p["age"] <= 25 else "mid" if p["age"] <= 45 else "mature"
            d["voice"] = stable_pick(AGE_VOICES[sex][br], d["id"])
            d["pitch"] = 3 if br == "child" else -2 if br == "mature" else random.choice([-1, 0, 0, 1])
            ident.dirty()
        return d["voice"], d.get("pitch", 0)

    # ── periodic ─────────────────────────────────────────────
    AGREE_RE = re.compile(r"\b(yes|yeah|yep|okay|ok|o-?kay|alright|all right|sure|fine|certainly|of course|i'?ll|i will|"
                          r"right away|if you say so|why not|gladly|i reckon i can|i can do that)\b", re.I)
    REFUSE_RE = re.compile(r"\b(no|nope|won'?t|can'?t|ain'?t gonna|not gonna|never|refuse|don'?t want|rather not|not now)\b", re.I)
    ACTIVITY_ACTS = {"activity", "sit", "drink", "smoke", "eat", "play_instrument", "lean", "go_to_place", "inspect_body"}

    def implied_activity(self, conv, utterance, reply, approved, ped, player):
        """0.5.1: words must match deeds - also the PLAYER's. He asks 'go to sleep' / 'have a drink', she says
        'alright, I'll sleep now' and the AI picks cower (Jesse, 16:32) or nothing (Jesse's beer). If the person agrees
        and asked for an everyday thing, they do it - from his own words."""
        if not utterance or not reply.get("say"):
            return approved
        from .activities import CONCEPTS
        cons = [c for c in concepts_of(utterance) if c in CONCEPTS and c not in ("inspect", "think", "crouch", "wait")]
        # 'go sleep on that bed' + the AI only WALKS her over there (go_to_place): she should actually lie down on it
        furniture = bool(self.LOCAL_THING.search(utterance)) and any(c in cons for c in ("sleep", "sit", "rest"))
        if furniture:
            approved = [a for a in approved if a["name"] != "go_to_place"]
        if not cons or any(a["name"] in self.ACTIVITY_ACTS for a in approved):
            return approved
        say = re.sub(r"(\w)-(\w)", r"\2", reply["say"])          # "Y-yes", "I-I'll"
        if not self.AGREE_RE.search(say) or (self.REFUSE_RE.search(say) and not re.search(r"\bi'?ll\b", say, re.I)):
            return approved
        if any(a["name"] in ("flee", "attack", "walk_away", "wander") for a in approved):
            return approved
        extra, notes = acts.plan([{"name": "activity", "args": {"what": utterance}, "when": "now"}], conv, ped, player)
        if not extra:
            return approved
        kept = [a for a in approved if a["name"] not in ("cower", "kneel", "hands_up", "wait", "stand_up", "tremble")]
        log.info("[ACT] %s agreed to %s - doing it from the player's words (AI chose %s)", conv.name, cons,
                 [a["name"] for a in approved])
        return kept + extra

    LOVE_YES = re.compile(r"\b(yes|yeah|mm+|oh yes|come here|let'?s|take me|i want you|i'?d love|gladly|of course|"
                          r"come to bed|follow me|i'?m yours|don'?t stop|finally)\b", re.I)
    LOVE_ASK = re.compile(r"\b(make love|have sex|sex with|fuck|in bed|to bed|bed with|take (?:me|you) to bed|undress|"
                          r"get naked|lie with|sleep with|do it)\b", re.I)

    def implied_love(self, conv, utterance, reply, approved, ped, player):
        """0.5.3: he asks for it, she says 'yes, come here' - and then nothing happened unless the AI also picked
        make_love. A clear YES in her own words to his clear question is her consent: it happens (on her bed if she
        has one). Never if anything stops it (threat, fear, tied, a child - plan() checks all of that)."""
        if not utterance or not reply.get("say") or not self.LOVE_ASK.search(utterance):
            return approved
        if any(a["name"] in ("make_love", "stop_making_love", "flee", "attack", "walk_away", "refuse") for a in approved):
            return approved
        say = re.sub(r"(\w)-(\w)", r"\2", reply["say"])
        if not self.LOVE_YES.search(say) or self.REFUSE_RE.search(say) or safety.is_threat(say) or \
                re.search(r"\b(sheriff|law|scream|help|get away|leave me|bastard|pig|how dare)\b", say, re.I):
            return approved
        extra, notes = acts.plan([{"name": "make_love", "args": {"with": "me"}, "when": "after"}], conv, ped, player)
        if extra:
            log.info("[LOVE] %s said yes in her own words - make_love", conv.name)
        return approved + extra

    GO_WITH_RE = re.compile(r"\b(i'?ll|i will|i'?m gonna|let me) (come|go|ride) with you\b|\bi'?ll follow you\b|"
                            r"\btake me (instead|with you)\b|\bi'?ll come along\b|\bi'?m coming with you\b", re.I)

    def implied_follow(self, conv, utterance, reply, approved, ped, player):
        """0.5.5: Maggie said "I'll come with you, just don't hurt them" - and the AI made her run. If they SAY they go
        with you, they go with you (follow); running off is dropped. (She can still run later - in another reply.)"""
        say = re.sub(r"(\w)-(\w)", r"\2", str(reply.get("say") or ""))
        if not self.GO_WITH_RE.search(say):
            return approved
        if any(a["name"] in ("follow", "ride_with_me", "lead_to", "invite_home") for a in approved):
            return approved
        kept = [a for a in approved if a["name"] not in ("flee", "walk_away", "wander", "hands_up", "cower", "stay", "wait")]
        extra, notes = acts.plan(["follow"], conv, ped, player)
        if extra:
            log.info("[ACT] %s said she'd go with him - follows (AI chose %s)", conv.name, [a["name"] for a in approved])
            conv.ending = False
            reply["end"] = False
            return kept + extra
        return approved

    ASK_WHERE = re.compile(r"\b(where|know (?:of )?(?:any|a|some)|looking for|find (?:me )?(?:a|some)|heard of|point me)\b", re.I)
    # a real place: "over at Sweetwater" (a NAME - capital letter, case-sensitive) or "at the manor by the pond"
    TELLS_PLACE = re.compile(r"\b(?:[Aa]t|[Ii]n|[Oo]ver at|[Oo]ut by|[Oo]ut past|[Nn]ear|[Bb]ehind|[Bb]y the|[Dd]own by|[Uu]p at|"
                             r"[Aa]cross)\s+(?:the\s+)?(?:[A-Z][a-z]+|(?i:manor|mansion|farm|ranch|saloon|hotel|mill|pond|"
                             r"creek|river|church|station|brothel|camp)\b)")
    # 'where is the bed?' - something right HERE: never a line on the map
    LOCAL_THING = re.compile(r"\b(bed|beds|bedroom|chair|bench|table|stove|fireplace|couch|sofa|stool|cot|mattress|door|"
                             r"window|room|corner|kitchen|upstairs|downstairs|cellar|basement|porch|in here|this house|"
                             r"the house|inside)\b", re.I)
    PEOPLE_WORDS = re.compile(r"\b(who|someone|somebody|people|folks|man|woman|girl|fella|couple|family|husband|wife|"
                              r"brother|sister|son|daughter|friend|gang|doctor|sheriff|whores?|working girls?)\b", re.I)

    FAMILY_FACT_RE = re.compile(r"[^.!?]*\b(?:my|our)\s+(?:late\s+)?(husband|wife|man|missus|son|daughter|boy|girl|"
                                r"brother|sister|pa|ma|father|mother|children|kids|family)\b[^.!?]*[.!?]?", re.I)

    def note_told_facts(self, conv, say: str):
        """0.5.8: what someone tells you about their own family is remembered and fed back to them, so the next story
        doesn't contradict the last one (a husband nearby, then a husband 'killed years back')."""
        try:
            told = conv.ident.d.setdefault("told_facts", [])
            for m in self.FAMILY_FACT_RE.finditer(say or ""):
                t = m.group(0).strip()
                if 12 <= len(t) <= 160 and t not in told:
                    told.append(t)
                if conv.ident.persona.get("family", "").startswith("widowed") and re.search(
                        r"\b(husband|wife|man|missus)\b", t, re.I) and re.search(
                        r"\b(died|killed|passed|shot|hanged|drowned|fever|lost)\b", t, re.I) and not conv.ident.d.get("late_spouse"):
                    conv.ident.d["late_spouse"] = "(" + t[:100] + ")"
            conv.ident.d["told_facts"] = told[-12:]
            conv.ident.dirty()
        except Exception:
            pass

    TRIP_ACTIONS = ("lead_to", "mark_person", "mark_stash", "invite_home")
    TRIP_ASK = re.compile(r"\b(instead|somewhere else|another place|change (?:of )?plans?|forget (?:it|that|about)|not there|"
                          r"cancel|different place)\b", re.I)

    def trip_on(self):
        """-> (who leads, where) of a trip that's already under way, or None."""
        j = self.journeys.active
        if j and j.state in ("route", "probing", "spawning"):
            return j.guide_ident.persona.get("first_name", "someone"), (getattr(j, "where", "") or j.target)
        for t in self.couples.trips:
            if t.get("state") not in ("done", "failed", "arrived"):
                c = t.get("conv")
                return (c.ident.persona.get("first_name", "someone") if c else "someone"), t["place"].get("kind", "a house")
        return None

    def trip_guard(self, conv, utterance, approved):
        """0.5.8: there was already a place to go - and the woman begging for her life said 'I know a place' and the
        yellow line moved. A trip that's on stays on: nobody replaces it with a new place unless HE asks for a change
        (then the old one is called off first)."""
        on = self.trip_on()
        if not on or not any(a["name"] in self.TRIP_ACTIONS for a in approved):
            return approved
        if utterance and self.TRIP_ASK.search(utterance) and self.journeys.active and self.journeys.active.guide == conv.ped:
            self.journeys.cancel(self.journeys.active, "he asked for somewhere else")
            return approved
        dropped = [a["name"] for a in approved if a["name"] in self.TRIP_ACTIONS]
        log.info("[ACT] %s: %s dropped - a trip is already on (%s -> %s)", conv.name, dropped, on[0], on[1])
        conv.last_results.append(f"you're all already on the way to {on[1]} ({on[0]} leads) - there's no new place to "
                                 "go; don't promise one (you can say you know somewhere, but nothing changes)")
        return [a for a in approved if a["name"] not in self.TRIP_ACTIONS]

    def local_guard(self, conv, utterance, approved):
        """'Where is the bed?' / 'is there a bed in this house?' is about THIS place: no yellow line to a family 600 m
        away (Ophelia, 00:12) - the person shows or uses the thing right here instead."""
        if not utterance or not self.LOCAL_THING.search(utterance) or self.PEOPLE_WORDS.search(utterance):
            return approved
        dropped = [a for a in approved if a["name"] in ("mark_person", "mark_stash", "lead_to")]
        if not dropped:
            return approved
        log.info("[ACT] %s: %s dropped - he asked about something right here (%r)", conv.name,
                 [a["name"] for a in dropped], self.LOCAL_THING.search(utterance).group(0))
        conv.last_results.append("he asked about something right here in this place - you point at it or go to it; "
                                 "no map needed")
        return [a for a in approved if a not in dropped]
    COUPLE_WORDS = re.compile(r"\b(couple|swap\w*|swinger\w*|cuckold\w*|husband and (?:his )?wife|threesome|open marriage)\b", re.I)

    def implied_mark(self, conv, utterance, reply, approved, ped, player):
        """0.5.5: Fred told you 'the wife-swappers are over at Sweetwater, at the manor by the pond' - and no line on your
        map. If you ask where to find someone and they TELL you a place, it's marked (they REALLY are there)."""
        say = str(reply.get("say") or "")
        if not utterance or not self.ASK_WHERE.search(utterance) or not self.TELLS_PLACE.search(say):
            return approved
        if self.LOCAL_THING.search(utterance) and not self.PEOPLE_WORDS.search(utterance):
            return approved
        if any(a["name"] in ("mark_person", "mark_stash", "lead_to", "refuse", "flee", "attack") for a in approved):
            return approved
        if self.REFUSE_RE.search(say) and not re.search(r"\b(over at|out by|at the)\b", say, re.I):
            return approved
        if self.journeys.active and self.journeys.active.state not in ("done", "failed", "arrived"):
            return approved
        kind = "couple" if (self.COUPLE_WORDS.search(utterance) or self.COUPLE_WORDS.search(say)) else "person"
        who = "the couple he told you about" if kind == "couple" else "the people he told you about"
        extra, notes = acts.plan([{"name": "mark_person", "args": {"kind": kind, "who": who, "story": say[:200],
                                                                   "where": say[:160]},
                                   "when": "after"}], conv, ped, player)
        if extra:
            log.info("[ACT] %s told him where to find them - marked on his map (%s)", conv.name, kind)
        return approved + extra

    CALL_RE = re.compile(r"\b([A-Z][a-z]+)\s*[,!]?\s*(?:come|get|step)\s+(?:on\s+)?(?:over\s+)?(?:here|over)\b")

    ORDER_RE = re.compile(r"\b([A-Z][a-z]+)\s*[,!]\s*(run|get out|hide|go inside|get inside|get back|stay|don'?t move|"
                          r"put your hands up|hands up|follow me|go home)\b", re.I)
    ORDER_DO = {"run": "run", "get out": "run", "hide": "hide", "go inside": "hide", "get inside": "hide", "get back": "run",
                "stay": "stay", "don't move": "stay", "dont move": "stay", "put your hands up": "hands_up",
                "hands up": "hands_up", "follow me": "follow_me", "go home": "go_home"}

    def implied_call(self, conv, reply, approved, ped, player):
        """0.5.5: what one person tells another happens: 'Clara, come here!' / 'Clara, run!' / 'Clara, hands up!'"""
        if any(a["name"] in ("call_over", "order_person") for a in approved):
            return approved
        say = str(reply.get("say") or "")
        for name, what in self.ORDER_RE.findall(say):
            do = self.ORDER_DO.get(what.lower().replace("’", "'"), "")
            extra, notes = acts.plan([{"name": "order_person", "args": {"who": name, "do": do}}], conv, ped, player)
            if extra:
                log.info("[ACT] %s tells %s: %s", conv.name, name, do)
                return approved + extra
        """0.5.5: Henry said 'Clara, come on over here' and Clara never moved. Calling someone by name brings them."""
        if any(a["name"] == "call_over" for a in approved):
            return approved
        for name in self.CALL_RE.findall(say):
            extra, notes = acts.plan([{"name": "call_over", "args": {"who": name}}], conv, ped, player)
            if extra:
                log.info("[ACT] %s calls %s over", conv.name, name)
                return approved + extra
        return approved

    def same_household(self, a, b) -> bool:
        """0.5.5: people who belong together (a couple, a family, a trip's people) stay in the conversation together -
        talking to Clara no longer sends Henry away."""
        from .drama import KIN
        try:
            ra = (a.ident.d.get("relations") or {}) if a.ident else {}
            rb = (b.ident.d.get("relations") or {}) if b.ident else {}
            if str((ra.get(f"id:{b.ident.id}") or {}).get("rel", "")) in KIN or \
                    str((rb.get(f"id:{a.ident.id}") or {}).get("rel", "")) in KIN:
                return True
            if (ra.get("guide") or {}).get("name") == b.ident.persona.get("name") and str(ra["guide"].get("rel", "")) in KIN:
                return True
            if (rb.get("guide") or {}).get("name") == a.ident.persona.get("name") and str(rb["guide"].get("rel", "")) in KIN:
                return True
            fa, fb = a.ident.d.get("flags", {}), b.ident.d.get("flags", {})
            if fa.get("open_couple") and fa.get("open_couple") == fb.get("open_couple"):
                return True
        except Exception:
            return False
        return False

    def pain_reaction(self, conv: Conversation, cur: dict, pl: dict):
        """0.5.1: no waiting for the AI when you're cut or shot: a scream from the game's own pain voice right now, and
        the body does what a person does (runs, curls up, or - a brave armed man - fights back). The AI's words follow."""
        if conv.seconds_since("pain_reacted") < 2.5:
            return
        conv.mark("pain_reacted")
        p = conv.ident.persona
        self.asi.prim(conv.ped, "pain", ("pain", 1))
        if cur.get("melee") and not pl.get("armed"):
            return                      # a fist fight: they keep swinging
        if cur.get("hog") or cur.get("lasso"):
            return
        brave = float(p.get("bravery", 0.4))
        if p.get("child") or brave < 0.45 or (cur.get("hpmax") and cur.get("hp", 0) < 0.35 * cur["hpmax"]):
            prims = [("block", 0), ("look_clear",), ("keep", 0), ("persist", 0), ("flee", 150)]
            conv.flags.update({"following": False, "staying": False, "hands_up": False, "fleeing": True})
        elif brave >= 0.7 and cur.get("hasw"):
            prims = [("block", 0), ("draw",), ("combat",)]
            conv.flags["hostile"] = True
        else:
            prims = [("clear",), ("cower", 20000)]
            conv.flags["cowering"] = True
        for pr in prims:
            self.asi.prim(conv.ped, "pain", pr)
        log.info("[PAIN] %s: hurt by the player -> %s", conv.name, prims[-1][0])

    def player_view(self) -> dict:
        pl = dict(self.game.player)
        pl["in_vehicle"] = pl.get("veh")
        pl["last_mount_dist"] = pl.get("lm_d", 999)
        pl["last_vehicle_dist"] = pl.get("lv_d", 999)
        pl["cash_cents"] = pl.get("cash", 0)
        return pl

    def after_tick(self):
        pl = self.game.player
        self.update_freeze()
        sp = self.speaking
        if sp:
            ped = self.game.ped(sp["ped"])
            if ped:
                self.voice.spatialize(pl, ped)
        for conv in list(self.convs.values()):
            if conv.ended:
                continue
            cur = self.game.ped(conv.ped)
            if not cur:
                continue
            # normalise field names for actions/safety
            cur.update({"hogtied": cur.get("hog"), "being_hogtied": cur.get("bhog"), "lassoed": cur.get("lasso"),
                        "ragdoll": cur.get("rag"), "mounted": cur.get("mnt"), "in_vehicle": cur.get("veh"),
                        "has_weapon": cur.get("hasw"), "aimed_at": cur.get("aimed")})
            self.watch_body(conv, cur)
            if cur.get("lt") and not (conv.prev_ped or {}).get("lt"):      # 0.5.7: he's going through their pockets
                self.witness.on_looted(conv, cur)
            self.witness.violation_tick(conv, cur)
            aboard = bool(cur.get("pin"))         # 0.4.0: the player is riding on THEIR wagon: the talk goes on
            if aboard != bool(conv.flags.get("player_aboard")):
                conv.flags["player_aboard"] = aboard
                conv.pending_events.append(("aboard" if aboard else "got_off",
                                            "He just climbed onto your wagon - he's riding with you now." if aboard else
                                            "He just got off your wagon.", 2))
            if not conv.prev_ped:
                # first look at the situation: shocking things that are ALREADY true count as events too
                conv.prev_ped = {k: v for k, v in cur.items() if k not in ("aimed", "hog", "lasso")}
                conv.prev_player = {k: v for k, v in pl.items() if k not in ("c", "cdead", "chog", "hb", "hbdead")}
            evs = diff_events(conv.prev_ped, cur, conv.prev_player, pl)
            conv.prev_ped, conv.prev_player = dict(cur), dict(pl)
            for key, desc, imp in evs:
                conv.mark(key)
                if key in ("aimed", "hurt_by_player", "shots"):
                    conv.mark("threatened")
                if key in MEMORY_EVENTS:
                    what, w = MEMORY_EVENTS[key]
                    conv.ident.add_event(f"he {what}", self.game.game_minutes_total, self.game.place(), w)
                if key == "hit_player":
                    conv.ident.add_event("you punched him in a fist fight", self.game.game_minutes_total, self.game.place(), 1)
                elif key == "fist_fight":
                    conv.mark("threatened")
                    conv.ident.adjust({"anger": 8, "trust": -6}, "fist fight")
                if key == "hurt_by_player":
                    conv.ident.adjust({"fear": 12, "anger": 10, "trust": -12}, "hurt")
                    self.pain_reaction(conv, cur, pl)
                elif key == "aimed":
                    conv.ident.adjust({"fear": 8, "trust": -6}, "aimed at")
                elif key in ("carrying_body", "dropped_body", "body_on_horse", "carrying_captive"):
                    conv.mark("threatened")
                    conv.ident.adjust({"fear": 10, "trust": -6}, key)
                    conv.ident.add_event("he " + {"carrying_body": "showed up carrying a dead body",
                                                  "dropped_body": "dumped a body at your feet",
                                                  "body_on_horse": "had a corpse slung over his horse",
                                                  "carrying_captive": "carried a tied-up captive"}[key],
                                         self.game.game_minutes_total, self.game.place(), 2)
                elif key == "hogtied":
                    world.add_deed(self.memory, self.game.place(), self.game.zone()["state"],
                                   f"THE_STRANGER hogtied {conv.name}", 2, self.game.game_minutes_total,
                                   self.game.near.get("people", 0))
                elif key == "freed":
                    conv.ident.adjust({"trust": 8, "fear": -5}, "freed")
                    conv.flags["captive"] = False
                conv.pending_events.append((key, desc, imp))
                log.info("[EVENT] %s: %s (imp %d)", conv.name, key, imp)
            if evs and self.cfg.reactions:
                self.maybe_react(conv)

    # ── game freeze / pause / weapon wheel ─────────────────────
    def freeze_reason(self) -> str:
        if not self.asi.up:
            return ""
        w = self.game.world
        if self.alive_seen and time.time() - self.frame_t > 0.9:
            return "game frozen (paused / alt-tab / loading)"
        if w.get("pause"):
            return "pause menu"
        if w.get("wheel"):
            return "weapon wheel"
        return ""

    def update_freeze(self):
        why = self.freeze_reason()
        if why and not self.frozen:
            self.frozen, self.frozen_why, self.frozen_since = True, why, time.time()
            self.voice.set_paused(True)
            log.info("[PAUSE] %s - voice, scenes, reactions and timers on hold", why)
        elif not why and self.frozen:
            dur = time.time() - self.frozen_since
            self.frozen, self.thawed_at = False, time.time()
            self.voice.set_paused(False)
            self.shift_timers(dur)
            log.info("[PAUSE] resumed after %.1fs (%s)", dur, self.frozen_why)
        elif why and why != self.frozen_why:
            self.frozen_why = why

    def shift_timers(self, dur: float):
        """Time spent frozen doesn't count: a line resumes where it stopped, nobody 'walked away' or 'was ignored'."""
        sp = self.speaking
        if sp:
            sp["start"] += dur
            sp["until"] += dur
        for conv in self.convs.values():
            conv.last_activity += dur
            conv.last_reaction += dur
            if conv.far_since:
                conv.far_since += dur
            conv.missing_since = 0
            for k in conv.marks:
                conv.marks[k] += dur
        self.last_ptt_up += dur if self.last_ptt_up else 0

    async def wait_unfrozen(self, limit: float = 3600):
        t0 = time.time()
        while self.frozen and time.time() - t0 < limit:
            await asyncio.sleep(0.1)

    def maybe_react(self, conv: Conversation):
        if self.frozen or conv.ended:
            return
        if conv.busy or conv.listening or self.ptt_ped or (self.speaking and self.speaking.get("ped") == conv.ped):
            return
        if time.time() - self.last_ptt_up < 1.5:     # the player just finished talking: their turn comes first
            return
        top = max((e[2] for e in conv.pending_events), default=0)
        if time.time() - conv.last_reaction < (2.5 if top >= 3 else self.cfg.reaction_cooldown):
            return
        if top >= 2 or (top == 1 and random.random() < 0.3):
            if top >= 3 and time.time() - conv.last_reaction < 2.5:
                return
            conv.last_reaction = time.time()
            log.info("[REACT] %s reacts to %s", conv.name, [e[0] for e in conv.pending_events])
            asyncio.create_task(self.run_turn(conv, reaction=True))

    async def housekeeping(self):
        n = 0
        while True:
            await asyncio.sleep(0.2)
            n += 1
            try:
                self.update_freeze()
                if self.frozen:
                    continue
                self.check_speech_end()
                self.check_conversations()
                if n % 5 == 0:
                    await self.director.tick()
                    await self.journeys.tick()
                    await self.couples.tick()
                    await self.households.tick()
                    await self.drama.tick()
            except Exception:
                log.error("housekeeping crashed:\n%s", traceback.format_exc())

    def check_speech_end(self):
        sp = self.speaking
        if not sp:
            return
        if time.time() >= sp["until"] + 0.15 or (self.voice.ok and not self.voice.busy() and time.time() > sp["start"] + 0.6
                                                 and not self.cfg.fake_ai and time.time() >= sp["until"] - 0.2):
            conv = sp["conv"]
            self.speaking = {}
            if conv:
                self.asi.send("state", conv.ped, "idle")
                self.run_after_actions(conv)
                conv.touch()

    def check_conversations(self):
        now = time.time()
        for conv in list(self.convs.values()):
            if conv.ended:
                continue
            if self.speaking and self.speaking.get("ped") == conv.ped:
                continue
            ped = self.game.ped(conv.ped)
            stale = not ped or now - ped.get("_t", 0) > 4
            if now - self.thawed_at < 5:
                stale = False
            if stale and self.asi.up and conv.engaged_ok:
                conv.missing_since = conv.missing_since or now
                if now - conv.missing_since > 8:
                    self.end(conv, "lost track of them")
                continue
            conv.missing_since = 0
            if not ped:
                continue
            # something important happened while they were busy talking/listening: react now
            if self.cfg.reactions and conv.pending_events and conv.engaged_ok and \
                    max(e[2] for e in conv.pending_events) >= 2:
                # 0.4.0: a companion in the background only speaks up about things that happen TO THEM (a gun on them,
                # being hurt) - not every time you threaten someone else (Louis kept begging while you talked to Lula)
                if conv.ped == self.active or any(e[0] in PERSONAL_EVENTS for e in conv.pending_events):
                    self.maybe_react(conv)
            if not ped.get("alive", 1):
                self.end(conv, "they died")
                continue
            if self.game.world.get("mission"):
                self.end(conv, "a mission started")
                continue
            if conv.ending and not conv.busy and not conv.after_actions:
                self.end(conv, "they ended it")
                continue
            d = ped.get("d", 0)
            if conv.companion:
                if d > 150:
                    self.end(conv, "they lost you", release_tasks=True)
                continue
            if conv.flags.get("hands_up") or ped.get("hog"):
                far_limit = self.cfg.end_far_m * 2
            else:
                far_limit = self.cfg.end_far_m
            if d > far_limit:
                conv.far_since = conv.far_since or now
                if now - conv.far_since > self.cfg.end_far_s:
                    self.end(conv, "you walked away")
                    continue
            else:
                conv.far_since = 0
            if not conv.busy and not conv.listening and now - conv.last_activity > self.cfg.end_idle_s:
                self.end(conv, "you ignored them")

    def end(self, conv: Conversation, reason: str, release_tasks=False):
        if conv.ended:
            return
        conv.ended = True
        conv.engaged_ok = False
        conv.gen += 1                         # anything still being thought up is dropped
        conv.pending_events = []
        log.info("[END] conversation with %s ended: %s (turns=%d, flags=%s)", conv.name, reason, conv.turns, conv.flags)
        keep = conv.companion and not release_tasks
        # 0.4.0: someone you scared (hands up, cowering, begging, your captive) doesn't stand there for two minutes once
        # you turn away - they run. (0.3.x: a man kept begging on a busy road after you'd moved on.)
        scared = (conv.flags.get("hands_up") or conv.flags.get("cowering") or conv.flags.get("surrendered") or
                  (conv.flags.get("captive") and not keep))
        if scared and not keep and not self.dead(conv.ped) and reason not in ("they died", "they are gone") \
                and not self.game.ped(conv.ped).get("hog"):
            log.info("[END] %s was scared of you - runs off now", conv.name)
            for p in (("block", 0), ("look_clear",), ("keep", 0), ("persist", 0), ("clear",), ("flee", 120)):
                self.asi.prim(conv.ped, "scared_off", p)
            conv.ident.add_event("you ran off the moment he turned away", self.game.game_minutes_total, self.game.place(), 1)
        if not keep and reason in ("they died", "they are gone"):
            self.stop_activity(conv.ped)
        self.asi.send("release", conv.ped, 1 if keep else 0, reason)
        if self.active == conv.ped:
            self.active = 0
        ident = conv.ident
        ident.d["last_seen"] = time.time()
        ident.d["last_game_min"] = self.game.game_minutes_total
        ident.d["last_zone"] = self.game.place()
        ident.dirty()
        self.memory.save_player()
        if conv.turns:
            asyncio.create_task(self.summarize(conv, reason))
        if not keep:
            self.convs.pop(conv.ped, None)

    async def summarize(self, conv: Conversation, reason: str):
        lines = "\n".join(conv.transcript[-30:])
        if self.cfg.fake_ai or not lines:
            summary = (lines[-300:] or "a short meeting") + f" (ended: {reason})"
        else:
            msgs = [{"role": "system", "content": "Summarise encounters for a character's memory. 1-2 sentences, "
                                                  "from the character's own point of view in the FIRST person ('I ...', the stranger = 'he'), concrete facts only."},
                    {"role": "user", "content": f"I am {conv.name}. The encounter ended because: {reason}.\n{lines}"}]
            raw, _, _ = await asyncio.to_thread(self.ai.chat, msgs, False, 120, 0.4)
            summary = raw.strip()
            if summary.startswith("{"):
                try:
                    summary = str(next(iter(json.loads(summary).values())))
                except Exception:
                    pass
        conv.ident.add_summary(summary, self.game.game_minutes_total, self.game.place())
        log.info("[MEM] summary for %s: %s", conv.name, summary)

    # ── recognition (nemesis) ────────────────────────────────
    def update_near(self, m: dict):
        """Who/what is around: people, lawmen, dead bodies (and whether we know who they were)."""
        peds = m.get("peds") or []
        engaged = {c.ped for c in self.convs.values() if not c.ended}
        alive = [p for p in peds if p.get("alive", 1) and int(p.get("h", 0)) not in engaged]
        carried = {int(self.game.player.get("ch", 0)), int(self.game.player.get("hbh", 0))} - {0}
        dead = [p for p in peds if not p.get("alive", 1) and p.get("d", 99) <= 25 and int(p.get("h", 0)) not in carried]
        law = sum(1 for p in alive if self.peddb.classify(int(p.get("m", 0)), None)["role"] == "lawman" and p.get("d", 99) < 30)
        known = []
        for p in dead:
            ident = self.memory.find(int(p.get("m", 0)), int(p.get("o", 0)), self.game.place(), set(), include_dead=True)
            if ident:
                known.append(f"{ident.persona['name']} the {ident.persona['job']}")
        self.game.near = {"people": sum(1 for p in alive if p.get("d", 99) < 25), "law": law, "dead": len(dead),
                          "dead_closest": min((p.get("d", 99) for p in dead), default=0), "dead_known": known}
        # 0.5.1: people you're talking to stay visible to EACH OTHER (0.5.0 hid every engaged/companion ped from
        # everyone else's list: Tommy couldn't see his own mother standing next to him)
        self.game.near_peds = [p for p in peds if int(p.get("h", 0)) not in carried]
        try:
            self.witness.on_nearby(peds)      # 0.5.7: looted / stripped while you weren't talking to them
        except Exception:
            log.error("[WITNESS] on_nearby crashed:\n%s", traceback.format_exc())
        new_dead = [p for p in dead if int(p.get("h", 0)) not in self._dead_seen]
        first_scan = not self._dead_seen and not hasattr(self, "_near_init")
        self._near_init = True
        for p in dead:
            self._dead_seen.add(int(p.get("h", 0)))
        if new_dead and not first_scan:
            for nd in new_dead:
                h = int(nd.get("h", 0))
                if nd.get("kp") and h not in self.director.kills:
                    cls = self.peddb.classify(int(nd.get("m", 0)), bool(nd.get("male")))
                    desc = f"a {'man' if nd.get('male') else 'woman'}" + (f" ({cls['role']})" if cls["role"] else "")
                    wit = sum(1 for q in peds if q.get("alive", 1) and q.get("d", 99) < 30)
                    seen = [int(q.get("h", 0)) for q in peds if q.get("alive", 1) and q.get("d", 99) < 30 and q.get("los")]
                    self.director.note_kill(h, desc, wit, seen)
                    world.add_deed(self.memory, self.game.place(), self.game.zone()["state"],
                                   f"THE_STRANGER shot {desc} dead", 3, self.game.game_minutes_total, wit)
            from .surroundings import relation
            for conv in self.convs.values():
                if conv.ended or not conv.engaged_ok:
                    continue
                for nd in new_dead[:3]:
                    cls = self.peddb.classify(int(nd.get("m", 0)), bool(nd.get("male")))
                    r = relation(conv, nd, cls, self.game.place(), self.memory)
                    who = f"{r['rel']} {r['name']}".strip() if r["name"] else r["rel"]
                    saw = nd.get("elos", nd.get("los", 0))
                    if nd.get("kp") and int(nd.get("h", 0)) not in self.director.kills:
                        wit = sum(1 for q in peds if q.get("alive", 1) and q.get("d", 99) < 30)
                        seen = [int(q.get("h", 0)) for q in peds if q.get("alive", 1) and q.get("d", 99) < 30 and q.get("los")]
                        self.director.note_kill(int(nd.get("h", 0)), who, wit, seen + ([conv.ped] if saw else []))
                        world.add_deed(self.memory, self.game.place(), self.game.zone()["state"],
                                       f"THE_STRANGER shot {who.replace('your ', 'a ').replace('you ', '')} dead",
                                       3, self.game.game_minutes_total, wit)
                    # 0.5.8: only what they could SEE or HEAR (the husband behind a wall 80 m away didn't watch it)
                    if self.perception.can_ask():
                        asyncio.create_task(self._death_perceived(conv, nd, who, r, bool(nd.get("kp"))))
                    else:
                        self._death_apply(conv, nd, who, r, bool(nd.get("kp")),
                                          self.perception.death_guess(conv.ped, int(nd.get("h", 0)), nd))

    async def _death_perceived(self, conv, nd, who, r, by_player: bool):
        """0.5.8: someone died near a person you're talking to. They react to what they perceived: saw it (they know
        who and who did it), heard a shot / a scream (they don't know who was hit), or nothing at all."""
        try:
            pr = await self.perception.death(conv.ped, int(nd.get("h", 0)), nd)
            self._death_apply(conv, nd, who, r, by_player, pr)
        except Exception:
            log.error("[EVENT] death perception crashed:\n%s", traceback.format_exc())

    def _death_apply(self, conv, nd, who, r, by_player: bool, pr: dict):
        try:
            if conv.ended or self.dead(conv.ped):
                return
            g = self.game
            close = r["rel"] not in ("a stranger", "a rough stranger", "a lawman you don't know")
            name = r.get("name") or ""
            if pr["saw"]:
                if by_player:
                    desc = f"The player just KILLED {who} right in front of your eyes!"
                    conv.ident.add_event(f"he killed {who} in front of you", g.game_minutes_total, g.place(), 3)
                    conv.ident.adjust({"fear": 35, "anger": 25 if close else 6, "trust": -30}, "killing", cap=40)
                else:
                    desc = f"{who} just dropped dead about {pr['d']:.0f} m away - you saw it."
                conv.pending_events.append(("new_body", desc, 3))
                conv.mark("threatened")
            elif pr["heard"] == "shot":
                worry = (f" It came from where {who} was - you're scared for {name or 'them'}, but you did NOT see it"
                         if close and pr["d"] < 60 else "")
                desc = (f"A GUNSHOT just rang out, about {pr['d']:.0f} m away.{worry} You don't know who fired or who was "
                        "hit - never say anyone is dead or name a victim. React to the shot as it is.")
                conv.ident.add_event("you heard a gunshot close by", g.game_minutes_total, g.place(), 1)
                conv.ident.adjust({"fear": 12}, "gunshot", cap=20)
                conv.pending_events.append(("heard_shot", desc, 2))
                conv.mark("threatened")
            elif pr["heard"] == "scream":
                conv.pending_events.append(("heard_scream", f"You heard a scream somewhere close, about {pr['d']:.0f} m away. "
                                                             "You didn't see what happened.", 1))
            else:
                log.info("[EVENT] %s didn't see or hear %s die (%.0f m) - knows nothing yet", conv.name, who, pr["d"])
                return
            log.info("[EVENT] %s: %s", conv.name, conv.pending_events[-1][1])
            if self.cfg.reactions:
                self.maybe_react(conv)
        except Exception:
            log.error("[EVENT] death perception crashed:\n%s", traceback.format_exc())

    def on_nearby(self, m: dict):
        self.update_near(m)
        if not self.cfg.recognition or not self.asi.up or self.ptt_ped or self.speaking:
            return
        if time.time() - self.last_recognition < 60:
            return
        if any(not c.ended and not c.companion for c in self.convs.values()):
            return
        for p in m.get("peds") or []:
            ped = int(p.get("h", 0))
            if not ped or ped in self.convs or not p.get("alive", 1) or not p.get("los"):
                continue
            if p.get("d", 99) > self.cfg.recognition_radius:
                continue
            ident = self.memory.find(int(p.get("m", 0)), int(p.get("o", 0)), self.game.place(), set())
            if not ident:
                continue
            s, nem = ident.stats, ident.d["nemesis"]
            strong = nem["grudge"] >= 45 or s["trust"] >= 65 or s["attraction"] >= 65 or s["fear"] >= 60
            if not strong or time.time() - self.recog_cooldown.get(ident.id, 0) < 600:
                continue
            if random.random() > self.cfg.recognition_chance:
                self.recog_cooldown[ident.id] = time.time()
                continue
            self.recog_cooldown[ident.id] = time.time()
            self.last_recognition = time.time()
            log.info("[RECOGNISE] %s (%s, grudge %d, trust %d) spotted the player at %.0fm", ident.persona["name"],
                     nem["rank"], nem["grudge"], s["trust"], p.get("d", 0))
            self.asi.send("engage", ped)
            conv = self.on_engage_req({"ped": ped, "model": p.get("m"), "outfit": p.get("o"), "male": p.get("male"),
                                       "alive": 1, "human": 1}, forced_ident=ident, reason="recognition")
            if conv:
                conv.pending_events.append(("spotted", "You just spotted HIM – the man you remember. React to seeing him again.", 3))
                asyncio.create_task(self.run_turn(conv, reaction=True))
            return

    # ── misc events ──────────────────────────────────────────
    def on_event(self, m: dict):
        kind, ped = m.get("kind"), int(m.get("ped", 0))
        log.info("[ASI EVENT] %s", m)
        conv = self.convs.get(ped)
        if kind == "ped_dead":
            self._dead_seen.add(ped)
            self.game.peds.setdefault(ped, {})["alive"] = 0          # don't trust a stale 'alive' from before
            self.game.peds[ped]["_t"] = time.time()
        if kind in ("ped_dead", "ped_gone"):
            self.journeys.guide_lost(ped, kind)
        if kind == "ped_dead" and self.speaking.get("ped") == ped:
            self.voice.stop()
            self.speaking = {}
            log.info("[VOICE] cut off - they died mid-sentence")
        if kind == "ped_dead" and conv:
            self.drama.on_kin_killed(conv, conv.seconds_since("hurt_by_player") < 15 or bool(self.game.player.get("shoot"))
                                     or conv.seconds_since("pain_reacted") < 15)
            conv.gen += 1                      # nothing they were about to say will be said
            conv.ident.d["dead"] = True
            conv.ident.d["died_game_min"] = self.game.game_minutes_total
            conv.ident.dirty()
            log.info("[MEM] %s is dead – will not be 'recognised' alive again", conv.name)
        if kind == "ped_gone":
            self.handle_ident.pop(ped, None)
        if kind in ("ped_gone", "ped_dead") and conv:
            self.end(conv, "they died" if kind == "ped_dead" else "they are gone", release_tasks=True)
        elif kind == "released" and conv and not conv.ended:
            conv.engaged_ok = False
            self.end(conv, m.get("why", "released by game"))
        elif kind == "engage_fail" and conv:
            self.end(conv, "could not engage")
        elif kind == "danger" and conv:
            conv.mark("threatened")
        elif kind == "couple_over":
            sc = self.couples.scene_of(ped)
            if sc:
                self.couples.scenes.pop(sc.id, None)
        elif kind == "veh_arrived" and conv:
            conv.pending_events.append(("arrived", "You've got there - the place he wanted. The wagon is stopped.", 2))
            if self.cfg.reactions:
                self.maybe_react(conv)
        elif kind == "order_failed" and conv:
            conv.last_results.append(f"the game would not let you: {m.get('why', '')}")
            if "horse" in str(m.get("why", "")) or "wagon" in str(m.get("why", "")):
                conv.flags["riding"] = False

    def on_act_result(self, m: dict):
        seq = int(m.get("seq", 0))
        info = self.asi.pending.pop(seq, None)
        ok = bool(m.get("ok"))
        why = m.get("why", "")
        if not info:
            return
        ped, action, prim = info
        conv = self.convs.get(ped)
        log.log(20 if ok else 30, "[ACT RESULT] %s/%s on %d: %s %s", action, prim, ped, "OK" if ok else "FAILED", why)
        self.couples.on_act_result(action, prim, ok, ped)
        if action == "make_love" and prim == "hookup" and not ok and conv and "NpcHookups" in str(why):
            # 0.5.1: no NpcHookups (or another build): NpcVoice plays the scene itself
            log.info("[LOVE] NpcHookups not available (%s) - NpcVoice runs the scene itself", why)
            other = conv.flags.get("hookup_with")
            self.couples.make_love(conv, other if isinstance(other, int) else 0)
            return
        if conv and not ok and action != "talk_gesture":
            conv.last_results.append(f"{action} failed in the game: {why}")
            if prim in ("mount_near", "ride_with_player", "lead_horse"):
                conv.flags["following"] = conv.flags.get("following") and prim != "ride_with_player"
                conv.flags["riding"] = False

    def native_proof(self, game_dir: str):
        """Handoff rule: a native is 'proven' if another installed .asi also contains its hash."""
        try:
            used = json.loads((self.root / "data" / "natives_used.json").read_text())
            gd = Path(game_dir)
            if not game_dir or not gd.exists():
                log.info("[NATIVES] game folder %r not readable from here – skipping proof scan", game_dir)
                return
            blobs = {}
            for f in gd.glob("*.asi"):
                if f.name.lower() != "npcvoice.asi":
                    try:
                        blobs[f.name] = f.read_bytes()
                    except OSError:
                        pass
            lines, unproven = [], []
            for n in used:
                h = int(n["hash"], 16).to_bytes(8, "little")
                users = [k for k, b in blobs.items() if h in b]
                lines.append(f"{'PROVEN ' if users else 'new    '} {n['name']:42s} {n['hash']}  {', '.join(users[:4])}")
                if not users:
                    unproven.append(n["name"])
            out = self.root / "logs" / "native_proof.txt"
            out.write_text(f"{len(used) - len(unproven)}/{len(used)} natives also used by your other mods "
                           f"({len(blobs)} .asi scanned)\n" + "\n".join(lines), encoding="utf-8")
            log.info("[NATIVES] %d/%d proven by your other mods; new (crash-guarded): %s -> %s",
                     len(used) - len(unproven), len(used), ", ".join(unproven) or "none", out)
        except Exception as e:
            log.warning("[NATIVES] proof scan failed: %s", e)

    # ── fake AI for rig tests ────────────────────────────────
    def fake_stt(self, wav):
        return "hello there", []

    def fake_llm(self, text: str, events: list[str], conv) -> str:
        t = text.lower()
        acts_ = []
        if "clothes off" in t:
            say, emo, acts_ = "If you insist... I don't mind.", "happy", ["undress"]
        elif "clothes back on" in t:
            say, emo, acts_ = "Fine, fine.", "calm", ["dress"]
        elif "make love" in t:
            say, emo, acts_ = "Come here then.", "happy", [{"name": "make_love", "args": {"with": "me"}}]
        elif "give me a ride" in t:
            say, emo, acts_ = "Sure, hop on.", "calm", ["give_ride"]
        elif "marker" in t or "waypoint" in t:
            say, emo, acts_ = "Alright, I know the way.", "calm", ["drive_to_marker"]
        elif "turn left" in t:
            say, emo, acts_ = "Left it is.", "calm", [{"name": "turn_wagon", "args": {"dir": "left"}}]
        elif "stop the wagon" in t:
            say, emo, acts_ = "Whoa there.", "calm", ["stop_wagon"]
        elif "punch" in t:
            say, emo, acts_ = "With pleasure.", "angry", [{"name": "attack_person", "args": {"target": "P1", "weapon": "fists"}}]
        elif "look at the body" in t:
            say, emo, acts_ = "Lord... alright, I'll look.", "fearful", [{"name": "inspect_body", "args": {"target": "B1"}}]
        elif "bench" in t:
            say, emo, acts_ = "My feet thank you.", "calm", [{"name": "sit", "args": {"what": "sit on the bench"}}]
        elif "beer" in t or "have a drink" in t:
            say, emo, acts_ = "Don't mind if I do.", "happy", [{"name": "drink", "args": {"what": t}}]
        elif "wife" in t or "family" in t or "your home" in t:
            say, emo, acts_ = "Alright, alright... I'll take you to Martha and the kids. Just don't hurt nobody.", "fearful", \
                [{"name": "lead_to", "args": {"kind": "family", "who": "my wife Martha and the kids"}}]
        elif "brother" in t:
            say, emo, acts_ = "You'd help me find Amos? God bless you, mister.", "happy", \
                [{"name": "lead_to", "args": {"kind": "relative", "who": "my brother Amos"}}]
        elif "pay" in t and (conv.ident.d.get("flags", {}).get("kidnapper") or {}).get("leader"):
            say, emo, acts_ = "Forty dollars... fine. Take him and git.", "angry", \
                [{"name": "take_money", "args": {"amount": 40}}, "release_hostage"]
        elif "report me" in t or "sheriff" in t:
            say, emo, acts_ = "You bet I will! Sheriff!", "angry", \
                [{"name": "report_to_law", "args": {"crime": "robbery", "what": "he robbed me at gunpoint"}}]
        elif "arrest" in t and conv.flags.get("is_law"):
            say, emo, acts_ = "That's it, you're under arrest!", "angry", [{"name": "arrest", "args": {"crime": "robbery"}}]
        elif "treasure" in t or "stash" in t:
            say, emo, acts_ = "Alright... my pa buried a box out yonder. I'll mark it for you.", "calm", \
                [{"name": "mark_stash", "args": {"what": "his pa's buried box", "dollars": 25}}]
        elif "get off" in t or "dismount" in t:
            say, emo, acts_ = "Alright, I'm gettin' down.", "fearful", ["dismount", "nod"]
        elif "ride" in t and "pay" in t:
            say, emo, acts_ = "Here's for your trouble - now let me up.", "calm", ["ride_with_me", {"name": "give_money", "args": {"amount": 2}}]
        elif "don't follow" in t or "fuck off" in t:
            say, emo, acts_ = "Fine! I'm goin', I'm goin'!", "angry", ["stop_following", {"name": "walk_away", "when": "after"}]
        elif "hands up" in t or "surrender" in t:
            say, emo, acts_ = "Please, mister, don't shoot! I got kids at home!", "fearful", ["hands_up", "tremble"]
        elif "you're free" in t or "go home" in t:
            say, emo, acts_ = "Thank you! God bless you!", "happy", [{"name": "flee", "when": "now"}]
        elif "follow" in t:
            say, emo, acts_ = "Alright, alright, I'm coming.", "fearful", ["follow"]
        elif "ride" in t:
            say, emo, acts_ = "Fine, I'll get on.", "calm", ["ride_with_me"]
        elif "smoke" in t:
            say, emo, acts_ = "Don't mind if I do.", "calm", ["smoke"]
        elif "mount" in t:
            say, emo, acts_ = "Gettin' on my horse.", "calm", ["mount"]
        elif "money" in t:
            say, emo, acts_ = "Here, take it!", "fearful", [{"name": "give_money", "args": {"amount": 3}}]
        elif any("dead body" in e.lower() or "body" in e.lower() for e in events):
            say, emo, acts_ = "Lord have mercy, is that a dead man?!", "fearful", ["tremble"]
        elif events:
            say, emo, acts_ = "What in God's name are you doing?!", "surprised", ["look_at"]
        else:
            say, emo = "What do you want, stranger?", "angry"
        return json.dumps({"say": say, "emotion": emo, "actions": acts_, "feelings": {"fear": 3},
                           "remember": "", "end": False})

    # ── console ──────────────────────────────────────────────
    def console(self):
        log.info("console: type 'say <words>' to talk to the NPC you're engaged with, 'status', 'help'")
        while True:
            try:
                line = input()
            except (EOFError, KeyboardInterrupt):
                return
            line = line.strip()
            if not line or not self.loop:
                continue
            cmd, _, rest = line.partition(" ")
            if cmd == "say":
                conv = self.convs.get(self.active)
                if not conv:
                    print("no active conversation – focus someone in game and press X once")
                    continue
                asyncio.run_coroutine_threadsafe(self.run_turn(conv, text=rest), self.loop)
            elif cmd == "status":
                for c in self.convs.values():
                    print(f"  ped {c.ped}: {c.name} flags={c.flags} turns={c.turns} ended={c.ended}")
                print(f"  connected={self.asi.up} active={self.active} speaking={bool(self.speaking)} "
                      f"keys={self.km.summary()}")
            else:
                print("commands: say <words> | status")
