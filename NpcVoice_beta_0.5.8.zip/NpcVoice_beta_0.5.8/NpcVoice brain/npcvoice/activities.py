"""Activities (0.4.0): "sit down and have a drink", "light a cigar", "play us a tune", "go sweep the porch"...

Instead of a handful of hard-coded scenarios, the person can do anything the game has an animation for:
  1. words -> concepts (drink: beer/whiskey/moonshine/flask/coffee..., smoke: cigarette/cigar/pipe, sit, lean, guitar...)
  2. every human scenario in the game (data/scenarios.json) is scored against those concepts, the person's sex,
     sitting vs standing, whether it needs furniture (a chair, a bar, a table) - and what we LEARNED so far
  3. the best one is started; the plugin checks 3.5 s later whether the person is really doing it
  4. not running -> it's remembered as broken (for that sex), the next candidate is tried (up to 4)
  5. nothing works -> a matching emote (wet your whistle, smoke a cigarette...) - or, for sitting/leaning,
     the nearest REAL bench/chair/railing/fire around (the game's own scenario points)
What works and what doesn't is saved in data/learned_activities.json, so it gets better the more you play.
"""
from __future__ import annotations

import json
import re
import threading
import time
from pathlib import Path

from .log import log

CONCEPTS = {
    "drink": ["DRINK", "DRINKING", "BEER", "WHISKEY", "MOONSHINE", "FLASK", "BOTTLE", "CHAMPAGNE"],
    "beer": ["BEER"], "whiskey": ["WHISKEY", "FLASK", "DRINKING"], "moonshine": ["MOONSHINE"],
    "coffee": ["COFFEE"], "champagne": ["CHAMPAGNE"],
    "smoke": ["SMOKE", "SMOKING", "CIGAR", "CIGARETTE", "PIPE"], "cigar": ["CIGAR"], "pipe": ["PIPE"],
    "sit": ["SIT", "SEAT", "SEATED"], "lean": ["LEAN"], "sleep": ["SLEEP", "ASLEEP", "PASSED_OUT"],
    "guitar": ["GUITAR"], "banjo": ["BANJO"], "fiddle": ["FIDDLE"], "harmonica": ["HARMONICA"], "trumpet": ["TRUMPET"],
    "mandolin": ["MANDOLIN"], "concertina": ["CONCERTINA"], "jaw harp": ["JAW_HARP"],
    "music": ["GUITAR", "BANJO", "FIDDLE", "HARMONICA", "TRUMPET", "MANDOLIN", "CONCERTINA", "JAW_HARP"],
    "eat": ["EAT", "EATING", "STEW", "FOOD", "CANNED"], "cook": ["COOK", "COOKING", "STIR", "CAULDRON", "KETTLE"],
    "read": ["READ", "READING", "BOOK", "NEWSPAPER", "JOURNAL"], "write": ["WRITE", "NOTEBOOK", "SKETCH", "JOURNAL"],
    "sketch": ["SKETCH", "SKETCHING", "SKETCHBOOK"], "whittle": ["WHITTLE"], "knife": ["SHARPEN_KNIFE", "WHITTLE"],
    "pray": ["PRAY", "PRAYER", "MOURNING"], "mourn": ["MOURNING"], "kneel": ["KNEEL"],
    "dance": ["DANCE", "DANCING"], "sweep": ["BROOM", "SWEEP"], "wash": ["WASH", "WASHBOARD", "LAUNDRY", "BUCKET"],
    "fire": ["FIRE"], "warm": ["FIRE"], "wait": ["WAITING", "STAND_WAITING", "IMPATIENT"],
    "guard": ["GUARD", "BADASS", "STERNGUY", "STARE"], "tough": ["BADASS", "STERNGUY"],
    "gun": ["CHECK_PISTOL", "PISTOL", "RIFLE", "GUN"], "clean": ["CLEAN"], "repair": ["REPAIR", "HAMMER", "WRENCH"],
    "hammer": ["HAMMER"], "saw": ["SAW"], "wood": ["SAW", "LUMBER", "AXE", "CHOP"], "chop": ["CHOP", "AXE"],
    "dig": ["DIG", "GRAVEDIG", "SHOVEL"], "fish": ["FISH"], "feed": ["FEED"], "chicken": ["CHICKEN"], "pig": ["PIGS"],
    "horse": ["HORSE_TEND", "BRUSH"], "brush": ["BRUSH"], "vomit": ["VOMIT", "HURL"], "drunk": ["DRUNK"],
    "pee": ["PEE"], "fan": ["FAN"], "mirror": ["MIRROR"], "inspect": ["INSPECT", "CROUCH_INSPECT"],
    "shop": ["SHOP_BROWSE"], "knock": ["KNOCK_DOOR"], "bartend": ["BARTENDER", "BAR_DRINK_BARTENDER"],
    "crouch": ["CROUCH"], "rest": ["SIT_BACK_EXHAUSTED", "REST", "SLEEP"], "think": ["STARE", "STERNGUY"],
}
WORDS = {   # what people say -> concept
    "drink": "drink", "drinking": "drink", "drunk": "drunk", "booze": "drink", "a drink": "drink", "shot": "whiskey",
    "beer": "beer", "ale": "beer", "whiskey": "whiskey", "whisky": "whiskey", "bourbon": "whiskey", "rum": "whiskey",
    "moonshine": "moonshine", "coffee": "coffee", "champagne": "champagne", "flask": "whiskey", "bottle": "drink",
    "smoke": "smoke", "smoking": "smoke", "cigarette": "smoke", "cig": "smoke", "cigar": "cigar", "pipe": "pipe",
    "light up": "smoke", "sit": "sit", "sitting": "sit", "seat": "sit", "bench": "sit", "chair": "sit", "lean": "lean",
    "sleep": "sleep", "nap": "sleep", "lie down": "sleep", "guitar": "guitar", "banjo": "banjo", "fiddle": "fiddle",
    "violin": "fiddle", "harmonica": "harmonica", "trumpet": "trumpet", "mandolin": "mandolin", "concertina": "concertina",
    "play": "music", "music": "music", "tune": "music", "song": "music", "sing": "music", "eat": "eat", "food": "eat",
    "stew": "eat", "cook": "cook", "read": "read", "book": "read", "newspaper": "read", "paper": "read", "write": "write",
    "journal": "write", "draw": "sketch", "sketch": "sketch", "whittle": "whittle", "sharpen": "knife", "pray": "pray",
    "mourn": "mourn", "grieve": "mourn", "kneel": "kneel", "dance": "dance", "sweep": "sweep", "broom": "sweep",
    "wash": "wash", "laundry": "wash", "fire": "fire", "warm up": "warm", "wait": "wait", "guard": "guard",
    "keep watch": "guard", "clean your gun": "gun", "check your gun": "gun", "repair": "repair", "fix": "repair",
    "hammer": "hammer", "saw": "saw", "chop": "chop", "wood": "wood", "dig": "dig", "fish": "fish", "feed": "feed",
    "chickens": "chicken", "pigs": "pig", "brush": "brush", "puke": "vomit", "vomit": "vomit", "throw up": "vomit",
    "piss": "pee", "pee": "pee", "fan": "fan", "mirror": "mirror", "inspect": "inspect", "look at": "inspect",
    "rest": "rest", "crouch": "crouch", "think": "think",
}
FURNITURE = ("PROP_HUMAN_SEAT", "CHAIR", "BENCH", "TABLE", "_BAR_", "COUNTER", "STOOL", "CRATE", "BARREL", "LEDGE",
             "STEPS", "RAILING", "WALL", "POST", "FENCE", "_DESK", "PIANO", "BED", "TUB", "_SINK")
EXCLUDE = re.compile(r"^(WORLD_ANIMAL|PROP_ANIMAL|WORLD_PLAYER|PROP_PLAYER|MP_|RANSACK|SCRIPT_|CNV_|CC_|PLAYER_|SC_|"
                     r"DUAL_|PROP_VEHICLE)|_JACK_|_HORSE_|_DOG_|PICKUP|PUTDOWN|PUT_DOWN|_NO_[A-Z]+$|_WIP$|VIRGIL|NAZAR|"
                     r"SAL1|TRAIN_PLANS|_CA$|INTERACTION|DYNAMIC|_LINK$")
EMOTE_FALLBACK = {   # (category, emote) the KIT emote system plays on anyone
    "drink": (1, "KIT_EMOTE_ACTION_WET_YOUR_WHISTLE_1"), "beer": (1, "KIT_EMOTE_ACTION_WET_YOUR_WHISTLE_1"),
    "whiskey": (1, "KIT_EMOTE_ACTION_WET_YOUR_WHISTLE_1"), "moonshine": (1, "KIT_EMOTE_ACTION_WET_YOUR_WHISTLE_1"),
    "smoke": (1, "KIT_EMOTE_ACTION_SMOKE_CIGARETTE_1"), "cigar": (1, "KIT_EMOTE_ACTION_SMOKE_CIGAR_1"),
    "pray": (1, "KIT_EMOTE_ACTION_PRAYER_1"), "dance": (5, "KIT_EMOTE_DANCE_CAREFREE_A_1"),
    "music": (1, "KIT_EMOTE_ACTION_AIR_BANJO_1"), "write": (1, "KIT_EMOTE_ACTION_TAKE_NOTES_1"),
    "vomit": (0, "KIT_EMOTE_REACTION_HURL_1"), "think": (1, "KIT_EMOTE_ACTION_IDEA_1"),
}
SIT_WORDS = ("SIT", "SEAT", "SEATED", "SLEEP", "PASSED_OUT", "SLUMPED")
ALT = {   # a weaker match: a beer scenario is best, any drinking one will do
    "beer": ["DRINK", "DRINKING"], "whiskey": ["DRINK", "DRINKING"], "moonshine": ["DRINK", "DRINKING"],
    "champagne": ["DRINK"], "coffee": ["DRINK"], "cigar": ["SMOKE", "SMOKING"], "pipe": ["SMOKE", "SMOKING"],
    "banjo": ["GUITAR", "MANDOLIN"], "mandolin": ["GUITAR", "BANJO"], "fiddle": ["GUITAR"], "rest": ["SIT"],
}
GENERIC = {"drink": ("beer", "whiskey", "moonshine", "champagne", "coffee"), "smoke": ("cigar", "pipe"),
           "music": ("guitar", "banjo", "fiddle", "harmonica", "trumpet", "mandolin", "concertina", "jaw harp")}


EXTRA_KEYS = {"drink": ["DRINK", "DRINKING", "BEER", "WHISKEY", "MOONSHINE", "COFFEE"], "smoke": ["SMOKE", "CIGAR"],
              "music": ["GUITAR", "BANJO", "FIDDLE", "TRUMPET", "HARMONICA"], "read": ["READING", "READ", "NEWSPAPER"],
              "sleep": ["SLEEP", "ASLEEP", "PASSED_OUT"], "drunk": ["DRUNK"], "sketch": ["SKETCHING"], "whittle": ["WHITTLE"]}


def has(name: str, key: str) -> bool:
    return key in name if "_" in key else key in name.split("_")


def concepts_of(text: str) -> list[str]:
    t = " " + re.sub(r"[^a-z ]", " ", text.lower()) + " "
    found = []
    for w in sorted(WORDS, key=len, reverse=True):
        if f" {w} " in t or (len(w) > 4 and w in t):
            c = WORDS[w]
            if c not in found:
                found.append(c)
            t = t.replace(w, " ")
    return found


class Activities:
    def __init__(self, scenarios: list[str], learned_path: Path):
        self.all = [s for s in scenarios if s.startswith(("WORLD_HUMAN_", "PROP_HUMAN_", "WORLD_CAMP_", "PROP_CAMP_"))
                    and not EXCLUDE.search(s)]
        self.path = learned_path
        self.lock = threading.Lock()
        try:
            self.learned = json.loads(learned_path.read_text(encoding="utf-8"))
        except Exception:
            self.learned = {}

    def save(self):
        with self.lock:
            try:
                self.path.write_text(json.dumps(self.learned, indent=1, sort_keys=True), encoding="utf-8")
            except Exception as e:
                log.warning("[ACTIVITY] could not save what was learned: %s", e)

    def learn(self, scen: str, male: bool, ok: bool):
        k = f"{scen}|{'m' if male else 'f'}"
        with self.lock:
            e = self.learned.setdefault(k, {"ok": 0, "fail": 0})
            e["ok" if ok else "fail"] += 1
            e["t"] = int(time.time())
        log.info("[ACTIVITY] learned: %s (%s) %s -> %s", scen, "male" if male else "female", "WORKS" if ok else "broken", e)
        self.save()

    def score(self, scen: str, cons: list[str], male: bool, sitting_ok: bool) -> float:
        name = scen
        sc = 0.0
        for c in cons:
            keys = CONCEPTS.get(c, [c.upper()])
            if any(has(name, k) for k in keys):
                sc += 10 if c not in ("sit", "lean") else 6
            elif any(has(name, k) for k in ALT.get(c, [])):
                sc += 5
            else:
                sc -= 7          # every concept asked for that this scenario lacks
        if sc <= 0:
            return -1
        for c, keys in EXTRA_KEYS.items():       # doing something nobody asked for (sit -> sit AND play guitar)
            if c not in cons and any(has(name, k) for k in keys):
                sc -= 3
        if ("_FEMALE" in name and male) or (("_MALE" in name) and "_FEMALE" not in name and not male):
            return -1
        is_sit = any(has(name, w) for w in SIT_WORDS)
        if is_sit and not sitting_ok:
            sc -= 8
        if name.startswith("WORLD_HUMAN_"):
            sc += 4
        if "BARTENDER" in name and "bartend" not in cons:
            sc -= 9               # 0.5.1: "have a beer" is not "work behind the bar" (it never plays outside one)
        if any(f in name for f in FURNITURE):
            sc -= 5               # needs a chair/bar/railing that might not be there
        sc -= name.count("_") * 0.3          # simpler = more general
        e = self.learned.get(f"{scen}|{'m' if male else 'f'}", {})
        if e.get("fail", 0) and not e.get("ok", 0):
            sc -= 12 * e["fail"]
        sc += min(6, 2 * e.get("ok", 0)) - 3 * max(0, e.get("fail", 0) - e.get("ok", 0))
        return sc

    def candidates(self, what: str, male: bool, limit: int = 4) -> tuple[list[str], list[str]]:
        cons = concepts_of(what)
        if not cons:
            return [], []
        for g, specific in GENERIC.items():
            if g in cons and any(x in cons for x in specific):
                cons.remove(g)
        sitting_ok = any(c in cons for c in ("sit", "sleep", "rest", "guitar", "banjo", "mandolin", "fiddle", "concertina",
                                              "harmonica", "jaw harp", "music", "read", "sketch", "whittle", "eat"))
        ranked = sorted(((self.score(s, cons, male, sitting_ok), s) for s in self.all), reverse=True)
        out = [s for sc, s in ranked if sc > 0][:limit]
        return out, cons

    def emote_for(self, cons: list[str]):
        for c in cons:
            if c in EMOTE_FALLBACK:
                return EMOTE_FALLBACK[c]
        return None

    def wants_furniture(self, cons: list[str], what: str) -> bool:
        w = what.lower()
        return any(k in w for k in ("bench", "chair", "stool", "table", "bar", "porch", "railing", "fire", "wall", " bed", "cot",
                                    "bedroll", "mattress"))
